# Football Analyzer 3.0 — open-matchday

A clean Android rebuild using **open-matchday** CSV data only. No API key, account, subscription, or API.SH/API-Football connection is used.

## Data source
- https://github.com/oladeeayo/open-matchday
- Raw CSV files: `https://raw.githubusercontent.com/oladeeayo/open-matchday/master/data/<competition>/fixtures_2627.csv` and `results_2627.csv`
- Daily refresh, not live. Data is for personal, informational, non-commercial use; attribution to open-matchday is shown in the app and required by the source project.

## Supported competitions in this build
UEFA Champions League, Europa League and Conference League; selected national leagues including England, Spain, Germany, Italy, France, Netherlands, Portugal, Belgium, Turkey, Greece, Russia and Ukraine. The repository currently does **not** list UEFA Nations League, Russian First League, Russian Cup or Ukrainian Cup, so those are not shown as falsely supported.

## Important data limitations
- Fixtures/results update daily, not in real time.
- Detailed stats (corners, cards, shots, fouls) are only populated for some competitions and matches. Blank means unavailable, not zero.
- No bookmaker odds, xG, lineups, injuries or live scores are supplied by this source.
- This compilation is for non-commercial informational use. See upstream README and DISCLAIMER.

## Build
Push to `main` or run the GitHub Actions workflow `Build Football Analyzer 3`; download `FootballAnalyzer3-APK` from the workflow artifacts. This archive is source code; an APK is not included.
