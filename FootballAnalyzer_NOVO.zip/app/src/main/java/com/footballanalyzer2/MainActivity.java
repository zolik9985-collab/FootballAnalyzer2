package com.footballanalyzer2;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.AlertDialog;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.widget.*;
import android.content.SharedPreferences;
import java.net.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;
import org.json.*;

public class MainActivity extends Activity {
    private static final String RAW = "https://raw.githubusercontent.com/oladeeayo/open-matchday/master/data/";
    private static final String CDN = "https://cdn.jsdelivr.net/gh/oladeeayo/open-matchday@master/data/";
    private static final String SEASON = "2627";
    private static final int BG = 0xff06120d, GREEN = 0xff35d879, PANEL = 0xff12251b, MUTED = 0xff9bb4a5;

    private static class League {
        final String title, folder;
        League(String title, String folder) { this.title = title; this.folder = folder; }
        public String toString() { return title; }
    }

    // Only competitions confirmed in the public open-matchday index are listed.
    private final League[] leagues = new League[] {
        new League("🏆 Лига чемпионов UEFA", "UEFA_1_champions-league"),
        new League("🏆 Лига Европы UEFA", "UEFA_1_europa-league"),
        new League("🏆 Лига конференций UEFA", "UEFA_1_conference-league"),
        new League("Англия · FA Cup", "ENG_CUP_fa-cup"),
        new League("Англия · EFL Cup", "ENG_CUP_efl-cup"),
        new League("Испания · Copa del Rey", "ESP_CUP_copa-del-rey"),
        new League("Италия · Coppa Italia", "ITA_CUP_coppa-italia"),
        new League("Германия · DFB-Pokal", "GER_CUP_dfb-pokal"),
        new League("Нидерланды · KNVB Beker", "NED_CUP_knvb-beker"),
        new League("Англия · Premier League", "ENG_1_premier-league"),
        new League("Испания · La Liga", "ESP_1_la-liga"),
        new League("Германия · Bundesliga", "GER_1_bundesliga"),
        new League("Италия · Serie A", "ITA_1_serie-a"),
        new League("Франция · Ligue 1", "FRA_1_ligue-1"),
        new League("Нидерланды · Eredivisie", "NED_1_eredivisie"),
        new League("Португалия · Primeira Liga", "POR_1_primeira-liga"),
        new League("Бельгия · Pro League", "BEL_1_pro-league"),
        new League("Турция · Süper Lig", "TUR_1_super-lig"),
        new League("Греция · Super League", "GRE_1_super-league"),
        new League("Россия · Премьер-лига", "RUS_1_premier-liga"),
        new League("Украина · Премьер-лига", "UKR_1_premier-league"),
        new League("Норвегия · Eliteserien", "NOR_1_eliteserien"),
        new League("Шотландия · Premiership", "SCO_1_premiership"),
        new League("Польша · Ekstraklasa", "POL_1_ekstraklasa")
    };

    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final Handler ui = new Handler(Looper.getMainLooper());
    private LinearLayout root, cards;
    private TextView status, selectedDateText;
    private Spinner leagueSpinner;
    private int selectedLeague = 0;
    private String mode = "today";
    private String chosenDate;
    private boolean dateWasChosen = false;

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density); }
    private GradientDrawable shape(int color, int radius) { GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d; }
    private TextView label(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(null, Typeface.BOLD); return t;
    }
    private LinearLayout.LayoutParams lp(int top, int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.setMargins(0, dp(top), 0, dp(bottom)); return p;
    }
    private Button button(String s) {
        Button b = new Button(this); b.setText(s); b.setAllCaps(false); b.setTextColor(BG); b.setTextSize(16); b.setTypeface(null, Typeface.BOLD); b.setBackground(shape(GREEN, 13)); return b;
    }
    private String today() { return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date()); }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG);
        chosenDate = today();
        buildUi();
        loadFixtures();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(22), dp(18), dp(28)); root.setBackgroundColor(BG);
        scroll.addView(root); setContentView(scroll);

        root.addView(label("⚽ FOOTBALL ANALYZER 3", 25, GREEN, true));
        root.addView(label("Матчи и статистика сезона 2026/27", 14, 0xffb8c9bf, true), lp(4, 16));

        Button history = button("📅 ИСТОРИЯ СОХРАНЁННЫХ ПРОГНОЗОВ"); root.addView(history, lp(0, 8));
        history.setOnClickListener(v -> showHistory());

        root.addView(label("ВЫБЕРИ ТУРНИР", 15, GREEN, true), lp(4, 6));
        leagueSpinner = new Spinner(this);
        ArrayAdapter<League> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, leagues);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        leagueSpinner.setAdapter(adapter); leagueSpinner.setBackground(shape(PANEL, 12)); root.addView(leagueSpinner, lp(0, 12));

        LinearLayout modes = new LinearLayout(this);
        String[][] choices = {{"Сегодня", "today"}, {"Завтра", "tomorrow"}, {"Все матчи", "all"}};
        for (String[] c : choices) {
            Button b = button(c[0]); LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(48), 1); p.setMargins(dp(2), 0, dp(2), 0); modes.addView(b, p);
            b.setOnClickListener(v -> { mode = c[1]; dateWasChosen = false; loadFixtures(); });
        }
        root.addView(modes, lp(0, 8));

        Button date = button("📅 ВЫБРАТЬ ДАТУ"); root.addView(date, lp(0, 8));
        selectedDateText = label("Дата: " + chosenDate, 15, Color.WHITE, true); root.addView(selectedDateText, lp(0, 12));
        date.setOnClickListener(v -> openDatePicker());

        Button refresh = button("ОБНОВИТЬ МАТЧИ"); root.addView(refresh, lp(0, 8)); refresh.setOnClickListener(v -> loadFixtures());
        status = label("Подключаюсь к бесплатному источнику…", 14, 0xffc3d2c9, false); root.addView(status, lp(0, 10));
        cards = new LinearLayout(this); cards.setOrientation(LinearLayout.VERTICAL); root.addView(cards);
        root.addView(label("Источник: open-matchday · GitHub CSV. Обновление примерно раз в сутки, не live. API-ключ не нужен. Данные для личного некоммерческого использования.", 12, 0xff879b8e, false), lp(18, 0));

        leagueSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onNothingSelected(android.widget.AdapterView<?> parent) {}
            public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) { selectedLeague = position; loadFixtures(); }
        });
    }

    private void openDatePicker() {
        Calendar c = Calendar.getInstance();
        try { c.setTime(new SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(chosenDate)); } catch (Exception ignored) {}
        DatePickerDialog dlg = new DatePickerDialog(this, (picker, y, m, d) -> {
            Calendar picked = Calendar.getInstance(); picked.set(y, m, d);
            chosenDate = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(picked.getTime());
            dateWasChosen = true; mode = "custom"; selectedDateText.setText("Дата: " + chosenDate); loadFixtures();
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH));
        dlg.show();
    }

    private String fetchWithFallback(String path) throws Exception {
        Exception last = null;
        for (String base : new String[]{RAW, CDN}) {
            HttpURLConnection conn = null;
            try {
                URL url = new URL(base + path);
                conn = (HttpURLConnection) url.openConnection();
                conn.setConnectTimeout(12000); conn.setReadTimeout(18000);
                conn.setRequestProperty("User-Agent", "FootballAnalyzer3/3.0");
                conn.setRequestProperty("Accept", "text/csv,*/*");
                int code = conn.getResponseCode();
                InputStream in = (code >= 200 && code < 300) ? conn.getInputStream() : conn.getErrorStream();
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                if (in != null) { try (InputStream stream = in) { byte[] buf = new byte[8192]; int n; while ((n = stream.read(buf)) != -1) out.write(buf, 0, n); } }
                String body = out.toString("UTF-8");
                if (code == 404) throw new FileNotFoundException("Для этого турнира файл пока не опубликован: " + path);
                if (code < 200 || code >= 300) throw new IOException("HTTP " + code + " при загрузке CSV");
                if (body.trim().isEmpty()) throw new IOException("Источник вернул пустой CSV: " + path);
                return body;
            } catch (Exception e) { last = e; }
            finally { if (conn != null) conn.disconnect(); }
        }
        throw last == null ? new IOException("Не удалось подключиться к open-matchday") : last;
    }

    private List<String[]> parseCsv(String csv) throws IOException {
        List<String[]> rows = new ArrayList<>();
        BufferedReader reader = new BufferedReader(new StringReader(csv));
        String line;
        while ((line = reader.readLine()) != null) {
            if (line.trim().isEmpty()) continue;
            ArrayList<String> cells = new ArrayList<>(); StringBuilder cell = new StringBuilder(); boolean quoted = false;
            for (int i = 0; i < line.length(); i++) {
                char ch = line.charAt(i);
                if (ch == '"') {
                    if (quoted && i + 1 < line.length() && line.charAt(i + 1) == '"') { cell.append('"'); i++; }
                    else quoted = !quoted;
                } else if (ch == ',' && !quoted) { cells.add(cell.toString()); cell.setLength(0); }
                else cell.append(ch);
            }
            cells.add(cell.toString()); rows.add(cells.toArray(new String[0]));
        }
        return rows;
    }

    private Map<String, Integer> headerIndex(String[] header) {
        Map<String, Integer> map = new HashMap<>();
        for (int i = 0; i < header.length; i++) map.put(header[i].trim().toLowerCase(Locale.US), i);
        return map;
    }
    private String val(String[] row, Map<String, Integer> ix, String key) {
        Integer i = ix.get(key.toLowerCase(Locale.US)); return i == null || i < 0 || i >= row.length ? "" : row[i].trim();
    }
    private Double number(String[] row, Map<String, Integer> ix, String key) {
        try { String s = val(row, ix, key); return s.isEmpty() ? null : Double.parseDouble(s); } catch (Exception e) { return null; }
    }

    private void loadFixtures() {
        if (status == null || cards == null) return;
        final League league = leagues[selectedLeague]; final String selectedMode = mode; final String date = chosenDate;
        status.setText("Загружаю CSV: " + league.title + "…"); cards.removeAllViews();
        worker.execute(() -> {
            try {
                String folder = league.folder + "/";
                List<String[]> fixtures = parseCsv(fetchWithFallback(folder + "fixtures_" + SEASON + ".csv"));
                List<String[]> results;
                try { results = parseCsv(fetchWithFallback(folder + "results_" + SEASON + ".csv")); }
                catch (Exception unavailable) { results = new ArrayList<>(); }
                if (fixtures.isEmpty()) throw new IOException("CSV расписания не содержит заголовка и матчей.");
                Map<String, Integer> fixIx = headerIndex(fixtures.get(0));
                if (!fixIx.containsKey("date") || !fixIx.containsKey("home") || !fixIx.containsKey("away")) throw new IOException("Неожиданный формат CSV расписания.");
                String target = date;
                if (selectedMode.equals("today")) target = today();
                else if (selectedMode.equals("tomorrow")) { Calendar cal = Calendar.getInstance(); cal.add(Calendar.DAY_OF_YEAR, 1); target = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.getTime()); }
                final String filterDate = target;
                List<String[]> found = new ArrayList<>();
                for (int i = 1; i < fixtures.size(); i++) {
                    String[] row = fixtures.get(i); String rowDate = val(row, fixIx, "date");
                    if (selectedMode.equals("all") || rowDate.equals(filterDate)) found.add(row);
                }
                found.sort((a,b) -> (val(a,fixIx,"date") + val(a,fixIx,"time")).compareTo(val(b,fixIx,"date") + val(b,fixIx,"time")));
                List<String[]> finalResults = results; int fixtureCount = fixtures.size() - 1; int resultCount = Math.max(0, results.size() - 1);
                ui.post(() -> renderMatches(league, found, finalResults, fixIx, filterDate, selectedMode, fixtureCount, resultCount));
            } catch (Exception e) {
                String message = e.getMessage() == null ? e.toString() : e.getMessage();
                ui.post(() -> { status.setText("Ошибка open-matchday: " + message); cards.removeAllViews(); });
            }
        });
    }

    private void renderMatches(League league, List<String[]> found, List<String[]> results, Map<String,Integer> fixIx,
                               String date, String selectedMode, int fixtureCount, int resultCount) {
        status.setText("open-matchday · расписание: " + fixtureCount + " · сыграно: " + resultCount + " · найдено: " + found.size());
        if (found.isEmpty()) {
            String msg = selectedMode.equals("all") ? "В опубликованном файле расписания пока нет будущих матчей." : "На " + date + " матчей в опубликованном расписании этого турнира нет. Это не ошибка API.";
            cards.addView(label(msg, 15, Color.WHITE, true), lp(8, 8));
            return;
        }
        for (String[] row : found) addMatchCard(league, row, fixIx, results);
    }

    private void addMatchCard(League league, String[] match, Map<String,Integer> fixIx, List<String[]> resultRows) {
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(14),dp(13),dp(14),dp(13)); box.setBackground(shape(PANEL,15)); cards.addView(box,lp(0,10));
        String date = val(match,fixIx,"date"), time = val(match,fixIx,"time"), home = val(match,fixIx,"home"), away = val(match,fixIx,"away"), round = val(match,fixIx,"gw");
        box.addView(label(date + (time.isEmpty()?"":" · "+time) + (round.isEmpty()?"":" · тур "+round),12,MUTED,true));
        box.addView(label(home + " — " + away,18,Color.WHITE,true),lp(5,8));
        Button analyze = button("📊 АНАЛИЗ ПОСЛЕДНИХ МАТЧЕЙ"); box.addView(analyze);
        TextView report = label("",13,0xffd9e7de,false); box.addView(report,lp(7,0));
        analyze.setOnClickListener(v -> {
            analyze.setEnabled(false); report.setText("Анализирую доступную историю…");
            worker.execute(() -> { String text = makeReport(home, away, resultRows); ui.post(() -> { report.setText(text); analyze.setEnabled(true); }); });
        });
        Button save = button("СОХРАНИТЬ МАТЧ В ИСТОРИЮ"); box.addView(save,lp(7,0));
        save.setOnClickListener(v -> { saveHistory(date + " · " + league.title + "\n" + home + " — " + away); Toast.makeText(this,"Матч сохранён в историю",Toast.LENGTH_SHORT).show(); });
    }

    private String makeReport(String home, String away, List<String[]> rows) {
        if (rows == null || rows.size() < 2) return "Нет файла с результатами для анализа. Расписание доступно, но история этой лиги пока не опубликована.";
        Map<String,Integer> ix = headerIndex(rows.get(0));
        String[] metrics = {"голы", "угловые", "жёлтые карточки", "удары в створ", "фолы"};
        String[] homeCols = {"ft_home", "home_corners", "home_yellow", "home_target", "home_fouls"};
        String[] awayCols = {"ft_away", "away_corners", "away_yellow", "away_target", "away_fouls"};
        StringBuilder out = new StringBuilder("ИСТОРИЯ ПОСЛЕДНИХ МАТЧЕЙ\n");
        for (int k=0;k<metrics.length;k++) {
            ArrayList<Double> h = new ArrayList<>(), a = new ArrayList<>();
            for (int i=rows.size()-1;i>=1;i--) {
                String[] r=rows.get(i); String rh=val(r,ix,"home"), ra=val(r,ix,"away");
                if (home.equalsIgnoreCase(rh) || home.equalsIgnoreCase(ra)) {
                    Double x=number(r,ix,homeCols[k]), y=number(r,ix,awayCols[k]);
                    if (x!=null && y!=null) h.add(home.equalsIgnoreCase(rh)?x:y);
                }
                if (away.equalsIgnoreCase(rh) || away.equalsIgnoreCase(ra)) {
                    Double x=number(r,ix,awayCols[k]), y=number(r,ix,homeCols[k]);
                    if (x!=null && y!=null) a.add(away.equalsIgnoreCase(rh)?x:y);
                }
                if (h.size()>=8 && a.size()>=8) break;
            }
            out.append("\n").append(metrics[k]).append(": ").append(home).append(" — ").append(avg(h)).append(" (n=").append(h.size()).append("), ").append(away).append(" — ").append(avg(a)).append(" (n=").append(a.size()).append(")");
            if (h.isEmpty() && a.isEmpty()) out.append(" · нет данных");
        }
        out.append("\n\nПустые значения в источнике означают, что статистика недоступна, а не ноль. История ограничена опубликованными матчами сезона.");
        return out.toString();
    }
    private String avg(List<Double> a) { if(a.isEmpty()) return "нет данных"; double s=0; for(double v:a)s+=v; return String.format(Locale.US,"%.1f",s/a.size()); }

    private void saveHistory(String item) {
        SharedPreferences p = getSharedPreferences("football_history", MODE_PRIVATE);
        try { JSONArray arr = new JSONArray(p.getString("items","[]")); arr.put(0,item); while(arr.length()>100) arr.remove(arr.length()-1); p.edit().putString("items",arr.toString()).apply(); }
        catch(Exception e) { p.edit().putString("items",new JSONArray().put(item).toString()).apply(); }
    }
    private void showHistory() {
        SharedPreferences p = getSharedPreferences("football_history", MODE_PRIVATE);
        try {
            JSONArray arr = new JSONArray(p.getString("items","[]"));
            if(arr.length()==0) { new AlertDialog.Builder(this).setTitle("История").setMessage("Пока нет сохранённых матчей.").setPositiveButton("OK",null).show(); return; }
            String[] items = new String[arr.length()]; for(int i=0;i<arr.length();i++) items[i]=arr.optString(i);
            new AlertDialog.Builder(this).setTitle("Сохранённые матчи").setItems(items,null).setPositiveButton("Закрыть",null).setNeutralButton("Очистить",(d,w)->p.edit().remove("items").apply()).show();
        } catch(Exception e) { new AlertDialog.Builder(this).setTitle("История").setMessage("Не удалось прочитать историю.").setPositiveButton("OK",null).show(); }
    }

    @Override protected void onDestroy() { super.onDestroy(); worker.shutdownNow(); }
}
