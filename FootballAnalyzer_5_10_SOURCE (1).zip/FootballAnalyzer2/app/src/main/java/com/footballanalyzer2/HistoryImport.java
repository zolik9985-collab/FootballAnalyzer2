package com.footballanalyzer2;

import java.text.Normalizer;
import java.util.*;

/**
 * История прошлых сезонов из football-data.co.uk (угловые, карточки, удары, фолы) в формате open-matchday.
 * Чистая Java: сопоставление названий команд, перевод дат и строк. Загрузка файлов — в MainActivity.
 */
final class HistoryImport {
    private HistoryImport() {}

    /** Папка open-matchday -> код дивизиона football-data.co.uk. */
    static final String[][] DIVS = {
        {"ENG_1_premier-league", "E0"}, {"ENG_2_championship", "E1"}, {"ENG_3_league-one", "E2"}, {"ENG_4_league-two", "E3"}, {"ENG_5_national-league", "EC"},
        {"SCO_1_premiership", "SC0"}, {"SCO_2_championship", "SC1"}, {"SCO_3_league-one", "SC2"}, {"SCO_4_league-two", "SC3"},
        {"GER_1_bundesliga", "D1"}, {"GER_2_2-bundesliga", "D2"}, {"ITA_1_serie-a", "I1"}, {"ITA_2_serie-b", "I2"},
        {"ESP_1_la-liga", "SP1"}, {"ESP_2_segunda-division", "SP2"}, {"FRA_1_ligue-1", "F1"}, {"FRA_2_ligue-2", "F2"},
        {"NED_1_eredivisie", "N1"}, {"BEL_1_pro-league", "B1"}, {"POR_1_primeira-liga", "P1"}, {"TUR_1_super-lig", "T1"}, {"GRE_1_super-league", "G1"}
    };

    static String divisionFor(String folder) {
        for (String[] d : DIVS) if (d[0].equals(folder)) return d[1];
        return null;
    }

    /** "2627", 1 -> "2526". */
    static String prevSeason(String code, int back) {
        try {
            int a = Integer.parseInt(code.substring(0, 2)) - back, b = Integer.parseInt(code.substring(2, 4)) - back;
            if (a < 0 || b < 0) return null;
            return String.format(Locale.US, "%02d%02d", a, b);
        } catch (Exception e) { return null; }
    }

    // ---------------- названия команд ----------------
    private static final Set<String> STOP = new HashSet<>(Arrays.asList(
        "fc", "cf", "ac", "as", "sc", "sv", "vfb", "vfl", "fsv", "tsg", "ca", "cd", "ud", "rcd", "rc", "ssc", "afc", "bsc", "kv", "kvc", "kaa", "krc", "ksc", "kfc",
        "ksv", "club", "de", "da", "do", "del", "di", "la", "le", "les", "el", "the", "royal", "1", "r"));

    private static final Map<String, String> ALIAS = new HashMap<>();
    static {
        String[][] a = {
            {"man united", "manchester united"}, {"man utd", "manchester united"}, {"man city", "manchester city"},
            {"spurs", "tottenham"}, {"nottm forest", "nottingham forest"}, {"wolves", "wolverhampton"},
            {"ath bilbao", "athletic bilbao"}, {"athletic club", "athletic bilbao"}, {"ath madrid", "atletico madrid"},
            {"sociedad", "real sociedad"}, {"vallecano", "rayo vallecano"}, {"betis", "real betis"}, {"espanol", "espanyol"},
            {"ein frankfurt", "eintracht frankfurt"}, {"mgladbach", "monchengladbach"}, {"bayern munich", "bayern munchen"},
            {"inter", "internazionale"}, {"paris sg", "paris saint germain"}, {"hearts", "heart of midlothian"},
            {"verona", "hellas verona"}, {"st etienne", "saint etienne"}, {"olympiakos", "olympiacos"},
            {"sp lisbon", "sporting cp"}, {"guimaraes", "vitoria guimaraes"}, {"st truiden", "sint truidense"},
            {"union sg", "union st gilloise"}, {"oh leuven", "oud heverlee leuven"}, {"oud heverlee leuven", "oud heverlee leuven"},
            {"psg", "paris saint germain"}, {"leeds united", "leeds"}, {"sheffield weds", "sheffield wednesday"},
            {"nijmegen", "nec nijmegen"}, {"for sittard", "fortuna sittard"}, {"fortuna sittard", "fortuna sittard"}
        };
        for (String[] e : a) ALIAS.put(e[0], e[1]);
    }

    static String stripAccents(String s) {
        String n = Normalizer.normalize(s, Normalizer.Form.NFD);
        return n.replaceAll("\\p{M}+", "").replace("ß", "ss").replace("ø", "o").replace("æ", "ae");
    }

    private static String basic(String name) {
        String s = stripAccents(name == null ? "" : name).toLowerCase(Locale.ROOT);
        s = s.replace(".", "").replace("'", "").replace("’", "").replace("`", "");
        s = s.replaceAll("[^a-z0-9]+", " ").trim();
        s = s.replace("munich", "munchen").replace("rennais", "rennes");
        return s;
    }

    static Set<String> tokens(String name) {
        String b = basic(name);
        String aliased = ALIAS.get(b);
        if (aliased != null) b = aliased;
        Set<String> out = new LinkedHashSet<>();
        for (String t : b.split(" ")) {
            if (t.isEmpty() || STOP.contains(t) || t.matches("[0-9]+")) continue;
            out.add(t);
        }
        return out;
    }

    private static boolean prefixMatch(String x, String y) {
        int m = Math.min(x.length(), y.length());
        return m >= 4 && (x.startsWith(y) || y.startsWith(x));
    }

    /** 3 — равны, 2+ — все слова короткого названия есть в длинном, 1+ — совпадение по началу слов, 0 — нет. */
    static double similarity(String a, String b) {
        Set<String> x = tokens(a), y = tokens(b);
        if (x.isEmpty() || y.isEmpty()) return 0;
        if (x.equals(y)) return 3.0;
        Set<String> small = x.size() <= y.size() ? x : y, big = small == x ? y : x;
        if (big.containsAll(small)) return 2.0 + (double) small.size() / big.size();
        int hit = 0;
        for (String t : small) {
            boolean found = false;
            for (String u : big) if (t.equals(u) || prefixMatch(t, u)) { found = true; break; }
            if (found) hit++;
        }
        return hit == small.size() ? 1.0 + (double) small.size() / big.size() : 0;
    }

    /** Названия football-data -> названия open-matchday. Неоднозначные совпадения пропускаются. */
    static Map<String, String> mapNames(Collection<String> targetNames, Collection<String> sourceNames) {
        Map<String, String> result = new HashMap<>();
        Map<String, Double> best = new HashMap<>();
        for (String f : sourceNames) {
            String bestT = null; double s1 = 0, s2 = 0;
            for (String t : targetNames) {
                double s = similarity(f, t);
                if (s > s1) { s2 = s1; s1 = s; bestT = t; } else if (s > s2) s2 = s;
            }
            if (bestT == null || s1 < 1.0 || s1 - s2 < 0.15) continue;          // нет совпадения или оно неоднозначно
            Double prev = best.get(bestT);
            if (prev == null || s1 > prev) {                                     // одна команда — один источник
                for (Iterator<Map.Entry<String, String>> it = result.entrySet().iterator(); it.hasNext(); ) if (it.next().getValue().equals(bestT)) it.remove();
                result.put(f, bestT); best.put(bestT, s1);
            }
        }
        return result;
    }

    // ---------------- строки ----------------
    /** dd/mm/yyyy или dd/mm/yy -> yyyy-MM-dd; null если не разобрать. */
    static String isoDate(String d) {
        if (d == null) return null;
        String[] p = d.trim().split("/");
        if (p.length != 3) return null;
        try {
            int day = Integer.parseInt(p[0]), mon = Integer.parseInt(p[1]), year = Integer.parseInt(p[2]);
            if (year < 100) year += 2000;
            if (day < 1 || day > 31 || mon < 1 || mon > 12) return null;
            return String.format(Locale.US, "%04d-%02d-%02d", year, mon, day);
        } catch (NumberFormatException e) { return null; }
    }

    private static final String[][] COLS = {
        {"HS", "home_shots"}, {"AS", "away_shots"}, {"HST", "home_target"}, {"AST", "away_target"}, {"HF", "home_fouls"}, {"AF", "away_fouls"},
        {"HC", "home_corners"}, {"AC", "away_corners"}, {"HY", "home_yellow"}, {"AY", "away_yellow"}, {"HR", "home_red"}, {"AR", "away_red"}};

    static Map<String, Integer> index(String[] header) {
        Map<String, Integer> m = new HashMap<>();
        for (int i = 0; i < header.length; i++) {
            String h = header[i].trim();
            if (i == 0 && h.startsWith("﻿")) h = h.substring(1);
            m.put(h.toLowerCase(Locale.ROOT), i);
        }
        return m;
    }

    /** Имена команд всех строк football-data. */
    static Set<String> teamNames(List<String[]> fd) {
        Set<String> s = new TreeSet<>();
        if (fd.isEmpty()) return s;
        Map<String, Integer> ix = index(fd.get(0));
        Integer h = ix.get("hometeam"), a = ix.get("awayteam");
        if (h == null || a == null) return s;
        for (int i = 1; i < fd.size(); i++) { String[] r = fd.get(i); if (h < r.length) s.add(r[h].trim()); if (a < r.length) s.add(r[a].trim()); }
        s.remove("");
        return s;
    }

    /**
     * Строки football-data -> строки в колонках outHeader (формат open-matchday).
     * Пропускаются матчи без результата и без даты. Показатели, которых нет в файле, остаются пустыми (не нулями).
     */
    static List<String[]> convert(List<String[]> fd, String[] outHeader, Map<String, String> nameMap) {
        List<String[]> out = new ArrayList<>();
        if (fd.isEmpty()) return out;
        Map<String, Integer> in = index(fd.get(0)), oi = index(outHeader);
        Integer iDate = in.get("date"), iH = in.get("hometeam"), iA = in.get("awayteam"), iFh = in.get("fthg"), iFa = in.get("ftag");
        if (iDate == null || iH == null || iA == null || iFh == null || iFa == null) return out;
        for (String need : new String[]{"date", "home", "away", "ft_home", "ft_away"}) if (!oi.containsKey(need)) return out;
        for (int i = 1; i < fd.size(); i++) {
            String[] r = fd.get(i);
            if (r.length <= Math.max(Math.max(iDate, iH), Math.max(iA, Math.max(iFh, iFa)))) continue;
            String date = isoDate(r[iDate]);
            String fh = r[iFh].trim(), fa = r[iFa].trim();
            if (date == null || fh.isEmpty() || fa.isEmpty()) continue;
            try { Integer.parseInt(fh); Integer.parseInt(fa); } catch (NumberFormatException e) { continue; }
            String[] o = new String[outHeader.length];
            Arrays.fill(o, "");
            String home = r[iH].trim(), away = r[iA].trim();
            o[oi.get("date")] = date;
            o[oi.get("home")] = nameMap.containsKey(home) ? nameMap.get(home) : home;
            o[oi.get("away")] = nameMap.containsKey(away) ? nameMap.get(away) : away;
            o[oi.get("ft_home")] = fh; o[oi.get("ft_away")] = fa;
            for (String[] c : COLS) {
                Integer s = in.get(c[0].toLowerCase(Locale.ROOT)), d = oi.get(c[1]);
                if (s != null && d != null && s < r.length && !r[s].trim().isEmpty()) o[d] = r[s].trim();
            }
            Integer src = oi.get("source");
            if (src != null) o[src] = "football-data";
            out.add(o);
        }
        return out;
    }
}
