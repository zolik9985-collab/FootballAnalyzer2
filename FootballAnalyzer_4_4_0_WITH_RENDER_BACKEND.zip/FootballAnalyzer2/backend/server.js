const http = require("http");
const https = require("https");
const { URL } = require("url");

const PORT = Number(process.env.PORT || 10000);
const API_KEY = (process.env.API_SH_KEY || "").trim();
const cache = new Map();
const CACHE_TTL_MS = 60 * 1000;
const MAX_BODY = 1024 * 1024;

function send(res, status, body, extra = {}) {
  res.writeHead(status, {
    "content-type": "application/json; charset=utf-8",
    "access-control-allow-origin": "*",
    "access-control-allow-methods": "GET, OPTIONS",
    "access-control-allow-headers": "Content-Type",
    ...extra
  });
  res.end(JSON.stringify(body));
}

function proxy(path, res) {
  if (!API_KEY) return send(res, 503, { error: "API_SH_KEY is not configured on the server" });

  const cached = cache.get(path);
  if (cached && Date.now() - cached.time < CACHE_TTL_MS) {
    return send(res, 200, cached.body, { "x-cache": "HIT" });
  }

  const request = https.request({
    hostname: "api.api.sh",
    path,
    method: "GET",
    headers: { "x-api-key": API_KEY, "accept": "application/json" },
    timeout: 25000
  }, upstream => {
    let raw = "";
    upstream.setEncoding("utf8");
    upstream.on("data", chunk => {
      raw += chunk;
      if (raw.length > MAX_BODY) request.destroy(new Error("Upstream response too large"));
    });
    upstream.on("end", () => {
      let data;
      try { data = JSON.parse(raw); }
      catch { return send(res, 502, { error: "Invalid JSON response from API provider" }); }

      if (upstream.statusCode < 200 || upstream.statusCode >= 300) {
        return send(res, upstream.statusCode || 502, {
          error: "API provider returned an error",
          provider_status: upstream.statusCode,
          details: data
        });
      }
      cache.set(path, { time: Date.now(), body: data });
      send(res, 200, data, { "x-cache": "MISS" });
    });
  });

  request.on("timeout", () => request.destroy(new Error("Upstream timeout")));
  request.on("error", err => send(res, 502, { error: "Provider connection failed", details: err.message }));
  request.end();
}

const server = http.createServer((req, res) => {
  if (req.method === "OPTIONS") return send(res, 204, {});
  const url = new URL(req.url, `http://${req.headers.host || "localhost"}`);

  if (req.method === "GET" && url.pathname === "/health") {
    return send(res, 200, { ok: true, service: "FootballAnalyzer2 backend", api_key_configured: Boolean(API_KEY) });
  }

  if (req.method !== "GET") return send(res, 405, { error: "Method not allowed" });

  // Only expose the two read-only API.SH endpoints currently used by the Android app.
  if (url.pathname === "/flashscore/v1/matches") {
    const sport = url.searchParams.get("sport");
    const date = url.searchParams.get("date");
    if (!["football", "hockey"].includes(sport) || !date || !/^\d{4}-\d{2}-\d{2}$/.test(date)) {
      return send(res, 400, { error: "Expected sport=football|hockey and date=YYYY-MM-DD" });
    }
    return proxy(`/flashscore/v1/matches?sport=${encodeURIComponent(sport)}&date=${encodeURIComponent(date)}`, res);
  }

  if (url.pathname === "/flashscore/v1/match/statistics") {
    const matchId = url.searchParams.get("match_id");
    if (!matchId || matchId.length > 160 || !/^[a-zA-Z0-9_-]+$/.test(matchId)) {
      return send(res, 400, { error: "A valid match_id is required" });
    }
    return proxy(`/flashscore/v1/match/statistics?match_id=${encodeURIComponent(matchId)}`, res);
  }

  return send(res, 404, { error: "Route not found" });
});

server.listen(PORT, "0.0.0.0", () => {
  console.log(`FootballAnalyzer2 backend listening on ${PORT}`);
});
