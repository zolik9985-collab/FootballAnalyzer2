# FootballAnalyzer2 backend

Deploy this directory as a Render Web Service using Docker.

- Root Directory: `backend`
- Dockerfile Path: `./Dockerfile`
- Environment variable: `API_SH_KEY` = your newly rotated API.SH key
- Health check path: `/health`

Read-only routes:
- `/flashscore/v1/matches?sport=football&date=YYYY-MM-DD`
- `/flashscore/v1/matches?sport=hockey&date=YYYY-MM-DD`
- `/flashscore/v1/match/statistics?match_id=...`

The API.SH key is read only from the server environment and is never returned by the API.
Successful GET responses are cached in memory for 60 seconds.
