const http = require("http");
const https = require("https");
const { URL } = require("url");

const PORT = Number(process.env.PORT || 10000);
const FOOTBALL_KEY = (process.env.FOOTBALLDATA_API_KEY || "").trim();
const APISH_KEY = (process.env.API_SH_KEY || "").trim();
const cache = new Map();

function send(res, status, data, headers = {}) {
  res.writeHead(status, {
    "content-type": "application/json; charset=utf-8",
    "access-control-allow-origin": "*",
    ...headers
  });
  res.end(JSON.stringify(data));
}

function requestJson(hostname, path, headers = {}) {
  return new Promise((resolve, reject) => {
    const req = https.request({
      hostname, path, method: "GET",
      headers: { accept: "application/json", ...headers },
      timeout: 25000
    }, response => {
      let raw = "";
      response.setEncoding("utf8");
      response.on("data", chunk => raw += chunk);
      response.on("end", () => {
        let body;
        try { body = JSON.parse(raw); }
        catch { return reject(new Error(`Provider returned invalid JSON (HTTP ${response.statusCode})`)); }
        if (response.statusCode < 200 || response.statusCode >= 300) {
          const detail = body && (body.error || body.message);
          return reject(new Error(`Provider HTTP ${response.statusCode}${detail ? ": " + detail : ""}`));
        }
        resolve(body);
      });
    });
    req.on("timeout", () => req.destroy(new Error("Provider timeout")));
    req.on("error", reject);
    req.end();
  });
}

async function cached(key, ttl, fn) {
  const entry = cache.get(key);
  if (entry && Date.now() - entry.time < ttl) return entry.data;
  const data = await fn();
  cache.set(key, { time: Date.now(), data });
  return data;
}

async function footballData(path, ttl = 60000) {
  if (!FOOTBALL_KEY) throw new Error("FOOTBALLDATA_API_KEY is not configured in Render");
  return cached("fd:" + path, ttl, () =>
    requestJson("footballdata.io", "/api/v1" + path, {
      authorization: `Bearer ${FOOTBALL_KEY}`
    })
  );
}

async function apiSh(path, ttl = 60000) {
  if (!APISH_KEY) throw new Error("API_SH_KEY is not configured (hockey API.SH fallback unavailable)");
  return cached("apish:" + path, ttl, () =>
    requestJson("api.api.sh", path, { "x-api-key": APISH_KEY })
  );
}

function getMatches(payload) {
  if (Array.isArray(payload?.data?.matches)) return payload.data.matches;
  if (Array.isArray(payload?.matches)) return payload.matches;
  if (Array.isArray(payload?.data)) return payload.data;
  return [];
}

function nameOf(team) {
  return team?.team_name || team?.name || team?.name_localized || "—";
}

function normalizeFixture(m) {
  const home = m.home_team || {};
  const away = m.away_team || {};
  const league = m.league || m.tournament || {};
  const score = m.score || {};
  const homeScore = score.home ?? score.home_score ?? m.home_score ?? null;
  const awayScore = score.away ?? score.away_score ?? m.away_score ?? null;
  return {
    id: String(m.match_id ?? m.id ?? ""),
    home_team: { name: nameOf(home) },
    away_team: { name: nameOf(away) },
    tournament: { name: league.competition_name || league.name || "Футбол" },
    home_score: homeScore,
    away_score: awayScore,
    status: m.status_localized || m.status || "",
    stage: m.round || m.game_week || m.status_localized || m.status || "",
    start_time: m.match_time || m.kickoff_time || m.date_time || m.match_date || "",
    minute: m.minute ?? null
  };
}

function statsToPeriods(payload) {
  const stats = payload?.data?.stats || payload?.stats || {};
  const items = [];
  const labels = {
    goals: "Голы", corners: "Угловые", yellow_cards: "Жёлтые карточки",
    red_cards: "Красные карточки", shots: "Удары", shots_on_target: "Удары в створ",
    shots_off_target: "Удары мимо", fouls: "Фолы", possession: "Владение мячом",
    xg: "xG", offsides: "Офсайды", attacks: "Атаки",
    dangerous_attacks: "Опасные атаки"
  };
  for (const [key, value] of Object.entries(stats)) {
    if (!value || typeof value !== "object" || Array.isArray(value)) continue;
    const home = value.home ?? value.home_total ?? value.home_value;
    const away = value.away ?? value.away_total ?? value.away_value;
    if (home == null && away == null) continue;
    items.push({
      name: labels[key] || key.replace(/_/g, " "),
      home: home == null ? "—" : String(home),
      away: away == null ? "—" : String(away)
    });
  }
  return {
    periods: items.length ? [{ period: "Матч", groups: [{ name: "Статистика матча", items }] }] : []
  };
}

async function handle(req, res) {
  const url = new URL(req.url, `http://${req.headers.host || "localhost"}`);
  if (req.method !== "GET") return send(res, 405, { error: "Method not allowed" });

  if (url.pathname === "/health") {
    return send(res, 200, {
      ok: true,
      service: "FootballAnalyzer2 backend",
      football_data_key_configured: !!FOOTBALL_KEY,
      api_sh_key_configured: !!APISH_KEY
    });
  }

  if (url.pathname === "/flashscore/v1/matches") {
    const sport = url.searchParams.get("sport") || "football";
    const date = url.searchParams.get("date");
    if (!["football", "hockey"].includes(sport) || !date || !/^\d{4}-\d{2}-\d{2}$/.test(date))
      return send(res, 400, { error: "Expected sport and date" });
    try {
      if (sport === "hockey") {
        const result = await apiSh(`/flashscore/v1/matches?sport=hockey&date=${encodeURIComponent(date)}`);
        return send(res, 200, result);
      }
      const result = await footballData(`/matches/date/${date}?limit=100`, 5 * 60 * 1000);
      return send(res, 200, { matches: getMatches(result).map(normalizeFixture), meta: result.meta || {} });
    } catch (error) {
      return send(res, 502, { error: error.message, provider: sport === "football" ? "Footballdata.io" : "API.SH" });
    }
  }

  if (url.pathname === "/flashscore/v1/live") {
    const sport = url.searchParams.get("sport") || "football";
    try {
      if (sport === "hockey") {
        const result = await apiSh(`/flashscore/v1/live?sport=hockey`);
        return send(res, 200, result);
      }
      const result = await footballData("/fixtures/live", 30000);
      return send(res, 200, { matches: getMatches(result).map(normalizeFixture), meta: result.meta || {} });
    } catch (error) {
      return send(res, 502, { error: error.message, provider: sport === "football" ? "Footballdata.io" : "API.SH" });
    }
  }

  if (url.pathname === "/flashscore/v1/match/statistics") {
    const id = url.searchParams.get("match_id");
    if (!id || id.length > 160 || !/^[A-Za-z0-9_-]+$/.test(id))
      return send(res, 400, { error: "Valid match_id required" });
    try {
      // FootballData.io exposes detailed football stats on the match stats endpoint.
      if (/^\d+$/.test(id) && FOOTBALL_KEY) {
        const result = await footballData(`/matches/${id}/stats`, 10 * 60 * 1000);
        return send(res, 200, statsToPeriods(result));
      }
      const result = await apiSh(`/flashscore/v1/match/statistics?match_id=${encodeURIComponent(id)}`);
      return send(res, 200, result);
    } catch (error) {
      return send(res, 502, { error: error.message });
    }
  }

  return send(res, 404, { error: "Route not found" });
}

http.createServer((req, res) => {
  handle(req, res).catch(error => send(res, 500, { error: error.message || "Internal server error" }));
}).listen(PORT, "0.0.0.0", () => console.log(`Backend listening on ${PORT}`));
