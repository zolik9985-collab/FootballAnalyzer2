package com.footballanalyzer2;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.AlertDialog;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.widget.*;
import android.media.MediaPlayer;
import android.content.SharedPreferences;
import java.net.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.text.Normalizer;
import java.util.*;
import java.util.concurrent.*;
import org.json.*;

public class MainActivity extends Activity {
    private MediaPlayer radioPlayer;
    private Button radioToggleButton;
    private TextView radioStatus;
    private static final String RAW = "https://raw.githubusercontent.com/oladeeayo/open-matchday/master/data/";
    private static final String CDN = "https://cdn.jsdelivr.net/gh/oladeeayo/open-matchday@master/data/";
    private static final String SEASON = "2627";
    private static final int BG = 0xff06120d, GREEN = 0xff35d879, PANEL = 0xff12251b, MUTED = 0xff9bb4a5;

    private static class League {
        final String title, folder;
        League(String title, String folder) { this.title = title; this.folder = folder; }
        public String toString() { return title; }
    }

    // Only competitions confirmed in the public open-matchday index are listed.
    private final League[] leagues = new League[] {
        new League("🏆 Лига чемпионов UEFA", "UEFA_1_champions-league"),
        new League("🏆 Лига Европы UEFA", "UEFA_1_europa-league"),
        new League("🏆 Лига конференций UEFA", "UEFA_1_conference-league"),
        new League("🌍 Лига наций UEFA", "UEFA_NATIONS_LEAGUE"),
        new League("Англия · FA Cup", "ENG_CUP_fa-cup"),
        new League("Англия · EFL Cup", "ENG_CUP_efl-cup"),
        new League("Испания · Copa del Rey", "ESP_CUP_copa-del-rey"),
        new League("Италия · Coppa Italia", "ITA_CUP_coppa-italia"),
        new League("Германия · DFB-Pokal", "GER_CUP_dfb-pokal"),
        new League("Нидерланды · KNVB Beker", "NED_CUP_knvb-beker"),
        new League("Англия · Premier League", "ENG_1_premier-league"),
        new League("Испания · La Liga", "ESP_1_la-liga"),
        new League("Германия · Bundesliga", "GER_1_bundesliga"),
        new League("Италия · Serie A", "ITA_1_serie-a"),
        new League("Франция · Ligue 1", "FRA_1_ligue-1"),
        new League("Нидерланды · Eredivisie", "NED_1_eredivisie"),
        new League("Португалия · Primeira Liga", "POR_1_primeira-liga"),
        new League("Бельгия · Pro League", "BEL_1_pro-league"),
        new League("Турция · Süper Lig", "TUR_1_super-lig"),
        new League("Греция · Super League", "GRE_1_super-league"),
        new League("Россия · Премьер-лига", "RUS_1_premier-liga"),
        new League("Украина · Премьер-лига", "UKR_1_premier-league"),
        new League("Норвегия · Eliteserien", "NOR_1_eliteserien"),
        new League("Шотландия · Premiership", "SCO_1_premiership"),
        new League("Польша · Ekstraklasa", "POL_1_ekstraklasa"),
        new League("Англия · Championship", "ENG_2_championship"),
        new League("Англия · League One", "ENG_3_league-one"),
        new League("Англия · League Two", "ENG_4_league-two"),
        new League("Шотландия · Championship", "SCO_2_championship"),
        new League("Шотландия · League One", "SCO_3_league-one"),
        new League("Шотландия · League Two", "SCO_4_league-two"),
        new League("Шотландия · Кубок", "SCO_CUP_scottish-cup"),
        new League("Шотландия · Кубок лиги", "SCO_CUP_league-cup"),
        new League("Португалия · Кубок", "POR_CUP_taca-de-portugal"),
        new League("Австрия · Bundesliga", "AUT_1_bundesliga"),
        new League("Австрия · Кубок", "AUT_CUP_ofb-cup"),
        new League("Швейцария · Super League", "SUI_1_super-league"),
        new League("Швейцария · Кубок", "SUI_CUP_swiss-cup"),
        new League("Дания · Superliga", "DEN_1_superliga"),
        new League("Швеция · Allsvenskan", "SWE_1_allsvenskan"),
        new League("Румыния · Liga I", "ROU_1_liga-1"),
        new League("Ирландия · First Division", "IRE_2_first-division"),
        new League("Ирландия · National League", "IRE_3_national-league"),
        new League("Польша · I Liga", "POL_2_division-1"),
        new League("Польша · II Liga", "POL_3_division-2"),
        new League("Бельгия · U21 Pro League", "BEL_U21_pro-league"),
        new League("Уэльс · Cymru Premier", "WAL_1_cymru-premier"),
        new League("Уэльс · Cymru North", "WAL_2_cymru-north"),
        new League("Уэльс · Cymru South", "WAL_3_cymru-south"),
        new League("Хорватия · HNL", "CRO_1_hnl"),
        new League("Чехия · Chance Liga", "CZE_1_chance-liga"),
        new League("Кипр · First Division", "CYP_1_first-division"),
        new League("Словакия · Nike Liga", "SVK_1_nike-liga"),
        new League("Словения · Prva Liga", "SVN_1_prva-liga"),
        new League("Финляндия · Veikkausliiga", "FIN_1_veikkausliiga"),
        new League("Казахстан · Премьер-лига", "KAZ_1_premier-league"),
        new League("Испания · Segunda División", "ESP_2_segunda-division"),
        new League("Италия · Serie B", "ITA_2_serie-b"),
        new League("Франция · Ligue 2", "FRA_2_ligue-2"),
        new League("Нидерланды · Eerste Divisie", "NED_2_eerste-divisie"),
        new League("Бразилия · Série A", "BRA_1_serie-a"),
        new League("Бразилия · Série B", "BRA_2_serie-b"),
        new League("Аргентина · Liga Profesional", "ARG_1_liga-profesional"),
        new League("Аргентина · Primera Nacional", "ARG_2_primera-nacional"),
        new League("Мексика · Liga MX", "MEX_1_liga-mx"),
        new League("Мексика · Liga de Expansión", "MEX_2_liga-expansion"),
        new League("США · MLS", "USA_1_mls"),
        new League("Япония · J1 League", "JPN_1_j1-league"),
        new League("Австралия · A-League", "AUS_1_a-league"),
        new League("Китай · Super League", "CHN_1_super-league")
    };

    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final Handler ui = new Handler(Looper.getMainLooper());
    private LinearLayout root, cards;
    private TextView status, selectedDateText;
    private Spinner leagueSpinner;
    private SharedPreferences apiPrefs;
    private EditText apiKeyField;
    private Spinner matchCountSpinner;
    private int selectedMatchCount = 5;
    private volatile String apiFootballDiagnostic = "API-Football: проверка ещё не выполнялась";
    private int selectedLeague = 0;
    private String mode = "today";
    private String chosenDate;
    private boolean dateWasChosen = false;


    private String currentLanguage() { return apiPrefs.getString("app_language", "ru"); }

    private String tr(String text) {
        String lang = currentLanguage();
        if ("ru".equals(lang)) return text;
        String[][] pairs = {
            {"🔑 НАСТРОЙКИ", "🔑 SETTINGS", "🔑 CONFIGURACIÓN", "🔑 EINSTELLUNGEN", "🔑 IMPOSTAZIONI"},
            {"Язык приложения / App language", "App language", "Idioma de la aplicación", "App-Sprache", "Lingua dell'app"},
            {"Закрыть", "Close", "Cerrar", "Schließen", "Chiudi"},
            {"Сохранить настройки", "Save settings", "Guardar ajustes", "Einstellungen speichern", "Salva impostazioni"},
            {"Ключ сохранён", "Key saved", "Clave guardada", "Schlüssel gespeichert", "Chiave salvata"},
            {"Вставь сюда API-Football ключ", "Paste API-Football key here", "Pega aquí la clave de API-Football", "API-Football-Schlüssel hier einfügen", "Incolla qui la chiave API-Football"},
            {"⚙️ НАСТРОЙКИ", "⚙️ SETTINGS", "⚙️ CONFIGURACIÓN", "⚙️ EINSTELLUNGEN", "⚙️ IMPOSTAZIONI"},
            {"Матчи · статистика open-matchday + ESPN + API-Football", "Matches · open-matchday + ESPN + API-Football stats", "Partidos · estadísticas open-matchday + ESPN + API-Football", "Spiele · open-matchday + ESPN + API-Football-Statistiken", "Partite · statistiche open-matchday + ESPN + API-Football"},
            {"📅 ИСТОРИЯ СОХРАНЁННЫХ ПРОГНОЗОВ", "📅 SAVED PREDICTIONS HISTORY", "📅 HISTORIAL DE PRONÓSTICOS", "📅 GESPEICHERTE PROGNOSEN", "📅 CRONOLOGIA PRONOSTICI"},
            {"ВЫБЕРИ ТУРНИР", "SELECT COMPETITION", "ELIGE COMPETICIÓN", "WETTBEWERB WÄHLEN", "SCEGLI COMPETIZIONE"},
            {"📊 СКОЛЬКО ПОСЛЕДНИХ МАТЧЕЙ БРАТЬ ДЛЯ СТАТИСТИКИ", "📊 NUMBER OF RECENT MATCHES FOR STATS", "📊 NÚMERO DE PARTIDOS RECIENTES", "📊 ANZAHL LETZTER SPIELE FÜR STATISTIK", "📊 NUMERO DI PARTITE RECENTI PER LE STATISTICHE"},
            {"2 матча", "2 matches", "2 partidos", "2 Spiele", "2 partite"},
            {"5 матчей", "5 matches", "5 partidos", "5 Spiele", "5 partite"},
            {"6 матчей", "6 matches", "6 partidos", "6 Spiele", "6 partite"},
            {"8 матчей", "8 matches", "8 partidos", "8 Spiele", "8 partite"},
            {"10 матчей", "10 matches", "10 partidos", "10 Spiele", "10 partite"},
            {"Сегодня", "Today", "Hoy", "Heute", "Oggi"},
            {"Завтра", "Tomorrow", "Mañana", "Morgen", "Domani"},
            {"Все матчи", "All matches", "Todos los partidos", "Alle Spiele", "Tutte le partite"},
            {"📅 ВЫБРАТЬ ДАТУ", "📅 SELECT DATE", "📅 ELEGIR FECHA", "📅 DATUM WÄHLEN", "📅 SCEGLI DATA"},
            {"ОБНОВИТЬ МАТЧИ", "REFRESH MATCHES", "ACTUALIZAR PARTIDOS", "SPIELE AKTUALISIEREN", "AGGIORNA PARTITE"},
            {"🔑 API-FOOTBALL — КЛЮЧ ДЛЯ СТАТИСТИКИ", "🔑 API-FOOTBALL — STATISTICS KEY", "🔑 API-FOOTBALL — CLAVE DE ESTADÍSTICAS", "🔑 API-FOOTBALL — STATISTIK-API-SCHLÜSSEL", "🔑 API-FOOTBALL — CHIAVE STATISTICHE"},
            {"СОХРАНИТЬ КЛЮЧ", "SAVE KEY", "GUARDAR CLAVE", "SCHLÜSSEL SPEICHERN", "SALVA CHIAVE"},
            {"ПРОВЕРИТЬ КЛЮЧ", "TEST KEY", "PROBAR CLAVE", "SCHLÜSSEL TESTEN", "VERIFICA CHIAVE"},
            {"Вставь сюда API-Football ключ", "Paste API-Football key here", "Pega aquí la clave de API-Football", "API-Football-Schlüssel hier einfügen", "Incolla qui la chiave API-Football"},
            {"ПОЛНЫЙ АНАЛИЗ И ПРОГНОЗ", "FULL ANALYSIS & PREDICTION", "ANÁLISIS Y PRONÓSTICO COMPLETO", "VOLLSTÄNDIGE ANALYSE & PROGNOSE", "ANALISI E PRONOSTICO COMPLETI"},
            {"СОХРАНИТЬ АНАЛИЗ В ИСТОРИЮ", "SAVE ANALYSIS TO HISTORY", "GUARDAR ANÁLISIS", "ANALYSE SPEICHERN", "SALVA ANALISI"},
            {"⚽ АНАЛИЗ МАТЧА", "⚽ MATCH ANALYSIS", "⚽ ANÁLISIS DEL PARTIDO", "⚽ SPIELANALYSE", "⚽ ANALISI DELLA PARTITA"},
            {"📈 1. ГОЛЫ И ФОРМА КОМАНД", "📈 1. GOALS & TEAM FORM", "📈 1. GOLES Y FORMA", "📈 1. TORE & TEAMFORM", "📈 1. GOL E FORMA"},
            {"📊 2. ДЕТАЛЬНАЯ СТАТИСТИКА ПО КОМАНДАМ", "📊 2. DETAILED TEAM STATISTICS", "📊 2. ESTADÍSTICAS DETALLADAS", "📊 2. DETAILLIERTE TEAMSTATISTIKEN", "📊 2. STATISTICHE DETTAGLIATE"},
            {"🚩 Угловые", "🚩 Corners", "🚩 Córneres", "🚩 Ecken", "🚩 Calci d'angolo"},
            {"🟨 Жёлтые карточки", "🟨 Yellow cards", "🟨 Tarjetas amarillas", "🟨 Gelbe Karten", "🟨 Cartellini gialli"},
            {"🎯 Удары в створ", "🎯 Shots on target", "🎯 Tiros a puerta", "🎯 Schüsse aufs Tor", "🎯 Tiri in porta"},
            {"🥅 Все удары по воротам", "🥅 Total shots", "🥅 Tiros totales", "🥅 Gesamtschüsse", "🥅 Tiri totali"},
            {"🤼 Фолы", "🤼 Fouls", "🤼 Faltas", "🤼 Fouls", "🤼 Falli"},
            {"нет опубликованных данных", "no published data", "sin datos publicados", "keine veröffentlichten Daten", "nessun dato pubblicato"},
            {"Сыграно матчей:", "Matches played:", "Partidos jugados:", "Gespielte Spiele:", "Partite giocate:"},
            {"Забито:", "Goals scored:", "Goles marcados:", "Erzielte Tore:", "Gol segnati:"},
            {"Пропущено:", "Goals conceded:", "Goles recibidos:", "Gegentore:", "Gol subiti:"},
            {"Результаты:", "Results:", "Resultados:", "Ergebnisse:", "Risultati:"},
            {"всего", "total", "total", "insgesamt", "totale"},
            {"за матч", "per match", "por partido", "pro Spiel", "per partita"},
            {"🔌 API-Football:", "🔌 API-Football:", "🔌 API-Football:", "🔌 API-Football:", "🔌 API-Football:"}
        };
        int index = "en".equals(lang)?1:"es".equals(lang)?2:"de".equals(lang)?3:"it".equals(lang)?4:0;
        for (String[] pair : pairs) if (text.equals(pair[0])) return pair[index];
        return text;
    }

    private String translateReport(String report) {
        if ("ru".equals(currentLanguage())) return report;
        String result = report;
        String[][] phrases = {
            {"АНАЛИЗ МАТЧА","MATCH ANALYSIS","ANÁLISIS DEL PARTIDO","SPIELANALYSE","ANALISI DELLA PARTITA"},
            {"1. ГОЛЫ И ФОРМА КОМАНД","1. GOALS & TEAM FORM","1. GOLES Y FORMA","1. TORE & TEAMFORM","1. GOL E FORMA"},
            {"2. ДЕТАЛЬНАЯ СТАТИСТИКА ПО КОМАНДАМ","2. DETAILED TEAM STATISTICS","2. ESTADÍSTICAS DETALLADAS","2. DETAILLIERTE TEAMSTATISTIKEN","2. STATISTICHE DETTAGLIATE"},
            {"Угловые","Corners","Córneres","Ecken","Calci d'angolo"},
            {"Жёлтые карточки","Yellow cards","Tarjetas amarillas","Gelbe Karten","Cartellini gialli"},
            {"Удары в створ","Shots on target","Tiros a puerta","Schüsse aufs Tor","Tiri in porta"},
            {"Все удары по воротам","Total shots","Tiros totales","Gesamtschüsse","Tiri totali"},
            {"Фолы","Fouls","Faltas","Fouls","Falli"},
            {"Сыграно матчей:","Matches played:","Partidos jugados:","Gespielte Spiele:","Partite giocate:"},
            {"Забито:","Goals scored:","Goles marcados:","Erzielte Tore:","Gol segnati:"},
            {"Пропущено:","Goals conceded:","Goles recibidos:","Gegentore:","Gol subiti:"},
            {"Результаты:","Results:","Resultados:","Ergebnisse:","Risultati:"},
            {"нет опубликованных данных","no published data","sin datos publicados","keine veröffentlichten Daten","nessun dato pubblicato"},
            {"всего","total","total","insgesamt","totale"},
            {"за матч","per match","por partido","pro Spiel","per partita"},
            {"матчей","matches","partidos","Spiele","partite"},
            {"Ошибка API-Football:","API-Football error:","Error de API-Football:","API-Football-Fehler:","Errore API-Football:"}
        };
        int index = "en".equals(currentLanguage())?1:"es".equals(currentLanguage())?2:"de".equals(currentLanguage())?3:4;
        for (String[] p : phrases) result = result.replace(p[0],p[index]);
        return result;
    }

    private void showSettings() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(18),dp(8),dp(18),dp(4));
        panel.addView(label(tr("Язык приложения / App language"),15,GREEN,true));
        Spinner language = new Spinner(this);
        String[] names = {"Русский","English","Español","Deutsch","Italiano"};
        String[] codes = {"ru","en","es","de","it"};
        ArrayAdapter<String> langAdapter = new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,names);
        langAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        language.setAdapter(langAdapter);
        String current=currentLanguage(); int selected=0;
        for(int i=0;i<codes.length;i++) if(codes[i].equals(current)) selected=i;
        language.setSelection(selected);
        panel.addView(language);

        panel.addView(label("API-Football key",15,GREEN,true),lp(12,4));
        apiKeyField = new EditText(this);
        apiKeyField.setSingleLine(true); apiKeyField.setTextSize(14);
        apiKeyField.setTextColor(Color.WHITE); apiKeyField.setHintTextColor(MUTED);
        apiKeyField.setHint(tr("Вставь сюда API-Football ключ"));
        apiKeyField.setInputType(129); apiKeyField.setPadding(dp(13),dp(8),dp(13),dp(8));
        apiKeyField.setBackground(shape(PANEL,12));
        apiKeyField.setText(apiPrefs.getString("api_football_key",""));
        panel.addView(apiKeyField,lp(0,8));

        LinearLayout actions = new LinearLayout(this);
        Button save = button("СОХРАНИТЬ КЛЮЧ"), test = button("ПРОВЕРИТЬ КЛЮЧ");
        actions.addView(save,new LinearLayout.LayoutParams(0,dp(46),1));
        actions.addView(test,new LinearLayout.LayoutParams(0,dp(46),1));
        panel.addView(actions);
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle(tr("⚙️ НАСТРОЙКИ")).setView(panel)
            .setNegativeButton(tr("Закрыть"),null)
            .setPositiveButton(tr("Сохранить настройки"),null).create();
        save.setOnClickListener(v -> {
            String key=apiKeyField.getText().toString().trim();
            if(!key.isEmpty()) apiPrefs.edit().putString("api_football_key",key).apply();
            Toast.makeText(this,tr("Ключ сохранён"),Toast.LENGTH_SHORT).show();
        });
        test.setOnClickListener(v -> testApiFootballKey());
        dialog.setOnShowListener(v -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(w -> {
            String key=apiKeyField.getText().toString().trim();
            if(!key.isEmpty()) apiPrefs.edit().putString("api_football_key",key).apply();
            int pos=language.getSelectedItemPosition();
            apiPrefs.edit().putString("app_language",codes[pos]).apply();
            dialog.dismiss();
            buildUi();
            loadFixtures();
        }));
        dialog.show();
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density); }
    private GradientDrawable shape(int color, int radius) { GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d; }
    private TextView label(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(tr(s)); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(null, Typeface.BOLD); return t;
    }
    private LinearLayout.LayoutParams lp(int top, int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.setMargins(0, dp(top), 0, dp(bottom)); return p;
    }
    private Button button(String s) {
        Button b = new Button(this); b.setText(tr(s)); b.setAllCaps(false); b.setTextColor(BG); b.setTextSize(16); b.setTypeface(null, Typeface.BOLD); b.setBackground(shape(GREEN, 13)); return b;
    }
    private String today() { return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date()); }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG);
        chosenDate = today();
        apiPrefs = getSharedPreferences("football_analyzer", MODE_PRIVATE);
        buildUi();
        loadFixtures();
    }

    private void showToolsMenu() {
        String[] items = {
            "📅 История сохранённых прогнозов",
            "🧠 Обучение и разбор ошибок",
            "📻 European Hit Radio"
        };
        new AlertDialog.Builder(this)
            .setTitle("Дополнительные функции")
            .setItems(items, (dialog, which) -> {
                if (which == 0) showHistory();
                else if (which == 1) showLearning();
                else if (which == 2) showRadio();
            })
            .setNegativeButton("Закрыть", null)
            .show();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(22), dp(18), dp(28)); root.setBackgroundColor(BG);
        scroll.addView(root); setContentView(scroll);

        root.addView(label("⚽ FOOTBALL ANALYZER 5.6", 25, GREEN, true));
        root.addView(label("Матчи · статистика open-matchday + ESPN + API-Football", 14, 0xffb8c9bf, true), lp(4, 12));

        Button settings = button("⚙️ НАСТРОЙКИ");
        root.addView(settings, lp(8, 12));
        settings.setOnClickListener(v -> showSettings());

        Button toolsMenu = button("☰ ДОПОЛНИТЕЛЬНО");
        root.addView(toolsMenu, lp(0, 12));
        toolsMenu.setOnClickListener(v -> showToolsMenu());

        root.addView(label("ВЫБЕРИ ТУРНИР", 15, GREEN, true), lp(4, 6));
        leagueSpinner = new Spinner(this);
        ArrayAdapter<League> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, leagues);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        leagueSpinner.setAdapter(adapter); leagueSpinner.setBackground(shape(PANEL, 12)); root.addView(leagueSpinner, lp(0, 12));

        root.addView(label("📊 СКОЛЬКО ПОСЛЕДНИХ МАТЧЕЙ БРАТЬ ДЛЯ СТАТИСТИКИ", 14, GREEN, true), lp(4, 6));
        matchCountSpinner = new Spinner(this);
        String[] matchCountOptions = {"2 матча", "5 матчей", "6 матчей", "8 матчей", "10 матчей"};
        ArrayAdapter<String> countAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, matchCountOptions);
        countAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        matchCountSpinner.setAdapter(countAdapter);
        matchCountSpinner.setBackground(shape(PANEL, 12));
        selectedMatchCount = apiPrefs.getInt("analysis_match_count", 5);
        int[] initialCounts = {2,5,6,8,10}; int initialCountPosition = 1;
        for (int ci=0; ci<initialCounts.length; ci++) if (initialCounts[ci] == selectedMatchCount) initialCountPosition = ci;
        matchCountSpinner.setSelection(initialCountPosition);
        matchCountSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onNothingSelected(AdapterView<?> parent) {}
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                int[] counts = {2,5,6,8,10};
                selectedMatchCount = counts[position];
                apiPrefs.edit().putInt("analysis_match_count", selectedMatchCount).apply();
            }
        });
        root.addView(matchCountSpinner, lp(0, 12));

        LinearLayout modes = new LinearLayout(this);
        String[][] choices = {{"Сегодня", "today"}, {"Завтра", "tomorrow"}, {"Все матчи", "all"}};
        for (String[] c : choices) {
            Button b = button(c[0]); LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(48), 1); p.setMargins(dp(2), 0, dp(2), 0); modes.addView(b, p);
            b.setOnClickListener(v -> { mode = c[1]; dateWasChosen = false; loadFixtures(); });
        }
        root.addView(modes, lp(0, 8));

        Button date = button("📅 ВЫБРАТЬ ДАТУ"); root.addView(date, lp(0, 8));
        selectedDateText = label("Дата: " + chosenDate, 15, Color.WHITE, true); root.addView(selectedDateText, lp(0, 12));
        date.setOnClickListener(v -> openDatePicker());

        Button refresh = button("ОБНОВИТЬ МАТЧИ"); root.addView(refresh, lp(0, 8)); refresh.setOnClickListener(v -> loadFixtures());
        status = label("Подключаюсь к бесплатному источнику…", 14, 0xffc3d2c9, false); root.addView(status, lp(0, 10));
        cards = new LinearLayout(this); cards.setOrientation(LinearLayout.VERTICAL); root.addView(cards);
        root.addView(label("Источники: open-matchday + ESPN + API-Football (если добавлен ключ). Покрытие статистики зависит от лиги и тарифа API.", 12, 0xff879b8e, false), lp(18, 0));

        leagueSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onNothingSelected(android.widget.AdapterView<?> parent) {}
            public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) { selectedLeague = position; loadFixtures(); }
        });
    }

    private void openDatePicker() {
        Calendar c = Calendar.getInstance();
        try { c.setTime(new SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(chosenDate)); } catch (Exception ignored) {}
        DatePickerDialog dlg = new DatePickerDialog(this, (picker, y, m, d) -> {
            Calendar picked = Calendar.getInstance(); picked.set(y, m, d);
            chosenDate = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(picked.getTime());
            dateWasChosen = true; mode = "custom"; selectedDateText.setText("Дата: " + chosenDate); loadFixtures();
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH));
        dlg.show();
    }

    private String fetchWithFallback(String path) throws Exception {
        Exception last = null;
        for (String base : new String[]{RAW, CDN}) {
            HttpURLConnection conn = null;
            try {
                URL url = new URL(base + path);
                conn = (HttpURLConnection) url.openConnection();
                conn.setConnectTimeout(12000); conn.setReadTimeout(18000);
                conn.setRequestProperty("User-Agent", "FootballAnalyzer3/3.0");
                conn.setRequestProperty("Accept", "text/csv,*/*");
                int code = conn.getResponseCode();
                InputStream in = (code >= 200 && code < 300) ? conn.getInputStream() : conn.getErrorStream();
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                if (in != null) { try (InputStream stream = in) { byte[] buf = new byte[8192]; int n; while ((n = stream.read(buf)) != -1) out.write(buf, 0, n); } }
                String body = out.toString("UTF-8");
                if (code == 404) throw new FileNotFoundException("Для этого турнира файл пока не опубликован: " + path);
                if (code < 200 || code >= 300) throw new IOException("HTTP " + code + " при загрузке CSV");
                if (body.trim().isEmpty()) throw new IOException("Источник вернул пустой CSV: " + path);
                return body;
            } catch (Exception e) { last = e; }
            finally { if (conn != null) conn.disconnect(); }
        }
        throw last == null ? new IOException("Не удалось подключиться к open-matchday") : last;
    }

    private List<String[]> parseCsv(String csv) throws IOException {
        List<String[]> rows = new ArrayList<>();
        BufferedReader reader = new BufferedReader(new StringReader(csv));
        String line;
        while ((line = reader.readLine()) != null) {
            if (line.trim().isEmpty()) continue;
            ArrayList<String> cells = new ArrayList<>(); StringBuilder cell = new StringBuilder(); boolean quoted = false;
            for (int i = 0; i < line.length(); i++) {
                char ch = line.charAt(i);
                if (ch == '"') {
                    if (quoted && i + 1 < line.length() && line.charAt(i + 1) == '"') { cell.append('"'); i++; }
                    else quoted = !quoted;
                } else if (ch == ',' && !quoted) { cells.add(cell.toString()); cell.setLength(0); }
                else cell.append(ch);
            }
            cells.add(cell.toString()); rows.add(cells.toArray(new String[0]));
        }
        return rows;
    }

    private Map<String, Integer> headerIndex(String[] header) {
        Map<String, Integer> map = new HashMap<>();
        for (int i = 0; i < header.length; i++) map.put(header[i].trim().toLowerCase(Locale.US), i);
        return map;
    }
    private String val(String[] row, Map<String, Integer> ix, String key) {
        Integer i = ix.get(key.toLowerCase(Locale.US)); return i == null || i < 0 || i >= row.length ? "" : row[i].trim();
    }
    private Double number(String[] row, Map<String, Integer> ix, String key) {
        try { String s = val(row, ix, key); return s.isEmpty() ? null : Double.parseDouble(s); } catch (Exception e) { return null; }
    }

    private void loadFixtures() {
        if (status == null || cards == null) return;
        final League league = leagues[selectedLeague]; final String selectedMode = mode; final String date = chosenDate;
        status.setText("Загружаю CSV: " + league.title + "…"); cards.removeAllViews();
        worker.execute(() -> {
            try {
                if ("UEFA_NATIONS_LEAGUE".equals(league.folder)) {
                    // ESPN removed support for long YYYYMMDD-YYYYMMDD ranges (returns HTTP 400).
                    // Request each month separately using the supported YYYYMM format.
                    String target = date;
                    if (selectedMode.equals("today")) target = today();
                    else if (selectedMode.equals("tomorrow")) { Calendar cal = Calendar.getInstance(); cal.add(Calendar.DAY_OF_YEAR, 1); target = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.getTime()); }

                    LinkedHashMap<String,String[]> unique = new LinkedHashMap<>();
                    Calendar monthCursor = Calendar.getInstance();
                    monthCursor.setTime(new SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(today()));
                    int monthsBack = selectedMode.equals("all") ? 11 : 2;
                    monthCursor.add(Calendar.MONTH, -monthsBack);
                    SimpleDateFormat monthFmt = new SimpleDateFormat("yyyyMM", Locale.US);
                    for (int mi=0; mi<=monthsBack; mi++) {
                        String month = monthFmt.format(monthCursor.getTime());
                        JSONObject monthly = fetchJson("https://site.api.espn.com/apis/site/v2/sports/soccer/uefa.nations/scoreboard?dates=" + month);
                        List<String[]> monthRows = nationsRows(monthly);
                        for (int ri=1; ri<monthRows.size(); ri++) {
                            String[] r=monthRows.get(ri);
                            String eventKey = r[1] + "|" + r[3] + "|" + r[4];
                            unique.put(eventKey,r);
                        }
                        monthCursor.add(Calendar.MONTH,1);
                    }
                    // Include the chosen month too, if a custom date is outside the rolling window.
                    String targetMonth = target.replace("-","");
                    if (targetMonth.length() >= 6) {
                        String ym=targetMonth.substring(0,6);
                        boolean present=false;
                        for(String k:unique.keySet()) if(k.startsWith(ym.substring(0,4)+"-"+ym.substring(4,6))) { present=true; break; }
                        if(!present) {
                            JSONObject customMonth=fetchJson("https://site.api.espn.com/apis/site/v2/sports/soccer/uefa.nations/scoreboard?dates="+ym);
                            List<String[]> extra=nationsRows(customMonth);
                            for(int ri=1;ri<extra.size();ri++){String[] r=extra.get(ri);unique.put(r[1]+"|"+r[3]+"|"+r[4],r);}
                        }
                    }
                    List<String[]> allRows = new ArrayList<>();
                    allRows.add(new String[]{"gw","date","time","home","away","ft_home","ft_away","ft_result",
                        "home_corners","away_corners","home_yellow","away_yellow","home_target","away_target",
                        "home_shots","away_shots","home_fouls","away_fouls"});
                    allRows.addAll(unique.values());
                    List<String[]> fixtures = new ArrayList<>();
                    List<String[]> results = new ArrayList<>();
                    fixtures.add(allRows.get(0)); results.add(allRows.get(0));
                    for (int ri = 1; ri < allRows.size(); ri++) {
                        String[] r = allRows.get(ri);
                        boolean played = !r[5].isEmpty() && !r[6].isEmpty();
                        if (played) results.add(r);
                        if ((selectedMode.equals("all") && !played) || (!selectedMode.equals("all") && r[1].equals(target))) fixtures.add(r);
                    }
                    Map<String,Integer> fixIx = headerIndex(fixtures.get(0));
                    List<String[]> found = new ArrayList<>();
                    for (int fi = 1; fi < fixtures.size(); fi++) found.add(fixtures.get(fi));
                    found.sort((a,b) -> (val(a,fixIx,"date")+val(a,fixIx,"time")).compareTo(val(b,fixIx,"date")+val(b,fixIx,"time")));
                    List<String[]> finalResults = results;
                    int fixtureCount = fixtures.size()-1, resultCount = Math.max(0, results.size()-1);
                    ui.post(() -> renderMatches(league, found, finalResults, fixIx, date, selectedMode, fixtureCount, resultCount));
                    return;
                }
                String folder = league.folder + "/";
                List<String[]> fixtures = parseCsv(fetchWithFallback(folder + "fixtures_" + SEASON + ".csv"));
                List<String[]> results;
                try { results = parseCsv(fetchWithFallback(folder + "results_" + SEASON + ".csv")); }
                catch (Exception unavailable) { results = new ArrayList<>(); }
                if (fixtures.isEmpty()) throw new IOException("CSV расписания не содержит заголовка и матчей.");
                Map<String, Integer> fixIx = headerIndex(fixtures.get(0));
                if (!fixIx.containsKey("date") || !fixIx.containsKey("home") || !fixIx.containsKey("away")) throw new IOException("Неожиданный формат CSV расписания.");
                String target = date;
                if (selectedMode.equals("today")) target = today();
                else if (selectedMode.equals("tomorrow")) { Calendar cal = Calendar.getInstance(); cal.add(Calendar.DAY_OF_YEAR, 1); target = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.getTime()); }
                final String filterDate = target;
                List<String[]> found = new ArrayList<>();
                for (int i = 1; i < fixtures.size(); i++) {
                    String[] row = fixtures.get(i); String rowDate = val(row, fixIx, "date");
                    if (selectedMode.equals("all") || rowDate.equals(filterDate)) found.add(row);
                }
                found.sort((a,b) -> (val(a,fixIx,"date") + val(a,fixIx,"time")).compareTo(val(b,fixIx,"date") + val(b,fixIx,"time")));
                List<String[]> finalResults = results; int fixtureCount = fixtures.size() - 1; int resultCount = Math.max(0, results.size() - 1);
                ui.post(() -> renderMatches(league, found, finalResults, fixIx, filterDate, selectedMode, fixtureCount, resultCount));
            } catch (Exception e) {
                String message = e.getMessage() == null ? e.toString() : e.getMessage();
                ui.post(() -> { status.setText("Ошибка open-matchday: " + message); cards.removeAllViews(); });
            }
        });
    }

    private void renderMatches(League league, List<String[]> found, List<String[]> results, Map<String,Integer> fixIx,
                               String date, String selectedMode, int fixtureCount, int resultCount) {
        status.setText("open-matchday · расписание: " + fixtureCount + " · сыграно: " + resultCount + " · найдено: " + found.size());
        if (found.isEmpty()) {
            String msg = selectedMode.equals("all") ? "В опубликованном файле расписания пока нет будущих матчей." : "На " + date + " матчей в опубликованном расписании этого турнира нет. Это не ошибка API.";
            cards.addView(label(msg, 15, Color.WHITE, true), lp(8, 8));
            return;
        }
        for (String[] row : found) addMatchCard(league, row, fixIx, results);
    }

    // Дополнительный источник статистики: публичный ESPN Site API (без ключа).
    // Используется только как резерв, когда поле отсутствует в open-matchday.
    private String espnLeague(League league) {
        String f = league.folder;
        if (f.equals("UEFA_1_champions-league")) return "uefa.champions";
        if (f.equals("UEFA_1_europa-league")) return "uefa.europa";
        if (f.equals("UEFA_1_conference-league")) return "uefa.europa.conf";
        if (f.equals("UEFA_NATIONS_LEAGUE")) return "uefa.nations";
        if (f.startsWith("ENG_1_")) return "eng.1";
        if (f.startsWith("ENG_2_")) return "eng.2";
        if (f.startsWith("ENG_3_")) return "eng.3";
        if (f.startsWith("ENG_4_")) return "eng.4";
        if (f.startsWith("ESP_1_")) return "esp.1";
        if (f.startsWith("ESP_2_")) return "esp.2";
        if (f.startsWith("GER_1_")) return "ger.1";
        if (f.startsWith("ITA_1_")) return "ita.1";
        if (f.startsWith("ITA_2_")) return "ita.2";
        if (f.startsWith("FRA_1_")) return "fra.1";
        if (f.startsWith("FRA_2_")) return "fra.2";
        if (f.startsWith("NED_1_")) return "ned.1";
        if (f.startsWith("POR_1_")) return "por.1";
        if (f.startsWith("BEL_1_")) return "bel.1";
        if (f.startsWith("TUR_1_")) return "tur.1";
        if (f.startsWith("GRE_1_")) return "gre.1";
        if (f.startsWith("SCO_1_")) return "sco.1";
        if (f.startsWith("POL_1_")) return "pol.1";
        if (f.startsWith("NOR_1_")) return "nor.1";
        if (f.startsWith("AUT_1_")) return "aut.1";
        if (f.startsWith("SUI_1_")) return "sui.1";
        if (f.startsWith("DEN_1_")) return "den.1";
        if (f.startsWith("SWE_1_")) return "swe.1";
        if (f.startsWith("BRA_1_")) return "bra.1";
        if (f.startsWith("USA_1_")) return "usa.1";
        if (f.startsWith("JPN_1_")) return "jpn.1";
        if (f.startsWith("AUS_1_")) return "aus.1";
        return "";
    }

    // ESPN schedule/results adapter for UEFA Nations League (not present in open-matchday CSV registry).
    private List<String[]> nationsRows(JSONObject board) {
        List<String[]> rows = new ArrayList<>();
        rows.add(new String[]{"gw","date","time","home","away","ft_home","ft_away","ft_result",
                "home_corners","away_corners","home_yellow","away_yellow","home_target","away_target",
                "home_shots","away_shots","home_fouls","away_fouls"});
        JSONArray events = board == null ? null : board.optJSONArray("events");
        if (events == null) return rows;
        for (int i=0; i<events.length(); i++) {
            JSONObject ev = events.optJSONObject(i); if (ev == null) continue;
            JSONArray comps = ev.optJSONArray("competitions"); if (comps == null || comps.length()==0) continue;
            JSONObject comp = comps.optJSONObject(0); if (comp == null) continue;
            JSONArray sides = comp.optJSONArray("competitors"); if (sides == null) continue;
            String home="", away="", hs="", as="";
            for (int j=0; j<sides.length(); j++) {
                JSONObject side=sides.optJSONObject(j); if(side==null)continue;
                JSONObject team=side.optJSONObject("team");
                String name=team==null?"":team.optString("displayName",team.optString("name",""));
                if ("home".equalsIgnoreCase(side.optString("homeAway"))) { home=name; hs=side.optString("score",""); }
                else { away=name; as=side.optString("score",""); }
            }
            if(home.isEmpty()||away.isEmpty()) continue;
            String date=ev.optString("date","");
            if(date.length()>=10) date=date.substring(0,10);
            String time="";
            if(date.length()==10) {
                try { time=new SimpleDateFormat("HH:mm",Locale.US).format(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm",Locale.US).parse(ev.optString("date").substring(0,16))); } catch(Exception ignored) {}
            }
            String round=comp.optString("series",""); 
            String completed=comp.optJSONObject("status")==null?"":comp.optJSONObject("status").optJSONObject("type")==null?"":comp.optJSONObject("status").optJSONObject("type").optString("completed","");
            String result="";
            if(!hs.isEmpty()&&!as.isEmpty()) {
                try { int h=Integer.parseInt(hs), a=Integer.parseInt(as); result=h>a?"H":h<a?"A":"D"; } catch(Exception ignored) { hs=""; as=""; }
            }
            rows.add(new String[]{round,date,time,home,away,hs,as,result,"","","","","","","","","",""});
        }
        List<String[]> body = new ArrayList<>(rows.subList(1, rows.size()));
        Collections.sort(body, (a,b)->(a[1]+a[2]).compareTo(b[1]+b[2]));
        rows.subList(1, rows.size()).clear();
        rows.addAll(body);
        return rows;
    }

    private JSONObject fetchJson(String urlText) throws Exception {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(urlText).openConnection();
            c.setConnectTimeout(5000); c.setReadTimeout(7000);
            c.setRequestProperty("User-Agent", "Mozilla/5.0 FootballAnalyzer/3.8");
            c.setRequestProperty("Accept", "application/json");
            int code = c.getResponseCode();
            InputStream in = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
            if (in == null) throw new IOException("ESPN HTTP " + code);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            try (InputStream stream = in) { byte[] b = new byte[8192]; int n; while ((n=stream.read(b))!=-1) out.write(b,0,n); }
            if (code < 200 || code >= 300) throw new IOException("ESPN HTTP " + code);
            return new JSONObject(out.toString("UTF-8"));
        } finally { if (c != null) c.disconnect(); }
    }

    private String normTeam(String name) {
        String n = java.text.Normalizer.normalize(name == null ? "" : name, java.text.Normalizer.Form.NFD)
                .replaceAll("\\p{M}+", "").toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", "");
        n = n.replace("fc", "").replace("afc", "").replace("cf", "");
        if (n.equals("turkiye") || n.equals("turkiyea")) n = "turkey";
        if (n.equals("czechrepublic")) n = "czechia";
        if (n.equals("korearepublic")) n = "southkorea";
        if (n.equals("iriran")) n = "iran";
        return n;
    }
    private boolean sameTeam(String a, String b) {
        String x=normTeam(a), y=normTeam(b);
        return !x.isEmpty() && !y.isEmpty() && (x.equals(y) || (x.length()>=3 && y.length()>=3 && (x.contains(y)||y.contains(x))));
    }
    private String statName(JSONObject stat) {
        return (stat.optString("name", "") + " " + stat.optString("displayName", "") + " " + stat.optString("abbreviation", "")).toLowerCase(Locale.ROOT).replaceAll("[^a-z]", "");
    }
    private Double espnStat(JSONArray stats, String wanted) {
        if (stats == null) return null;
        for (int i=0;i<stats.length();i++) {
            JSONObject st=stats.optJSONObject(i); if(st==null) continue;
            String n=statName(st); boolean match=false;
            if (wanted.equals("corners")) match=n.contains("woncorners")||n.equals("corners")||n.contains("cornerkicks");
            else if (wanted.equals("yellow")) match=n.contains("yellowcards")||n.equals("yellowcard");
            else if (wanted.equals("target")) match=n.contains("shotsontarget")||n.contains("shotsongoal");
            else if (wanted.equals("shots")) match=n.equals("totalshots")||n.equals("shots")||n.equals("totalshot");
            else if (wanted.equals("fouls")) match=n.contains("foulscommitted")||n.equals("fouls");
            if (match) {
                String v=st.optString("displayValue", "");
                if(v.isEmpty()) v=st.optString("value", "");
                try { return Double.parseDouble(v.replace(",", "")); } catch(Exception ignored) {}
            }
        }
        return null;
    }
    private Map<String,Double> parseEspnTeamStats(JSONObject teamBox) {
        Map<String,Double> m=new HashMap<>();
        JSONArray stats=teamBox.optJSONArray("statistics");
        for(String key:new String[]{"corners","yellow","target","shots","fouls"}) {
            Double v=espnStat(stats,key); if(v!=null)m.put(key,v);
        }
        return m;
    }

    // ESPN scoreboard events often include team statistics directly on competitors.
    // Use this before requesting /summary so UCL/UEL matches do not lose available data.
    private Map<String,Double> parseEspnCompetitorStats(JSONObject competitor) {
        Map<String,Double> m = new HashMap<>();
        JSONArray stats = competitor.optJSONArray("statistics");
        for (String key : new String[]{"corners","target","shots","fouls"}) {
            Double value = espnStat(stats, key);
            if (value != null) m.put(key, value);
        }
        return m;
    }

    private Map<String,Integer> parseEspnYellowCards(JSONObject event) {
        Map<String,Integer> cards = new HashMap<>();
        JSONArray competitions = event.optJSONArray("competitions");
        if (competitions == null || competitions.length() == 0) return cards;
        JSONArray competitors = competitions.optJSONObject(0).optJSONArray("competitors");
        if (competitors == null) return cards;
        String homeId = "", awayId = "";
        for (int i=0; i<competitors.length(); i++) {
            JSONObject c = competitors.optJSONObject(i);
            if (c == null) continue;
            if ("home".equalsIgnoreCase(c.optString("homeAway"))) homeId = c.optString("id","");
            else awayId = c.optString("id","");
        }
        int homeCards = 0, awayCards = 0;
        JSONArray details = event.optJSONArray("details");
        if (details == null && competitions.optJSONObject(0) != null)
            details = competitions.optJSONObject(0).optJSONArray("details");
        if (details != null) for (int i=0; i<details.length(); i++) {
            JSONObject d = details.optJSONObject(i);
            if (d == null) continue;
            boolean yellow = d.optBoolean("yellowCard", false)
                    || "Yellow Card".equalsIgnoreCase(d.optJSONObject("type") == null ? "" : d.optJSONObject("type").optString("text",""));
            if (!yellow) continue;
            JSONObject team = d.optJSONObject("team");
            String id = team == null ? "" : team.optString("id","");
            if (!homeId.isEmpty() && homeId.equals(id)) homeCards++;
            else if (!awayId.isEmpty() && awayId.equals(id)) awayCards++;
        }
        if (details == null || details.length() == 0) return cards; // no event details => unknown, not 0
        if (!homeId.isEmpty()) cards.put(homeId, homeCards);
        if (!awayId.isEmpty()) cards.put(awayId, awayCards);
        return cards;
    }
    private String matchKey(String date,String home,String away) { return date+"|"+normTeam(home)+"|"+normTeam(away); }

    private String shiftIsoDate(String isoDate, int days) {
        try {
            SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
            fmt.setTimeZone(TimeZone.getTimeZone("UTC"));
            Date d = fmt.parse(isoDate);
            Calendar c = Calendar.getInstance(TimeZone.getTimeZone("UTC"), Locale.US);
            c.setTime(d);
            c.add(Calendar.DAY_OF_MONTH, days);
            return fmt.format(c.getTime());
        } catch (Exception e) {
            return isoDate;
        }
    }

    private JSONObject findEspnEvent(JSONObject board, String rowHome, String rowAway) {
        JSONArray events = board == null ? null : board.optJSONArray("events");
        if (events == null) return null;
        for (int i=0; i<events.length(); i++) {
            JSONObject ev = events.optJSONObject(i);
            if (ev == null) continue;
            JSONArray comps = ev.optJSONArray("competitions");
            if (comps == null || comps.length()==0) continue;
            JSONObject comp = comps.optJSONObject(0);
            JSONArray sides = comp == null ? null : comp.optJSONArray("competitors");
            if (sides == null) continue;
            String eh="", ea="";
            for (int j=0; j<sides.length(); j++) {
                JSONObject side=sides.optJSONObject(j);
                JSONObject team=side==null?null:side.optJSONObject("team");
                if (team==null) continue;
                String n=team.optString("displayName",team.optString("name",""));
                if ("home".equalsIgnoreCase(side.optString("homeAway"))) eh=n; else ea=n;
            }
            if (sameTeam(rowHome,eh) && sameTeam(rowAway,ea)) return ev;
        }
        return null;
    }

    private void mergeEspnStats(Map<String,Double> target, Map<String,Double> source) {
        if (source == null) return;
        for (String k : new String[]{"corners","yellow","target","shots","fouls"}) {
            if (source.containsKey(k)) target.put(k, source.get(k));
        }
    }

    private Map<String,Map<String,Double>> loadEspnFallback(League league, String home, String away, List<String[]> rows, Map<String,Integer> ix) {
        Map<String,Map<String,Double>> out=new HashMap<>();
        String slug=espnLeague(league);
        if (slug.isEmpty()) return out;

        LinkedHashMap<String,String[]> candidates=new LinkedHashMap<>();
        for (String team : new String[]{home,away}) {
            ArrayList<String[]> apps=new ArrayList<>();
            for (int i=1;i<rows.size();i++) {
                String[] r=rows.get(i);
                if (sameTeam(team,val(r,ix,"home")) || sameTeam(team,val(r,ix,"away"))) apps.add(r);
            }
            apps.sort((a,b)->val(b,ix,"date").compareTo(val(a,ix,"date")));
            int count=0;
            for (String[] r:apps) {
                if (count>=selectedMatchCount) break;
                String k=matchKey(val(r,ix,"date"),val(r,ix,"home"),val(r,ix,"away"));
                candidates.put(k,r); count++;
            }
        }

        // UEFA competitions can span many months. A single wide ESPN scoreboard
        // range is truncated/incomplete, so query each match date (free ESPN endpoint).
        Map<String,JSONObject> scoreboards = new HashMap<>();
        for (String[] r : candidates.values()) {
            String date=val(r,ix,"date"), rh=val(r,ix,"home"), ra=val(r,ix,"away");
            if (date.length()!=10) continue;
            String key=matchKey(date,rh,ra);
            try {
                JSONObject event=null;
                for (int offset=-1; offset<=1 && event==null; offset++) {
                    String queryDate=shiftIsoDate(date,offset);
                    JSONObject board=scoreboards.get(queryDate);
                    if (board==null) {
                        try {
                            board=fetchJson("https://site.api.espn.com/apis/site/v2/sports/soccer/"+slug+"/scoreboard?dates="+queryDate.replace("-",""));
                            scoreboards.put(queryDate,board);
                        } catch(Exception ignored) { scoreboards.put(queryDate,new JSONObject()); }
                    }
                    event=findEspnEvent(board,rh,ra);
                }
                if (event==null) continue;

                Map<String,Map<String,Double>> perSide=new HashMap<>();
                perSide.put("home",new HashMap<String,Double>());
                perSide.put("away",new HashMap<String,Double>());

                // Read any values embedded in scoreboard competitors.
                JSONArray comps=event.optJSONArray("competitions");
                JSONArray sides=(comps==null||comps.length()==0||comps.optJSONObject(0)==null)
                        ? null : comps.optJSONObject(0).optJSONArray("competitors");
                Map<String,Integer> yellowById=parseEspnYellowCards(event);
                if (sides!=null) for (int j=0;j<sides.length();j++) {
                    JSONObject side=sides.optJSONObject(j);
                    if (side==null) continue;
                    JSONObject team=side.optJSONObject("team");
                    String teamName=team==null?"":team.optString("displayName",team.optString("name",""));
                    String sideName=sameTeam(rh,teamName)?"home":sameTeam(ra,teamName)?"away":"";
                    if (sideName.isEmpty()) continue;
                    mergeEspnStats(perSide.get(sideName),parseEspnCompetitorStats(side));
                    String teamId=side.optString("id","");
                    if (yellowById.containsKey(teamId)) perSide.get(sideName).put("yellow",(double)yellowById.get(teamId));
                }

                // Always read summary too and merge field-by-field. Previously, one
                // scoreboard value could prevent summary from filling the other metrics.
                String eventId=event.optString("id","");
                if (!eventId.isEmpty()) {
                    try {
                        JSONObject summary=fetchJson("https://site.api.espn.com/apis/site/v2/sports/soccer/"+slug+"/summary?event="+eventId);
                        JSONObject box=summary.optJSONObject("boxscore");
                        JSONArray teams=box==null?null:box.optJSONArray("teams");
                        if (teams!=null) for (int j=0;j<teams.length();j++) {
                            JSONObject tb=teams.optJSONObject(j);
                            if (tb==null) continue;
                            JSONObject t=tb.optJSONObject("team");
                            String tn=t==null?"":t.optString("displayName",t.optString("name",""));
                            String sideName=sameTeam(rh,tn)?"home":sameTeam(ra,tn)?"away":"";
                            if (!sideName.isEmpty()) mergeEspnStats(perSide.get(sideName),parseEspnTeamStats(tb));
                        }
                    } catch(Exception ignored) { }
                }

                for (String sideName : new String[]{"home","away"}) {
                    if (!perSide.get(sideName).isEmpty()) out.put(key+"|"+sideName,perSide.get(sideName));
                }
            } catch(Exception ignored) { /* ESPN may not publish stats for every match */ }
        }
        return out;
    }

    private static class TeamStats {
        int played, wins, draws, losses;
        double goalsFor, goalsAgainst;
        final Map<String, ArrayList<Double>> metrics = new HashMap<>();
        final Map<String, ArrayList<Double>> conceded = new HashMap<>();
        void addConceded(String key, Double value) { if (value == null) return; if (!conceded.containsKey(key)) conceded.put(key, new ArrayList<>()); conceded.get(key).add(value); }
        ArrayList<Double> concededValues(String key) { return conceded.get(key); }
        void addMetric(String key, Double value) {
            if (value == null) return;
            if (!metrics.containsKey(key)) metrics.put(key, new ArrayList<>());
            metrics.get(key).add(value);
        }
        ArrayList<Double> values(String key) { return metrics.get(key); }
        double metricSum(String key) { ArrayList<Double> v=values(key); if(v==null)return 0; double s=0; for(double x:v)s+=x; return s; }
        double metricAvg(String key) { ArrayList<Double> v=values(key); return v==null||v.isEmpty()?Double.NaN:metricSum(key)/v.size(); }
        double avgGoalsFor() { return played == 0 ? 0 : goalsFor / played; }
        double avgGoalsAgainst() { return played == 0 ? 0 : goalsAgainst / played; }
        String form() { return "В-Н-П: " + wins + "-" + draws + "-" + losses; }
    }

    private void addMatchCard(League league, String[] match, Map<String,Integer> fixIx, List<String[]> resultRows) {
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(14),dp(13),dp(14),dp(13)); box.setBackground(shape(PANEL,15)); cards.addView(box,lp(0,10));
        String date = val(match,fixIx,"date"), time = val(match,fixIx,"time"), home = val(match,fixIx,"home"), away = val(match,fixIx,"away"), round = val(match,fixIx,"gw");
        box.addView(label(date + (time.isEmpty()?"":" · "+time) + (round.isEmpty()?"":" · тур "+round),12,MUTED,true));
        box.addView(label(home + " — " + away,20,Color.WHITE,true),lp(5,8));
        TextView report = label("Нажми кнопку ниже: покажу итоги последних 10 матчей, средние показатели и прогнозы тоталов.",14,0xffe1eee6,false); report.setLineSpacing(dp(3),1.0f); box.addView(report,lp(5,8));
        final String[] cachedReport = {""};
        Button analyze = button("📊 ПОЛНЫЙ АНАЛИЗ И ПРОГНОЗ"); box.addView(analyze);
        analyze.setOnClickListener(v -> {
            analyze.setEnabled(false); report.setText("Собираю статистику последних " + selectedMatchCount + " матчей…");
            worker.execute(() -> {
                String text = makeReport(league, home, away, resultRows);
                ui.post(() -> { cachedReport[0] = text; report.setText(text); analyze.setEnabled(true); });
            });
        });
        Button save = button("💾 СОХРАНИТЬ АНАЛИЗ В ИСТОРИЮ"); box.addView(save,lp(7,0));
        save.setOnClickListener(v -> {
            String saved = date + " · " + league.title + "\n" + home + " — " + away + (cachedReport[0].isEmpty() ? "\nАнализ ещё не рассчитан" : "\n" + cachedReport[0]);
            saveHistory(saved);
            saveLearningForecast(date, league.title, home, away, cachedReport[0]);
            Toast.makeText(this,"Матч сохранён в историю и базу обучения",Toast.LENGTH_SHORT).show();
        });
    }

    private TeamStats collectTeam(String team, List<String[]> rows, Map<String,Integer> ix, Map<String,Map<String,Double>> supplemental) {
        ArrayList<String[]> appearances = new ArrayList<>();
        for (int i=1; i<rows.size(); i++) {
            String[] r=rows.get(i);
            if (team.equalsIgnoreCase(val(r,ix,"home")) || team.equalsIgnoreCase(val(r,ix,"away"))) appearances.add(r);
        }
        appearances.sort((a,b) -> val(b,ix,"date").compareTo(val(a,ix,"date")));
        TeamStats st = new TeamStats();
        for (String[] r : appearances) {
            if (st.played >= selectedMatchCount) break;
            boolean atHome = team.equalsIgnoreCase(val(r,ix,"home"));
            Double gf=number(r,ix,atHome?"ft_home":"ft_away");
            Double ga=number(r,ix,atHome?"ft_away":"ft_home");
            if (gf==null || ga==null) continue;
            st.played++; st.goalsFor+=gf; st.goalsAgainst+=ga;
            if (gf>ga) st.wins++; else if (gf.equals(ga)) st.draws++; else st.losses++;
            String side = atHome ? "home" : "away";
            String key = matchKey(val(r,ix,"date"),val(r,ix,"home"),val(r,ix,"away")) + "|" + side;
            Map<String,Double> extra = supplemental == null ? null : supplemental.get(key);
            for (String metric : new String[]{"corners","yellow","target","shots","fouls"}) {
                Double value = number(r,ix,side+"_"+metric);
                if (value == null && extra != null) value = extra.get(metric);
                st.addMetric(metric,value);
                if ("corners".equals(metric)) {
                    Double against = number(r,ix,(atHome?"away":"home")+"_corners");
                    if (against == null && supplemental != null) {
                        String otherKey = matchKey(val(r,ix,"date"),val(r,ix,"home"),val(r,ix,"away")) + "|" + (atHome?"away":"home");
                        Map<String,Double> otherExtra = supplemental.get(otherKey);
                        if (otherExtra != null) against = otherExtra.get("corners");
                    }
                    st.addConceded("corners", against);
                }
            }
        }
        return st;
    }

    // Keep the public-source statistics when API-Football has no coverage for a metric.
    // The previous implementation replaced the whole TeamStats object, which erased
    // corners/cards/shots/fouls even when open-matchday or ESPN had those values.
    private TeamStats mergeTeamStats(TeamStats fallback, TeamStats api) {
        if (api == null || api.played < 3) return fallback;
        TeamStats merged = new TeamStats();
        merged.played = api.played;
        merged.wins = api.wins;
        merged.draws = api.draws;
        merged.losses = api.losses;
        merged.goalsFor = api.goalsFor;
        merged.goalsAgainst = api.goalsAgainst;

        String[] keys = new String[]{"corners","yellow","target","shots","fouls"};
        for (String key : keys) {
            ArrayList<Double> apiValues = api.values(key);
            ArrayList<Double> fallbackValues = fallback == null ? null : fallback.values(key);
            ArrayList<Double> chosen = (apiValues != null && apiValues.size() >= 3)
                    ? apiValues : fallbackValues;
            if (chosen != null) {
                for (Double value : chosen) merged.addMetric(key, value);
            }
            if ("corners".equals(key)) {
                ArrayList<Double> apiAgainst = api.concededValues(key);
                ArrayList<Double> fallbackAgainst = fallback == null ? null : fallback.concededValues(key);
                ArrayList<Double> chosenAgainst = (apiAgainst != null && apiAgainst.size() >= 3) ? apiAgainst : fallbackAgainst;
                if (chosenAgainst != null) for (Double value : chosenAgainst) merged.addConceded(key, value);
            }
        }
        return merged;
    }

    private String oneDecimal(double v) { return String.format(Locale.US,"%.1f",v); }
    private String metricTeamLine(String team, TeamStats st, String key) {
        ArrayList<Double> vals=st.values(key);
        if(vals==null||vals.isEmpty()) return "   " + team + ": нет опубликованных данных";
        return "   " + team + ": всего " + oneDecimal(st.metricSum(key)) + " · в среднем " + oneDecimal(st.metricAvg(key)) + " за матч (данные по " + vals.size() + " матчам)";
    }
    private String metricSection(String emoji, String title, String key, TeamStats h, TeamStats a, String home, String away) {
        return emoji + " " + title + "\n" + metricTeamLine(home,h,key) + "\n" + metricTeamLine(away,a,key) + "\n";
    }
    private String market(String title, double lambda, int line, String unit) {
        if (Double.isNaN(lambda) || Double.isInfinite(lambda) || lambda <= 0)
            return "   " + title + ": недостаточно статистики\n";
        // For a half-line N.5, OVER means N+1 or more and UNDER means N or fewer.
        // line is the integer N. The previous code used N+1 as the CDF limit,
        // shifting every market by one whole event and understating OVER.
        double expected = Math.max(0.01, Math.min(60.0, lambda));
        double under = poissonCdf(line, expected); // P(X <= N)
        double over = 1.0 - under;                 // P(X >= N+1)
        under = Math.max(0.0, Math.min(1.0, under));
        over = Math.max(0.0, Math.min(1.0, over));
        return "   " + title + " — линия " + line + ".5 " + unit + "\n" +
               "      Ожидаемый тотал: " + fmt(expected) + "\n" +
               "      🔼 Больше: " + pct(over) + "   🔽 Меньше: " + pct(under) + "\n";
    }
    // Count markets use an over-dispersion-aware normal approximation based on the actual recent samples.
    // It is deliberately disabled for small/incomplete samples; this is a baseline, not a trained ML model.
    private String marketFromSamples(String title, TeamStats h, TeamStats a, String key, int line, String unit) {
        ArrayList<Double> hv = h.values(key), av = a.values(key);
        if (hv == null || av == null || hv.size() < 5 || av.size() < 5) {
            int hn = hv == null ? 0 : hv.size(), an = av == null ? 0 : av.size();
            return "   " + title + ": недостаточно данных (" + hn + "/" + an + "; нужно минимум 5 матчей на команду)\n";
        }
        double mean = mean(hv) + mean(av);
        double variance = sampleVariance(hv) + sampleVariance(av);
        if (!Double.isFinite(mean) || !Double.isFinite(variance) || mean <= 0 || variance < 0)
            return "   " + title + ": статистика некорректна, прогноз отключён\n";
        // Negative Binomial handles over-dispersed count markets; Poisson is used otherwise.
        double over = countOverProbability(line, mean, variance);
        double under = 1.0 - over;
        double sd = Math.sqrt(Math.max(0.0, variance));
        return "   " + title + " — линия " + line + ".5 " + unit + "\n" +
                "      Ожидаемый тотал: " + fmt(mean) + " · разброс: " + fmt(sd) + "\n" +
                "      🔼 Больше: " + pct(over) + "   🔽 Меньше: " + pct(under) + "\n" +
                "      Выборка: " + hv.size() + "+" + av.size() + " матчей; Poisson/NB, предварительная оценка\n";
    }
    // Corners model: blend each team's own corners with the opponent's corners conceded.
    // This is a better baseline than simply adding both teams' attacking averages.
    private String cornerMarketFromSamples(String title, TeamStats home, TeamStats away, int line) {
        ArrayList<Double> hf = home.values("corners"), af = away.values("corners");
        ArrayList<Double> hc = home.concededValues("corners"), ac = away.concededValues("corners");
        if (hf == null || af == null || hc == null || ac == null || hf.size() < 5 || af.size() < 5 || hc.size() < 5 || ac.size() < 5) {
            return "   " + title + ": недостаточно данных атаки и обороны (нужно минимум 5 матчей с угловыми у каждой команды)\n";
        }
        double homeRate = (mean(hf) + mean(ac)) / 2.0;
        double awayRate = (mean(af) + mean(hc)) / 2.0;
        double expected = homeRate + awayRate;
        double variance = (sampleVariance(hf) + sampleVariance(af) + sampleVariance(hc) + sampleVariance(ac)) / 4.0 * 2.0;
        if (!Double.isFinite(expected) || !Double.isFinite(variance) || expected <= 0 || variance < 0)
            return "   " + title + ": некорректные данные, прогноз отключён\n";
        double over = countOverProbability(line, expected, Math.max(expected, variance));
        return "   " + title + " — линия " + line + ".5 угловых\n" +
                "      Ожидаемый тотал: " + fmt(expected) + " (" + fmt(homeRate) + " + " + fmt(awayRate) + ")\n" +
                "      🔼 Больше: " + pct(over) + "   🔽 Меньше: " + pct(1.0-over) + "\n" +
                "      Учтены угловые за и против; выборка: " + hf.size() + "+" + af.size() + " матчей; предварительная оценка\n";
    }

    private double mean(ArrayList<Double> values) {
        double sum = 0; for (double v : values) sum += v; return sum / values.size();
    }
    private double sampleVariance(ArrayList<Double> values) {
        if (values.size() < 2) return 1.0;
        double m = mean(values), sum = 0;
        for (double v : values) { double d = v - m; sum += d * d; }
        return sum / (values.size() - 1);
    }
    private double normalCdf(double x) {
        double t = 1.0 / (1.0 + 0.2316419 * Math.abs(x));
        double d = 0.3989423 * Math.exp(-x * x / 2.0);
        double tail = d * t * (0.3193815 + t * (-0.3565638 + t * (1.781478 + t * (-1.821256 + t * 1.330274))));
        return x >= 0 ? 1.0 - tail : tail;
    }
    // P(X >= line+1), exact integer boundary for a half-line N.5.
    private double countOverProbability(int line, double mean, double variance) {
        double cdf;
        if (variance > mean + 0.05) {
            double r = mean * mean / (variance - mean);
            double p = r / (r + mean);
            double term = Math.pow(p, r);
            cdf = term;
            for (int k = 1; k <= line; k++) {
                term *= ((k - 1 + r) / k) * (1.0 - p);
                cdf += term;
            }
        } else {
            double term = Math.exp(-mean);
            cdf = term;
            for (int k = 1; k <= line; k++) {
                term *= mean / k;
                cdf += term;
            }
        }
        return Math.max(0.0, Math.min(1.0, 1.0 - cdf));
    }

    private double combinedAvg(TeamStats h, TeamStats a, String key) {
        if(h.values(key)==null||a.values(key)==null||h.values(key).size()<3||a.values(key).size()<3) return Double.NaN;
        return h.metricAvg(key)+a.metricAvg(key);
    }

    // API-Football key is stored locally on this device, never embedded in the APK.
    private String apiFootballKey() {
        return apiPrefs == null ? "" : apiPrefs.getString("api_football_key", "");
    }

    private JSONObject apiFootballRequest(String path) throws Exception {
        String k = apiFootballKey();
        if (k.isEmpty()) throw new IOException("Не введён API-Football ключ. Вставь его вверху приложения и нажми «Сохранить ключ».");
        HttpURLConnection c = null;
        try {
            URL url = new URL("https://v3.football.api-sports.io/" + path);
            c = (HttpURLConnection) url.openConnection();
            c.setRequestMethod("GET");
            c.setConnectTimeout(12000);
            c.setReadTimeout(18000);
            c.setRequestProperty("x-apisports-key", k);
            c.setRequestProperty("Accept", "application/json");
            int code = c.getResponseCode();
            InputStream in = (code >= 200 && code < 300) ? c.getInputStream() : c.getErrorStream();
            if (in == null) throw new IOException("API-Football HTTP " + code);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            try (InputStream stream = in) {
                byte[] buf = new byte[8192]; int n;
                while ((n = stream.read(buf)) != -1) out.write(buf, 0, n);
            }
            JSONObject j = new JSONObject(out.toString("UTF-8"));
            if (code < 200 || code >= 300) throw new IOException("API-Football HTTP " + code + ": " + j.opt("errors"));
            Object errors = j.opt("errors");
            if (errors != null && errors != JSONObject.NULL && !errors.toString().equals("{}") && !errors.toString().equals("[]"))
                throw new IOException("API-Football: " + errors.toString());
            return j;
        } finally { if (c != null) c.disconnect(); }
    }

    private void testApiFootballKey() {
        String k = apiKeyField == null ? "" : apiKeyField.getText().toString().trim();
        if (k.isEmpty()) { Toast.makeText(this, "Сначала вставь API-Football ключ", Toast.LENGTH_LONG).show(); return; }
        apiPrefs.edit().putString("api_football_key", k).apply();
        Toast.makeText(this, "Проверяю ключ…", Toast.LENGTH_SHORT).show();
        worker.execute(() -> {
            try {
                JSONObject j = apiFootballRequest("status");
                JSONObject response = j.optJSONObject("response");
                String msg = "API-Football подключён";
                if (response != null) {
                    JSONObject requests = response.optJSONObject("requests");
                    if (requests != null) msg += ". Запросов сегодня: " + requests.optInt("current") + "/" + requests.optInt("limit_day");
                }
                final String result = msg;
                ui.post(() -> Toast.makeText(this, result, Toast.LENGTH_LONG).show());
            } catch (Exception e) {
                final String msg = "Ошибка API-Football: " + e.getMessage();
                ui.post(() -> Toast.makeText(this, msg, Toast.LENGTH_LONG).show());
            }
        });
    }

    private String apiSearchSafe(String name) {
        String value = Normalizer.normalize(name == null ? "" : name, Normalizer.Form.NFD)
                .replaceAll("\\p{M}+", "");
        value = value.replaceAll("[^A-Za-z0-9 ]", " ").replaceAll("\\s+", " ").trim();
        return value;
    }

    private String apiNorm(String name) {
        return apiSearchSafe(name).toLowerCase(Locale.ROOT).replace(" ", "");
    }

    private JSONObject apiFindTeam(String name) throws Exception {
        String safeName = apiSearchSafe(name);
        if (safeName.isEmpty()) throw new IOException("Название команды не подходит для поиска API-Football: " + name);
        JSONObject j = apiFootballRequest("teams?search=" + URLEncoder.encode(safeName, "UTF-8"));
        JSONArray arr = j.optJSONArray("response");
        if (arr == null || arr.length() == 0) throw new IOException("API-Football не нашёл команду: " + name);
        JSONObject selected = null;
        for (int i=0; i<arr.length(); i++) {
            JSONObject team = arr.optJSONObject(i) == null ? null : arr.optJSONObject(i).optJSONObject("team");
            if (team == null) continue;
            if (name.equalsIgnoreCase(team.optString("name")) || apiNorm(name).equals(apiNorm(team.optString("name")))) {
                selected = team; break;
            }
            if (selected == null) selected = team;
        }
        if (selected == null) throw new IOException("Не удалось определить команду: " + name);
        return selected;
    }

    private Double apiStatValue(JSONArray stats, String... names) {
        if (stats == null) return null;
        for (int i=0; i<stats.length(); i++) {
            JSONObject st = stats.optJSONObject(i); if (st == null) continue;
            String type = st.optString("type", "");
            boolean wanted = false;
            for (String n : names) if (n.equalsIgnoreCase(type)) wanted = true;
            if (!wanted) continue;
            Object value = st.opt("value");
            if (value == null || value == JSONObject.NULL) return null;
            try { return Double.parseDouble(value.toString().replace("%", "").replace(",", "")); }
            catch (Exception ignored) { return null; }
        }
        return null;
    }

    private boolean apiDatesNear(String a, String b) {
        if (a == null || b == null || a.length() < 10 || b.length() < 10) return false;
        if (a.substring(0,10).equals(b.substring(0,10))) return true;
        try {
            SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
            Calendar ca = Calendar.getInstance(), cb = Calendar.getInstance();
            ca.setTime(f.parse(a.substring(0,10))); cb.setTime(f.parse(b.substring(0,10)));
            long days = Math.abs(ca.getTimeInMillis() - cb.getTimeInMillis()) / 86400000L;
            return days <= 1;
        } catch (Exception ignored) { return false; }
    }

    private Map<String,Map<String,Double>> loadApiFootballFallback(String home, String away,
            List<String[]> rows, Map<String,Integer> ix) {
        Map<String,Map<String,Double>> out = new HashMap<>();
        apiFootballDiagnostic = "API-Football: ";
        if (apiFootballKey().isEmpty()) {
            apiFootballDiagnostic += "ключ не сохранён";
            return out;
        }
        int fixtureCount = 0, statsCount = 0;
        try {
            for (String requestedTeam : new String[]{home, away}) {
                JSONObject team = apiFindTeam(requestedTeam);
                int teamId = team.optInt("id");
                if (teamId <= 0) throw new IOException("не найден ID команды " + requestedTeam);
                int season = Calendar.getInstance().get(Calendar.YEAR);
                if (Calendar.getInstance().get(Calendar.MONTH) < Calendar.JULY) season--;
                JSONObject fixturesJson = apiFootballRequest("fixtures?team=" + teamId + "&last=20&season=" + season);
                JSONArray fixtures = fixturesJson.optJSONArray("response");
                if (fixtures == null || fixtures.length() == 0) {
                    fixturesJson = apiFootballRequest("fixtures?team=" + teamId + "&last=20&season=" + (season - 1));
                    fixtures = fixturesJson.optJSONArray("response");
                }
                if (fixtures == null) continue;
                for (int i=0; i<fixtures.length(); i++) {
                    JSONObject fixture = fixtures.optJSONObject(i); if (fixture == null) continue;
                    JSONObject fx = fixture.optJSONObject("fixture");
                    JSONObject teams = fixture.optJSONObject("teams");
                    if (fx == null || teams == null) continue;
                    int fixtureId = fx.optInt("id");
                    JSONObject ht = teams.optJSONObject("home"), at = teams.optJSONObject("away");
                    if (fixtureId <= 0 || ht == null || at == null) continue;
                    String hName = ht.optString("name"), aName = at.optString("name");
                    String apiDate = fx.optString("date", "");
                    if (apiDate.length() < 10) continue;

                    // Find the corresponding open-matchday row. Team names can differ (Türkiye/Turkey),
                    // and API dates can shift by one day because of UTC/local time.
                    String[] matchedRow = null;
                    for (int ri=1; ri<rows.size(); ri++) {
                        String[] candidate = rows.get(ri);
                        if (sameTeam(hName, val(candidate,ix,"home"))
                                && sameTeam(aName, val(candidate,ix,"away"))
                                && apiDatesNear(apiDate, val(candidate,ix,"date"))) {
                            matchedRow = candidate; break;
                        }
                    }
                    if (matchedRow == null) continue;
                    fixtureCount++;
                    String csvDate = val(matchedRow,ix,"date");
                    String csvHome = val(matchedRow,ix,"home");
                    String csvAway = val(matchedRow,ix,"away");

                    JSONObject statJson = apiFootballRequest("fixtures/statistics?fixture=" + fixtureId);
                    JSONArray statRows = statJson.optJSONArray("response");
                    if (statRows == null) continue;
                    for (int si=0; si<statRows.length(); si++) {
                        JSONObject side = statRows.optJSONObject(si); if (side == null) continue;
                        JSONObject sideTeam = side.optJSONObject("team");
                        if (sideTeam == null) continue;
                        String sideName = sideTeam.optString("name");
                        String sideKey = sameTeam(sideName,hName) ? "home" :
                                sameTeam(sideName,aName) ? "away" : "";
                        if (sideKey.isEmpty()) continue;
                        JSONArray values = side.optJSONArray("statistics");
                        Map<String,Double> vals = new HashMap<>();
                        Double v = apiStatValue(values, "Corner Kicks", "Corners");
                        if (v != null) vals.put("corners", v);
                        v = apiStatValue(values, "Yellow Cards");
                        if (v != null) vals.put("yellow", v);
                        v = apiStatValue(values, "Shots on Goal", "Shots on Target");
                        if (v != null) vals.put("target", v);
                        v = apiStatValue(values, "Total Shots", "Shots");
                        if (v != null) vals.put("shots", v);
                        v = apiStatValue(values, "Fouls");
                        if (v != null) vals.put("fouls", v);
                        if (!vals.isEmpty()) {
                            String key = matchKey(csvDate,csvHome,csvAway) + "|" + sideKey;
                            out.put(key, vals); statsCount++;
                        }
                    }
                }
            }
            apiFootballDiagnostic += "найдено матчей для сверки: " + fixtureCount
                    + ", получено строк статистики: " + statsCount;
            if (statsCount == 0) apiFootballDiagnostic += ". Возможно, API-тариф не отдаёт статистику этих матчей.";
        } catch (Exception e) {
            apiFootballDiagnostic += "ошибка: " + e.getMessage();
        }
        return out;
    }

    // Build the team's last-10 form directly from API-Football, across ALL competitions.
    // Upcoming fixture itself is not used; only completed historical fixtures are requested.
    // Load last 10 completed matches for both teams, then fetch all fixture statistics
    // in ONE bulk request (API-Football supports up to 20 fixture IDs per request).
    // Load the selected number of recent completed fixtures for both teams.
    // API-Football fixture statistics are fetched through the dedicated statistics endpoint.
    private Map<String,TeamStats> loadApiFootballHistories(String homeName, String awayName) throws Exception {
        JSONObject homeTeam = apiFindTeam(homeName);
        JSONObject awayTeam = apiFindTeam(awayName);
        int homeId = homeTeam.optInt("id"), awayId = awayTeam.optInt("id");
        if (homeId <= 0 || awayId <= 0) throw new IOException("Не удалось определить ID обеих команд");

        int limit = selectedMatchCount;
        TeamStats homeStats = new TeamStats(), awayStats = new TeamStats();
        Map<Integer,Set<Integer>> fixturesByTeam = new HashMap<>();
        LinkedHashSet<Integer> allFixtureIds = new LinkedHashSet<>();
        int[] teamIds = new int[]{homeId, awayId};
        TeamStats[] teamStats = new TeamStats[]{homeStats, awayStats};

        for (int ti=0; ti<teamIds.length; ti++) {
            int teamId = teamIds[ti];
            JSONObject fixturesJson = apiFootballRequest("fixtures?team=" + teamId + "&last=" + limit);
            JSONArray fixtures = fixturesJson.optJSONArray("response");
            if (fixtures == null || fixtures.length() == 0)
                throw new IOException("API не вернул историю матчей для " + (ti==0?homeName:awayName));

            for (int fi=0; fi<fixtures.length() && teamStats[ti].played<limit; fi++) {
                JSONObject item = fixtures.optJSONObject(fi); if (item == null) continue;
                JSONObject fx = item.optJSONObject("fixture");
                JSONObject teams = item.optJSONObject("teams");
                JSONObject goals = item.optJSONObject("goals");
                if (fx == null || teams == null || goals == null) continue;
                JSONObject status = fx.optJSONObject("status");
                String state = status == null ? "" : status.optString("short","");
                if (!("FT".equals(state) || "AET".equals(state) || "PEN".equals(state))) continue;
                JSONObject hTeam = teams.optJSONObject("home"), aTeam = teams.optJSONObject("away");
                if (hTeam == null || aTeam == null) continue;
                boolean isHome = hTeam.optInt("id") == teamId;
                int gf = goals.optInt(isHome ? "home" : "away", -1);
                int ga = goals.optInt(isHome ? "away" : "home", -1);
                int fixtureId = fx.optInt("id");
                if (gf < 0 || ga < 0 || fixtureId <= 0) continue;

                TeamStats st = teamStats[ti];
                st.played++; st.goalsFor += gf; st.goalsAgainst += ga;
                if (gf > ga) st.wins++; else if (gf == ga) st.draws++; else st.losses++;
                allFixtureIds.add(fixtureId);
                if (!fixturesByTeam.containsKey(teamId)) fixturesByTeam.put(teamId,new HashSet<Integer>());
                fixturesByTeam.get(teamId).add(fixtureId);
            }
        }
        if (homeStats.played == 0 || awayStats.played == 0)
            throw new IOException("Не удалось получить завершённые матчи обеих команд");

        int statsFixtureCount = 0;
        // Statistics endpoint returns both teams for one fixture. Avoid duplicate calls
        // when the two teams have faced each other within the selected sample.
        for (Integer fixtureId : allFixtureIds) {
            JSONObject statJson = apiFootballRequest("fixtures/statistics?fixture=" + fixtureId);
            JSONArray statRows = statJson.optJSONArray("response");
            if (statRows == null) continue;
            for (int si=0; si<statRows.length(); si++) {
                JSONObject side = statRows.optJSONObject(si); if (side == null) continue;
                JSONObject sideTeam = side.optJSONObject("team"); if (sideTeam == null) continue;
                int sideTeamId = sideTeam.optInt("id");
                Set<Integer> teamFixtures = fixturesByTeam.get(sideTeamId);
                if (teamFixtures == null || !teamFixtures.contains(fixtureId)) continue;
                TeamStats target = sideTeamId == homeId ? homeStats : sideTeamId == awayId ? awayStats : null;
                if (target == null) continue;
                JSONArray values = side.optJSONArray("statistics");
                Double v = apiStatValue(values, "Corner Kicks", "Corners"); if (v != null) target.addMetric("corners",v);
                v = apiStatValue(values, "Yellow Cards"); if (v != null) target.addMetric("yellow",v);
                v = apiStatValue(values, "Shots on Goal", "Shots on Target"); if (v != null) target.addMetric("target",v);
                v = apiStatValue(values, "Total Shots", "Shots"); if (v != null) target.addMetric("shots",v);
                v = apiStatValue(values, "Fouls"); if (v != null) target.addMetric("fouls",v);
                statsFixtureCount++;
            }
        }

        int hc = homeStats.values("corners")==null?0:homeStats.values("corners").size();
        int ac = awayStats.values("corners")==null?0:awayStats.values("corners").size();
        apiFootballDiagnostic = "API-Football: выборка " + limit + " матчей; поиск команд: " + apiSearchSafe(homeName) + " / " + apiSearchSafe(awayName) + ". "
                + homeName + ": сыграно " + homeStats.played + ", статистика угловых в " + hc + " матчах; "
                + awayName + ": сыграно " + awayStats.played + ", статистика угловых в " + ac
                + " матчах. Статистических строк получено: " + statsFixtureCount + ".";
        Map<String,TeamStats> result = new HashMap<>();
        result.put("home",homeStats);
        result.put("away",awayStats);
        return result;
    }

    private TeamStats loadApiFootballTeamHistory(String requestedTeam) throws Exception {
        JSONObject team = apiFindTeam(requestedTeam);
        int teamId = team.optInt("id");
        if (teamId <= 0) throw new IOException("не найден ID команды " + requestedTeam);

        int season = Calendar.getInstance().get(Calendar.YEAR);
        if (Calendar.getInstance().get(Calendar.MONTH) < Calendar.JULY) season--;
        JSONObject fixturesJson = apiFootballRequest("fixtures?team=" + teamId + "&last=10&season=" + season);
        JSONArray fixtures = fixturesJson.optJSONArray("response");
        if (fixtures == null || fixtures.length() == 0) {
            fixturesJson = apiFootballRequest("fixtures?team=" + teamId + "&last=10&season=" + (season - 1));
            fixtures = fixturesJson.optJSONArray("response");
        }
        if (fixtures == null || fixtures.length() == 0)
            throw new IOException("API-Football не вернул предыдущие матчи для " + requestedTeam + " (сезоны " + season + " и " + (season-1) + ")");

        TeamStats stats = new TeamStats();
        int statsFixtures = 0;
        for (int i=0; i<fixtures.length() && stats.played<10; i++) {
            JSONObject fixture = fixtures.optJSONObject(i); if (fixture == null) continue;
            JSONObject fx = fixture.optJSONObject("fixture");
            JSONObject teams = fixture.optJSONObject("teams");
            JSONObject goals = fixture.optJSONObject("goals");
            if (fx == null || teams == null || goals == null) continue;
            JSONObject status = fx.optJSONObject("status");
            String shortStatus = status == null ? "" : status.optString("short","");
            if (!("FT".equals(shortStatus) || "AET".equals(shortStatus) || "PEN".equals(shortStatus))) continue;

            JSONObject h = teams.optJSONObject("home"), a = teams.optJSONObject("away");
            if (h == null || a == null) continue;
            boolean isHome = h.optInt("id") == teamId;
            int gf = goals.optInt(isHome ? "home" : "away", -1);
            int ga = goals.optInt(isHome ? "away" : "home", -1);
            if (gf < 0 || ga < 0) continue;

            stats.played++;
            stats.goalsFor += gf;
            stats.goalsAgainst += ga;
            if (gf > ga) stats.wins++; else if (gf == ga) stats.draws++; else stats.losses++;

            int fixtureId = fx.optInt("id");
            if (fixtureId <= 0) continue;
            JSONObject statJson = apiFootballRequest("fixtures/statistics?fixture=" + fixtureId);
            JSONArray statRows = statJson.optJSONArray("response");
            if (statRows == null || statRows.length() == 0) continue;
            JSONObject row = null;
            for (int si=0; si<statRows.length(); si++) {
                JSONObject candidate = statRows.optJSONObject(si);
                JSONObject candidateTeam = candidate == null ? null : candidate.optJSONObject("team");
                if (candidateTeam != null && candidateTeam.optInt("id") == teamId) {
                    row = candidate; break;
                }
            }
            if (row == null) continue;
            JSONArray values = row.optJSONArray("statistics");
            Double v = apiStatValue(values, "Corner Kicks", "Corners"); if (v != null) stats.addMetric("corners",v);
            v = apiStatValue(values, "Yellow Cards"); if (v != null) stats.addMetric("yellow",v);
            v = apiStatValue(values, "Shots on Goal", "Shots on Target"); if (v != null) stats.addMetric("target",v);
            v = apiStatValue(values, "Total Shots", "Shots"); if (v != null) stats.addMetric("shots",v);
            v = apiStatValue(values, "Fouls"); if (v != null) stats.addMetric("fouls",v);
            statsFixtures++;
        }
        apiFootballDiagnostic = "API-Football: " + requestedTeam + " — форма по " + stats.played
                + " последним матчам из всех турниров; статистика получена для " + statsFixtures + " матчей.";
        if (stats.played == 0) throw new IOException("нет завершённых матчей в ответе API для " + requestedTeam);
        return stats;
    }

    // ===== Сборные: последние N матчей по ВСЕМ турнирам (ESPN scoreboard по месяцам, от новых к старым) =====
    private static final String[] NATIONAL_SLUGS = {"uefa.nations","fifa.friendly","fifa.worldq.uefa","uefa.euroq","uefa.euro","fifa.world"};
    private final Map<String,JSONObject> boardCache = new ConcurrentHashMap<>();

    private static class NatCand {
        String slug="", date="", h="", a="", hs="", as="";
        JSONObject ev, hSide, aSide;
    }

    // "Ireland" не должна совпадать с "Northern Ireland", а "Niger" с "Nigeria": для сборных только точное совпадение.
    private boolean sameNation(String a, String b) {
        String x = normTeam(a), y = normTeam(b);
        return !x.isEmpty() && x.equals(y);
    }

    private JSONObject cachedBoard(String slug, String month, boolean cacheable) {
        String ck = slug + "|" + month;
        JSONObject c = boardCache.get(ck);
        if (c != null) return c;
        try {
            JSONObject b = fetchJson("https://site.api.espn.com/apis/site/v2/sports/soccer/" + slug + "/scoreboard?dates=" + month + "&limit=500");
            if (cacheable) boardCache.put(ck, b);   // текущий месяц не кэшируем: он ещё меняется
            return b;
        } catch (Exception e) { return null; }
    }

    private String scoreText(JSONObject side) {
        Object sc = side.opt("score");
        if (sc instanceof JSONObject) return ((JSONObject) sc).optString("displayValue", "");
        return sc == null || sc == JSONObject.NULL ? "" : sc.toString();
    }

    private String statCell(Map<String,Double> m, String key) {
        Double v = m.get(key);
        return v == null ? "" : String.valueOf(Math.round(v));
    }

    private void putMissing(Map<String,Double> target, Map<String,Double> source) {
        if (source == null) return;
        for (Map.Entry<String,Double> e : source.entrySet()) if (!target.containsKey(e.getKey())) target.put(e.getKey(), e.getValue());
    }

    private boolean hasAllStats(Map<String,Double> m) {
        for (String k : new String[]{"corners","yellow","target","shots","fouls"}) if (!m.containsKey(k)) return false;
        return true;
    }

    private List<String[]> loadNationalHistory(String home, String away) {
        List<String[]> rows = new ArrayList<>();
        rows.add(new String[]{"gw","date","time","home","away","ft_home","ft_away","ft_result",
                "home_corners","away_corners","home_yellow","away_yellow","home_target","away_target",
                "home_shots","away_shots","home_fouls","away_fouls"});
        final int need = selectedMatchCount;
        int hCount = 0, aCount = 0;
        Set<String> seen = new HashSet<>();
        SimpleDateFormat monthFmt = new SimpleDateFormat("yyyyMM", Locale.US);
        Calendar cur = Calendar.getInstance();
        ExecutorService pool = Executors.newFixedThreadPool(NATIONAL_SLUGS.length);
        try {
            for (int back = 0; back < 24 && (hCount < need || aCount < need); back++, cur.add(Calendar.MONTH, -1)) {
                final String month = monthFmt.format(cur.getTime());
                final boolean cacheable = back > 0;
                List<Future<JSONObject>> futures = new ArrayList<>();
                for (final String slug : NATIONAL_SLUGS) futures.add(pool.submit(() -> cachedBoard(slug, month, cacheable)));

                List<NatCand> cands = new ArrayList<>();
                for (int si = 0; si < futures.size(); si++) {
                    JSONObject board;
                    try { board = futures.get(si).get(); } catch (Exception e) { continue; }
                    JSONArray events = board == null ? null : board.optJSONArray("events");
                    if (events == null) continue;
                    for (int i = 0; i < events.length(); i++) {
                        JSONObject ev = events.optJSONObject(i); if (ev == null) continue;
                        JSONArray comps = ev.optJSONArray("competitions"); if (comps == null || comps.length() == 0) continue;
                        JSONObject comp = comps.optJSONObject(0); if (comp == null) continue;
                        JSONObject statusObj = comp.optJSONObject("status");
                        if (statusObj == null) statusObj = ev.optJSONObject("status");
                        JSONObject type = statusObj == null ? null : statusObj.optJSONObject("type");
                        if (type == null || !type.optBoolean("completed", false)) continue;
                        JSONArray sides = comp.optJSONArray("competitors"); if (sides == null) continue;
                        NatCand c = new NatCand(); c.slug = NATIONAL_SLUGS[si]; c.ev = ev;
                        boolean hasHome = false, hasAway = false;
                        for (int j = 0; j < sides.length(); j++) {
                            JSONObject side = sides.optJSONObject(j); if (side == null) continue;
                            JSONObject team = side.optJSONObject("team");
                            String name = team == null ? "" : team.optString("displayName", team.optString("name", ""));
                            if ("home".equalsIgnoreCase(side.optString("homeAway"))) { c.h = name; c.hs = scoreText(side); c.hSide = side; hasHome = true; }
                            else { c.a = name; c.as = scoreText(side); c.aSide = side; hasAway = true; }
                        }
                        if (!hasHome || !hasAway || c.h.isEmpty() || c.a.isEmpty() || c.hs.isEmpty() || c.as.isEmpty()) continue;
                        String d = ev.optString("date", "");
                        if (d.length() < 10) continue;
                        c.date = d.substring(0, 10);
                        boolean involved = sameNation(home, c.h) || sameNation(home, c.a) || sameNation(away, c.h) || sameNation(away, c.a);
                        if (!involved) continue;
                        if (!seen.add(c.date + "|" + normTeam(c.h) + "|" + normTeam(c.a))) continue;
                        cands.add(c);
                    }
                }
                Collections.sort(cands, (x, y) -> y.date.compareTo(x.date));   // новые первыми

                for (NatCand c : cands) {
                    boolean forHome = sameNation(home, c.h) || sameNation(home, c.a);
                    boolean forAway = sameNation(away, c.h) || sameNation(away, c.a);
                    if (!((forHome && hCount < need) || (forAway && aCount < need))) continue;
                    if (forHome) hCount++;
                    if (forAway) aCount++;

                    Map<String,Double> hm = new HashMap<>(), am = new HashMap<>();
                    mergeEspnStats(hm, parseEspnCompetitorStats(c.hSide));
                    mergeEspnStats(am, parseEspnCompetitorStats(c.aSide));
                    Map<String,Integer> yellow = parseEspnYellowCards(c.ev);
                    String hid = c.hSide.optString("id", ""), aid = c.aSide.optString("id", "");
                    if (yellow.containsKey(hid)) hm.put("yellow", (double) yellow.get(hid));
                    if (yellow.containsKey(aid)) am.put("yellow", (double) yellow.get(aid));
                    if (!hasAllStats(hm) || !hasAllStats(am)) {
                        String eventId = c.ev.optString("id", "");
                        if (!eventId.isEmpty()) {
                            try {
                                JSONObject summary = fetchJson("https://site.api.espn.com/apis/site/v2/sports/soccer/" + c.slug + "/summary?event=" + eventId);
                                JSONObject box = summary.optJSONObject("boxscore");
                                JSONArray teams = box == null ? null : box.optJSONArray("teams");
                                if (teams != null) for (int j = 0; j < teams.length(); j++) {
                                    JSONObject tb = teams.optJSONObject(j); if (tb == null) continue;
                                    JSONObject t = tb.optJSONObject("team");
                                    String tn = t == null ? "" : t.optString("displayName", t.optString("name", ""));
                                    if (sameNation(c.h, tn)) putMissing(hm, parseEspnTeamStats(tb));
                                    else if (sameNation(c.a, tn)) putMissing(am, parseEspnTeamStats(tb));
                                }
                            } catch (Exception ignored) { }
                        }
                    }
                    int hsInt, asInt;
                    String result = "";
                    try { hsInt = Integer.parseInt(c.hs); asInt = Integer.parseInt(c.as); result = hsInt > asInt ? "H" : hsInt < asInt ? "A" : "D"; }
                    catch (Exception ignored) { continue; }
                    rows.add(new String[]{c.slug, c.date, "", c.h, c.a, c.hs, c.as, result,
                            statCell(hm,"corners"), statCell(am,"corners"), statCell(hm,"yellow"), statCell(am,"yellow"),
                            statCell(hm,"target"), statCell(am,"target"), statCell(hm,"shots"), statCell(am,"shots"),
                            statCell(hm,"fouls"), statCell(am,"fouls")});
                }
            }
        } finally { pool.shutdownNow(); }
        return rows;
    }

    private double[] toArr(ArrayList<Double> list) {
        if (list == null) return null;
        double[] r = new double[list.size()];
        for (int i = 0; i < r.length; i++) r[i] = list.get(i);
        return r;
    }

    // Средние голы хозяев/гостей по всей лиге (из сыгранных матчей CSV); при малой выборке - типичные значения.
    private double[] leagueGoalAverages(List<String[]> rows, Map<String,Integer> ix) {
        double sh = 0, sa = 0; int n = 0;
        for (int i = 1; i < rows.size(); i++) {
            Double gh = number(rows.get(i), ix, "ft_home"), ga = number(rows.get(i), ix, "ft_away");
            if (gh == null || ga == null) continue;
            sh += gh; sa += ga; n++;
        }
        return n >= 30 ? new double[]{sh / n, sa / n} : new double[]{1.45, 1.15};
    }

    // Среднее значение показателя на одну команду за матч по всей лиге; если данных мало - типичное значение.
    private double leagueMetricMean(List<String[]> rows, Map<String,Integer> ix, String metric, double fallback, boolean national) {
        if (national) return fallback;
        double sum = 0; int n = 0;
        for (int i = 1; i < rows.size(); i++) {
            Double hv = number(rows.get(i), ix, "home_" + metric), av = number(rows.get(i), ix, "away_" + metric);
            if (hv != null) { sum += hv; n++; }
            if (av != null) { sum += av; n++; }
        }
        return n >= 60 ? sum / n : fallback;
    }

    private String makeReport(League league, String home, String away, List<String[]> rows) {
        final boolean national = "UEFA_NATIONS_LEAGUE".equals(league.folder);
        if (national) rows = loadNationalHistory(home, away);
        if (rows == null || rows.size() < 2) return "⚠️ АНАЛИЗ НЕВОЗМОЖЕН\nНет опубликованных сыгранных матчей этой лиги.";
        Map<String,Integer> ix = headerIndex(rows.get(0));
        Map<String,Map<String,Double>> supplemental = national
                ? new HashMap<String,Map<String,Double>>()
                : loadEspnFallback(league,home,away,rows,ix);
        TeamStats h=collectTeam(home,rows,ix,supplemental), a=collectTeam(away,rows,ix,supplemental);
        if (!apiFootballKey().isEmpty()) {
            try {
                Map<String,TeamStats> apiHistory = loadApiFootballHistories(home, away);
                TeamStats apiHome = apiHistory.get("home");
                TeamStats apiAway = apiHistory.get("away");
                h = mergeTeamStats(h, apiHome);
                a = mergeTeamStats(a, apiAway);
            } catch (Exception apiError) {
                apiFootballDiagnostic = "API-Football: " + apiError.getMessage()
                        + ". Показана доступная статистика основного источника.";
            }
        }
        StringBuilder out = new StringBuilder();
        out.append("━━━━━━━━━━━━━━━━━━\n⚽ АНАЛИЗ МАТЧА\n").append(home).append(" — ").append(away).append("\n━━━━━━━━━━━━━━━━━━\n");
        out.append("🔌 ").append(apiFootballDiagnostic).append("\n");
        if (national) out.append("🌍 Сборные: в выборку входят матчи всех турниров (Лига наций, товарищеские, отбор, ЧЕ, ЧМ) по данным ESPN.\n");
        out.append("━━━━━━━━━━━━━━━━━━\n\n");
        out.append("📈 1. ГОЛЫ И ФОРМА КОМАНД\n");
        out.append("🏠 ").append(home).append("\n");
        out.append("   Сыграно матчей: ").append(h.played).append(" из ").append(selectedMatchCount).append("\n");
        out.append("   Забито: ").append(oneDecimal(h.goalsFor)).append(" всего · ").append(oneDecimal(h.avgGoalsFor())).append(" за матч\n");
        out.append("   Пропущено: ").append(oneDecimal(h.goalsAgainst)).append(" всего · ").append(oneDecimal(h.avgGoalsAgainst())).append(" за матч\n");
        out.append("   Результаты: ").append(h.form()).append("\n\n");
        out.append("✈️ ").append(away).append("\n");
        out.append("   Сыграно матчей: ").append(a.played).append(" из ").append(selectedMatchCount).append("\n");
        out.append("   Забито: ").append(oneDecimal(a.goalsFor)).append(" всего · ").append(oneDecimal(a.avgGoalsFor())).append(" за матч\n");
        out.append("   Пропущено: ").append(oneDecimal(a.goalsAgainst)).append(" всего · ").append(oneDecimal(a.avgGoalsAgainst())).append(" за матч\n");
        out.append("   Результаты: ").append(a.form()).append("\n\n");
        out.append("📊 2. ДЕТАЛЬНАЯ СТАТИСТИКА ПО КОМАНДАМ\n");
        out.append(metricSection("🚩","Угловые","corners",h,a,home,away)).append("\n");
        out.append(metricSection("🟨","Жёлтые карточки","yellow",h,a,home,away)).append("\n");
        out.append(metricSection("🎯","Удары в створ","target",h,a,home,away)).append("\n");
        out.append(metricSection("🥅","Все удары по воротам","shots",h,a,home,away)).append("\n");
        out.append(metricSection("🤼","Фолы","fouls",h,a,home,away)).append("\n");
        out.append("🔌 ").append(apiFootballDiagnostic).append("\n\n");
        out.append("↗️ Вбрасывания из аута\n   Источник open-matchday не публикует эту статистику — цифры не подставляются.\n\n");
        out.append("🔮 3. ПРОГНОЗЫ ТОТАЛОВ НА МАТЧ\n");
        if(h.played<3||a.played<3) {
            out.append("⚠️ Для надёжного расчёта пока мало матчей: нужно минимум 3 сыгранных матча каждой команды.\n");
        } else {
            double[] lg = national ? new double[]{1.45, 1.15} : leagueGoalAverages(rows, ix);
            double[] xg = ForecastModel.expectedGoals(h.goalsFor, h.goalsAgainst, h.played, a.goalsFor, a.goalsAgainst, a.played, lg[0], lg[1]);
            out.append(ForecastModel.goalsBlock(home, away, xg[0], xg[1], Math.min(h.played, a.played)));
            out.append("\n🚩 УГЛОВЫЕ\n").append(ForecastModel.countBlock("Тотал угловых", toArr(h.values("corners")), toArr(a.values("corners")),
                    toArr(h.concededValues("corners")), toArr(a.concededValues("corners")), leagueMetricMean(rows, ix, "corners", 5.0, national), 1.05));
            out.append("\n🟨 ЖЁЛТЫЕ КАРТОЧКИ\n").append(ForecastModel.countBlock("Тотал карточек", toArr(h.values("yellow")), toArr(a.values("yellow")),
                    null, null, leagueMetricMean(rows, ix, "yellow", 2.0, national), 1.2));
            out.append("\n🤼 ФОЛЫ\n").append(ForecastModel.countBlock("Тотал фолов", toArr(h.values("fouls")), toArr(a.values("fouls")),
                    null, null, leagueMetricMean(rows, ix, "fouls", 12.0, national), 1.05));
            out.append("\n🎯 УДАРЫ В СТВОР\n").append(ForecastModel.countBlock("Тотал ударов в створ", toArr(h.values("target")), toArr(a.values("target")),
                    null, null, leagueMetricMean(rows, ix, "target", 4.2, national), 1.15));
            out.append("\n🥅 ВСЕ УДАРЫ\n").append(ForecastModel.countBlock("Тотал всех ударов", toArr(h.values("shots")), toArr(a.values("shots")),
                    null, null, leagueMetricMean(rows, ix, "shots", 12.5, national), 1.2));
        }
        out.append("\n━━━━━━━━━━━━━━━━━━\nℹ️ КАК ЧИТАТЬ ПРОГНОЗ\n🔼 Больше — вероятность превышения указанной линии. 🔽 Меньше — вероятность остаться ниже неё. Это математическая оценка по средним показателям последних матчей, не гарантия и не букмекерские коэффициенты.\n");
        out.append("Модель: голы — Пуассон с поправкой Диксона–Коулса, силы атаки и обороны относительно среднего по лиге со сглаживанием; угловые, карточки, фолы и удары — сглаженное среднее и отрицательное биномиальное распределение, линии подбираются вокруг ожидаемого значения. «Уверенность» зависит от размера выборки.\n");
        out.append("Сначала используются данные open-matchday; если отдельные показатели отсутствуют, приложение пытается найти их в публичном ESPN API без ключа. Если ESPN не покрывает матч или турнир, статистика остаётся пустой. Угловые, карточки, удары и фолы доступны не для всех матчей. Вбрасывания из аута в этом источнике отсутствуют.\n");
        out.append("Выборка: ").append(h.played).append(" матчей — ").append(home).append("; ").append(a.played).append(" — ").append(away).append(". Результаты open-matchday обновляются примерно раз в сутки; резервная статистика ESPN может обновляться чаще. Источники: open-matchday и ESPN.");
        return translateReport(out.toString());
    }

    private double[] poissonOutcome(double lh,double la) {
        double home=0,draw=0,away=0;
        for(int i=0;i<=12;i++) for(int j=0;j<=12;j++) {
            double p=poisson(i,lh)*poisson(j,la);
            if(i>j) home+=p; else if(i==j) draw+=p; else away+=p;
        }
        double sum=home+draw+away; return new double[]{home/sum,draw/sum,away/sum};
    }
    private double poisson(int k,double lambda) { return Math.exp(-lambda)*Math.pow(lambda,k)/factorial(k); }
    private double factorial(int n) { double x=1; for(int i=2;i<=n;i++)x*=i; return x; }
    private double poissonCdf(int max,double lambda) { double p=0; for(int i=0;i<=max;i++)p+=poisson(i,lambda); return Math.max(0,Math.min(1,p)); }
    private String pct(double v) { return String.format(Locale.US,"%.0f%%",v*100); }
    private String fmt(double v) { return String.format(Locale.US,"%.2f",v); }
    private String avg(List<Double> a) { if(a==null||a.isEmpty())return "нет данных"; double s=0; for(double v:a)s+=v; return String.format(Locale.US,"%.1f",s/a.size()); }

    private void saveHistory(String item) {
        SharedPreferences p = getSharedPreferences("football_history", MODE_PRIVATE);
        try { JSONArray arr = new JSONArray(p.getString("items","[]")); arr.put(0,item); while(arr.length()>100) arr.remove(arr.length()-1); p.edit().putString("items",arr.toString()).apply(); }
        catch(Exception e) { p.edit().putString("items",new JSONArray().put(item).toString()).apply(); }
    }
    private void saveLearningForecast(String date, String league, String home, String away, String report) {
        SharedPreferences p = getSharedPreferences("football_learning", MODE_PRIVATE);
        try {
            JSONArray arr = new JSONArray(p.getString("records", "[]"));
            JSONObject item = new JSONObject();
            item.put("date", date);
            item.put("league", league);
            item.put("home", home);
            item.put("away", away);
            item.put("report", report == null ? "" : report);
            item.put("actual_entered", false);
            item.put("saved_at", System.currentTimeMillis());
            arr.put(item);
            while (arr.length() > 300) arr.remove(arr.length()-1);
            p.edit().putString("records", arr.toString()).apply();
        } catch (Exception ignored) { }
    }

    private void showLearning() {
        SharedPreferences p = getSharedPreferences("football_learning", MODE_PRIVATE);
        try {
            JSONArray arr = new JSONArray(p.getString("records", "[]"));
            int completed = 0;
            for (int i=0; i<arr.length(); i++) if (arr.optJSONObject(i) != null && arr.optJSONObject(i).optBoolean("actual_entered")) completed++;
            String summary = "Сохранено прогнозов: " + arr.length()
                    + "\nВнесено фактических результатов: " + completed
                    + "\n\nСохраняй анализ до матча, а после финального свистка внеси реальные показатели. Так мы соберём честную обучающую выборку."
                    + "\n\nДля первой калибровки желательно минимум 100 матчей. До накопления данных коэффициенты автоматически не меняются.";
            if (arr.length() == 0) {
                new AlertDialog.Builder(this).setTitle("🧠 AI LEARNING")
                        .setMessage(summary + "\n\nСначала сделай анализ и нажми «СОХРАНИТЬ АНАЛИЗ В ИСТОРИЮ».")
                        .setPositiveButton("OK", null).show();
                return;
            }
            String[] choices = new String[arr.length()];
            for (int i=0; i<arr.length(); i++) {
                JSONObject o = arr.optJSONObject(i);
                choices[i] = (o == null ? "Матч" : o.optString("date") + " · " + o.optString("home") + " — " + o.optString("away"))
                        + (o != null && o.optBoolean("actual_entered") ? "  ✓ результат внесён" : "  · ожидает результата");
            }
            AlertDialog dialog = new AlertDialog.Builder(this).setTitle("🧠 AI LEARNING")
                    .setMessage(summary + "\n\nВыбери матч, чтобы внести фактическую статистику.")
                    .setItems(choices, (d, which) -> showLearningResultEntry(which))
                    .setPositiveButton("Закрыть", null).create();
            dialog.show();
        } catch (Exception e) {
            new AlertDialog.Builder(this).setTitle("AI LEARNING").setMessage("Не удалось прочитать обучающую базу.")
                    .setPositiveButton("OK", null).show();
        }
    }

    private void showLearningResultEntry(int index) {
        SharedPreferences p = getSharedPreferences("football_learning", MODE_PRIVATE);
        try {
            JSONArray arr = new JSONArray(p.getString("records", "[]"));
            JSONObject record = arr.optJSONObject(index);
            if (record == null) return;
            LinearLayout panel = new LinearLayout(this);
            panel.setOrientation(LinearLayout.VERTICAL);
            panel.setPadding(dp(18), dp(8), dp(18), dp(4));
            panel.addView(label(record.optString("home") + " — " + record.optString("away"), 17, GREEN, true));
            EditText[] fields = new EditText[6];
            String[] names = {"Голы в матче", "Угловые всего", "Жёлтые карточки всего", "Удары в створ всего", "Все удары всего", "Фолы всего"};
            String[] keys = {"goals", "corners", "yellow", "target", "shots", "fouls"};
            JSONObject actual = record.optJSONObject("actual");
            for (int i=0; i<fields.length; i++) {
                TextView title = label(names[i], 14, Color.WHITE, true);
                panel.addView(title, lp(8, 2));
                fields[i] = new EditText(this);
                fields[i].setSingleLine(true);
                fields[i].setInputType(2);
                fields[i].setTextColor(Color.WHITE);
                fields[i].setHintTextColor(MUTED);
                fields[i].setHint("Введите фактическое число");
                fields[i].setBackground(shape(PANEL, 10));
                fields[i].setPadding(dp(12), dp(7), dp(12), dp(7));
                if (actual != null && actual.has(keys[i])) fields[i].setText(String.valueOf(actual.optInt(keys[i])));
                panel.addView(fields[i], lp(0, 2));
            }
            new AlertDialog.Builder(this).setTitle("Фактический результат")
                    .setView(panel).setNegativeButton("Отмена", null)
                    .setPositiveButton("Сохранить результат", (d,w) -> {
                        try {
                            JSONObject result = new JSONObject();
                            for (int i=0; i<fields.length; i++) {
                                String value = fields[i].getText().toString().trim();
                                if (!value.isEmpty()) result.put(keys[i], Integer.parseInt(value));
                            }
                            if (result.length() == 0) {
                                Toast.makeText(this, "Введи хотя бы один показатель", Toast.LENGTH_SHORT).show();
                                return;
                            }
                            record.put("actual", result);
                            record.put("actual_entered", true);
                            arr.put(index, record);
                            p.edit().putString("records", arr.toString()).apply();
                            Toast.makeText(this, "Результат добавлен в обучающую базу", Toast.LENGTH_LONG).show();
                        } catch (Exception ex) {
                            Toast.makeText(this, "Проверь введённые числа", Toast.LENGTH_SHORT).show();
                        }
                    }).show();
        } catch (Exception ignored) { }
    }

    private void stopRadioPlayer() {
        if (radioPlayer != null) {
            try { if (radioPlayer.isPlaying()) radioPlayer.stop(); } catch (Exception ignored) { }
            try { radioPlayer.reset(); radioPlayer.release(); } catch (Exception ignored) { }
            radioPlayer = null;
        }
        if (radioToggleButton != null) radioToggleButton.setText("▶ ВКЛЮЧИТЬ РАДИО");
        if (radioStatus != null) radioStatus.setText("Радио выключено");
    }

    private int radioStreamIndex = 0;
    private final String[] radioStreams = {
            "http://stream.europeanhitradio.com:8000/Stream_05.aac",
            "http://stream.europeanhitradio.com:8000/Stream_03.mp3",
            "http://stream.europeanhitradio.com:8000/ehr.mp3"
    };
    private final String[] radioStreamNames = {"FRESH", "TOP 40", "EUROPEAN HIT RADIO"};

    private void startRadioPlayer() {
        stopRadioPlayer();
        radioStreamIndex = 0;
        tryRadioStream();
    }

    private void tryRadioStream() {
        if (radioStreamIndex >= radioStreams.length) {
            radioToggleButton.setEnabled(true);
            radioStatus.setText("Не удалось подключиться ни к одному потоку. Проверь интернет или попробуй позже.");
            Toast.makeText(this, "Все потоки радио недоступны", Toast.LENGTH_LONG).show();
            return;
        }
        final int attempt = radioStreamIndex;
        radioStatus.setText("Подключаюсь: " + radioStreamNames[attempt] + " (" + (attempt + 1) + "/" + radioStreams.length + ")");
        radioToggleButton.setEnabled(false);
        try {
            radioPlayer = new MediaPlayer();
            radioPlayer.setAudioStreamType(android.media.AudioManager.STREAM_MUSIC);
            radioPlayer.setDataSource(radioStreams[attempt]);
            radioPlayer.setOnPreparedListener(mp -> {
                mp.start();
                radioToggleButton.setEnabled(true);
                radioToggleButton.setText("■ ВЫКЛЮЧИТЬ РАДИО");
                radioStatus.setText("Играет: EUROPEAN HIT RADIO · " + radioStreamNames[attempt]);
            });
            radioPlayer.setOnErrorListener((mp, what, extra) -> {
                stopRadioPlayer();
                radioStreamIndex = attempt + 1;
                tryRadioStream();
                return true;
            });
            radioPlayer.prepareAsync();
        } catch (Exception e) {
            stopRadioPlayer();
            radioStreamIndex = attempt + 1;
            tryRadioStream();
        }
    }

    private void showRadio() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(18), dp(14), dp(18), dp(8));
        panel.setBackgroundColor(BG);

        TextView title = label("EUROPEAN HIT RADIO · FRESH", 18, GREEN, true);
        panel.addView(title, lp(0, 10));
        radioStatus = label("Радио выключено", 14, Color.WHITE, false);
        panel.addView(radioStatus, lp(0, 16));

        radioToggleButton = button("▶ ВКЛЮЧИТЬ РАДИО");
        panel.addView(radioToggleButton, lp(0, 8));
        radioToggleButton.setOnClickListener(v -> {
            if (radioPlayer != null) stopRadioPlayer();
            else startRadioPlayer();
        });

        TextView hint = label("Прямой аудиопоток станции. Без рекламной страницы и браузера. Для прослушивания нужен интернет.", 12, MUTED, false);
        panel.addView(hint, lp(0, 8));

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("📻 SPORT RADIO")
                .setView(panel)
                .setNegativeButton("Закрыть", (d, w) -> stopRadioPlayer())
                .create();
        dialog.setOnCancelListener(d -> stopRadioPlayer());
        dialog.show();
    }

    private void showHistory() {
        SharedPreferences p = getSharedPreferences("football_history", MODE_PRIVATE);
        try {
            JSONArray arr = new JSONArray(p.getString("items","[]"));
            if(arr.length()==0) { new AlertDialog.Builder(this).setTitle("История").setMessage("Пока нет сохранённых матчей.").setPositiveButton("OK",null).show(); return; }
            String[] items = new String[arr.length()]; for(int i=0;i<arr.length();i++) items[i]=arr.optString(i);
            new AlertDialog.Builder(this).setTitle("Сохранённые матчи").setItems(items,null).setPositiveButton("Закрыть",null).setNeutralButton("Очистить",(d,w)->p.edit().remove("items").apply()).show();
        } catch(Exception e) { new AlertDialog.Builder(this).setTitle("История").setMessage("Не удалось прочитать историю.").setPositiveButton("OK",null).show(); }
    }

    @Override protected void onDestroy() { stopRadioPlayer(); super.onDestroy(); worker.shutdownNow(); }
}
