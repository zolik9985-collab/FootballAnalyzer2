package com.footballanalyzer2;

import java.util.Locale;

/**
 * Чистая математика прогнозов (без Android-зависимостей, поэтому проверяется обычным JVM-тестом).
 *
 * Голы: силы атаки/обороны относительно среднего по лиге со сглаживанием к среднему (малая выборка
 * не даёт экстремальных значений), домашнее преимущество берётся из средних лиги (хозяева/гости),
 * счёт считается по Пуассону с поправкой Диксона-Коулса для низких счетов.
 * Счётные рынки (угловые, карточки, фолы, удары): сглаженное среднее + отрицательное биномиальное
 * распределение (Пуассон, если разброс не больше среднего), линии подбираются вокруг ожидания.
 */
final class ForecastModel {
    private ForecastModel() {}

    static final double DC_RHO = -0.10;
    private static final int MAX_GOALS = 10;
    private static final double GOALS_PRIOR_MATCHES = 5.0;   // вес "среднего по лиге" в матчах
    private static final double COUNT_PRIOR_MATCHES = 4.0;
    private static final double DISPERSION_PRIOR_WEIGHT = 20.0;

    // ---------- базовые функции ----------
    static double mean(double[] v) { double s = 0; for (double x : v) s += x; return s / v.length; }

    static double sampleVariance(double[] v) {
        if (v.length < 2) return Double.NaN;
        double m = mean(v), s = 0;
        for (double x : v) { double d = x - m; s += d * d; }
        return s / (v.length - 1);
    }

    static double shrunkMean(double[] v, double prior, double k) {
        double s = 0; for (double x : v) s += x;
        return (s + k * prior) / (v.length + k);
    }

    private static double logFactorial(int n) { double r = 0; for (int i = 2; i <= n; i++) r += Math.log(i); return r; }

    static double poisson(int k, double lambda) {
        return Math.exp(-lambda + k * Math.log(lambda) - logFactorial(k));
    }

    private static double clamp(double v, double lo, double hi) { return Math.max(lo, Math.min(hi, v)); }
    private static String pct(double v) { return String.format(Locale.US, "%.0f%%", clamp(v, 0, 1) * 100); }
    private static String f1(double v) { return String.format(Locale.US, "%.1f", v); }
    private static String f2(double v) { return String.format(Locale.US, "%.2f", v); }

    static String confidence(int n) { return n >= 8 ? "высокая" : n >= 5 ? "средняя" : "низкая"; }

    // ---------- голы ----------
    /** Возвращает {ожидаемые голы хозяев, ожидаемые голы гостей}. gf/ga — суммы за n матчей. */
    static double[] expectedGoals(double gfH, double gaH, int nH, double gfA, double gaA, int nA,
                                  double leagueHome, double leagueAway) {
        double avgTeam = (leagueHome + leagueAway) / 2.0, k = GOALS_PRIOR_MATCHES;
        double attH = ((gfH + k * avgTeam) / (nH + k)) / avgTeam;
        double defH = ((gaH + k * avgTeam) / (nH + k)) / avgTeam;
        double attA = ((gfA + k * avgTeam) / (nA + k)) / avgTeam;
        double defA = ((gaA + k * avgTeam) / (nA + k)) / avgTeam;
        double lh = leagueHome * attH * defA;
        double la = leagueAway * attA * defH;
        return new double[]{clamp(lh, 0.15, 4.5), clamp(la, 0.15, 4.5)};
    }

    /**
     * Расклад сил относительно "обычного" матча каждой команды.
     * Среднее по последним матчам команды уже отражает её силу против обычных соперников, поэтому поправка зависит только от того,
     * насколько ЭТОТ соперник отличается от среднего: ln(слабость обороны соперника / сила его атаки).
     * > 0 : соперник слабее обычного (команда будет доминировать), < 0 : сильнее обычного.
     * Возвращает {для хозяев, для гостей}.
     */
    static double[] matchupLogRatios(double gfH, double gaH, int nH, double gfA, double gaA, int nA,
                                     double leagueHome, double leagueAway) {
        double avgTeam = (leagueHome + leagueAway) / 2.0, k = GOALS_PRIOR_MATCHES;
        double attH = ((gfH + k * avgTeam) / (nH + k)) / avgTeam;
        double defH = ((gaH + k * avgTeam) / (nH + k)) / avgTeam;
        double attA = ((gfA + k * avgTeam) / (nA + k)) / avgTeam;
        double defA = ((gaA + k * avgTeam) / (nA + k)) / avgTeam;
        return new double[]{clamp(Math.log(defA / attA), -1.0, 1.0), clamp(Math.log(defH / attH), -1.0, 1.0)};
    }

    private static double tau(int i, int j, double lh, double la) {
        if (i == 0 && j == 0) return 1.0 - lh * la * DC_RHO;
        if (i == 0 && j == 1) return 1.0 + lh * DC_RHO;
        if (i == 1 && j == 0) return 1.0 + la * DC_RHO;
        if (i == 1 && j == 1) return 1.0 - DC_RHO;
        return 1.0;
    }

    static double[][] scoreGrid(double lh, double la) {
        double[][] g = new double[MAX_GOALS + 1][MAX_GOALS + 1];
        double sum = 0;
        for (int i = 0; i <= MAX_GOALS; i++) for (int j = 0; j <= MAX_GOALS; j++) {
            double p = poisson(i, lh) * poisson(j, la) * tau(i, j, lh, la);
            g[i][j] = p; sum += p;
        }
        for (int i = 0; i <= MAX_GOALS; i++) for (int j = 0; j <= MAX_GOALS; j++) g[i][j] /= sum;
        return g;
    }

    static String goalsBlock(String home, String away, double lh, double la, int minSample) {
        double[][] g = scoreGrid(lh, la);
        double pH = 0, pD = 0, pA = 0, btts = 0;
        double[] totalOver = new double[3];   // P(сумма >= 2), >=3, >=4  -> линии 1.5 / 2.5 / 3.5
        for (int i = 0; i <= MAX_GOALS; i++) for (int j = 0; j <= MAX_GOALS; j++) {
            double p = g[i][j];
            if (i > j) pH += p; else if (i == j) pD += p; else pA += p;
            if (i >= 1 && j >= 1) btts += p;
            for (int t = 0; t < 3; t++) if (i + j >= t + 2) totalOver[t] += p;
        }
        // три самых вероятных счёта
        int[][] best = new int[3][2]; double[] bestP = new double[3];
        for (int i = 0; i <= MAX_GOALS; i++) for (int j = 0; j <= MAX_GOALS; j++) {
            double p = g[i][j];
            for (int r = 0; r < 3; r++) if (p > bestP[r]) {
                for (int s = 2; s > r; s--) { bestP[s] = bestP[s - 1]; best[s][0] = best[s - 1][0]; best[s][1] = best[s - 1][1]; }
                bestP[r] = p; best[r][0] = i; best[r][1] = j; break;
            }
        }
        StringBuilder b = new StringBuilder();
        b.append("⚽ ГОЛЫ · ожидаемый счёт: ").append(home).append(" ").append(f2(lh)).append(" : ").append(f2(la)).append(" ").append(away)
         .append(" · уверенность: ").append(confidence(minSample)).append("\n");
        b.append("   1X2: ").append(home).append(" ").append(pct(pH)).append(" · ничья ").append(pct(pD)).append(" · ").append(away).append(" ").append(pct(pA)).append("\n");
        double[] lines = {1.5, 2.5, 3.5};
        for (int t = 0; t < 3; t++)
            b.append("   Тотал голов ").append(f1(lines[t])).append(": 🔼 Больше ").append(pct(totalOver[t])).append(" · 🔽 Меньше ").append(pct(1 - totalOver[t])).append("\n");
        b.append("   Обе забьют: Да ").append(pct(btts)).append(" · Нет ").append(pct(1 - btts)).append("\n");
        b.append("   Вероятные счета: ");
        for (int r = 0; r < 3; r++) b.append(r > 0 ? ", " : "").append(best[r][0]).append(":").append(best[r][1]).append(" (").append(pct(bestP[r])).append(")");
        b.append("\n");
        return b.toString();
    }

    // ---------- счётные рынки ----------
    /** P(X >= line+1) для целого N=line (линия N.5). Отрицательное биномиальное при разбросе > среднего, иначе Пуассон. */
    static double overProbability(int line, double mean, double variance) {
        double cdf;
        if (variance > mean + 0.05) {
            double r = mean * mean / (variance - mean), p = r / (r + mean);
            double term = Math.pow(p, r);
            cdf = term;
            for (int k = 1; k <= line; k++) { term *= ((k - 1 + r) / k) * (1.0 - p); cdf += term; }
        } else {
            double term = Math.exp(-mean);
            cdf = term;
            for (int k = 1; k <= line; k++) { term *= mean / k; cdf += term; }
        }
        return clamp(1.0 - cdf, 0.0, 1.0);
    }

    /**
     * @param hOwn  значения команды-хозяев по матчам (за матч), aOwn - гостей
     * @param hConc что пропускают хозяева (может быть null), aConc - гости (может быть null)
     * @param prior среднее по лиге на одну команду за матч; phiPrior - типичное отношение дисперсии к среднему
     */
    static String countBlock(String title, double[] hOwn, double[] aOwn, double[] hConc, double[] aConc,
                             double prior, double phiPrior, double[] matchup, double elasticity) {
        int nh = hOwn == null ? 0 : hOwn.length, na = aOwn == null ? 0 : aOwn.length;
        if (nh < 3 || na < 3)
            return "   " + title + ": недостаточно данных (" + nh + "/" + na + "; нужно минимум 3 матча со статистикой у каждой команды)\n";
        double k = COUNT_PRIOR_MATCHES;
        double ownH = shrunkMean(hOwn, prior, k), ownA = shrunkMean(aOwn, prior, k);
        double rateH = ownH, rateA = ownA;
        if (aConc != null && aConc.length >= 3) rateH = (ownH + shrunkMean(aConc, prior, k)) / 2.0;
        if (hConc != null && hConc.length >= 3) rateA = (ownA + shrunkMean(hConc, prior, k)) / 2.0;
        // Поправка на расклад сил: elasticity > 0 для "атакующих" показателей (удары, угловые), < 0 для фолов и карточек
        double multH = 1.0, multA = 1.0;
        if (matchup != null && matchup.length == 2) {
            multH = clamp(Math.exp(elasticity * matchup[0]), 0.7, 1.4);
            multA = clamp(Math.exp(elasticity * matchup[1]), 0.7, 1.4);
            rateH *= multH; rateA *= multA;
        }
        double expected = rateH + rateA;
        if (!(expected > 0) || Double.isInfinite(expected)) return "   " + title + ": некорректные данные, прогноз отключён\n";

        double vh = sampleVariance(hOwn), va = sampleVariance(aOwn);
        double phiSample = (Double.isNaN(vh) || Double.isNaN(va)) ? phiPrior : (vh + va) / (mean(hOwn) + mean(aOwn));
        if (Double.isNaN(phiSample) || Double.isInfinite(phiSample)) phiSample = phiPrior;
        double nTot = nh + na;
        double phi = clamp((nTot * phiSample + DISPERSION_PRIOR_WEIGHT * phiPrior) / (nTot + DISPERSION_PRIOR_WEIGHT), 1.0, 2.2);
        double variance = expected * phi;

        int nearest = (int) Math.floor(expected);   // ближайшая к ожиданию линия = nearest + 0.5
        StringBuilder b = new StringBuilder();
        b.append("   ").append(title).append(" · ожидание ").append(f1(expected)).append(" (").append(f1(rateH)).append(" + ").append(f1(rateA))
         .append(") · уверенность: ").append(confidence(Math.min(nh, na))).append(" (").append(nh).append("+").append(na).append(" матчей)\n");
        if (Math.abs(multH - 1.0) >= 0.02 || Math.abs(multA - 1.0) >= 0.02)
            b.append("      Поправка на расклад сил: хозяева ×").append(f2(multH)).append(" · гости ×").append(f2(multA)).append("\n");
        for (int n = nearest - 1; n <= nearest + 1; n++) {
            if (n < 0) continue;
            double over = overProbability(n, expected, variance);
            b.append("      ").append(n).append(".5: 🔼 Больше ").append(pct(over)).append(" · 🔽 Меньше ").append(pct(1 - over)).append("\n");
        }
        return b.toString();
    }
}
