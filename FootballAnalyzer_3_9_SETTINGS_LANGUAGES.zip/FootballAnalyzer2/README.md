# Football Analyzer 3.5

Android-приложение на Java. Источник: open-matchday CSV (обновление примерно раз в сутки, без API-ключа).

## Что изменено в 3.5
- Вместо одного среднего голевого показателя показываются забитые и пропущенные голы и форма В-Н-П.
- Для каждой команды берутся до 8 последних сыгранных матчей по дате.
- Статистические показатели считаются только по реально заполненным значениям; пустые поля не превращаются в нули.
- Добавлен прогноз: ожидаемые голы, вероятности 1X2, тотал больше 2.5 и обе забьют (модель Пуассона).
- Если у команды меньше 3 матчей, приложение честно сообщает, что прогноза недостаточно для расчёта.
- В историю сохраняется и сам рассчитанный прогноз.

Источник обновляется раз в сутки и не предоставляет xG, составы, травмы или коэффициенты. Прогноз не является гарантией результата.


## Версия 3.6 — подробный отчёт и тоталы

Отчёт показывает последние 10 сыгранных матчей каждой команды: забитые/пропущенные голы суммарно и в среднем, угловые, жёлтые карточки, удары в створ, все удары и фолы (сумма и среднее по числу матчей с опубликованной статистикой). Добавлены ориентировочные вероятности больше/меньше по тоталам. Вбрасывания из аута не входят в схему open-matchday и поэтому помечаются как недоступные. Вероятности — простая модель Пуассона по средним, не гарантии и не букмекерские коэффициенты.


## Резервная статистика 3.8

Для матчей с пустыми статистическими полями приложение сначала использует open-matchday CSV, затем пытается найти тот же матч в публичном ESPN Site API без ключа. Совпадение выполняется по дате и названиям обеих команд. Подтягиваются угловые, жёлтые карточки, удары в створ, все удары и фолы. Значения из ESPN используются только для пустых полей; уже опубликованные значения open-matchday не перезаписываются.

ESPN — дополнительный необязательный источник: он не покрывает все турниры и матчи, а его публичный интерфейс не является гарантированным коммерческим API. Если матч не найден или статистика отсутствует, приложение продолжает показывать «нет опубликованных данных», не подставляя нули.


## Update 3.9 (work in progress)
- Added an in-app Settings button.
- Added language selection: Russian, English, Norwegian and Ukrainian for the main navigation and settings controls.
- Added a password-masked SportsAPI Pro token field in Settings; the token is stored in private app preferences and is not hard-coded into source.
- The SportsAPI Pro token is currently saved but is NOT yet wired into match/statistics requests. The API integration requires mapping the provider's tournament, fixture, event and match-statistics response models to the existing analyzer.
- The previously shared token should be revoked and replaced because it was exposed in chat. Enter the replacement token in Settings.
- Android APK build was not run in this environment (Gradle/Android SDK build tools are unavailable).
