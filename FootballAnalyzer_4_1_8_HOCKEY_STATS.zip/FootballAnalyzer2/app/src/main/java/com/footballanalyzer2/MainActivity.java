package com.footballanalyzer2;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.AlertDialog;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.widget.*;
import android.text.InputType;
import android.content.SharedPreferences;
import java.net.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;
import org.json.*;

public class MainActivity extends Activity {
    private static final String RAW = "https://raw.githubusercontent.com/oladeeayo/open-matchday/master/data/";
    private static final String CDN = "https://cdn.jsdelivr.net/gh/oladeeayo/open-matchday@master/data/";
    private static final String SEASON = "2627";
    private static final int BG = 0xff06120d, GREEN = 0xff35d879, PANEL = 0xff12251b, MUTED = 0xff9bb4a5;

    private static class League {
        final String title, folder;
        League(String title, String folder) { this.title = title; this.folder = folder; }
        public String toString() { return title; }
    }

    // Only competitions confirmed in the public open-matchday index are listed.
    private final League[] leagues = new League[] {
        new League("🏆 Лига чемпионов UEFA", "UEFA_1_champions-league"),
        new League("🏆 Лига Европы UEFA", "UEFA_1_europa-league"),
        new League("🏆 Лига конференций UEFA", "UEFA_1_conference-league"),
        new League("Англия · FA Cup", "ENG_CUP_fa-cup"),
        new League("Англия · EFL Cup", "ENG_CUP_efl-cup"),
        new League("Испания · Copa del Rey", "ESP_CUP_copa-del-rey"),
        new League("Италия · Coppa Italia", "ITA_CUP_coppa-italia"),
        new League("Германия · DFB-Pokal", "GER_CUP_dfb-pokal"),
        new League("Нидерланды · KNVB Beker", "NED_CUP_knvb-beker"),
        new League("Англия · Premier League", "ENG_1_premier-league"),
        new League("Испания · La Liga", "ESP_1_la-liga"),
        new League("Германия · Bundesliga", "GER_1_bundesliga"),
        new League("Италия · Serie A", "ITA_1_serie-a"),
        new League("Франция · Ligue 1", "FRA_1_ligue-1"),
        new League("Нидерланды · Eredivisie", "NED_1_eredivisie"),
        new League("Португалия · Primeira Liga", "POR_1_primeira-liga"),
        new League("Бельгия · Pro League", "BEL_1_pro-league"),
        new League("Турция · Süper Lig", "TUR_1_super-lig"),
        new League("Греция · Super League", "GRE_1_super-league"),
        new League("Россия · Премьер-лига", "RUS_1_premier-liga"),
        new League("Украина · Премьер-лига", "UKR_1_premier-league"),
        new League("Норвегия · Eliteserien", "NOR_1_eliteserien"),
        new League("Шотландия · Premiership", "SCO_1_premiership"),
        new League("Польша · Ekstraklasa", "POL_1_ekstraklasa"),
        new League("Англия · Championship", "ENG_2_championship"),
        new League("Англия · League One", "ENG_3_league-one"),
        new League("Англия · League Two", "ENG_4_league-two"),
        new League("Шотландия · Championship", "SCO_2_championship"),
        new League("Шотландия · League One", "SCO_3_league-one"),
        new League("Шотландия · League Two", "SCO_4_league-two"),
        new League("Шотландия · Кубок", "SCO_CUP_scottish-cup"),
        new League("Шотландия · Кубок лиги", "SCO_CUP_league-cup"),
        new League("Португалия · Кубок", "POR_CUP_taca-de-portugal"),
        new League("Австрия · Bundesliga", "AUT_1_bundesliga"),
        new League("Австрия · Кубок", "AUT_CUP_ofb-cup"),
        new League("Швейцария · Super League", "SUI_1_super-league"),
        new League("Швейцария · Кубок", "SUI_CUP_swiss-cup"),
        new League("Дания · Superliga", "DEN_1_superliga"),
        new League("Швеция · Allsvenskan", "SWE_1_allsvenskan"),
        new League("Румыния · Liga I", "ROU_1_liga-1"),
        new League("Ирландия · First Division", "IRE_2_first-division"),
        new League("Ирландия · National League", "IRE_3_national-league"),
        new League("Польша · I Liga", "POL_2_division-1"),
        new League("Польша · II Liga", "POL_3_division-2"),
        new League("Бельгия · U21 Pro League", "BEL_U21_pro-league"),
        new League("Уэльс · Cymru Premier", "WAL_1_cymru-premier"),
        new League("Уэльс · Cymru North", "WAL_2_cymru-north"),
        new League("Уэльс · Cymru South", "WAL_3_cymru-south"),
        new League("Хорватия · HNL", "CRO_1_hnl"),
        new League("Чехия · Chance Liga", "CZE_1_chance-liga"),
        new League("Кипр · First Division", "CYP_1_first-division"),
        new League("Словакия · Nike Liga", "SVK_1_nike-liga"),
        new League("Словения · Prva Liga", "SVN_1_prva-liga"),
        new League("Финляндия · Veikkausliiga", "FIN_1_veikkausliiga"),
        new League("Казахстан · Премьер-лига", "KAZ_1_premier-league"),
        new League("Испания · Segunda División", "ESP_2_segunda-division"),
        new League("Италия · Serie B", "ITA_2_serie-b"),
        new League("Франция · Ligue 2", "FRA_2_ligue-2"),
        new League("Нидерланды · Eerste Divisie", "NED_2_eerste-divisie"),
        new League("Бразилия · Série A", "BRA_1_serie-a"),
        new League("Бразилия · Série B", "BRA_2_serie-b"),
        new League("Аргентина · Liga Profesional", "ARG_1_liga-profesional"),
        new League("Аргентина · Primera Nacional", "ARG_2_primera-nacional"),
        new League("Мексика · Liga MX", "MEX_1_liga-mx"),
        new League("Мексика · Liga de Expansión", "MEX_2_liga-expansion"),
        new League("США · MLS", "USA_1_mls"),
        new League("Япония · J1 League", "JPN_1_j1-league"),
        new League("Австралия · A-League", "AUS_1_a-league"),
        new League("Китай · Super League", "CHN_1_super-league")
    };

    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final Handler ui = new Handler(Looper.getMainLooper());
    private LinearLayout root, cards;
    private TextView status, selectedDateText;
    private Spinner leagueSpinner;
    private int selectedLeague = 0;
    private List<League> leagueOptions;
    private String mode = "today";
    private String chosenDate;
    private boolean dateWasChosen = false;
    private String appLanguage = "ru";
    private int analysisMatchCount = 10;
    private boolean hockeyMode = false;
    private Spinner hockeyLeagueSpinner;
    private String hockeyLeagueFilter = "Все хоккейные лиги";
    private boolean hockeyLastLiveOnly = true;
    private SharedPreferences appPrefs;

    private String tr(String key) {
        String lang = appLanguage;
        String[][] words = {
            {"settings","Настройки","Settings","Innstillinger","Налаштування"},
            {"history","📅 ИСТОРИЯ СОХРАНЁННЫХ ПРОГНОЗОВ","📅 SAVED ANALYSIS HISTORY","📅 LAGRET ANALYSEHISTORIKK","📅 ІСТОРІЯ ЗБЕРЕЖЕНИХ ПРОГНОЗІВ"},
            {"choose_league","ВЫБЕРИ ТУРНИР","CHOOSE LEAGUE","VELG LIGA","ОБЕРИ ЛІГУ"},
            {"today","Сегодня","Today","I dag","Сьогодні"},
            {"tomorrow","Завтра","Tomorrow","I morgen","Завтра"},
            {"all","Все матчи","All matches","Alle kamper","Усі матчі"},
            {"choose_date","📅 ВЫБРАТЬ ДАТУ","📅 CHOOSE DATE","📅 VELG DATO","📅 ОБРАТИ ДАТУ"},
            {"refresh","ОБНОВИТЬ МАТЧИ","REFRESH MATCHES","OPPDATER KAMPER","ОНОВИТИ МАТЧІ"},
            {"loading","Подключаюсь к бесплатному источнику…","Connecting to free data source…","Kobler til gratis datakilde…","Підключаюся до безкоштовного джерела…"},
            {"date","Дата: ","Date: ","Dato: ","Дата: "},
            {"api_title","API-ключ SportsAPI Pro","SportsAPI Pro API token","SportsAPI Pro API-token","API-токен SportsAPI Pro"},
            {"api_hint","Токен сохраняется в настройках приложения. Подключение API требует проверки документации SportsAPI Pro.","Token is saved in app settings. API integration requires verifying SportsAPI Pro documentation.","Token lagres i appinnstillingene. API-integrasjon krever kontroll av SportsAPI Pro-dokumentasjonen.","Токен зберігається в налаштуваннях. Інтеграція потребує перевірки документації SportsAPI Pro."},
            {"language","Язык приложения","App language","Appspråk","Мова програми"},
            {"save","Сохранить","Save","Lagre","Зберегти"},
            {"test_api","Проверить подключение","Test connection","Test tilkobling","Перевірити підключення"},
            {"cancel","Отмена","Cancel","Avbryt","Скасувати"},
            {"token_label","API-токен (вставьте новый токен)","API token (paste your new token)","API-token (lim inn ny token)","API-токен (вставте новий токен)"},
            {"source_note","Источники: open-matchday + резервный ESPN API. Данные для личного некоммерческого использования.","Sources: open-matchday + ESPN fallback. Personal, non-commercial use only.","Kilder: open-matchday + ESPN reserve. Kun personlig, ikke-kommersiell bruk.","Джерела: open-matchday + резервний ESPN API. Для особистого некомерційного використання."}
        };
        int col = lang.equals("en") ? 2 : lang.equals("no") ? 3 : lang.equals("uk") ? 4 : 1;
        for (String[] row : words) if (row[0].equals(key)) return row[col];
        return key;
    }

    private void showSettings() {
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(20), dp(8), dp(20), dp(4));
        TextView langLabel = label(tr("language"), 14, Color.WHITE, true); box.addView(langLabel);
        Spinner langs = new Spinner(this);
        String[] names = {"Русский", "English", "Norsk", "Українська"};
        String[] codes = {"ru", "en", "no", "uk"};
        ArrayAdapter<String> ad = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, names); ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item); langs.setAdapter(ad);
        int selected = Arrays.asList(codes).indexOf(appLanguage); langs.setSelection(Math.max(0, selected)); box.addView(langs, lp(4, 12));
        TextView sampleLabel = label("Количество последних матчей для анализа (3–10)", 14, Color.WHITE, true); box.addView(sampleLabel, lp(8, 2));
        Spinner sampleSpinner = new Spinner(this);
        Integer[] sampleCounts = {3, 5, 7, 10};
        ArrayAdapter<Integer> sampleAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, sampleCounts); sampleAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item); sampleSpinner.setAdapter(sampleAdapter);
        int samplePos = Arrays.asList(sampleCounts).indexOf(analysisMatchCount); sampleSpinner.setSelection(Math.max(0, samplePos)); box.addView(sampleSpinner, lp(2, 12));
        TextView tokenLabel = label(tr("token_label"), 14, Color.WHITE, true); box.addView(tokenLabel);
        EditText token = new EditText(this); token.setSingleLine(true); token.setTextSize(14); token.setHint("xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"); token.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        token.setText(appPrefs.getString("sportsapi_token", "")); box.addView(token);
        box.addView(label(tr("api_hint"), 12, MUTED, false), lp(4, 0));
        final EditText tokenField = token;
        new AlertDialog.Builder(this).setTitle(tr("settings")).setView(box)
            .setPositiveButton(tr("save"), (d,w) -> { appLanguage = codes[langs.getSelectedItemPosition()]; appPrefs.edit().putString("language", appLanguage).putString("sportsapi_token", tokenField.getText().toString().trim()).putInt("analysis_match_count", (Integer) sampleSpinner.getSelectedItem()).apply(); analysisMatchCount = (Integer) sampleSpinner.getSelectedItem(); buildUi(); loadFixtures(); })
            .setNeutralButton(tr("test_api"), (d,w) -> {
                String candidate = tokenField.getText().toString().trim();
                if (candidate.isEmpty()) { Toast.makeText(this, "Сначала вставь API-токен", Toast.LENGTH_LONG).show(); return; }
                Toast.makeText(this, "Проверяю SportsAPI Pro…", Toast.LENGTH_SHORT).show();
                worker.execute(() -> {
                    String result;
                    try { result = testSportsApi(candidate); }
                    catch (Exception e) { result = "Ошибка подключения: " + (e.getMessage()==null?e.toString():e.getMessage()); }
                    final String message = result;
                    ui.post(() -> new AlertDialog.Builder(this).setTitle("SportsAPI Pro").setMessage(message).setPositiveButton("OK", null).show());
                });
            })
            .setNegativeButton(tr("cancel"), null).show();
    }

    private String testSportsApi(String token) throws Exception {
        HttpURLConnection c = null;
        try {
            URL url = new URL("https://api.sportsapipro.com/v2/football/api/live");
            c = (HttpURLConnection) url.openConnection();
            c.setRequestMethod("GET"); c.setConnectTimeout(10000); c.setReadTimeout(15000);
            c.setRequestProperty("x-api-key", token);
            c.setRequestProperty("Accept", "application/json");
            c.setRequestProperty("User-Agent", "FootballAnalyzer/4.0");
            int code = c.getResponseCode();
            InputStream in = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            if (in != null) { try (InputStream stream = in) { byte[] b = new byte[8192]; int n; while ((n=stream.read(b))!=-1) out.write(b,0,n); } }
            String body = out.toString("UTF-8");
            if (code == 401 || code == 403) return "Ключ отклонён сервером (HTTP " + code + "). Проверь токен и статус аккаунта.";
            if (code == 429) return "Ключ принят, но превышен лимит запросов (HTTP 429). Попробуй позже.";
            if (code < 200 || code >= 300) return "Сервер вернул HTTP " + code + ": " + body.substring(0, Math.min(350, body.length()));
            JSONObject json = new JSONObject(body);
            JSONArray events = json.optJSONArray("events");
            if (events == null) {
                JSONObject data = json.optJSONObject("data");
                if (data != null) events = data.optJSONArray("events");
            }
            int count = events == null ? json.optInt("count", -1) : events.length();
            StringBuilder msg = new StringBuilder("Подключение успешно (HTTP 200).\nAPI-ключ принят сервером.");
            if (count >= 0) msg.append("\nТекущих live-матчей: ").append(count);
            else msg.append("\nСервер вернул корректный JSON-ответ.");
            msg.append("\n\nЭто проверяет авторизацию и доступ к live endpoint. Наличие угловых, фолов, карточек и ударов проверяется отдельно на конкретном матче.");
            return msg.toString();
        } finally { if (c != null) c.disconnect(); }
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density); }
    private GradientDrawable shape(int color, int radius) { GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d; }
    private TextView label(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(null, Typeface.BOLD); return t;
    }
    private LinearLayout.LayoutParams lp(int top, int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.setMargins(0, dp(top), 0, dp(bottom)); return p;
    }
    private Button button(String s) {
        Button b = new Button(this); b.setText(s); b.setAllCaps(false); b.setTextColor(BG); b.setTextSize(16); b.setTypeface(null, Typeface.BOLD); b.setBackground(shape(GREEN, 13)); return b;
    }
    private String today() { return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date()); }
    private String tomorrow() { Calendar cal=Calendar.getInstance(); cal.add(Calendar.DAY_OF_YEAR,1); return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(cal.getTime()); }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG);
        appPrefs = getSharedPreferences("football_analyzer_settings", MODE_PRIVATE);
        appLanguage = appPrefs.getString("language", "ru");
        analysisMatchCount = appPrefs.getInt("analysis_match_count", 10);
        if (analysisMatchCount != 3 && analysisMatchCount != 5 && analysisMatchCount != 7 && analysisMatchCount != 10) analysisMatchCount = 10;
        chosenDate = today();
        buildUi();
        loadFixtures();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(22), dp(18), dp(28)); root.setBackgroundColor(BG);
        scroll.addView(root); setContentView(scroll);

        LinearLayout top = new LinearLayout(this); top.setOrientation(LinearLayout.HORIZONTAL); top.setGravity(android.view.Gravity.CENTER_VERTICAL);
        TextView appTitle = label("⚽ FOOTBALL ANALYZER 4.1.5", 22, GREEN, true); top.addView(appTitle, new LinearLayout.LayoutParams(0, -2, 1));
        Button settings = button("⚙ " + tr("settings")); settings.setTextSize(12); top.addView(settings); settings.setOnClickListener(v -> showSettings()); root.addView(top, lp(0, 8));
        Button hockey = button("🏒 ОТКРЫТЬ РАЗДЕЛ ХОККЕЙ");
        root.addView(hockey, lp(0, 8));
        hockey.setOnClickListener(v -> buildHockeyUi());
        root.addView(label("Matches · open-matchday (all available competitions) + ESPN · 2026/27", 14, 0xffb8c9bf, true), lp(4, 16));

        Button history = button(tr("history")); root.addView(history, lp(0, 8));
        history.setOnClickListener(v -> showHistory());

        root.addView(label(tr("choose_league"), 15, GREEN, true), lp(4, 6));
        leagueSpinner = new Spinner(this);
        leagueOptions = new ArrayList<>();
        leagueOptions.add(new League("🌍 Все матчи", ""));
        leagueOptions.addAll(Arrays.asList(leagues));
        ArrayAdapter<League> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, leagueOptions);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        leagueSpinner.setAdapter(adapter); leagueSpinner.setBackground(shape(PANEL, 12)); root.addView(leagueSpinner, lp(0, 12));

        LinearLayout modes = new LinearLayout(this);
        String[][] choices = {{tr("today"), "today"}, {tr("tomorrow"), "tomorrow"}};
        for (String[] c : choices) {
            Button b = button(c[0]); LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(48), 1); p.setMargins(dp(2), 0, dp(2), 0); modes.addView(b, p);
            b.setOnClickListener(v -> { mode = c[1]; dateWasChosen = false; loadFixtures(); });
        }
        root.addView(modes, lp(0, 8));

        Button date = button(tr("choose_date")); root.addView(date, lp(0, 8));
        selectedDateText = label(tr("date") + chosenDate, 15, Color.WHITE, true); root.addView(selectedDateText, lp(0, 12));
        date.setOnClickListener(v -> openDatePicker());

        Button refresh = button(tr("refresh")); root.addView(refresh, lp(0, 8)); refresh.setOnClickListener(v -> loadFixtures());
        status = label(tr("loading"), 14, 0xffc3d2c9, false); root.addView(status, lp(0, 10));
        cards = new LinearLayout(this); cards.setOrientation(LinearLayout.VERTICAL); root.addView(cards);
        root.addView(label(tr("source_note"), 12, 0xff879b8e, false), lp(18, 0));

        leagueSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onNothingSelected(android.widget.AdapterView<?> parent) {}
            public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) { selectedLeague = position; loadFixtures(); }
        });
    }


    private void buildHockeyUi() {
        hockeyMode = true;
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(22), dp(18), dp(28)); root.setBackgroundColor(BG);
        scroll.addView(root); setContentView(scroll);
        LinearLayout top = new LinearLayout(this); top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(android.view.Gravity.CENTER_VERTICAL);
        TextView title = label("🏒 HOCKEY ANALYZER", 23, GREEN, true);
        top.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        Button back = button("⚽ ФУТБОЛ"); top.addView(back);
        back.setOnClickListener(v -> { hockeyMode = false; buildUi(); loadFixtures(); });
        root.addView(top, lp(0, 12));
        root.addView(label("NHL · КХЛ · ВХЛ · МХЛ · Европа · Северная Америка", 13, MUTED, false), lp(4, 14));
        root.addView(label("ВЫБЕРИ ТУРНИР", 14, GREEN, true), lp(8, 6));
        hockeyLeagueSpinner = new Spinner(this);
        String[] leagues = {
            "Все хоккейные лиги", "NHL", "AHL", "ECHL", "КХЛ", "ВХЛ", "МХЛ",
            "Швеция · SHL", "Швеция · HockeyAllsvenskan", "Финляндия · Liiga",
            "Чехия · Extraliga", "Словакия · Extraliga", "Швейцария · National League",
            "Германия · DEL", "Австрия · ICE Hockey League", "Норвегия · EHL",
            "Польша · Polska Hokej Liga", "Франция · Ligue Magnus",
            "Канада · OHL", "Канада · WHL", "Канада · QMJHL",
            "США · NCAA", "PWHL", "IIHF · Чемпионат мира", "Champions Hockey League"
        };
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, leagues);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        hockeyLeagueSpinner.setAdapter(adapter); hockeyLeagueSpinner.setBackground(shape(PANEL, 12));
        root.addView(hockeyLeagueSpinner, lp(0, 12));
        LinearLayout controls = new LinearLayout(this); controls.setOrientation(LinearLayout.HORIZONTAL);
        Button live = button("LIVE"); Button schedule = button("РАСПИСАНИЕ");
        controls.addView(live, new LinearLayout.LayoutParams(0, dp(48), 1));
        controls.addView(schedule, new LinearLayout.LayoutParams(0, dp(48), 1));
        root.addView(controls, lp(0, 8));
        Button refresh = button("ОБНОВИТЬ"); root.addView(refresh, lp(0, 8));
        status = label("Загружаю хоккейные матчи…", 14, Color.WHITE, false); root.addView(status, lp(8, 8));
        cards = new LinearLayout(this); cards.setOrientation(LinearLayout.VERTICAL); root.addView(cards);
        hockeyLeagueSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onNothingSelected(AdapterView<?> p) {}
            public void onItemSelected(AdapterView<?> p, View v, int position, long id) {
                hockeyLeagueFilter = (String)p.getItemAtPosition(position); loadHockey(true);
            }
        });
        live.setOnClickListener(v -> loadHockey(true));
        schedule.setOnClickListener(v -> loadHockey(false));
        refresh.setOnClickListener(v -> loadHockey(true));
        loadHockey(true);
    }

    private String hockeyCompetitionName(JSONObject event) {
        // Providers may place competition metadata under different keys.
        String[] objectKeys = {"tournament", "league", "competition", "uniqueTournament"};
        for (String key : objectKeys) {
            JSONObject obj = event.optJSONObject(key);
            if (obj != null) {
                String name = obj.optString("name", "");
                if (!name.isEmpty()) return name;
                String slug = obj.optString("slug", "");
                if (!slug.isEmpty()) return slug;
                JSONObject nested = obj.optJSONObject("uniqueTournament");
                if (nested != null && !nested.optString("name", "").isEmpty())
                    return nested.optString("name");
                JSONObject category = obj.optJSONObject("category");
                if (category != null && !category.optString("name", "").isEmpty())
                    return category.optString("name");
            }
            Object raw = event.opt(key);
            if (raw instanceof String && !((String)raw).trim().isEmpty())
                return ((String)raw).trim();
        }
        JSONObject context = event.optJSONObject("sportEventContext");
        if (context != null) {
            JSONObject tournament = context.optJSONObject("tournament");
            if (tournament != null) {
                String name = tournament.optString("name", "");
                if (!name.isEmpty()) return name;
                JSONObject unique = tournament.optJSONObject("uniqueTournament");
                if (unique != null) return unique.optString("name", "");
            }
        }
        return "";
    }

    private boolean hockeyLeagueMatches(String selected, String competition) {
        if (selected == null || selected.equals("Все хоккейные лиги")) return true;
        String c = competition == null ? "" : competition.toLowerCase(Locale.ROOT)
                .replace("ё", "е").replaceAll("[^\\p{L}\\p{N}]+", " ").trim();
        String f = selected.toLowerCase(Locale.ROOT).replace("ё", "е");
        String[] aliases;
        if (f.contains("кхл")) aliases = new String[]{"khl", "kontinental hockey league", "континентальная хоккейная лига"};
        else if (f.contains("вхл")) aliases = new String[]{"vhl", "supreme hockey league", "высшая хоккейная лига"};
        else if (f.contains("мхл")) aliases = new String[]{"mhl", "junior hockey league", "молодежная хоккейная лига"};
        else if (f.contains("nhl")) aliases = new String[]{"nhl", "national hockey league"};
        else if (f.contains("ahl")) aliases = new String[]{"ahl", "american hockey league"};
        else if (f.contains("echl")) aliases = new String[]{"echl", "east coast hockey league"};
        else if (f.contains("shl")) aliases = new String[]{"shl", "swedish hockey league"};
        else if (f.contains("hockeyallsvenskan")) aliases = new String[]{"hockeyallsvenskan", "allsvenskan"};
        else if (f.contains("liiga")) aliases = new String[]{"liiga", "sm liiga", "sm-liiga"};
        else if (f.contains("чехия")) aliases = new String[]{"extraliga", "czech extraliga", "tipsport extraliga"};
        else if (f.contains("словакия")) aliases = new String[]{"slovak extraliga", "tipsport liga"};
        else if (f.contains("швейцария")) aliases = new String[]{"national league", "swiss national league"};
        else if (f.contains("германия")) aliases = new String[]{"del", "deutsche eishockey liga"};
        else if (f.contains("австрия")) aliases = new String[]{"ice hockey league", "icehl", "ebel"};
        else if (f.contains("норвегия")) aliases = new String[]{"elitehockey ligaen", "ehl", "fjordkraft ligaen"};
        else if (f.contains("польша")) aliases = new String[]{"polska hokej liga", "pko bp ekstraliga"};
        else if (f.contains("франция")) aliases = new String[]{"ligue magnus"};
        else if (f.contains("канад")) aliases = new String[]{"ohl", "whl", "qmjhl"};
        else if (f.contains("ncaa")) aliases = new String[]{"ncaa"};
        else if (f.contains("pwhl")) aliases = new String[]{"pwhl", "professional womens hockey league"};
        else if (f.contains("iihf")) aliases = new String[]{"iihf", "world championship", "worlds"};
        else if (f.contains("champions hockey")) aliases = new String[]{"champions hockey league", "chl"};
        else {
            String cleaned = f.replaceAll("^[^·]+·\\s*", "").replaceAll("[^\\p{L}\\p{N}]+", " ").trim();
            return !cleaned.isEmpty() && c.contains(cleaned);
        }
        for (String alias : aliases) {
            String a = alias.toLowerCase(Locale.ROOT).replaceAll("[^\\p{L}\\p{N}]+", " ").trim();
            if (!a.isEmpty() && c.contains(a)) return true;
        }
        return false;
    }


    private JSONObject hockeyRequest(String path, String token) throws Exception {
        HttpURLConnection conn = null;
        try {
            URL url = new URL("https://api.sportsapipro.com/v2/hockey" + path);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(12000); conn.setReadTimeout(18000);
            conn.setRequestProperty("x-api-key", token);
            conn.setRequestProperty("Accept", "application/json");
            int code = conn.getResponseCode();
            InputStream in = code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream();
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            if (in != null) {
                try (InputStream stream = in) {
                    byte[] buf = new byte[8192]; int n;
                    while ((n = stream.read(buf)) != -1) out.write(buf, 0, n);
                }
            }
            String body = out.toString("UTF-8");
            if (code < 200 || code >= 300)
                throw new IOException("HTTP " + code + ": " + body.substring(0, Math.min(300, body.length())));
            return new JSONObject(body);
        } finally { if (conn != null) conn.disconnect(); }
    }

    private JSONArray hockeyFindArray(Object value) {
        if (value instanceof JSONArray) return (JSONArray)value;
        if (value instanceof JSONObject) {
            JSONObject obj = (JSONObject)value;
            String[] likely = {"statistics", "data", "events", "results", "matches", "items", "response"};
            for (String key : likely) {
                Object child = obj.opt(key);
                if (child instanceof JSONArray) return (JSONArray)child;
            }
            for (String key : obj.keySet()) {
                JSONArray found = hockeyFindArray(obj.opt(key));
                if (found != null) return found;
            }
        }
        return null;
    }

    private void hockeyFlatten(Object value, String prefix, List<String> lines) {
        if (value instanceof JSONObject) {
            JSONObject obj = (JSONObject)value;
            for (String key : obj.keySet()) {
                Object child = obj.opt(key);
                String name = prefix.isEmpty() ? key : prefix + " · " + key;
                if (child instanceof JSONObject || child instanceof JSONArray) hockeyFlatten(child, name, lines);
                else if (child != null && child != JSONObject.NULL) {
                    String v = String.valueOf(child);
                    if (!v.trim().isEmpty() && !"null".equals(v)) lines.add(name + ": " + v);
                }
            }
        } else if (value instanceof JSONArray) {
            JSONArray arr = (JSONArray)value;
            for (int i=0;i<arr.length();i++) hockeyFlatten(arr.opt(i), prefix, lines);
        }
    }


    private JSONArray hockeyRecentEvents(int teamId, String token) throws Exception {
        JSONObject j = hockeyRequest("/api/teams/" + teamId + "/events/last/0", token);
        JSONArray a = hockeyFindArray(j);
        return a == null ? new JSONArray() : a;
    }

    private double hockeyAverageGoals(JSONArray events, int teamId) {
        double total = 0; int count = 0;
        for (int i=0;i<events.length();i++) {
            JSONObject e = events.optJSONObject(i); if (e == null) continue;
            JSONObject h = e.optJSONObject("homeTeam"), a = e.optJSONObject("awayTeam");
            JSONObject hs = e.optJSONObject("homeScore"), as = e.optJSONObject("awayScore");
            if (h == null || a == null || hs == null || as == null) continue;
            int homeGoals = hs.optInt("current", hs.optInt("display", -1));
            int awayGoals = as.optInt("current", as.optInt("display", -1));
            if (homeGoals < 0 || awayGoals < 0) continue;
            total += h.optInt("id", -2) == teamId ? homeGoals : awayGoals;
            count++;
        }
        return count == 0 ? -1 : total / count;
    }

    private String hockeyPretty(String key) {
        String k = key.toLowerCase(Locale.ROOT).replace("_", "").replace("-", "").replace(" ", "");
        if (k.contains("shotsongoal") || k.equals("shots")) return "Броски в створ";
        if (k.contains("save")) return "Сейвы";
        if (k.contains("powerplay")) return "Большинство";
        if (k.contains("penaltyminutes") || k.equals("pim")) return "Штрафные минуты";
        if (k.contains("faceoff")) return "Вбрасывания";
        if (k.contains("blockedshot")) return "Блокированные броски";
        if (k.equals("hits")) return "Силовые приёмы";
        if (k.contains("goal")) return "Голы";
        if (k.contains("period1")) return "1-й период";
        if (k.contains("period2")) return "2-й период";
        if (k.contains("period3")) return "3-й период";
        return key;
    }

    private void showHockeyMatchDetails(JSONObject event) {
        final long matchId = event.optLong("id", -1);
        if (matchId < 0) { toast("У матча нет ID для загрузки статистики"); return; }
        JSONObject home = event.optJSONObject("homeTeam"), away = event.optJSONObject("awayTeam");
        final String homeName = home == null ? "Хозяева" : home.optString("name", "Хозяева");
        final String awayName = away == null ? "Гости" : away.optString("name", "Гости");
        final int homeId = home == null ? -1 : home.optInt("id", -1);
        final int awayId = away == null ? -1 : away.optInt("id", -1);
        final String token = appPrefs.getString("sportsapi_token", "").trim();

        ScrollView detailScroll = new ScrollView(this);
        LinearLayout detailRoot = new LinearLayout(this);
        detailRoot.setOrientation(LinearLayout.VERTICAL);
        detailRoot.setPadding(dp(18), dp(20), dp(18), dp(28));
        detailRoot.setBackgroundColor(BG);
        detailScroll.addView(detailRoot);
        setContentView(detailScroll);

        Button back = button("← К МАТЧАМ");
        detailRoot.addView(back, lp(0, 8));
        back.setOnClickListener(v -> buildHockeyUi());
        TextView title = label("🏒 " + homeName + " — " + awayName, 20, GREEN, true);
        detailRoot.addView(title, lp(8, 8));
        TextView detailStatus = label("Загружаю статистику матча…", 14, Color.WHITE, false);
        detailRoot.addView(detailStatus, lp(4, 8));
        LinearLayout detailCards = new LinearLayout(this);
        detailCards.setOrientation(LinearLayout.VERTICAL);
        detailRoot.addView(detailCards, lp(0, 8));

        worker.execute(() -> {
            StringBuilder report = new StringBuilder();
            boolean gotStats = false;
            JSONObject statsJson = null, h2hJson = null, formJson = null;
            JSONArray homeRecent = new JSONArray(), awayRecent = new JSONArray();
            try {
                statsJson = hockeyRequest("/api/match/" + matchId + "/statistics", token);
                gotStats = true;
            } catch (Exception ex) { report.append("Статистика матча: ").append(ex.getMessage()).append("\\n\\n"); }
            try { h2hJson = hockeyRequest("/api/match/" + matchId + "/h2h", token); }
            catch (Exception ex) { report.append("Личные встречи: ").append(ex.getMessage()).append("\\n\\n"); }
            try { formJson = hockeyRequest("/api/match/" + matchId + "/pregame-form", token); }
            catch (Exception ex) { report.append("Форма перед матчем: ").append(ex.getMessage()).append("\\n\\n"); }
            if (homeId > 0) try { homeRecent = hockeyRecentEvents(homeId, token); }
            catch (Exception ex) { report.append("Последние матчи хозяев: ").append(ex.getMessage()).append("\\n\\n"); }
            if (awayId > 0) try { awayRecent = hockeyRecentEvents(awayId, token); }
            catch (Exception ex) { report.append("Последние матчи гостей: ").append(ex.getMessage()).append("\\n\\n"); }

            final JSONObject fs = statsJson, fh = h2hJson, ff = formJson;
            final JSONArray hr = homeRecent, ar = awayRecent;
            final double homeAvgGoals = hockeyAverageGoals(homeRecent, homeId);
            final double awayAvgGoals = hockeyAverageGoals(awayRecent, awayId);
            final boolean hasStats = gotStats;
            final String errors = report.toString();
            ui.post(() -> {
                detailCards.removeAllViews();
                detailStatus.setText("Матч ID " + matchId + " · данные SportsAPI Pro");
                if (hasStats && fs != null) {
                    detailCards.addView(label("📊 СТАТИСТИКА МАТЧА", 16, GREEN, true), lp(4, 6));
                    List<String> lines = new ArrayList<>();
                    hockeyFlatten(fs, "", lines);
                    if (lines.isEmpty()) detailCards.addView(label("Источник не вернул опубликованную статистику для этого матча.", 14, MUTED, false), lp(4, 8));
                    else {
                        int shown = 0;
                        for (String line : lines) {
                            if (shown++ >= 80) break;
                            String[] pair = line.split(": ", 2);
                            String text = pair.length == 2 ? hockeyPretty(pair[0].substring(pair[0].lastIndexOf(" · ") + 3)) + ": " + pair[1] : line;
                            detailCards.addView(label(text, 14, Color.WHITE, false), lp(4, 4));
                        }
                    }
                } else {
                    detailCards.addView(label("Статистика пока недоступна. Это может означать, что провайдер ещё не опубликовал её или тариф не включает этот endpoint.", 14, MUTED, false), lp(4, 8));
                }
                if (ff != null) {
                    detailCards.addView(label("📈 ФОРМА КОМАНД ПЕРЕД МАТЧЕМ", 16, GREEN, true), lp(4, 12));
                    List<String> formLines = new ArrayList<>(); hockeyFlatten(ff, "", formLines);
                    int n=0; for (String line : formLines) { if (n++ >= 35) break; detailCards.addView(label(line, 13, Color.WHITE, false), lp(4, 3)); }
                }
                if (fh != null) {
                    detailCards.addView(label("🤝 ЛИЧНЫЕ ВСТРЕЧИ", 16, GREEN, true), lp(4, 12));
                    List<String> h2hLines = new ArrayList<>(); hockeyFlatten(fh, "", h2hLines);
                    int n=0; for (String line : h2hLines) { if (n++ >= 45) break; detailCards.addView(label(line, 13, Color.WHITE, false), lp(4, 3)); }
                }
                detailCards.addView(label("🎯 ПРОГНОЗЫ", 16, GREEN, true), lp(4, 14));
                if (hr.length() > 0 || ar.length() > 0) {
                    detailCards.addView(label(homeName + " · последние матчи: " + hr.length(), 13, Color.WHITE, false), lp(4, 4));
                    detailCards.addView(label(awayName + " · последние матчи: " + ar.length(), 13, Color.WHITE, false), lp(4, 4));
                }
                if (homeAvgGoals >= 0 && awayAvgGoals >= 0) {
                    double projectedGoals = homeAvgGoals + awayAvgGoals;
                    detailCards.addView(label("Ожидаемый ориентир по голам: " + String.format(Locale.US, "%.2f", projectedGoals)
                            + " (сумма средних забитых голов за последние матчи)", 14, Color.WHITE, false), lp(4, 6));
                    detailCards.addView(label("Это статистический ориентир, не гарантия ставки. Для бросков нужна история матчевой статистики, если провайдер её отдаёт.", 13, MUTED, false), lp(4, 4));
                } else {
                    detailCards.addView(label("Недостаточно результатов последних матчей для расчёта среднего тотала голов. Проверь доступность истории в тарифе.", 14, MUTED, false), lp(4, 6));
                }
                if (!errors.isEmpty()) detailCards.addView(label("Диагностика API:\n" + errors, 12, MUTED, false), lp(4, 12));
            });
        });
    }

    private void loadHockey(boolean liveOnly) {
        if (!hockeyMode || cards == null || status == null) return;
        hockeyLastLiveOnly = liveOnly;
        final String filter = hockeyLeagueFilter;
        final String date = today();
        status.setText("Подключаю хоккейный источник SportsAPI Pro…"); cards.removeAllViews();
        final String token = appPrefs.getString("sportsapi_token", "").trim();
        if (token.isEmpty()) {
            status.setText("Нет API-токена. Открой ⚙ Настройки футбольного раздела и сохрани SportsAPI Pro token.");
            cards.addView(label("Хоккей использует тот же SportsAPI Pro ключ, что и футбол. Без ключа реальные матчи не загружаются.", 14, Color.WHITE, false), lp(8, 8));
            return;
        }
        worker.execute(() -> {
            try {
                String path = liveOnly ? "/api/live" : "/api/schedule/" + URLEncoder.encode(date, "UTF-8");
                JSONObject json = hockeyRequest(path, token);
                JSONArray events = json.optJSONArray("events");
                if (events == null && json.optJSONObject("data") != null) events = json.optJSONObject("data").optJSONArray("events");
                if (events == null && json.optJSONArray("data") != null) events = json.optJSONArray("data");
                if (events == null) throw new IOException("Источник ответил, но формат списка матчей отличается.");
                int sourceCount = events.length();
                List<JSONObject> result = new ArrayList<>();
                for (int i=0;i<events.length();i++) {
                    JSONObject e = events.optJSONObject(i); if (e == null) continue;
                    String competition = hockeyCompetitionName(e);
                    if (competition.isEmpty()) competition = "Турнир не указан";
                    if (!hockeyLeagueMatches(filter, competition)) continue;
                    result.add(e);
                }
                final List<JSONObject> matches = result;
                ui.post(() -> {
                    status.setText("SportsAPI Pro · получено: " + sourceCount + " · по фильтру: " + matches.size());
                    if (matches.isEmpty()) {
                        String hint = sourceCount == 0
                            ? "Сейчас API не вернул матчи в этом режиме. Попробуй расписание."
                            : "API вернул " + sourceCount + " матч(ей), но выбранная лига не совпала. Выбери «Все хоккейные лиги».";
                        cards.addView(label(hint, 14, Color.WHITE, false), lp(8, 8));
                    }
                    for (JSONObject e : matches) {
                        String competition = hockeyCompetitionName(e);
                        if (competition.isEmpty()) competition = "Хоккей";
                        JSONObject home = e.optJSONObject("homeTeam"), away = e.optJSONObject("awayTeam");
                        String hn = home == null ? "Хозяева" : home.optString("name", "Хозяева");
                        String an = away == null ? "Гости" : away.optString("name", "Гости");
                        JSONObject hs = e.optJSONObject("homeScore"), as = e.optJSONObject("awayScore");
                        String hscore = hs == null ? "–" : hs.has("current") ? String.valueOf(hs.opt("current")) : "–";
                        String ascore = as == null ? "–" : as.has("current") ? String.valueOf(as.opt("current")) : "–";
                        JSONObject st = e.optJSONObject("status");
                        String state = st == null ? "" : st.optString("description", "");
                        long id = e.optLong("id", -1);
                        String row = competition + "\n" + hn + "  " + hscore + " : " + ascore + "  " + an
                                + "\n" + state + (id >= 0 ? "  · ID " + id : "")
                                + "\nНажми, чтобы открыть статистику и анализ";
                        TextView card = label(row, 15, Color.WHITE, true);
                        card.setPadding(dp(14),dp(14),dp(14),dp(14));
                        card.setBackground(shape(PANEL, 14));
                        card.setOnClickListener(v -> showHockeyMatchDetails(e));
                        cards.addView(card, lp(0, 8));
                    }
                });
            } catch (Exception ex) {
                String msg = ex.getMessage() == null ? ex.toString() : ex.getMessage();
                ui.post(() -> { status.setText("Не удалось загрузить хоккей: " + msg); cards.removeAllViews();
                    cards.addView(label("Проверь API-токен и доступность SportsAPI Pro.", 13, MUTED, false), lp(8,8)); });
            }
        });
    }

    private void openDatePicker() {
        Calendar c = Calendar.getInstance();
        try { c.setTime(new SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(chosenDate)); } catch (Exception ignored) {}
        DatePickerDialog dlg = new DatePickerDialog(this, (picker, y, m, d) -> {
            Calendar picked = Calendar.getInstance(); picked.set(y, m, d);
            chosenDate = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(picked.getTime());
            dateWasChosen = true; mode = "custom"; selectedDateText.setText(tr("date") + chosenDate); loadFixtures();
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH));
        dlg.show();
    }

    private String fetchWithFallback(String path) throws Exception {
        Exception last = null;
        for (String base : new String[]{RAW, CDN}) {
            HttpURLConnection conn = null;
            try {
                URL url = new URL(base + path);
                conn = (HttpURLConnection) url.openConnection();
                conn.setConnectTimeout(12000); conn.setReadTimeout(18000);
                conn.setRequestProperty("User-Agent", "FootballAnalyzer3/3.0");
                conn.setRequestProperty("Accept", "text/csv,*/*");
                int code = conn.getResponseCode();
                InputStream in = (code >= 200 && code < 300) ? conn.getInputStream() : conn.getErrorStream();
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                if (in != null) { try (InputStream stream = in) { byte[] buf = new byte[8192]; int n; while ((n = stream.read(buf)) != -1) out.write(buf, 0, n); } }
                String body = out.toString("UTF-8");
                if (code == 404) throw new FileNotFoundException("Для этого турнира файл пока не опубликован: " + path);
                if (code < 200 || code >= 300) throw new IOException("HTTP " + code + " при загрузке CSV");
                if (body.trim().isEmpty()) throw new IOException("Источник вернул пустой CSV: " + path);
                return body;
            } catch (Exception e) { last = e; }
            finally { if (conn != null) conn.disconnect(); }
        }
        throw last == null ? new IOException("Не удалось подключиться к open-matchday") : last;
    }

    private List<String[]> parseCsv(String csv) throws IOException {
        List<String[]> rows = new ArrayList<>();
        BufferedReader reader = new BufferedReader(new StringReader(csv));
        String line;
        while ((line = reader.readLine()) != null) {
            if (line.trim().isEmpty()) continue;
            ArrayList<String> cells = new ArrayList<>(); StringBuilder cell = new StringBuilder(); boolean quoted = false;
            for (int i = 0; i < line.length(); i++) {
                char ch = line.charAt(i);
                if (ch == '"') {
                    if (quoted && i + 1 < line.length() && line.charAt(i + 1) == '"') { cell.append('"'); i++; }
                    else quoted = !quoted;
                } else if (ch == ',' && !quoted) { cells.add(cell.toString()); cell.setLength(0); }
                else cell.append(ch);
            }
            cells.add(cell.toString()); rows.add(cells.toArray(new String[0]));
        }
        return rows;
    }

    private Map<String, Integer> headerIndex(String[] header) {
        Map<String, Integer> map = new HashMap<>();
        for (int i = 0; i < header.length; i++) map.put(header[i].trim().toLowerCase(Locale.US), i);
        return map;
    }
    private String val(String[] row, Map<String, Integer> ix, String key) {
        Integer i = ix.get(key.toLowerCase(Locale.US)); return i == null || i < 0 || i >= row.length ? "" : row[i].trim();
    }
    private Double number(String[] row, Map<String, Integer> ix, String key) {
        try { String s = val(row, ix, key); return s.isEmpty() ? null : Double.parseDouble(s); } catch (Exception e) { return null; }
    }

    private static class MatchGroup {
        League league; List<String[]> found; List<String[]> results; Map<String,Integer> ix; int fixtureCount, resultCount;
        MatchGroup(League l, List<String[]> f, List<String[]> r, Map<String,Integer> i, int fc, int rc) { league=l; found=f; results=r; ix=i; fixtureCount=fc; resultCount=rc; }
    }

    private String fetchQuickFixtures(String path) throws Exception {
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL(RAW + path).openConnection();
            conn.setConnectTimeout(3500); conn.setReadTimeout(4500);
            conn.setRequestProperty("User-Agent", "FootballAnalyzer/4.1.3");
            conn.setRequestProperty("Accept", "text/csv,*/*");
            int code=conn.getResponseCode();
            if(code<200 || code>=300) throw new IOException("HTTP " + code);
            try(InputStream in=conn.getInputStream(); ByteArrayOutputStream out=new ByteArrayOutputStream()) {
                byte[] b=new byte[8192]; int n; while((n=in.read(b))!=-1) out.write(b,0,n);
                return out.toString("UTF-8");
            }
        } finally { if(conn!=null) conn.disconnect(); }
    }

    private MatchGroup loadOneLeagueToday(League league, String target) throws Exception {
        List<String[]> fixtures=parseCsv(fetchQuickFixtures(league.folder + "/fixtures_" + SEASON + ".csv"));
        if(fixtures.isEmpty()) return null;
        Map<String,Integer> ix=headerIndex(fixtures.get(0));
        if(!ix.containsKey("date") || !ix.containsKey("home") || !ix.containsKey("away")) return null;
        List<String[]> found=new ArrayList<>();
        for(int i=1;i<fixtures.size();i++) { String[] row=fixtures.get(i); if(val(row,ix,"date").equals(target)) found.add(row); }
        if(found.isEmpty()) return null;
        found.sort((a,b)->val(a,ix,"date").concat(val(a,ix,"time")).compareTo(val(b,ix,"date").concat(val(b,ix,"time"))));
        return new MatchGroup(league,found,new ArrayList<>(),ix,fixtures.size()-1,0);
    }

    private void loadAllToday() {
        final String target = mode.equals("custom") ? chosenDate : mode.equals("tomorrow") ? tomorrow() : today();
        status.setText("Загружаю матчи всех турниров на " + target + "…"); cards.removeAllViews();
        worker.execute(() -> {
            ExecutorService pool=Executors.newFixedThreadPool(8);
            CompletionService<MatchGroup> completion=new ExecutorCompletionService<>(pool);
            for(League l:leagues) completion.submit(() -> loadOneLeagueToday(l,target));
            List<MatchGroup> groups=new ArrayList<>();
            try {
                for(int i=0;i<leagues.length;i++) {
                    Future<MatchGroup> f=completion.poll(25,TimeUnit.SECONDS);
                    if(f==null) break;
                    try { MatchGroup g=f.get(); if(g!=null && !g.found.isEmpty()) groups.add(g); }
                    catch(Exception ignored) { }
                }
            } catch(InterruptedException interrupted) { Thread.currentThread().interrupt(); }
            finally { pool.shutdownNow(); }
            groups.sort((a,b)->a.league.title.compareToIgnoreCase(b.league.title));
            int total=0; for(MatchGroup g:groups) total+=g.found.size();
            final int count=total; final List<MatchGroup> ready=groups;
            ui.post(() -> {
                status.setText(target + " · найдено матчей: " + count + " · турниров: " + ready.size());
                if(ready.isEmpty()) { cards.addView(label("На " + target + " в доступных опубликованных расписаниях матчей не найдено.",15,Color.WHITE,true),lp(8,8)); return; }
                for(MatchGroup g:ready) {
                    TextView heading=label(g.league.title,16,GREEN,true); cards.addView(heading,lp(10,5));
                    for(String[] row:g.found) addMatchCard(g.league,row,g.ix,g.results);
                }
            });
        });
    }

    private void loadFixtures() {
        if (status == null || cards == null) return;
        if(selectedLeague==0) { loadAllToday(); return; }
        final League league = leagues[selectedLeague-1]; final String selectedMode = mode; final String date = chosenDate;
        status.setText("Загружаю CSV: " + league.title + "…"); cards.removeAllViews();
        worker.execute(() -> {
            try {
                String folder = league.folder + "/";
                List<String[]> fixtures = parseCsv(fetchWithFallback(folder + "fixtures_" + SEASON + ".csv"));
                List<String[]> results;
                try { results = parseCsv(fetchWithFallback(folder + "results_" + SEASON + ".csv")); }
                catch (Exception unavailable) { results = new ArrayList<>(); }
                if (fixtures.isEmpty()) throw new IOException("CSV расписания не содержит заголовка и матчей.");
                Map<String, Integer> fixIx = headerIndex(fixtures.get(0));
                if (!fixIx.containsKey("date") || !fixIx.containsKey("home") || !fixIx.containsKey("away")) throw new IOException("Неожиданный формат CSV расписания.");
                String target = date;
                if (selectedMode.equals("today")) target = today();
                else if (selectedMode.equals("tomorrow")) target = tomorrow();
                final String filterDate = target;
                List<String[]> found = new ArrayList<>();
                for (int i = 1; i < fixtures.size(); i++) {
                    String[] row = fixtures.get(i); String rowDate = val(row, fixIx, "date");
                    if (rowDate.equals(filterDate)) found.add(row);
                }
                found.sort((a,b) -> (val(a,fixIx,"date") + val(a,fixIx,"time")).compareTo(val(b,fixIx,"date") + val(b,fixIx,"time")));
                List<String[]> finalResults = results; int fixtureCount = fixtures.size() - 1; int resultCount = Math.max(0, results.size() - 1);
                ui.post(() -> renderMatches(league, found, finalResults, fixIx, filterDate, selectedMode, fixtureCount, resultCount));
            } catch (Exception e) {
                String message = e.getMessage() == null ? e.toString() : e.getMessage();
                ui.post(() -> { status.setText("Ошибка open-matchday: " + message); cards.removeAllViews(); });
            }
        });
    }

    private void renderMatches(League league, List<String[]> found, List<String[]> results, Map<String,Integer> fixIx,
                               String date, String selectedMode, int fixtureCount, int resultCount) {
        status.setText("open-matchday · расписание: " + fixtureCount + " · сыграно: " + resultCount + " · найдено: " + found.size());
        if (found.isEmpty()) {
            String msg = selectedMode.equals("all") ? "В опубликованном файле расписания пока нет будущих матчей." : "На " + date + " матчей в опубликованном расписании этого турнира нет. Это не ошибка API.";
            cards.addView(label(msg, 15, Color.WHITE, true), lp(8, 8));
            return;
        }
        for (String[] row : found) addMatchCard(league, row, fixIx, results);
    }

    // Дополнительный источник статистики: публичный ESPN Site API (без ключа).
    // Используется только как резерв, когда поле отсутствует в open-matchday.
    private String espnLeague(League league) {
        String f = league.folder;
        if (f.equals("UEFA_1_champions-league")) return "uefa.champions";
        if (f.equals("UEFA_1_europa-league")) return "uefa.europa";
        if (f.equals("UEFA_1_conference-league")) return "uefa.europa.conf";
        if (f.startsWith("ENG_1_")) return "eng.1";
        if (f.startsWith("ENG_2_")) return "eng.2";
        if (f.startsWith("ENG_3_")) return "eng.3";
        if (f.startsWith("ENG_4_")) return "eng.4";
        if (f.startsWith("ESP_1_")) return "esp.1";
        if (f.startsWith("ESP_2_")) return "esp.2";
        if (f.startsWith("GER_1_")) return "ger.1";
        if (f.startsWith("ITA_1_")) return "ita.1";
        if (f.startsWith("ITA_2_")) return "ita.2";
        if (f.startsWith("FRA_1_")) return "fra.1";
        if (f.startsWith("FRA_2_")) return "fra.2";
        if (f.startsWith("NED_1_")) return "ned.1";
        if (f.startsWith("POR_1_")) return "por.1";
        if (f.startsWith("BEL_1_")) return "bel.1";
        if (f.startsWith("TUR_1_")) return "tur.1";
        if (f.startsWith("GRE_1_")) return "gre.1";
        if (f.startsWith("SCO_1_")) return "sco.1";
        if (f.startsWith("POL_1_")) return "pol.1";
        if (f.startsWith("NOR_1_")) return "nor.1";
        if (f.startsWith("AUT_1_")) return "aut.1";
        if (f.startsWith("SUI_1_")) return "sui.1";
        if (f.startsWith("DEN_1_")) return "den.1";
        if (f.startsWith("SWE_1_")) return "swe.1";
        if (f.startsWith("BRA_1_")) return "bra.1";
        if (f.startsWith("USA_1_")) return "usa.1";
        if (f.startsWith("JPN_1_")) return "jpn.1";
        if (f.startsWith("AUS_1_")) return "aus.1";
        return "";
    }

    private JSONObject fetchJson(String urlText) throws Exception {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(urlText).openConnection();
            c.setConnectTimeout(5000); c.setReadTimeout(7000);
            c.setRequestProperty("User-Agent", "Mozilla/5.0 FootballAnalyzer/3.8");
            c.setRequestProperty("Accept", "application/json");
            int code = c.getResponseCode();
            InputStream in = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
            if (in == null) throw new IOException("ESPN HTTP " + code);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            try (InputStream stream = in) { byte[] b = new byte[8192]; int n; while ((n=stream.read(b))!=-1) out.write(b,0,n); }
            if (code < 200 || code >= 300) throw new IOException("ESPN HTTP " + code);
            return new JSONObject(out.toString("UTF-8"));
        } finally { if (c != null) c.disconnect(); }
    }

    private String normTeam(String name) {
        String n = java.text.Normalizer.normalize(name == null ? "" : name, java.text.Normalizer.Form.NFD)
                .replaceAll("\\p{M}+", "").toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", "");
        n = n.replace("fc", "").replace("afc", "").replace("cf", "");
        return n;
    }
    private boolean sameTeam(String a, String b) {
        String x=normTeam(a), y=normTeam(b);
        return !x.isEmpty() && !y.isEmpty() && (x.equals(y) || (x.length()>=3 && y.length()>=3 && (x.contains(y)||y.contains(x))));
    }
    private String statName(JSONObject stat) {
        return (stat.optString("name", "") + " " + stat.optString("displayName", "") + " " + stat.optString("abbreviation", "")).toLowerCase(Locale.ROOT).replaceAll("[^a-z]", "");
    }
    private Double espnStat(JSONArray stats, String wanted) {
        if (stats == null) return null;
        for (int i=0;i<stats.length();i++) {
            JSONObject st=stats.optJSONObject(i); if(st==null) continue;
            String n=statName(st); boolean match=false;
            if (wanted.equals("corners")) match=n.contains("woncorners")||n.equals("corners")||n.contains("cornerkicks");
            else if (wanted.equals("yellow")) match=n.contains("yellowcards")||n.equals("yellowcard");
            else if (wanted.equals("target")) match=n.contains("shotsontarget")||n.contains("shotsongoal");
            else if (wanted.equals("shots")) match=n.equals("totalshots")||n.equals("shots")||n.equals("totalshot");
            else if (wanted.equals("fouls")) match=n.contains("foulscommitted")||n.equals("fouls");
            if (match) {
                String v=st.optString("displayValue", "");
                if(v.isEmpty()) v=st.optString("value", "");
                try { return Double.parseDouble(v.replace(",", "")); } catch(Exception ignored) {}
            }
        }
        return null;
    }
    private Map<String,Double> parseEspnTeamStats(JSONObject teamBox) {
        Map<String,Double> m=new HashMap<>();
        JSONArray stats=teamBox.optJSONArray("statistics");
        for(String key:new String[]{"corners","yellow","target","shots","fouls"}) {
            Double v=espnStat(stats,key); if(v!=null)m.put(key,v);
        }
        return m;
    }
    private String matchKey(String date,String home,String away) { return date+"|"+normTeam(home)+"|"+normTeam(away); }

    private Map<String,Map<String,Double>> loadEspnFallback(League league, String home, String away, List<String[]> rows, Map<String,Integer> ix) {
        Map<String,Map<String,Double>> out=new HashMap<>();
        String slug=espnLeague(league); if(slug.isEmpty()) return out;
        LinkedHashMap<String,String[]> candidates=new LinkedHashMap<>();
        for(String team:new String[]{home,away}) {
            ArrayList<String[]> apps=new ArrayList<>();
            for(int i=1;i<rows.size();i++) { String[] r=rows.get(i); if(team.equalsIgnoreCase(val(r,ix,"home"))||team.equalsIgnoreCase(val(r,ix,"away"))) apps.add(r); }
            apps.sort((a,b)->val(b,ix,"date").compareTo(val(a,ix,"date")));
            int count=0; for(String[] r:apps) { if(count>=10)break; String key=matchKey(val(r,ix,"date"),val(r,ix,"home"),val(r,ix,"away")); candidates.put(key,r); count++; }
        }
        // Один запрос табло на весь интервал последних матчей, затем отдельные summary только для совпавших игр.
        String minDate=null,maxDate=null;
        for(String[] r:candidates.values()) { String d=val(r,ix,"date"); if(d.length()==10) { if(minDate==null||d.compareTo(minDate)<0)minDate=d; if(maxDate==null||d.compareTo(maxDate)>0)maxDate=d; } }
        JSONObject board=null;
        if(minDate!=null) try { board=fetchJson("https://site.api.espn.com/apis/site/v2/sports/soccer/"+slug+"/scoreboard?dates="+minDate.replace("-","")+"-"+maxDate.replace("-","")); } catch(Exception ignored) {}
        for(String[] r:candidates.values()) {
            String date=val(r,ix,"date"), rh=val(r,ix,"home"), ra=val(r,ix,"away");
            if(date.length()!=10 || board==null) continue;
            String key=matchKey(date,rh,ra);
            boolean need=false;
            for(String prefix:new String[]{"home_","away_"}) for(String field:new String[]{"corners","yellow","target","shots","fouls"}) if(number(r,ix,prefix+field)==null) need=true;
            if(!need) continue;
            try {
                JSONArray events=board.optJSONArray("events"); String eventId=null;
                if(events!=null) for(int ei=0;ei<events.length();ei++) {
                    JSONObject ev=events.optJSONObject(ei); if(ev==null)continue;
                    JSONArray comps=ev.optJSONArray("competitions"); if(comps==null||comps.length()==0)continue;
                    JSONArray sides=comps.optJSONObject(0).optJSONArray("competitors"); if(sides==null)continue;
                    String eh="",ea="";
                    for(int si=0;si<sides.length();si++) { JSONObject side=sides.optJSONObject(si); JSONObject t=side==null?null:side.optJSONObject("team"); if(t==null)continue; if("home".equalsIgnoreCase(side.optString("homeAway")))eh=t.optString("displayName",t.optString("name","")); else ea=t.optString("displayName",t.optString("name","")); }
                    if(sameTeam(rh,eh)&&sameTeam(ra,ea)) { eventId=ev.optString("id",null); break; }
                }
                if(eventId==null) continue;
                JSONObject summary=fetchJson("https://site.api.espn.com/apis/site/v2/sports/soccer/"+slug+"/summary?event="+eventId);
                JSONObject box=summary.optJSONObject("boxscore"); JSONArray teams=box==null?null:box.optJSONArray("teams");
                if(teams==null)continue;
                for(int ti=0;ti<teams.length();ti++) {
                    JSONObject tb=teams.optJSONObject(ti); if(tb==null)continue;
                    JSONObject t=tb.optJSONObject("team"); String tn=t==null?"":t.optString("displayName",t.optString("name",""));
                    String side=sameTeam(rh,tn)?"home":sameTeam(ra,tn)?"away":""; if(side.isEmpty())continue;
                    Map<String,Double> vals=parseEspnTeamStats(tb); if(!vals.isEmpty()) out.put(key+"|"+side,vals);
                }
            } catch(Exception ignored) { /* резервный источник может не покрывать турнир/матч */ }
        }
        return out;
    }

    private static class TeamStats {
        int played, wins, draws, losses;
        double goalsFor, goalsAgainst;
        final Map<String, ArrayList<Double>> metrics = new HashMap<>();
        void addMetric(String key, Double value) {
            if (value == null) return;
            if (!metrics.containsKey(key)) metrics.put(key, new ArrayList<>());
            metrics.get(key).add(value);
        }
        ArrayList<Double> values(String key) { return metrics.get(key); }
        double metricSum(String key) { ArrayList<Double> v=values(key); if(v==null)return 0; double s=0; for(double x:v)s+=x; return s; }
        double metricAvg(String key) { ArrayList<Double> v=values(key); return v==null||v.isEmpty()?Double.NaN:metricSum(key)/v.size(); }
        double avgGoalsFor() { return played == 0 ? 0 : goalsFor / played; }
        double avgGoalsAgainst() { return played == 0 ? 0 : goalsAgainst / played; }
        String form() { return "В-Н-П: " + wins + "-" + draws + "-" + losses; }
    }

    private void addMatchCard(League league, String[] match, Map<String,Integer> fixIx, List<String[]> resultRows) {
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(14),dp(13),dp(14),dp(13)); box.setBackground(shape(PANEL,15)); cards.addView(box,lp(0,10));
        String date = val(match,fixIx,"date"), time = val(match,fixIx,"time"), home = val(match,fixIx,"home"), away = val(match,fixIx,"away"), round = val(match,fixIx,"gw");
        box.addView(label(date + (time.isEmpty()?"":" · "+time) + (round.isEmpty()?"":" · тур "+round),12,MUTED,true));
        box.addView(label(home + " — " + away,20,Color.WHITE,true),lp(5,8));
        TextView report = label("Нажми кнопку ниже: покажу итоги последних матчей, средние показатели и прогнозы тоталов.",14,0xffe1eee6,false); report.setLineSpacing(dp(3),1.0f); box.addView(report,lp(5,8));
        final String[] cachedReport = {""};
        Button analyze = button("📊 ПОЛНЫЙ АНАЛИЗ И ПРОГНОЗ"); box.addView(analyze);
        analyze.setOnClickListener(v -> {
            analyze.setEnabled(false); report.setText("Собираю статистику последних " + analysisMatchCount + " матчей…");
            worker.execute(() -> {
                String text = makeReport(league, home, away, resultRows);
                ui.post(() -> { cachedReport[0] = text; report.setText(text); analyze.setEnabled(true); });
            });
        });
        Button save = button("💾 СОХРАНИТЬ АНАЛИЗ В ИСТОРИЮ"); box.addView(save,lp(7,0));
        save.setOnClickListener(v -> {
            String saved = date + " · " + league.title + "\n" + home + " — " + away + (cachedReport[0].isEmpty() ? "\nАнализ ещё не рассчитан" : "\n" + cachedReport[0]);
            saveHistory(saved); Toast.makeText(this,"Матч и анализ сохранены",Toast.LENGTH_SHORT).show();
        });
    }

    // Загружает историю команды не только из выбранного турнира, но и из остальных
    // опубликованных турниров open-matchday. Матчи без итогового счёта отбрасываются.
    private List<String[]> collectHistoryAcrossCompetitions(League currentLeague, String home, String away, List<String[]> currentRows) {
        if (currentRows == null || currentRows.isEmpty()) return currentRows;
        final String[] header = currentRows.get(0);
        final Map<String,Integer> targetIx = headerIndex(header);
        final LinkedHashMap<String,String[]> unique = new LinkedHashMap<>();
        for (int i=1;i<currentRows.size();i++) {
            String[] r=currentRows.get(i);
            if (sameTeam(val(r,targetIx,"home"),home) || sameTeam(val(r,targetIx,"away"),home) ||
                sameTeam(val(r,targetIx,"home"),away) || sameTeam(val(r,targetIx,"away"),away)) {
                unique.put(matchKey(val(r,targetIx,"date"),val(r,targetIx,"home"),val(r,targetIx,"away")),r);
            }
        }
        ExecutorService pool=Executors.newFixedThreadPool(6);
        ArrayList<Future<List<String[]>>> jobs=new ArrayList<>();
        for (League league : leagues) {
            if (currentLeague != null && league.folder.equals(currentLeague.folder)) continue;
            jobs.add(pool.submit(() -> {
                try {
                    List<String[]> csv=parseCsv(fetchQuickFixtures(league.folder + "/results_" + SEASON + ".csv"));
                    if(csv.size()<2) return Collections.emptyList();
                    Map<String,Integer> sourceIx=headerIndex(csv.get(0));
                    if(!sourceIx.containsKey("date") || !sourceIx.containsKey("home") || !sourceIx.containsKey("away") ||
                       !sourceIx.containsKey("ft_home") || !sourceIx.containsKey("ft_away")) return Collections.emptyList();
                    ArrayList<String[]> matched=new ArrayList<>();
                    for(int i=1;i<csv.size();i++) {
                        String[] r=csv.get(i);
                        boolean relevant=sameTeam(val(r,sourceIx,"home"),home) || sameTeam(val(r,sourceIx,"away"),home) ||
                                        sameTeam(val(r,sourceIx,"home"),away) || sameTeam(val(r,sourceIx,"away"),away);
                        if(!relevant || number(r,sourceIx,"ft_home")==null || number(r,sourceIx,"ft_away")==null) continue;
                        String[] mapped=new String[header.length];
                        for(int c=0;c<header.length;c++) mapped[c]=val(r,sourceIx,header[c].trim().toLowerCase(Locale.US));
                        matched.add(mapped);
                    }
                    return matched;
                } catch(Exception ignored) { return Collections.emptyList(); }
            }));
        }
        long deadline=System.currentTimeMillis()+15000;
        for(Future<List<String[]>> job:jobs) {
            try {
                long left=deadline-System.currentTimeMillis(); if(left<=0) { job.cancel(true); continue; }
                for(String[] r:job.get(left,TimeUnit.MILLISECONDS)) {
                    String key=matchKey(val(r,targetIx,"date"),val(r,targetIx,"home"),val(r,targetIx,"away"));
                    unique.put(key,r);
                }
            } catch(Exception ignored) { job.cancel(true); }
        }
        pool.shutdownNow();
        ArrayList<String[]> merged=new ArrayList<>(); merged.add(header);
        merged.addAll(unique.values());
        merged.subList(1,merged.size()).sort((a,b)->val(b,targetIx,"date").compareTo(val(a,targetIx,"date")));
        return merged;
    }

    private TeamStats collectTeam(String team, List<String[]> rows, Map<String,Integer> ix, Map<String,Map<String,Double>> supplemental) {
        ArrayList<String[]> appearances = new ArrayList<>();
        for (int i=1; i<rows.size(); i++) {
            String[] r=rows.get(i);
            if (sameTeam(val(r,ix,"home"),team) || sameTeam(val(r,ix,"away"),team)) appearances.add(r);
        }
        appearances.sort((a,b) -> val(b,ix,"date").compareTo(val(a,ix,"date")));
        TeamStats st = new TeamStats();
        for (String[] r : appearances) {
            if (st.played >= analysisMatchCount) break;
            boolean atHome = sameTeam(team, val(r,ix,"home"));
            Double gf=number(r,ix,atHome?"ft_home":"ft_away");
            Double ga=number(r,ix,atHome?"ft_away":"ft_home");
            if (gf==null || ga==null) continue;
            st.played++; st.goalsFor+=gf; st.goalsAgainst+=ga;
            if (gf>ga) st.wins++; else if (gf.equals(ga)) st.draws++; else st.losses++;
            String side = atHome ? "home" : "away";
            String key = matchKey(val(r,ix,"date"),val(r,ix,"home"),val(r,ix,"away")) + "|" + side;
            Map<String,Double> extra = supplemental == null ? null : supplemental.get(key);
            for (String metric : new String[]{"corners","yellow","target","shots","fouls"}) {
                Double value = number(r,ix,side+"_"+metric);
                if (value == null && extra != null) value = extra.get(metric);
                st.addMetric(metric,value);
            }
        }
        return st;
    }

    private String oneDecimal(double v) { return String.format(Locale.US,"%.1f",v); }
    private String metricTeamLine(String team, TeamStats st, String key) {
        ArrayList<Double> vals=st.values(key);
        if(vals==null||vals.isEmpty()) return "   " + team + ": нет опубликованных данных";
        return "   " + team + ": всего " + oneDecimal(st.metricSum(key)) + " · в среднем " + oneDecimal(st.metricAvg(key)) + " за матч (данные по " + vals.size() + " матчам)";
    }
    private String metricSection(String emoji, String title, String key, TeamStats h, TeamStats a, String home, String away) {
        return emoji + " " + title + "\n" + metricTeamLine(home,h,key) + "\n" + metricTeamLine(away,a,key) + "\n";
    }
    private String market(String title, double lambda, int line, String unit) {
        if (Double.isNaN(lambda) || lambda <= 0) return "   " + title + ": недостаточно статистики\n";
        double under=poissonCdf((int)Math.floor(line+0.5),lambda);
        return "   " + title + " — линия " + line + ".5 " + unit + "\n" +
               "      🔼 Больше: " + pct(1-under) + "   🔽 Меньше: " + pct(under) + "\n";
    }
    private double combinedAvg(TeamStats h, TeamStats a, String key) {
        if(h.values(key)==null||a.values(key)==null||h.values(key).size()<3||a.values(key).size()<3) return Double.NaN;
        return h.metricAvg(key)+a.metricAvg(key);
    }
    private String makeReport(League league, String home, String away, List<String[]> rows) {
        if (rows == null || rows.size() < 2) return "⚠️ АНАЛИЗ НЕВОЗМОЖЕН\nНет опубликованных сыгранных матчей этой лиги.";
        Map<String,Integer> ix = headerIndex(rows.get(0));
        List<String[]> historyRows = collectHistoryAcrossCompetitions(league,home,away,rows);
        Map<String,Map<String,Double>> supplemental = loadEspnFallback(league,home,away,rows,ix);
        TeamStats h=collectTeam(home,historyRows,ix,supplemental), a=collectTeam(away,historyRows,ix,supplemental);
        StringBuilder out = new StringBuilder();
        out.append("━━━━━━━━━━━━━━━━━━\n⚽ АНАЛИЗ МАТЧА\n").append(home).append(" — ").append(away).append("\n━━━━━━━━━━━━━━━━━━\n\n");
        out.append("📈 1. ГОЛЫ И ФОРМА КОМАНД\n");
        out.append("🏠 ").append(home).append("\n");
        out.append("   Сыграно матчей: ").append(h.played).append(" из ").append(analysisMatchCount).append("\n");
        out.append("   Забито: ").append(oneDecimal(h.goalsFor)).append(" всего · ").append(oneDecimal(h.avgGoalsFor())).append(" за матч\n");
        out.append("   Пропущено: ").append(oneDecimal(h.goalsAgainst)).append(" всего · ").append(oneDecimal(h.avgGoalsAgainst())).append(" за матч\n");
        out.append("   Результаты: ").append(h.form()).append("\n\n");
        out.append("✈️ ").append(away).append("\n");
        out.append("   Сыграно матчей: ").append(a.played).append(" из ").append(analysisMatchCount).append("\n");
        out.append("   Забито: ").append(oneDecimal(a.goalsFor)).append(" всего · ").append(oneDecimal(a.avgGoalsFor())).append(" за матч\n");
        out.append("   Пропущено: ").append(oneDecimal(a.goalsAgainst)).append(" всего · ").append(oneDecimal(a.avgGoalsAgainst())).append(" за матч\n");
        out.append("   Результаты: ").append(a.form()).append("\n\n");
        out.append("📊 2. ДЕТАЛЬНАЯ СТАТИСТИКА ПО КОМАНДАМ\n");
        out.append(metricSection("🚩","Угловые","corners",h,a,home,away)).append("\n");
        out.append(metricSection("🟨","Жёлтые карточки","yellow",h,a,home,away)).append("\n");
        out.append(metricSection("🎯","Удары в створ","target",h,a,home,away)).append("\n");
        out.append(metricSection("🥅","Все удары по воротам","shots",h,a,home,away)).append("\n");
        out.append(metricSection("🤼","Фолы","fouls",h,a,home,away)).append("\n");
        out.append("↗️ Вбрасывания из аута\n   Источник open-matchday не публикует эту статистику — цифры не подставляются.\n\n");
        out.append("🔮 3. ПРОГНОЗЫ ТОТАЛОВ НА МАТЧ\n");
        if(h.played<3||a.played<3) {
            out.append("⚠️ Для надёжного расчёта пока мало матчей: нужно минимум 3 сыгранных матча каждой команды.\n");
        } else {
            double expH=Math.max(0.1,Math.min(4.5,(h.avgGoalsFor()+a.avgGoalsAgainst())/2.0));
            double expA=Math.max(0.1,Math.min(4.5,(a.avgGoalsFor()+h.avgGoalsAgainst())/2.0));
            double[] probs=poissonOutcome(expH,expA);
            out.append("⚽ ГОЛЫ · ожидаемый счёт: ").append(home).append(" ").append(fmt(expH)).append(" : ").append(fmt(expA)).append(" ").append(away).append("\n");
            out.append("   1X2: ").append(home).append(" ").append(pct(probs[0])).append(" · ничья ").append(pct(probs[1])).append(" · ").append(away).append(" ").append(pct(probs[2])).append("\n");
            out.append(market("Тотал голов",expH+expA,2,"голов"));
            out.append(market("Тотал голов",expH+expA,3,"голов"));
            out.append("\n🚩 УГЛОВЫЕ\n").append(market("Тотал угловых",combinedAvg(h,a,"corners"),8,"угловых"));
            out.append(market("Тотал угловых",combinedAvg(h,a,"corners"),9,"угловых"));
            out.append("\n🟨 ЖЁЛТЫЕ КАРТОЧКИ\n").append(market("Тотал карточек",combinedAvg(h,a,"yellow"),3,"карточек"));
            out.append(market("Тотал карточек",combinedAvg(h,a,"yellow"),4,"карточек"));
            out.append("\n🤼 ФОЛЫ\n").append(market("Тотал фолов",combinedAvg(h,a,"fouls"),21,"фолов"));
            out.append(market("Тотал фолов",combinedAvg(h,a,"fouls"),23,"фолов"));
            out.append("\n🎯 УДАРЫ В СТВОР\n").append(market("Тотал ударов в створ",combinedAvg(h,a,"target"),7,"ударов"));
            out.append(market("Тотал ударов в створ",combinedAvg(h,a,"target"),8,"ударов"));
            out.append("\n🥅 ВСЕ УДАРЫ\n").append(market("Тотал всех ударов",combinedAvg(h,a,"shots"),21,"ударов"));
            out.append(market("Тотал всех ударов",combinedAvg(h,a,"shots"),23,"ударов"));
        }
        out.append("\n━━━━━━━━━━━━━━━━━━\nℹ️ КАК ЧИТАТЬ ПРОГНОЗ\n🔼 Больше — вероятность превышения указанной линии. 🔽 Меньше — вероятность остаться ниже неё. Это математическая оценка по средним показателям последних матчей, не гарантия и не букмекерские коэффициенты.\n");
        out.append("Сначала используются данные open-matchday; если отдельные показатели отсутствуют, приложение пытается найти их в публичном ESPN API без ключа. Если ESPN не покрывает матч или турнир, статистика остаётся пустой. Угловые, карточки, удары и фолы доступны не для всех матчей. Вбрасывания из аута в этом источнике отсутствуют.\n");
        out.append("Выборка: ").append(h.played).append(" матчей — ").append(home).append("; ").append(a.played).append(" — ").append(away).append(". История ищется во всех доступных турнирах open-matchday; результаты обновляются примерно раз в сутки; резервная статистика ESPN может обновляться чаще. Источники: open-matchday и ESPN.");
        return out.toString();
    }

    private double[] poissonOutcome(double lh,double la) {
        double home=0,draw=0,away=0;
        for(int i=0;i<=12;i++) for(int j=0;j<=12;j++) {
            double p=poisson(i,lh)*poisson(j,la);
            if(i>j) home+=p; else if(i==j) draw+=p; else away+=p;
        }
        double sum=home+draw+away; return new double[]{home/sum,draw/sum,away/sum};
    }
    private double poisson(int k,double lambda) { return Math.exp(-lambda)*Math.pow(lambda,k)/factorial(k); }
    private double factorial(int n) { double x=1; for(int i=2;i<=n;i++)x*=i; return x; }
    private double poissonCdf(int max,double lambda) { double p=0; for(int i=0;i<=max;i++)p+=poisson(i,lambda); return Math.max(0,Math.min(1,p)); }
    private String pct(double v) { return String.format(Locale.US,"%.0f%%",v*100); }
    private String fmt(double v) { return String.format(Locale.US,"%.2f",v); }
    private String avg(List<Double> a) { if(a==null||a.isEmpty())return "нет данных"; double s=0; for(double v:a)s+=v; return String.format(Locale.US,"%.1f",s/a.size()); }

    private void saveHistory(String item) {
        SharedPreferences p = getSharedPreferences("football_history", MODE_PRIVATE);
        try { JSONArray arr = new JSONArray(p.getString("items","[]")); arr.put(0,item); while(arr.length()>100) arr.remove(arr.length()-1); p.edit().putString("items",arr.toString()).apply(); }
        catch(Exception e) { p.edit().putString("items",new JSONArray().put(item).toString()).apply(); }
    }
    private void showHistory() {
        SharedPreferences p = getSharedPreferences("football_history", MODE_PRIVATE);
        try {
            JSONArray arr = new JSONArray(p.getString("items","[]"));
            if(arr.length()==0) { new AlertDialog.Builder(this).setTitle("История").setMessage("Пока нет сохранённых матчей.").setPositiveButton("OK",null).show(); return; }
            String[] items = new String[arr.length()]; for(int i=0;i<arr.length();i++) items[i]=arr.optString(i);
            new AlertDialog.Builder(this).setTitle("Сохранённые матчи").setItems(items,null).setPositiveButton("Закрыть",null).setNeutralButton("Очистить",(d,w)->p.edit().remove("items").apply()).show();
        } catch(Exception e) { new AlertDialog.Builder(this).setTitle("История").setMessage("Не удалось прочитать историю.").setPositiveButton("OK",null).show(); }
    }

    @Override protected void onDestroy() { super.onDestroy(); worker.shutdownNow(); }
}
