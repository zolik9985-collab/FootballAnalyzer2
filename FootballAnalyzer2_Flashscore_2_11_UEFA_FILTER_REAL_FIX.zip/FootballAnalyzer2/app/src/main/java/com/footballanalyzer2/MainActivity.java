package com.footballanalyzer2;

import android.app.*; import android.os.*; import android.graphics.Color; import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable; import android.view.*; import android.widget.*;
import java.net.*; import java.io.*; import java.text.*; import java.util.*; import java.util.concurrent.*; import org.json.*;

public class MainActivity extends Activity {
 static final String BASE="https://raw.githubusercontent.com/oladeeayo/open-matchday/master/data/";
 String league="ALL", day="today";
 android.content.SharedPreferences prefs;
 String language="en";
 String apiKey="";
 String[][] leagues={{"Все турниры Flashscore","ALL"},{"Англия · Premier League","ENG_1_premier-league"},{"Испания · La Liga","ESP_1_la-liga"},{"Германия · Bundesliga","GER_1_bundesliga"},{"Италия · Serie A","ITA_1_serie-a"},{"Франция · Ligue 1","FRA_1_ligue-1"},{"Нидерланды · Eredivisie","NED_1_eredivisie"},{"Португалия · Primeira Liga","POR_1_primeira-liga"},{"Бельгия · Pro League","BEL_1_pro-league"},{"Турция · Süper Lig","TUR_1_super-lig"},{"Греция · Super League","GRE_1_super-league"},{"🏆 Лига чемпионов","UEFA_1_champions-league"},{"🏆 Лига Европы","UEFA_1_europa-league"},{"🏆 Лига конференций","UEFA_1_conference-league"},{"🏆 Лига наций","UEFA_1_nations-league"},{"🏆 Кубок Англии","ENG_CUP_fa-cup"},{"🏆 Кубок английской лиги","ENG_CUP_efl-cup"},{"🏆 Кубок Испании","ESP_CUP_copa-del-rey"},{"🏆 Кубок Италии","ITA_CUP_coppa-italia"},{"Англия · Championship","ENG_2_championship"},{"🇷🇺 Россия · Премьер-лига","RUS_1_premier-liga"},{"🇷🇺 Россия · Первая лига","RUS_2_first-league"},{"🇷🇺 Россия · Кубок России","RUS_CUP_russian-cup"},{"🇺🇦 Украина · Премьер-лига","UKR_1_premier-liha"},{"🇺🇦 Украина · Кубок Украины","UKR_CUP_ukrainian-cup"}};
 ExecutorService worker=Executors.newSingleThreadExecutor(); Handler ui=new Handler(Looper.getMainLooper());
 LinearLayout root,cards; TextView status;
 int dp(float x){return (int)(x*getResources().getDisplayMetrics().density);}
 GradientDrawable shape(int c,int r){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(dp(r));return d;}
 TextView label(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
 LinearLayout.LayoutParams lp(int top,int bottom){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,dp(top),0,dp(bottom));return p;}
 public void onCreate(Bundle b){super.onCreate(b);prefs=getSharedPreferences("football_analyzer",MODE_PRIVATE);language=prefs.getString("language","en");apiKey=prefs.getString("api_key","");getWindow().setStatusBarColor(0xff06120d);getWindow().setNavigationBarColor(0xff06120d);ui();}
 void ui(){
  ScrollView sc=new ScrollView(this);root=new LinearLayout(this);root.setOrientation(1);root.setPadding(dp(18),dp(22),dp(18),dp(28));root.setBackgroundColor(0xff06120d);sc.addView(root);setContentView(sc);
  root.addView(label("⚽ FOOTBALL ANALYZER 2",25,0xff35d879,true));
  root.addView(label(tr("Matches and 2026/27 season statistics","Матчи и статистика сезона 2026/27","Kamper og sesongstatistikk 2026/27","Spiele und Saisonstatistik 2026/27","Matchs et statistiques de la saison 2026/27","Partidos y estadísticas de la temporada 2026/27"),14,0xffb8c9bf,true),lp(4,10));
  Button history=button("📅 ИСТОРИЯ ПРОГНОЗОВ");root.addView(history,lp(0,10));history.setOnClickListener(v->chooseHistoryDate());
  Button settings=button(tr("⚙ SETTINGS","⚙ НАСТРОЙКИ","⚙ INNSTILLINGER","⚙ EINSTELLUNGEN","⚙ PARAMÈTRES","⚙ AJUSTES"));root.addView(settings,lp(0,14));settings.setOnClickListener(v->settingsDialog());
  root.addView(label(tr("CHOOSE LEAGUE","ВЫБЕРИ ЛИГУ","VELG LIGA","LIGA WÄHLEN","CHOISIR UNE LIGUE","ELIGE LIGA"),14,0xff35d879,true),lp(0,6));
  Spinner sp=new Spinner(this);String[] names=new String[leagues.length];for(int i=0;i<names.length;i++)names[i]=leagues[i][0];
  sp.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,names));sp.setBackground(shape(0xff12251b,12));int restoreLeague=0;for(int i=0;i<leagues.length;i++)if(leagues[i][1].equals(league))restoreLeague=i;sp.setSelection(restoreLeague);root.addView(sp,lp(0,12));
  sp.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> a){}public void onItemSelected(android.widget.AdapterView<?> a,View v,int p,long id){league=leagues[p][1];loadApi();}});
  LinearLayout tabs=new LinearLayout(this);for(String[] x:new String[][]{{tr("Today","Сегодня","I dag","Heute","Aujourd’hui","Hoy"),"today"},{tr("Tomorrow","Завтра","I morgen","Morgen","Demain","Mañana"),"tomorrow"},{tr("All matches","Все матчи","Alle kamper","Alle Spiele","Tous les matchs","Todos los partidos"),"all"}}){Button b=button(x[0]);LinearLayout.LayoutParams q=new LinearLayout.LayoutParams(0,dp(46),1);q.setMargins(dp(2),0,dp(2),0);tabs.addView(b,q);b.setOnClickListener(v->{day=x[1];loadApi();});}root.addView(tabs,lp(0,12));
  Button reload=button(tr("REFRESH","ОБНОВИТЬ","OPPDATER","AKTUALISIEREN","ACTUALISER","ACTUALIZAR"));root.addView(reload,lp(0,8));reload.setOnClickListener(v->loadApi());
  Button api=button(tr("⚽ FLASHSCORE: REFRESH MATCHES & ODDS","⚽ FLASHSCORE: ОБНОВИТЬ МАТЧИ И КОЭФФИЦИЕНТЫ","⚽ FLASHSCORE: OPPDATER KAMPER OG ODDS","⚽ FLASHSCORE: SPIELE & QUOTEN AKTUALISIEREN","⚽ FLASHSCORE : ACTUALISER MATCHS ET COTES","⚽ FLASHSCORE: ACTUALIZAR PARTIDOS Y CUOTAS"));root.addView(api,lp(0,12));
  api.setOnClickListener(v->loadApi());
  status=label("Подключение к Flashscore через API.SH…",14,0xffc3d2c9,false);root.addView(status,lp(0,10));cards=new LinearLayout(this);cards.setOrientation(1);root.addView(cards);
  root.addView(label("Источник: Flashscore через API.SH. При ошибке 401 требуется действующий API Key API.SH.",12,0xff879b8e,false),lp(20,0));
 }
 String tr(String en,String ru,String no,String de,String fr,String es){switch(language){case "ru":return ru;case "no":return no;case "de":return de;case "fr":return fr;case "es":return es;default:return en;}}
 void settingsDialog(){
  String[] labels={"English","Русский","Norsk","Deutsch","Français","Español"};String[] codes={"en","ru","no","de","fr","es"};int selected=0;for(int i=0;i<codes.length;i++)if(codes[i].equals(language))selected=i;
  new AlertDialog.Builder(this).setTitle(tr("Settings","Настройки","Innstillinger","Einstellungen","Paramètres","Ajustes"))
   .setSingleChoiceItems(labels,selected,(d,which)->{language=codes[which];prefs.edit().putString("language",language).apply();d.dismiss();ui();})
   .setNeutralButton(tr("Account","Аккаунт","Konto","Konto","Compte","Cuenta"),(d,w)->accountInfo())
   .setNegativeButton("API Key",(d,w)->apiDialog())
   .setPositiveButton(tr("Close","Закрыть","Lukk","Schließen","Fermer","Cerrar"),null).show();
 }
 void accountInfo(){new AlertDialog.Builder(this).setTitle(tr("Account registration","Регистрация аккаунта","Kontoregistrering","Konto-Registrierung","Inscription","Registro de cuenta"))
  .setMessage(tr("Online accounts and paid subscriptions require a secure authentication backend. It is not safe to store passwords in this app. The registration screen will be connected after the server is configured.","Онлайн-регистрация и платные подписки требуют защищённого сервера авторизации. Хранить пароли прямо в приложении небезопасно. Подключим регистрацию после настройки сервера.","Onlinekonto og abonnement krever en sikker autentiseringstjeneste.","Online-Konten und Abos benötigen einen sicheren Authentifizierungsserver.","Les comptes en ligne et abonnements nécessitent un serveur d’authentification sécurisé.","Las cuentas y suscripciones requieren un servidor seguro de autenticación."))
  .setPositiveButton("OK",null).show();}
 Button button(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextColor(0xff06120d);b.setBackground(shape(0xff35d879,12));return b;}
 String fetch(String u)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();c.setConnectTimeout(15000);c.setReadTimeout(20000);try(InputStream in=c.getInputStream();ByteArrayOutputStream o=new ByteArrayOutputStream()){byte[] b=new byte[8192];int n;while((n=in.read(b))>0)o.write(b,0,n);return o.toString("UTF-8");}finally{c.disconnect();}}
 List<String[]> csv(String s){List<String[]> out=new ArrayList<>();BufferedReader r=new BufferedReader(new StringReader(s));try{String l;while((l=r.readLine())!=null)out.add(split(l));}catch(Exception ignored){}return out;}
 String[] split(String s){ArrayList<String>a=new ArrayList<>();StringBuilder b=new StringBuilder();boolean q=false;for(int i=0;i<s.length();i++){char c=s.charAt(i);if(c=='"'){if(q&&i+1<s.length()&&s.charAt(i+1)=='"'){b.append('"');i++;}else q=!q;}else if(c==','&&!q){a.add(b.toString());b.setLength(0);}else b.append(c);}a.add(b.toString());return a.toArray(new String[0]);}
 void load(){status.setText("Загружаю данные сезона 2026/27…");cards.removeAllViews();final String l=league,d=day;worker.execute(()->{try{
  List<String[]> f=csv(fetch(BASE+l+"/fixtures_2627.csv")),r=csv(fetch(BASE+l+"/results_2627.csv"));
  String today=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());Calendar c=Calendar.getInstance();c.add(5,1);String tom=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(c.getTime());
  List<String[]> found=new ArrayList<>();for(int i=1;i<f.size();i++){String[] x=f.get(i);if(x.length<5)continue;if(d.equals("today")&&!x[1].equals(today))continue;if(d.equals("tomorrow")&&!x[1].equals(tom))continue;found.add(x);}
  ui.post(()->{status.setText("Матчей найдено: "+found.size());if(found.isEmpty()){cards.addView(label("На эту дату матчей нет в выбранной лиге. Выбери «Все матчи» или другую лигу.",15,Color.WHITE,false));return;}for(String[] x:found)addCard(x,r);});
 }catch(Exception e){ui.post(()->status.setText("Ошибка загрузки: "+e.getMessage()));}});}
 void addCard(String[] m,List<String[]> results){LinearLayout box=new LinearLayout(this);box.setOrientation(1);box.setPadding(dp(14),dp(13),dp(14),dp(13));box.setBackground(shape(0xff12251b,15));cards.addView(box,lp(0,10));
  box.addView(label(m[1]+"  "+m[2],12,0xff9bb4a5,true));box.addView(label(m[3]+"  —  "+m[4],18,Color.WHITE,true),lp(5,8));
  Button a=button("АНАЛИЗ ПОСЛЕДНИХ ИГР");box.addView(a);TextView out=label("",13,0xffd9e7de,false);box.addView(out,lp(7,0));
  a.setOnClickListener(v->{a.setEnabled(false);out.setText("Считаю…");worker.execute(()->{String s=report(m[3],m[4],results);ui.post(()->{out.setText(s);a.setEnabled(true);});});});
 }
 Map<String,Integer> index(String[] h){Map<String,Integer> m=new HashMap<>();for(int i=0;i<h.length;i++)m.put(h[i].trim(),i);return m;}
 String val(String[] row,Map<String,Integer> ix,String key){Integer i=ix.get(key);return i==null||i>=row.length?null:row[i].trim();}

 static class TeamStats {
  int matches; ArrayList<Double> goals=new ArrayList<>(); ArrayList<Double>[] markets=new ArrayList[4];
  TeamStats(){for(int i=0;i<4;i++)markets[i]=new ArrayList<>();}
 }
 int col(Map<String,Integer> ix,String... keys){for(String k:keys){Integer n=ix.get(k);if(n!=null)return n;}return -1;}
 Double num(String[] row,int i){if(i<0||i>=row.length)return null;try{String s=row[i].trim();if(s.isEmpty()||s.equalsIgnoreCase("null"))return null;return Double.parseDouble(s);}catch(Exception e){return null;}}
 TeamStats teamStats(String name,List<String[]> rows,Map<String,Integer> ix){
  TeamStats t=new TeamStats();int hg=col(ix,"ft_home"),ag=col(ix,"ft_away");
  int[] hc={col(ix,"home_corners"),col(ix,"home_yellow","home_yellows","home_yellow_cards"),col(ix,"home_fouls"),col(ix,"home_target","home_shots_on_target","home_sot")};
  int[] ac={col(ix,"away_corners"),col(ix,"away_yellow","away_yellows","away_yellow_cards"),col(ix,"away_fouls"),col(ix,"away_target","away_shots_on_target","away_sot")};
  for(int j=rows.size()-1;j>=1&&t.matches<10;j--){String[] x=rows.get(j);String h=val(x,ix,"home"),a=val(x,ix,"away");if(!name.equalsIgnoreCase(h)&&!name.equalsIgnoreCase(a))continue;
   Double gh=num(x,hg),ga=num(x,ag);if(gh==null||ga==null)continue;t.goals.add(gh+ga);t.matches++;
   for(int k=0;k<4;k++){Double hv=num(x,hc[k]),av=num(x,ac[k]);if(hv!=null&&av!=null)t.markets[k].add(hv+av);}
  }return t;
 }
 double average(ArrayList<Double> values){if(values.size()==0)return Double.NaN;double s=0;for(double v:values)s+=v;return s/values.size();}
 String hitCount(ArrayList<Double> values,double line,boolean over){
  int hits=0,total=0;
  for(double v:values){if(v==line)continue;total++;if(over?v>line:v<line)hits++;}
  return hits+"/"+total;
 }
 double hitRate(ArrayList<Double> values,double line,boolean over){
  int hits=0,total=0;
  for(double v:values){if(v==line)continue;total++;if(over?v>line:v<line)hits++;}
  return total==0?0:hits/(double)total;
 }
 String recommendation(String title,ArrayList<Double> samples,double[] standardLines,
                      ArrayList<Double> homeSamples,ArrayList<Double> awaySamples,
                      ArrayList<Double> h2hSamples){
  if(samples.size()<8)return title+": ПРОПУСТИТЬ — только "+samples.size()+" матчей со статистикой.";
  double mean=average(samples),bestP=0,bestLine=0;String bestSide="";
  // Оставляем только содержательные линии. Низкие тоталы вроде ТБ 0.5 исключены.
  for(double line:standardLines){
   double po=hitRate(samples,line,true),pu=hitRate(samples,line,false);
   if(po>bestP){bestP=po;bestLine=line;bestSide="ТБ";}
   if(pu>bestP){bestP=pu;bestLine=line;bestSide="ТМ";}
  }
  // Без букмекерского коэффициента это только историческая оценка, не подтверждённая value-ставка.
  if(bestP<0.65 || bestP>0.85 || samples.size()<8)
   return title+": ПРОПУСТИТЬ — нет подходящего соотношения вероятности и линии. Среднее "+
    fmt(mean,1)+", выборка "+samples.size()+".";
  StringBuilder out=new StringBuilder();
  out.append(title).append(": ").append(bestSide).append(" ")
    .append(String.format(Locale.US,"%.1f",bestLine))
    .append(" · проход ").append(Math.round(bestP*100)).append("%")
    .append(" · среднее ").append(fmt(mean,1)).append(" · выборка ").append(samples.size());
  if(homeSamples!=null)out.append("\n").append("  ").append("Домашняя команда: ")
    .append(hitCount(homeSamples,bestLine,bestSide.equals("ТБ"))).append(" проходов");
  if(awaySamples!=null)out.append(" | Гостевая: ")
    .append(hitCount(awaySamples,bestLine,bestSide.equals("ТБ"))).append(" проходов");
  if(h2hSamples!=null)out.append(" | H2H: ")
    .append(hitCount(h2hSamples,bestLine,bestSide.equals("ТБ"))).append(" проходов");
  out.append("\n  ").append("Сравни с реальным кэфом букмекера: он должен быть выше расчётного, иначе ставку пропустить.");
  return out.toString();
 }

 String report(String home,String away,List<String[]> rows){
  if(rows.size()<2)return "⚠️ Недостаточно завершённых матчей для анализа.";
  Map<String,Integer> ix=index(rows.get(0));
  TeamStats h=teamStats(home,rows,ix),a=teamStats(away,rows,ix);
  if(h.matches<3||a.matches<3)return "⚠️ Недостаточно истории даже для предварительного анализа: "+home+" — "+h.matches+", "+away+" — "+a.matches+". Нужно хотя бы 3 матча на команду.";
  StringBuilder b=new StringBuilder();
  b.append("⚽ ПРОГНОЗ НА МАТЧ\n").append(home).append(" — ").append(away).append("\n\n");
  b.append("📊 ОБЩАЯ ФОРМА КОМАНД\n");
  b.append("Последние матчи: ").append(home).append(" — ").append(h.matches).append(", ").append(away).append(" — ").append(a.matches).append(".\n");
  if(h.matches<5||a.matches<5)b.append("⚠️ Внимание: выборка небольшая, выводы предварительные.\n");
  b.append("Отбор: только содержательные линии. Нужна выборка от 12 матчей и исторический проход 55–78%; иначе — ПРОПУСТИТЬ.\nРасчётный кэф — обратная историческая частота, а не котировка букмекера.\n\n");
  ArrayList<Double> goals=new ArrayList<>();goals.addAll(h.goals);goals.addAll(a.goals);
  b.append("⚽ ГОЛЫ\n");
  b.append("Среднее за матч: ").append(home).append(" — ").append(fmt(average(h.goals),1)).append(", ").append(away).append(" — ").append(fmt(average(a.goals),1)).append(".\n");
  b.append(recommendation("🎯 Рекомендация",goals,new double[]{1.5,2.5,3.5},h.goals,a.goals,null)).append("\n\n");
  String[] titles={"🚩 УГЛОВЫЕ","🟨 ЖЁЛТЫЕ КАРТОЧКИ","🤼 ФОЛЫ","🥅 УДАРЫ В СТВОР"};
  double[][] lines={{8.5,9.5,10.5,11.5},{3.5,4.5,5.5,6.5},{19.5,21.5,23.5,25.5},{7.5,8.5,9.5,10.5}};
  for(int k=0;k<4;k++){
   ArrayList<Double> samples=new ArrayList<>();samples.addAll(h.markets[k]);samples.addAll(a.markets[k]);
   b.append(titles[k]).append("\n");
   b.append("Среднее: ").append(home).append(" — ").append(fmt(average(h.markets[k]),1)).append(", ").append(away).append(" — ").append(fmt(average(a.markets[k]),1)).append(".\n");
   b.append(recommendation("🎯 Рекомендация",samples,lines[k],h.markets[k],a.markets[k],null)).append("\n\n");
  }
  // Head-to-head within the selected competition's available season history.
  ArrayList<Double> hg2h=new ArrayList<>();
  ArrayList<Double>[] h2hMarkets=new ArrayList[4];
  for(int k=0;k<4;k++)h2hMarkets[k]=new ArrayList<>();
  int h2hCount=0;
  int[] homeCols={col(ix,"home_corners"),col(ix,"home_yellow"),col(ix,"home_fouls"),col(ix,"home_target")};
  int[] awayCols={col(ix,"away_corners"),col(ix,"away_yellow"),col(ix,"away_fouls"),col(ix,"away_target")};
  for(int j=1;j<rows.size();j++){
   String[] row=rows.get(j);
   String rh=val(row,ix,"home"),ra=val(row,ix,"away");
   if(!((home.equalsIgnoreCase(rh)&&away.equalsIgnoreCase(ra))||(home.equalsIgnoreCase(ra)&&away.equalsIgnoreCase(rh))))continue;
   Double gh=num(row,col(ix,"ft_home")),ga=num(row,col(ix,"ft_away"));
   if(gh==null||ga==null)continue;
   hg2h.add(gh+ga);h2hCount++;
   for(int k=0;k<4;k++){Double x=num(row,homeCols[k]),y=num(row,awayCols[k]);if(x!=null&&y!=null)h2hMarkets[k].add(x+y);}
  }
  b.append("🤝 ОЧНЫЕ ВСТРЕЧИ\n");
  if(h2hCount==0)b.append("В доступной базе выбранного турнира очные встречи не найдены. Это не означает, что их не было.\n");
  else{
   b.append("Найдено очных матчей: ").append(h2hCount).append(".\n");
   b.append("⚽ Голы: среднее ").append(fmt(average(hg2h),1)).append(".\n");
   b.append(recommendation("🎯 Тотал голов",hg2h,new double[]{1.5,2.5,3.5},null,null,hg2h)).append("\n");
   String[] hn={"🚩 Угловые","🟨 Жёлтые","🤼 Фолы","🥅 Удары в створ"};
   for(int k=0;k<4;k++){
    b.append(hn[k]).append(": среднее ").append(fmt(average(h2hMarkets[k]),1)).append(".\n");
    b.append(recommendation("🎯 Тотал",h2hMarkets[k],lines[k],null,null,h2hMarkets[k])).append("\n");
   }
  }
  b.append("\nℹ️ Исторический процент не гарантирует результат. Для ставки сравни реальный коэффициент с расчётным: реальный должен быть выше. Без котировки букмекера приложение не подтверждает value. Пустая статистика не считается нулём.");
  return b.toString();
 }

 String apiLeagueId(String key){
  if(key.equals("ENG_1_premier-league"))return "39";
  if(key.equals("ESP_1_la-liga"))return "140";
  if(key.equals("GER_1_bundesliga"))return "78";
  if(key.equals("ITA_1_serie-a"))return "135";
  if(key.equals("FRA_1_ligue-1"))return "61";
  if(key.equals("NED_1_eredivisie"))return "88";
  if(key.equals("POR_1_primeira-liga"))return "94";
  if(key.equals("BEL_1_pro-league"))return "144";
  if(key.equals("TUR_1_super-lig"))return "203";
  if(key.equals("GRE_1_super-league"))return "197";
  if(key.equals("UEFA_1_champions-league"))return "2";
  if(key.equals("UEFA_1_europa-league"))return "3";
  if(key.equals("UEFA_1_conference-league"))return "848";
  if(key.equals("ENG_CUP_fa-cup"))return "45";
  if(key.equals("ENG_CUP_efl-cup"))return "48";
  if(key.equals("ESP_CUP_copa-del-rey"))return "143";
  if(key.equals("ITA_CUP_coppa-italia"))return "137";
  if(key.equals("ENG_2_championship"))return "40";
  return "";
 }
 String apiGet(String path,String key)throws Exception{
  HttpURLConnection c=(HttpURLConnection)new URL("https://api.api.sh/flashscore/v1/"+path).openConnection();
  c.setRequestProperty("x-api-key",key);c.setRequestProperty("Accept","application/json");
  c.setConnectTimeout(15000);c.setReadTimeout(25000);
  int statusCode=c.getResponseCode();InputStream in=statusCode>=200&&statusCode<300?c.getInputStream():c.getErrorStream();
  ByteArrayOutputStream o=new ByteArrayOutputStream();
  if(in!=null){try(InputStream stream=in){byte[] b=new byte[8192];int n;while((n=stream.read(b))>0)o.write(b,0,n);}}
  String body=o.toString("UTF-8");c.disconnect();
  if(statusCode==401)throw new Exception("HTTP 401 — API.SH отклонил ключ (invalid api key). Это не ошибка Flashscore-запроса. Создай новый API Key в кабинете API.SH и замени ключ в проекте.");
  if(statusCode==403)throw new Exception("HTTP 403 — у ключа нет доступа к этому endpoint или исчерпан/не активирован тариф.");
  if(statusCode==429)throw new Exception("HTTP 429 — превышен лимит запросов API.SH. Подожди и повтори.");
  if(statusCode<200||statusCode>=300)throw new Exception("HTTP "+statusCode+": "+body);
  JSONObject parsed=new JSONObject(body);
  if(parsed.has("success")&&!parsed.optBoolean("success",true))
   throw new Exception(parsed.optString("error","API.SH вернул ошибку"));
  return body;
 }
 String normalizeCompetition(String s){
  return s==null?"":s.toLowerCase(Locale.ROOT).replace("'", "").replace("-", " ")
   .replaceAll("[^a-z0-9 ]","").replaceAll("\\s+"," ").trim();
 }
 String expectedCompetition(String key){
  if(key.equals("ENG_1_premier-league"))return "premier league";
  if(key.equals("ESP_1_la-liga"))return "la liga";
  if(key.equals("GER_1_bundesliga"))return "bundesliga";
  if(key.equals("ITA_1_serie-a"))return "serie a";
  if(key.equals("FRA_1_ligue-1"))return "ligue 1";
  if(key.equals("NED_1_eredivisie"))return "eredivisie";
  if(key.equals("POR_1_primeira-liga"))return "primeira liga";
  if(key.equals("BEL_1_pro-league"))return "pro league";
  if(key.equals("TUR_1_super-lig"))return "super lig";
  if(key.equals("GRE_1_super-league"))return "super league";
  if(key.equals("UEFA_1_champions-league"))return "champions league";
  if(key.equals("UEFA_1_europa-league"))return "europa league";
  if(key.equals("UEFA_1_conference-league"))return "conference league";
  if(key.equals("UEFA_1_nations-league"))return "nations league";
  if(key.equals("ENG_CUP_fa-cup"))return "fa cup";
  if(key.equals("ENG_CUP_efl-cup"))return "efl cup";
  if(key.equals("ESP_CUP_copa-del-rey"))return "copa del rey";
  if(key.equals("ITA_CUP_coppa-italia"))return "coppa italia";
  if(key.equals("ENG_2_championship"))return "championship";
  if(key.equals("RUS_1_premier-liga"))return "premier league";
  if(key.equals("RUS_2_first-league"))return "first league";
  if(key.equals("RUS_CUP_russian-cup"))return "russian cup";
  if(key.equals("UKR_1_premier-liha"))return "premier league";
  if(key.equals("UKR_CUP_ukrainian-cup"))return "ukrainian cup";
  return "";
 }
 String expectedCountry(String key){
  if(key.startsWith("ENG_"))return "england";
  if(key.startsWith("ESP_"))return "spain";
  if(key.startsWith("GER_"))return "germany";
  if(key.startsWith("ITA_"))return "italy";
  if(key.startsWith("FRA_"))return "france";
  if(key.startsWith("NED_"))return "netherlands";
  if(key.startsWith("POR_"))return "portugal";
  if(key.startsWith("BEL_"))return "belgium";
  if(key.startsWith("TUR_"))return "turkey";
  if(key.startsWith("GRE_"))return "greece";
  if(key.startsWith("UEFA_"))return "europe";
  if(key.startsWith("RUS_"))return "russia";
  if(key.startsWith("UKR_"))return "ukraine";
  return "";
 }
 String[] competitionAliases(String key){
  if(key.equals("RUS_1_premier-liga"))return new String[]{"premier league","premier liga","russian premier league","mir russian premier league"};
  if(key.equals("RUS_2_first-league"))return new String[]{"first league","football national league","fnl","russian first league","melbet first league"};
  if(key.equals("RUS_CUP_russian-cup"))return new String[]{"russian cup","russia cup","cup","fonbet russian cup"};
  if(key.equals("UKR_1_premier-liha"))return new String[]{"premier league","premier liha","ukrainian premier league","upla"};
  if(key.equals("UKR_CUP_ukrainian-cup"))return new String[]{"ukrainian cup","ukraine cup","cup"};
  String e=expectedCompetition(key);return e.isEmpty()?new String[0]:new String[]{e};
 }
 String jsonText(JSONObject o,String... keys){
  for(String k:keys){Object v=o.opt(k);if(v instanceof String&&!((String)v).trim().isEmpty())return (String)v;if(v instanceof JSONObject){JSONObject q=(JSONObject)v;String n=q.optString("name",q.optString("title",""));if(!n.isEmpty())return n;}}
  return "";
 }
 String tournamentCountry(JSONObject tournament,JSONObject match){
  String c=jsonText(tournament,"country","country_name","region","category");
  if(c.isEmpty())c=jsonText(match,"country","country_name");
  return normalizeCompetition(c);
 }
 boolean countryMatches(String actual,String expected){
  if(expected.isEmpty())return true;
  // Some API.SH match payloads omit country on the nested tournament object.
  // The request is already scoped by tournament_id or country in that case.
  if(actual.isEmpty())return true;
  if(expected.equals("russia"))return actual.contains("russia")||actual.contains("russian federation");
  if(expected.equals("ukraine"))return actual.contains("ukraine");
  if(expected.equals("europe"))return actual.contains("europe")||actual.contains("international")||actual.contains("uefa");
  return actual.contains(normalizeCompetition(expected));
 }
 String canonicalLeague(String value){
  // Strip Flashscore's region/country prefix before punctuation normalization.
  // Examples: "EUROPE: UEFA Champions League", "BELGIUM: Pro League".
  String source=value==null?"":value;
  int colon=source.lastIndexOf(':');
  if(colon>=0 && colon<source.length()-1)source=source.substring(colon+1);
  String n=normalizeCompetition(source);
  n=n.replaceFirst("^uefa ","").replace("laliga","la liga").replace("liga europa","europa league");
  if(n.equals("uefa europa league qualifying"))return "europa league";
  if(n.equals("spanish la liga")||n.equals("primera division"))return "la liga";
  if(n.equals("champions league women")||n.equals("caf champions league women"))return n;
  return n;
 }

 boolean matchesSelectedCompetition(JSONObject match,String selected){
  if(selected.equals("ALL"))return true;
  JSONObject tournament=match.optJSONObject("tournament");
  if(tournament==null)tournament=match.optJSONObject("competition");
  if(tournament==null)tournament=match.optJSONObject("league");
  // API.SH responses can expose tournament details in different nested fields.
  String full=(match==null?"":match.toString()).toLowerCase(Locale.ROOT);
  String normalizedFull=" "+normalizeCompetition(full)+" ";
  if(full.matches("(?s).*(\\b(women|female|u17|u18|u19|u20|u21|reserve|youth)\\b).*"))return false;
  String expectedCountry=expectedCountry(selected);
  boolean isUefa=selected.startsWith("UEFA_");
  if(isUefa){
   // Never accept similarly named CAF/AFC/CONCACAF/CONMEBOL/OFC competitions.
   if(full.contains("caf ")||full.contains("africa")||full.contains("african")||full.contains("afc ")||full.contains("asia")||full.contains("concacaf")||full.contains("conmebol")||full.contains("south america")||full.contains("ofc "))return false;
   // Do not require the literal words UEFA/Europe: API.SH often returns only
   // "Champions League", "Europa League" or "Conference League" in match payloads.
   // The exact competition name is checked below; non-European confederations are excluded above.
  }
  String[] aliases=competitionAliases(selected);
  boolean nameOk=false;
  if(tournament!=null){
   String[] names={canonicalLeague(jsonText(tournament,"name","title")),canonicalLeague(jsonText(tournament,"league")),canonicalLeague(jsonText(tournament,"slug")),canonicalLeague(jsonText(tournament,"unique_tournament"))};
   for(String a:aliases){String expected=canonicalLeague(a);for(String n:names){if(expected.equals(n)){nameOk=true;break;}}if(nameOk)break;}
  }
  // Fallback for API.SH variants where the tournament name is nested or flattened.
  if(!nameOk){
   for(String a:aliases){String expected=" "+normalizeCompetition(canonicalLeague(a))+" ";if(!expected.trim().isEmpty()&&normalizedFull.contains(expected)){nameOk=true;break;}}
  }
  if(!nameOk)return false;
  if(!isUefa){
   String actualCountry=tournament==null?tournamentCountry(new JSONObject(),match):tournamentCountry(tournament,match);
   if(!expectedCountry.isEmpty()&&!countryMatches(actualCountry,expectedCountry))return false;
  }
  return true;
 }
 boolean competitionNameMatches(String actual,String expected){
  if(actual==null||actual.isEmpty()||expected==null||expected.isEmpty())return false;
  // Compare normalized tournament titles, never partial substrings.
  return canonicalLeague(actual).equals(canonicalLeague(expected));
 }

 void apiDialog(){
  EditText input=new EditText(this);input.setSingleLine(true);input.setHint("Вставь API Key");
  input.setInputType( android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
  if(!apiKey.isEmpty())input.setText(apiKey);
  new AlertDialog.Builder(this).setTitle("API-Football")
   .setMessage("Ключ хранится только в памяти приложения до его закрытия. Не вставляй его в GitHub или исходный код.")
   .setView(input).setNegativeButton("Отмена",null)
   .setPositiveButton("Проверить и загрузить",(d,w)->{
    String candidate=input.getText().toString().trim();
    if(candidate.isEmpty()){status.setText("Введи API Key.");return;}
    apiKey=candidate;prefs.edit().putString("api_key",candidate).apply();loadApi();
   }).show();
 }
 String findFlashscoreTournamentId(String selected,String key)throws Exception{
  String expected=expectedCompetition(selected);if(expected.isEmpty())return "";
  String q=URLEncoder.encode(expected,"UTF-8");
  JSONObject search=new JSONObject(apiGet("search?q="+q+"&type=tournaments&sport=football",key));
  JSONArray results=search.optJSONArray("results");if(results==null)results=search.optJSONArray("tournaments");if(results==null)return "";
  String country=expectedCountry(selected);
  for(int i=0;i<results.length();i++){
   JSONObject item=results.optJSONObject(i);if(item==null)continue;
   String[] aliases=competitionAliases(selected);String n=canonicalLeague(jsonText(item,"name","title","slug"));boolean ok=false;
   for(String a:aliases)if(n.equals(canonicalLeague(a))){ok=true;break;}
   if(!ok)continue;
   String metadata=item.toString().toLowerCase(Locale.ROOT);
   if(metadata.matches("(?s).*\\b(women|female|u17|u18|u19|u20|u21|reserve|youth)\\b.*"))continue;
   if(!country.isEmpty()&&!selected.startsWith("UEFA_")&&!countryMatches(tournamentCountry(item,item),country))continue;
   String id=item.optString("id",item.optString("tournament_id",""));if(!id.isEmpty())return id;
  }
  return "";
 }
 void loadApi(){
  if(apiKey.isEmpty()){status.setText(tr("API.SH key is not configured.","Не настроен ключ API.SH.","API.SH-nøkkel er ikke konfigurert.","API.SH-Schlüssel fehlt.","Clé API.SH non configurée.","Falta configurar la clave API.SH."));return;}
  status.setText(tr("Loading Flashscore matches…","Загружаю матчи Flashscore…","Laster Flashscore-kamper…","Flashscore-Spiele werden geladen…","Chargement des matchs Flashscore…","Cargando partidos de Flashscore…"));cards.removeAllViews();
  final String selected=league,selectedDay=day,key=apiKey;
  worker.execute(()->{try{
   int[] offsets=selectedDay.equals("tomorrow")?new int[]{1}:selectedDay.equals("all")?new int[]{0,1,2,3,4,5,6,7}:new int[]{0};
   ArrayList<JSONObject> all=new ArrayList<>();int rawTotal=0;String lastDate="";
   for(int off:offsets){
    String query="matches?sport=football&day="+off;
    boolean national=!selected.equals("ALL")&&!selected.startsWith("UEFA_");
    String tournamentId="";
    if(!selected.equals("ALL")){
     // Resolve a precise Flashscore tournament ID first; country feed is fallback.
     tournamentId=findFlashscoreTournamentId(selected,key);
     if(!tournamentId.isEmpty())query+="&tournament_id="+URLEncoder.encode(tournamentId,"UTF-8");
     else {
      String country=expectedCountry(selected);
      if(!country.isEmpty())query+="&country="+URLEncoder.encode(country.substring(0,1).toUpperCase(Locale.ROOT)+country.substring(1),"UTF-8");
     }
    }
    JSONObject rootJson=new JSONObject(apiGet(query,key));
    JSONArray arr=rootJson.optJSONArray("matches");if(arr==null)arr=rootJson.optJSONArray("response");
    // UEFA tournament_id search can resolve an alias to the wrong competition or return
    // a partial feed. Always merge it with the general daily feed before exact filtering.
    JSONArray generalArr=null;
    if(selected.startsWith("UEFA_") || ((arr==null||arr.length()==0)&&national)){
     JSONObject generalJson=new JSONObject(apiGet("matches?sport=football&day="+off,key));
     generalArr=generalJson.optJSONArray("matches");if(generalArr==null)generalArr=generalJson.optJSONArray("response");
    }
    HashSet<String> seen=new HashSet<>();
    JSONArray[] feeds=generalArr==null?new JSONArray[]{arr}:new JSONArray[]{arr,generalArr};
    for(JSONArray feed:feeds){if(feed==null)continue;rawTotal+=feed.length();for(int i=0;i<feed.length();i++){
     JSONObject match=feed.optJSONObject(i);if(match==null)continue;
     String id=match.optString("id",match.optString("event_id",match.optString("match_id",match.toString())));
     if(!seen.add(id))continue;
     boolean fromExactTournamentFeed = tournamentId.length()>0 && feed==arr;
     boolean youthOrWomen = match.toString().toLowerCase(Locale.ROOT).matches("(?s).*(\\b(women|female|u17|u18|u19|u20|u21|reserve|youth)\\b).*");
     if(fromExactTournamentFeed && selected.startsWith("UEFA_") && !youthOrWomen) all.add(match);
     else if(matchesSelectedCompetition(match,selected)) all.add(match);
    }}
   }
   final ArrayList<JSONObject> matches=all;final int rawCount=rawTotal;final String leagueLabel=selected;
   ui.post(()->{
    status.setText("Flashscore API.SH · "+tr("raw matches","всего получено","råkamper","Rohspiele","matchs bruts","partidos recibidos")+": "+rawCount+" · "+tr("selected","подходящих","valgte","passende","retenus","seleccionados")+": "+matches.size());
    if(matches.isEmpty()){
     String reason=rawCount==0?tr("The API returned no matches for this date. Check the date/feed or API response.","API вернул пустой список на эту дату. Проверь дату, выдачу API и ключ.","API-et returnerte ingen kamper for denne datoen.","Die API lieferte für dieses Datum keine Spiele.","L’API n’a renvoyé aucun match pour cette date.","La API no devolvió partidos para esta fecha."):tr("Matches arrived, but none matched the selected competition. Check the tournament name/country mapping.","Матчи пришли, но не совпали с выбранным турниром. Проверь турнир или выбери «Все турниры Flashscore».","Kamper kom fra API-et, men turneringsfilteret fjernet dem.","Spiele kamen an, aber der Wettbewerbsfilter hat sie ausgeschlossen.","Des matchs sont arrivés, mais le filtre du tournoi les a exclus.","Llegaron partidos, pero el filtro del torneo los descartó.");
     cards.addView(label(reason,14,Color.WHITE,false));return;
    }
    for(JSONObject match:matches)addFlashscoreCard(match,key);
   });
  }catch(Exception e){ui.post(()->status.setText(tr("Flashscore API error: ","Ошибка Flashscore API: ","Flashscore API-feil: ","Flashscore-API-Fehler: ","Erreur API Flashscore : ","Error de API Flashscore: ")+e.getMessage()));}});
 }
 void addFlashscoreCard(JSONObject match,String key){
  LinearLayout box=new LinearLayout(this);box.setOrientation(1);box.setPadding(dp(14),dp(13),dp(14),dp(13));box.setBackground(shape(0xff12251b,15));cards.addView(box,lp(0,10));
  JSONObject home=match.optJSONObject("home_team"),away=match.optJSONObject("away_team"),tournament=match.optJSONObject("tournament");
  String homeName=home==null?"Команда 1":home.optString("name","Команда 1");
  String awayName=away==null?"Команда 2":away.optString("name","Команда 2");
  String tour=tournament==null?"":tournament.optString("name","");
  String date=match.optString("start_time",match.optString("date",""));
  String statusText=match.optString("status","");
  String score=(match.isNull("home_score")||!match.has("home_score"))?"":match.optString("home_score")+" : "+match.optString("away_score");
  box.addView(label(date+" · "+tour+" · "+statusText,11,0xff9bb4a5,true));
  box.addView(label(homeName+" — "+awayName+(score.isEmpty()?"":"   "+score),17,Color.WHITE,true),lp(4,7));
  Button detail=button("📊 АНАЛИЗ, СТАТИСТИКА И КОЭФФИЦИЕНТЫ");box.addView(detail);
  TextView output=label("",12,0xffd9e7de,false);box.addView(output,lp(7,0));
  String id=match.optString("id","");
  String homeId=home==null?"":home.optString("id","");
  String awayId=away==null?"":away.optString("id","");
  detail.setOnClickListener(v->{detail.setEnabled(false);output.setText("Загружаю статистику, последние матчи и реальные котировки…");worker.execute(()->{
   String result;
   try{
    String statsJson="",oddsOU="",odds1x2="",oddsRU="",homeResults="",awayResults="",h2hJson="";
    if(!statusText.equalsIgnoreCase("scheduled")){
     try{statsJson=apiGet("match/statistics?match_id="+URLEncoder.encode(id,"UTF-8"),key);}catch(Exception ignored){}
    }
    try{oddsOU=apiGet("match/odds?match_id="+URLEncoder.encode(id,"UTF-8")+"&bet_type=OVER_UNDER&country=NO",key);}catch(Exception ignored){}
    try{odds1x2=apiGet("match/odds?match_id="+URLEncoder.encode(id,"UTF-8")+"&bet_type=HOME_DRAW_AWAY&country=NO",key);}catch(Exception ignored){}
    try{oddsRU=apiGet("match/odds?match_id="+URLEncoder.encode(id,"UTF-8")+"&bet_type=OVER_UNDER&country=RU",key);}catch(Exception ignored){}
    try{if(!homeId.isEmpty())homeResults=apiGet("team/results?team_id="+URLEncoder.encode(homeId,"UTF-8")+"&sport=football&page=0",key);}catch(Exception ignored){}
    try{if(!awayId.isEmpty())awayResults=apiGet("team/results?team_id="+URLEncoder.encode(awayId,"UTF-8")+"&sport=football&page=0",key);}catch(Exception ignored){}
    try{h2hJson=apiGet("match/h2h?match_id="+URLEncoder.encode(id,"UTF-8"),key);}catch(Exception ignored){}
    result=prettyReport(statsJson,oddsOU,odds1x2,oddsRU,homeResults,awayResults,h2hJson,statusText,homeName,awayName,id);
   }catch(Exception ex){result="Ошибка загрузки данных: "+ex.getMessage();}
   final String finalResult=result;ui.post(()->{output.setText(finalResult);savePredictions(match,finalResult);detail.setEnabled(true);});
  });});
 }
 // Persistent prediction archive. Predictions are stored locally by fixture date and ID.
 String fixtureDate(JSONObject match){
  String raw=match.optString("start_time",match.optString("date",""));
  if(raw.length()>=10 && raw.substring(0,10).matches("\\d{4}-\\d{2}-\\d{2}"))return raw.substring(0,10);
  return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());
 }
 JSONArray history(){try{return new JSONArray(prefs.getString("prediction_history","[]"));}catch(Exception e){return new JSONArray();}}
 void savePredictions(JSONObject match,String report){
  try{
   String id=match.optString("id","");if(id.isEmpty())return;
   String date=fixtureDate(match);JSONObject h=match.optJSONObject("home_team"),a=match.optJSONObject("away_team");
   String teams=(h==null?"Команда 1":h.optString("name"))+" — "+(a==null?"Команда 2":a.optString("name"));
   JSONArray arr=history();
   // Replace predictions for this fixture if the report is recalculated.
   JSONArray kept=new JSONArray();for(int i=0;i<arr.length();i++){JSONObject x=arr.optJSONObject(i);if(x!=null&&!id.equals(x.optString("match_id")))kept.put(x);}arr=kept;
   java.util.regex.Matcher m=java.util.regex.Pattern.compile("🎯\\s*([^—\\n]+?)\\s*—\\s*(ТБ|ТМ)\\s*([0-9]+(?:\\.[0-9])?)\\s*·\\s*([0-9]+)/([0-9]+)").matcher(report);
   while(m.find()){
    JSONObject p=new JSONObject();p.put("match_id",id);p.put("date",date);p.put("teams",teams);p.put("market",m.group(1).trim());p.put("side",m.group(2));p.put("line",Double.parseDouble(m.group(3)));p.put("hits",Integer.parseInt(m.group(4)));p.put("sample",Integer.parseInt(m.group(5)));p.put("status","PENDING");p.put("score",match.optString("home_score","")+" : "+match.optString("away_score",""));arr.put(p);
   }
   // Keep a fixture marker even when the model correctly says PASS for every market.
   if(m.reset().find()==false){JSONObject p=new JSONObject();p.put("match_id",id);p.put("date",date);p.put("teams",teams);p.put("market","Нет рекомендованных ставок (PASS)");p.put("side","");p.put("line",-1);p.put("status","PASS");p.put("score","");arr.put(p);}
   prefs.edit().putString("prediction_history",arr.toString()).apply();
  }catch(Exception ignored){}
 }
 void chooseHistoryDate(){
  Calendar c=Calendar.getInstance();
  new DatePickerDialog(this,(v,y,month,dayOfMonth)->{
   Calendar selected=Calendar.getInstance();selected.set(y,month,dayOfMonth);
   String date=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(selected.getTime());showHistory(date);
  },c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show();
 }
 void showHistory(String date){
  JSONArray arr=history();ArrayList<JSONObject> selected=new ArrayList<>();
  for(int i=0;i<arr.length();i++){JSONObject p=arr.optJSONObject(i);if(p!=null&&date.equals(p.optString("date")))selected.add(p);}
  LinearLayout panel=new LinearLayout(this);panel.setOrientation(1);panel.setPadding(dp(18),dp(16),dp(18),dp(16));panel.setBackgroundColor(0xff06120d);
  TextView head=label("📅 ИСТОРИЯ · "+date,20,0xff35d879,true);panel.addView(head);
  if(selected.isEmpty())panel.addView(label("За эту дату сохранённых прогнозов нет. Прогнозы записываются после открытия анализа матча.",14,Color.WHITE,false),lp(12,8));
  int won=0,lost=0,pending=0,passed=0;for(JSONObject p:selected){String st=p.optString("status");if(st.equals("WON"))won++;else if(st.equals("LOST"))lost++;else if(st.equals("PASS"))passed++;else pending++;}
  panel.addView(label("Всего: "+selected.size()+" · Прошло: "+won+" · Не прошло: "+lost+" · Ожидает: "+pending+" · PASS: "+passed,13,0xffc3d2c9,true),lp(8,12));
  int settled=won+lost;panel.addView(label("Проходимость рассчитанных ставок: "+(settled==0?"—":Math.round(won*100.0/settled)+"%"),15,Color.WHITE,true),lp(0,12));
  for(JSONObject p:selected){String st=p.optString("status");String market=p.optString("market");String pick=p.optString("side").isEmpty()?"":p.optString("side")+" "+p.optString("line");String state=st.equals("WON")?"✅ ПРОШЁЛ":st.equals("LOST")?"❌ НЕ ПРОШЁЛ":st.equals("PASS")?"⏸ PASS":"🕒 ОЖИДАЕТ РЕЗУЛЬТАТА";
   panel.addView(label(p.optString("teams"),15,Color.WHITE,true),lp(5,2));panel.addView(label(market+"  "+pick+"\n"+state+(p.optString("score").isEmpty()?"":" · "+p.optString("score")),13,st.equals("WON")?0xff35d879:st.equals("LOST")?0xffff7777:0xffc3d2c9,false),lp(0,7));
  }
  ScrollView sc=new ScrollView(this);sc.addView(panel);new AlertDialog.Builder(this).setView(sc).setPositiveButton("Закрыть",null).setNeutralButton("Обновить результаты",(d,w)->refreshHistory(date)).show();
 }
 void refreshHistory(String date){
  status.setText("Обновляю результаты сохранённых прогнозов…");worker.execute(()->{
   JSONArray arr=history();HashMap<String,JSONObject> statsById=new HashMap<>();
   // Refresh the selected date's fixture feed as well as detailed statistics.
   try{SimpleDateFormat df=new SimpleDateFormat("yyyy-MM-dd",Locale.US);Date chosen=df.parse(date);long delta=(chosen.getTime()-df.parse(df.format(new Date())).getTime())/86400000L;
    if(delta>=-7&&delta<=0){JSONObject feed=new JSONObject(apiGet("matches?sport=football&day="+delta,apiKey));JSONArray matches=feed.optJSONArray("matches");if(matches==null)matches=feed.optJSONArray("response");
     if(matches!=null)for(int j=0;j<matches.length();j++){JSONObject m=matches.optJSONObject(j);if(m==null)continue;String mid=m.optString("id","");if(mid.isEmpty())continue;
      for(int i=0;i<arr.length();i++){JSONObject p=arr.optJSONObject(i);if(p!=null&&mid.equals(p.optString("match_id"))&&date.equals(p.optString("date"))){String hs=m.optString("home_score","");String as=m.optString("away_score","");if(!hs.isEmpty()&&!as.isEmpty())p.put("score",hs+" : "+as);p.put("match_status",m.optString("status",""));}}
     }
    }
   }catch(Exception ignored){}
   for(int i=0;i<arr.length();i++){JSONObject p=arr.optJSONObject(i);if(p==null||!date.equals(p.optString("date"))||p.optString("status").equals("PASS"))continue;String id=p.optString("match_id");if(statsById.containsKey(id))continue;
    try{JSONObject response=new JSONObject(apiGet("match/statistics?match_id="+URLEncoder.encode(id,"UTF-8"),apiKey));statsById.put(id,response);}catch(Exception ignored){}
   }
   int changed=0;
   for(int i=0;i<arr.length();i++){JSONObject p=arr.optJSONObject(i);if(p==null||!date.equals(p.optString("date"))||p.optString("status").equals("PASS"))continue;JSONObject response=statsById.get(p.optString("match_id"));if(response==null)continue;
    String state=settlePrediction(p,response);if(!state.equals("PENDING")){try{p.put("status",state);changed++;}catch(Exception ignored){}}
   }
   prefs.edit().putString("prediction_history",arr.toString()).apply();final int done=changed;ui.post(()->{status.setText("Проверка завершена. Обновлено ставок: "+done);showHistory(date);});
  });
 }
 String settlePrediction(JSONObject p,JSONObject response){
  String market=p.optString("market").toLowerCase(Locale.ROOT);double total=Double.NaN;
  if(market.contains("гол")){
   JSONObject fixture=response.optJSONObject("match");if(fixture==null)fixture=response;
   if(fixture.has("home_score")&&!fixture.isNull("home_score")&&fixture.has("away_score")&&!fixture.isNull("away_score"))total=fixture.optDouble("home_score",-1)+fixture.optDouble("away_score",-1);
   if(Double.isNaN(total)){String score=p.optString("score","");String[] parts=score.split("\\s*:\\s*");if(parts.length==2)try{total=Double.parseDouble(parts[0])+Double.parseDouble(parts[1]);}catch(Exception ignored){}}
  }else{
   JSONArray periods=response.optJSONArray("periods");if(periods!=null&&periods.length()>0){
    JSONObject period=periods.optJSONObject(0);JSONArray groups=period==null?null:period.optJSONArray("groups");
    if(groups!=null)for(int g=0;g<groups.length();g++){JSONObject group=groups.optJSONObject(g);JSONArray items=group==null?null:group.optJSONArray("items");if(items==null)continue;
     for(int k=0;k<items.length();k++){JSONObject item=items.optJSONObject(k);if(item==null)continue;String name=normalizedStatName(statValue(item,"name","label","title","type"));if(!name.contains(marketKey(market)))continue;
      double home=parseStatNumber(statValue(item,"home","home_value","homeValue"));double away=parseStatNumber(statValue(item,"away","away_value","awayValue"));if(home>=0&&away>=0){total=home+away;break;}
     }if(!Double.isNaN(total))break;
    }
   }
  }
  if(Double.isNaN(total)||total<0)return "PENDING";double line=p.optDouble("line",-1);boolean over=p.optString("side").equals("ТБ");if(total==line)return "PENDING";return ((over&&total>line)||(!over&&total<line))?"WON":"LOST";
 }
 String marketKey(String s){if(s.contains("углов"))return "corner";if(s.contains("карточ"))return "card";if(s.contains("фол"))return "foul";if(s.contains("створ"))return "shot";if(s.contains("офсайд"))return "offside";if(s.contains("вбрасыв"))return "throw";if(s.contains("ворот"))return "goal kick";return s;}
 String statValue(JSONObject item,String... keys){
  for(String k:keys){Object v=item.opt(k);if(v!=null&&v!=JSONObject.NULL){if(v instanceof JSONObject){JSONObject o=(JSONObject)v;String s=o.optString("value",o.optString("display",""));if(!s.isEmpty())return s;}else return String.valueOf(v);}}
  return "";
 }
 String priceText(JSONObject obj,String key){
  JSONObject v=obj.optJSONObject(key);
  if(v==null)return "";
  String value=v.optString("value","");
  return value;
 }
 void appendOdds(StringBuilder b,String json,String title){
  b.append("\n").append(title).append("\n");
  if(json==null||json.isEmpty()){b.append("Нет котировок от источника.\n");return;}
  try{
   JSONObject root=new JSONObject(json);
   JSONArray odds=root.optJSONArray("odds");
   if(odds==null||odds.length()==0){b.append("Букмекеры не предоставили этот рынок.\n");return;}
   int printed=0;
   for(int i=0;i<odds.length();i++){
    JSONObject row=odds.optJSONObject(i);if(row==null)continue;
    String bookmaker=row.optString("bookmaker","Букмекер");
    String type=row.optString("type","");
    if(type.equals("OVER_UNDER")){
     JSONArray opportunities=row.optJSONArray("opportunities");
     if(opportunities==null||opportunities.length()==0)continue;
     for(int k=0;k<opportunities.length()&&printed<5;k++){
      JSONObject op=opportunities.optJSONObject(k);if(op==null)continue;
      JSONObject handicap=op.optJSONObject("handicap");
      String line=handicap==null?"":handicap.optString("value","");
      JSONObject over=op.optJSONObject("over"),under=op.optJSONObject("under");
      String ov=over==null?"":over.optString("value","");
      String un=under==null?"":under.optString("value","");
      if(ov.isEmpty()&&un.isEmpty())continue;
      b.append("🏦 ").append(bookmaker);
      if(!line.isEmpty())b.append(" · линия ").append(line);
      b.append("\n");
      if(!ov.isEmpty())b.append("  🔼 ТБ ").append(line).append("  @ ").append(ov)
        .append(priceMovement(over)).append("\n");
      if(!un.isEmpty())b.append("  🔽 ТМ ").append(line).append("  @ ").append(un)
        .append(priceMovement(under)).append("\n");
      printed++;
     }
    }else{
     String home=priceText(row,"home"),draw=priceText(row,"draw"),away=priceText(row,"away");
     if(home.isEmpty()&&draw.isEmpty()&&away.isEmpty())continue;
     b.append("🏦 ").append(bookmaker).append("\n");
     if(!home.isEmpty())b.append("  🏠 П1 @ ").append(home).append(priceMovement(row.optJSONObject("home"))).append("\n");
     if(!draw.isEmpty())b.append("  🤝 X @ ").append(draw).append(priceMovement(row.optJSONObject("draw"))).append("\n");
     if(!away.isEmpty())b.append("  ✈️ П2 @ ").append(away).append(priceMovement(row.optJSONObject("away"))).append("\n");
     printed++;
    }
   }
   if(printed==0)b.append("Источник вернул данные другого формата или без активных цен. Сырые JSON-данные скрыты.\n");
  }catch(Exception e){b.append("Котировки временно не удалось разобрать. Сырые данные скрыты.\n");}
 }
 String priceMovement(JSONObject price){
  if(price==null)return "";
  String opening=price.optString("opening","");
  String current=price.optString("value","");
  if(opening.isEmpty()||current.isEmpty()||opening.equals(current))return "";
  return " · было "+opening;
 }
 String teamForm(String json,String teamName){
  if(json==null||json.isEmpty())return teamName+": история недоступна.\n";
  try{
   JSONArray arr=new JSONObject(json).optJSONArray("matches");
   if(arr==null||arr.length()==0)return teamName+": API не вернул завершённые матчи.\n";
   int n=0,goalsFor=0,goalsAgainst=0,over15=0,over25=0,wins=0,draws=0,losses=0;
   StringBuilder recent=new StringBuilder();
   for(int i=0;i<arr.length()&&n<10;i++){
    JSONObject m=arr.optJSONObject(i);if(m==null||!m.optString("status","").equalsIgnoreCase("finished"))continue;
    JSONObject h=m.optJSONObject("home_team"),a=m.optJSONObject("away_team");
    if(h==null||a==null||m.isNull("home_score")||m.isNull("away_score"))continue;
    int hs=m.optInt("home_score"),as=m.optInt("away_score");boolean isHome=teamName.equals(h.optString("name"));
    int gf=isHome?hs:as,ga=isHome?as:hs;goalsFor+=gf;goalsAgainst+=ga;
    if(gf+ga>=2)over15++;if(gf+ga>=3)over25++;
    if(gf>ga)wins++;else if(gf==ga)draws++;else losses++;
    if(n<5)recent.append("\n  ").append(h.optString("name")).append(" ").append(hs).append(":").append(as).append(" ").append(a.optString("name"));
    n++;
   }
   if(n==0)return teamName+": нет завершённых матчей в истории API.\n";
   StringBuilder b=new StringBuilder();
   b.append(teamName).append(" — последние ").append(n).append(" матчей: В-Н-П ").append(wins).append("-").append(draws).append("-").append(losses)
    .append("; голы забито/пропущено ").append(goalsFor).append("/").append(goalsAgainst)
    .append("; средний тотал матча ").append(String.format(Locale.US,"%.2f",(goalsFor+goalsAgainst)/(double)n))
    .append("; ТБ1.5 проходил ").append(Math.round(100*over15/(double)n)).append("%, ТБ2.5 — ").append(Math.round(100*over25/(double)n)).append("%")
    .append(recent).append("\n");
   return b.toString();
  }catch(Exception e){return teamName+": ошибка чтения формы — "+e.getMessage()+"\n";}
 }

 String goalRecommendation(String homeJson,String awayJson){
  ArrayList<Double> totals=new ArrayList<>();HashSet<String> seen=new HashSet<>();
  for(String json:new String[]{homeJson,awayJson}){
   if(json==null||json.isEmpty())continue;
   try{JSONArray arr=new JSONObject(json).optJSONArray("matches");if(arr==null)continue;
    for(int i=0;i<arr.length();i++){JSONObject m=arr.optJSONObject(i);if(m==null||!m.optString("status","").equalsIgnoreCase("finished")||m.isNull("home_score")||m.isNull("away_score"))continue;
     String id=m.optString("id","");if(!id.isEmpty()&&seen.contains(id))continue;if(!id.isEmpty())seen.add(id);
     totals.add((double)(m.optInt("home_score")+m.optInt("away_score")));
    }
   }catch(Exception ignored){}
  }
  if(totals.size()<8)return "⏸ Голы — ПРОПУСТИТЬ: мало завершённых матчей ("+totals.size()+"/8).\\n";
  return marketPick("Голы",totals,new double[]{1.5,2.5,3.5})+" Средний тотал: "+avgText(totals)+".\\n";
 }
 String normalizedStatName(String s){return s==null?"":s.toLowerCase(Locale.ROOT).replace("_"," ").replace("-"," ").trim();}
 double parseStatNumber(String s){
  if(s==null)return -1;String t=s.replace("%","").replace(",",".").replaceAll("[^0-9.]","");
  try{return Double.parseDouble(t);}catch(Exception e){return -1;}
 }
 void collectHistoricalStats(String teamJson,ArrayList<Double> corners,ArrayList<Double> cards,ArrayList<Double> fouls,ArrayList<Double> shots,ArrayList<Double> offsides,ArrayList<Double> throwIns,ArrayList<Double> goalKicks,HashSet<String> seen){
  try{
   JSONArray arr=new JSONObject(teamJson).optJSONArray("matches");if(arr==null)return;
   for(int i=0;i<arr.length();i++){
    JSONObject m=arr.optJSONObject(i);
    if(m==null||!m.optString("status","").equalsIgnoreCase("finished"))continue;
    String matchId=m.optString("id","");if(matchId.isEmpty()||seen.contains(matchId))continue;
    if(seen.size()>=10)break;
    JSONObject root=new JSONObject(apiGet("match/statistics?match_id="+URLEncoder.encode(matchId,"UTF-8"),apiKey));
    JSONArray periods=root.optJSONArray("periods");if(periods==null||periods.length()==0)continue;
    JSONObject period=periods.optJSONObject(0);JSONArray groups=period==null?null:period.optJSONArray("groups");if(groups==null)continue;
    Double co=null,ca=null,fo=null,sh=null,of=null,th=null,gk=null;
    for(int g=0;g<groups.length();g++){
     JSONObject group=groups.optJSONObject(g);JSONArray items=group==null?null:group.optJSONArray("items");if(items==null)continue;
     for(int k=0;k<items.length();k++){
      JSONObject item=items.optJSONObject(k);if(item==null)continue;
      String name=normalizedStatName(statValue(item,"name","label","title","type"));
      double hv=parseStatNumber(statValue(item,"home","home_value","homeValue"));
      double av=parseStatNumber(statValue(item,"away","away_value","awayValue"));
      if(hv<0||av<0)continue;
      double total=hv+av;
      if(name.contains("corner"))co=total;
      else if(name.contains("yellow card"))ca=total;
      else if(name.equals("fouls")||name.contains("foul"))fo=total;
      else if(name.contains("shots on target")||name.contains("shots on goal"))sh=total;
      else if(name.contains("offside"))of=total;
      else if(name.contains("throw in")||name.contains("throw-in"))th=total;
      else if(name.contains("goal kick")||name.contains("goal-kick"))gk=total;
     }
    }
    boolean added=false;
    if(co!=null){corners.add(co);added=true;} if(ca!=null){cards.add(ca);added=true;}
    if(fo!=null){fouls.add(fo);added=true;} if(sh!=null){shots.add(sh);added=true;}
    if(of!=null){offsides.add(of);added=true;} if(th!=null){throwIns.add(th);added=true;}
    if(gk!=null){goalKicks.add(gk);added=true;}
    if(added)seen.add(matchId);
   }
  }catch(Exception ignored){}
 }
 String marketPick(String title,ArrayList<Double> samples,double[] lines){
  int n=samples==null?0:samples.size();
  if(n<8)return "⏸ "+title+" — ПРОПУСТИТЬ: мало данных ("+n+"/8 матчей с полной статистикой).";
  double bestScore=-1,bestLine=0,bestRate=0;String bestSide="";
  for(double line:lines){
   int over=0,under=0;
   for(double v:samples){if(v>line)over++;else if(v<line)under++;}
   double po=over/(double)n,pu=under/(double)n;
   // Avoid trivial lines: accept only a useful but non-extreme historical hit range.
   if(po>=0.65&&po<=0.85&&po>bestScore){bestScore=po;bestRate=po;bestLine=line;bestSide="БОЛЬШЕ";}
   if(pu>=0.65&&pu<=0.85&&pu>bestScore){bestScore=pu;bestRate=pu;bestLine=line;bestSide="МЕНЬШЕ";}
  }
  if(bestScore<0)return "⏸ "+title+" — ПРОПУСТИТЬ: нет убедительной линии без чрезмерно лёгкого тотала. Выборка "+n+" матчей.";
  int hits=(int)Math.round(bestRate*n);
  return "🎯 "+title+" — "+(bestSide.equals("БОЛЬШЕ")?"ТБ ":"ТМ ")+String.format(Locale.US,"%.1f",bestLine)
    +" · "+hits+"/"+n+" матчей ("+Math.round(bestRate*100)+"%). Это историческая частота, не гарантия.";
 }
 String prettyReport(String statsJson,String oddsOU,String odds1x2,String oddsRU,String homeResults,String awayResults,String h2hJson,String status,String homeName,String awayName,String matchId){
  StringBuilder b=new StringBuilder();
  b.append("⚽ FOOTBALL ANALYZER · ОТЧЁТ\n────────────────────\n");
  b.append("⚽ ").append(homeName).append(" — ").append(awayName).append("\n");
  b.append(status.equalsIgnoreCase("scheduled")?"Матч ещё не начался · прематч-анализ\n":"Статус: "+status+"\n");
  b.append("\n📈 ФОРМА КОМАНД · ПОСЛЕДНИЕ 10 ИГР\n");
  b.append(teamForm(homeResults,homeName)).append("\n").append(teamForm(awayResults,awayName));
  b.append("\n📊 ИСТОРИЧЕСКИЕ ПОКАЗАТЕЛИ · ДО 10 РАЗНЫХ ПРЕДЫДУЩИХ МАТЧЕЙ\n");
  ArrayList<Double> corners=new ArrayList<>(),cards=new ArrayList<>(),fouls=new ArrayList<>(),shots=new ArrayList<>(),
   offsides=new ArrayList<>(),throwIns=new ArrayList<>(),goalKicks=new ArrayList<>();
  HashSet<String> statMatchIds=new HashSet<>();
  collectHistoricalStats(homeResults,corners,cards,fouls,shots,offsides,throwIns,goalKicks,statMatchIds);
  collectHistoricalStats(awayResults,corners,cards,fouls,shots,offsides,throwIns,goalKicks,statMatchIds);
  b.append("Угловые: ").append(corners.size()).append(" матчей с данными · среднее ")
   .append(avgText(corners)).append("\n");
  b.append("Жёлтые карточки: ").append(cards.size()).append(" матчей с данными · среднее ").append(avgText(cards)).append("\n");
  b.append("Фолы: ").append(fouls.size()).append(" матчей с данными · среднее ").append(avgText(fouls)).append("\n");
  b.append("Удары в створ: ").append(shots.size()).append(" матчей с данными · среднее ").append(avgText(shots)).append("\n");
  b.append("Офсайды: ").append(offsides.size()).append(" матчей с данными · среднее ").append(avgText(offsides)).append("\n");
  b.append("Вбрасывания: ").append(throwIns.size()).append(" матчей с данными · среднее ").append(avgText(throwIns)).append("\n");
  b.append("Удары от ворот: ").append(goalKicks.size()).append(" матчей с данными · среднее ").append(avgText(goalKicks)).append("\n");
  b.append("🚑 Выход медбригады: отдельная надёжная статистика API не предоставляет; прогноз не строится.\n");
  b.append("\n💹 КОЭФФИЦИЕНТЫ БУКМЕКЕРОВ\n");
  appendOdds(b,oddsOU,"ГОЛЫ · ТБ/ТМ");
  appendOdds(b,odds1x2,"ИСХОД · 1X2");
  appendOdds(b,oddsRU,"ДОПОЛНИТЕЛЬНЫЙ РЕГИОН RU");
  b.append("\n🎯 МОИ ПРОГНОЗЫ НА МАТЧ\n");
  b.append(goalRecommendation(homeResults,awayResults));
  b.append(marketPick("Угловые",corners,new double[]{7.5,8.5,9.5,10.5,11.5})).append("\n");
  b.append(marketPick("Жёлтые карточки",cards,new double[]{2.5,3.5,4.5,5.5,6.5})).append("\n");
  b.append(marketPick("Фолы",fouls,new double[]{17.5,19.5,21.5,23.5,25.5})).append("\n");
  b.append(marketPick("Удары в створ",shots,new double[]{5.5,6.5,7.5,8.5,9.5,10.5})).append("\n");
  b.append(marketPick("Офсайды",offsides,new double[]{1.5,2.5,3.5,4.5,5.5})).append("\n");
  b.append(marketPick("Вбрасывания",throwIns,new double[]{25.5,29.5,33.5,37.5,41.5})).append("\n");
  b.append(marketPick("Удары от ворот",goalKicks,new double[]{8.5,9.5,10.5,11.5,12.5})).append("\n");
  b.append("\nℹ️ Процент — историческая частота на выбранной линии, а не обещание результата. Реальные коэффициенты букмекера показываются отдельно, только если API их вернул. Модельный коэффициент здесь не рассчитывается.\n");
  b.append("Выборка ограничена последними 5 матчами с детальной статистикой на команду; низкая выборка снижает надёжность.\n");
  return b.toString();
 }
 String avgText(ArrayList<Double> a){if(a==null||a.isEmpty())return "нет данных";double s=0;for(double v:a)s+=v;return String.format(Locale.US,"%.1f",s/a.size());}

 String formatFlashscoreDetails(String statsJson,String oddsOU,String odds1x2,String oddsRU,String homeResults,String awayResults,String h2hJson,String status,String homeName,String awayName){
  StringBuilder b=new StringBuilder();
  b.append("📊 СТАТИСТИКА МАТЧА\n");
  if(status.equalsIgnoreCase("scheduled"))b.append("Матч ещё не начался: текущих игровых статистик пока нет. Ниже — форма команд и предматчевые коэффициенты.\n");
  else if(statsJson==null||statsJson.isEmpty())b.append("Статистика матча не предоставлена API для этой игры.\n");
  else try{
   JSONObject root=new JSONObject(statsJson);JSONArray periods=root.optJSONArray("periods");boolean any=false;
   if(periods!=null)for(int p=0;p<periods.length();p++){
    JSONObject period=periods.optJSONObject(p);if(period==null)continue;
    if(p>0)continue;
    JSONArray groups=period.optJSONArray("groups");if(groups==null)continue;
    for(int g=0;g<groups.length();g++){
     JSONObject group=groups.optJSONObject(g);if(group==null)continue;
     JSONArray items=group.optJSONArray("items");if(items==null)continue;
     b.append(group.optString("name","Статистика")).append(":\n");
     for(int i=0;i<items.length();i++){JSONObject item=items.optJSONObject(i);if(item==null)continue;
      String name=statValue(item,"name","label","title","type");
      String hv=statValue(item,"home","home_value","homeValue","home_team","value_home");
      String av=statValue(item,"away","away_value","awayValue","away_team","value_away");
      if(name.isEmpty())name="Показатель";
      if(!hv.isEmpty()||!av.isEmpty()){b.append("  ").append(name).append(": ").append(hv.isEmpty()?"—":hv).append(" — ").append(av.isEmpty()?"—":av).append("\n");any=true;}
      else {b.append("  ").append(item.toString()).append("\n");any=true;}
     }
    }
   }
   if(!any)b.append("Ответ API не содержит игровых показателей для этого матча.\n");
  }catch(Exception e){b.append("Ошибка чтения статистики: ").append(e.getMessage()).append("\n");}
  b.append("\n📈 ФОРМА КОМАНД (последние матчи)\n").append(teamForm(homeResults,homeName)).append(teamForm(awayResults,awayName));
  b.append("\n💹 РЕАЛЬНЫЕ КОЭФФИЦИЕНТЫ — без выдуманных значений\n");
  appendOdds(b,oddsOU,"ТОТАЛЫ БОЛЬШЕ/МЕНЬШЕ");
  appendOdds(b,odds1x2,"ПОБЕДА / НИЧЬЯ / ПОБЕДА — букмекеры страны NO");
  appendOdds(b,oddsRU,"ТОТАЛЫ — букмекеры страны RU (проверка наличия 1xBet)");
  if(h2hJson!=null&&!h2hJson.isEmpty()){
   try{JSONObject h=new JSONObject(h2hJson);JSONArray matches=h.optJSONArray("matches");b.append("\n🤝 ОЧНЫЕ ВСТРЕЧИ\n");
    if(matches!=null&&matches.length()>0){for(int i=0;i<Math.min(5,matches.length());i++){JSONObject m=matches.optJSONObject(i);if(m==null)continue;JSONObject ht=m.optJSONObject("home_team"),at=m.optJSONObject("away_team");b.append(ht==null?"":ht.optString("name")).append(" ").append(m.optString("home_score","-")).append(":").append(m.optString("away_score","-")).append(" ").append(at==null?"":at.optString("name")).append("\n");}}
    else b.append("В API нет доступных очных встреч.\n");
   }catch(Exception ignored){b.append("\n🤝 Очные встречи: API вернул данные, формат не распознан.\n");}
  }
  b.append("\n🎯 ВЫВОД\n");
  b.append(goalRecommendation(homeResults,awayResults));
  b.append("По угловым, карточкам и фолам пока не выдаю ставку без фактической истории этих показателей.\\n");
  b.append("\nИсточник: Flashscore через API.SH. Коэффициенты показываются только при наличии в ответе API.");
  return b.toString();
 }
 String fmt(double a,int n){return String.format(Locale.US,"%.1f",a/n);}
 public void onDestroy(){super.onDestroy();worker.shutdownNow();}
}
