package com.footballanalyzer2;

import android.app.*; import android.os.*; import android.graphics.Color; import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable; import android.view.*; import android.widget.*;
import java.net.*; import java.io.*; import java.text.*; import java.util.*; import java.util.concurrent.*;

public class MainActivity extends Activity {
 static final String BASE="https://raw.githubusercontent.com/oladeeayo/open-matchday/master/data/";
 String league="ENG_1_premier-league", day="today";
 String[][] leagues={{"Англия · Premier League","ENG_1_premier-league"},{"Испания · La Liga","ESP_1_la-liga"},{"Германия · Bundesliga","GER_1_bundesliga"},{"Италия · Serie A","ITA_1_serie-a"},{"Франция · Ligue 1","FRA_1_ligue-1"},{"Нидерланды · Eredivisie","NED_1_eredivisie"},{"Португалия · Primeira Liga","POR_1_primeira-liga"},{"Бельгия · Pro League","BEL_1_pro-league"},{"Турция · Süper Lig","TUR_1_super-lig"},{"Лига чемпионов","UEFA_1_champions-league"},{"Англия · Championship","ENG_2_championship"}};
 ExecutorService worker=Executors.newSingleThreadExecutor(); Handler ui=new Handler(Looper.getMainLooper());
 LinearLayout root,cards; TextView status;
 int dp(float x){return (int)(x*getResources().getDisplayMetrics().density);}
 GradientDrawable shape(int c,int r){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(dp(r));return d;}
 TextView label(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
 LinearLayout.LayoutParams lp(int top,int bottom){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,dp(top),0,dp(bottom));return p;}
 public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(0xff06120d);getWindow().setNavigationBarColor(0xff06120d);ui();}
 void ui(){
  ScrollView sc=new ScrollView(this);root=new LinearLayout(this);root.setOrientation(1);root.setPadding(dp(18),dp(22),dp(18),dp(28));root.setBackgroundColor(0xff06120d);sc.addView(root);setContentView(sc);
  root.addView(label("⚽ FOOTBALL ANALYZER 2",25,0xff35d879,true));
  root.addView(label("Матчи и статистика сезона 2026/27",14,0xffb8c9bf,true),lp(4,18));
  root.addView(label("ВЫБЕРИ ЛИГУ",14,0xff35d879,true),lp(0,6));
  Spinner sp=new Spinner(this);String[] names=new String[leagues.length];for(int i=0;i<names.length;i++)names[i]=leagues[i][0];
  sp.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,names));sp.setBackground(shape(0xff12251b,12));root.addView(sp,lp(0,12));
  sp.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> a){}public void onItemSelected(android.widget.AdapterView<?> a,View v,int p,long id){league=leagues[p][1];load();}});
  LinearLayout tabs=new LinearLayout(this);for(String[] x:new String[][]{{"Сегодня","today"},{"Завтра","tomorrow"},{"Все матчи","all"}}){Button b=button(x[0]);LinearLayout.LayoutParams q=new LinearLayout.LayoutParams(0,dp(46),1);q.setMargins(dp(2),0,dp(2),0);tabs.addView(b,q);b.setOnClickListener(v->{day=x[1];load();});}root.addView(tabs,lp(0,12));
  Button reload=button("ОБНОВИТЬ");root.addView(reload,lp(0,12));reload.setOnClickListener(v->load());
  status=label("Загружаю расписание…",14,0xffc3d2c9,false);root.addView(status,lp(0,10));cards=new LinearLayout(this);cards.setOrientation(1);root.addView(cards);
  root.addView(label("Источник: open-matchday. Обновляется ежедневно, не в реальном времени. Пустые значения означают, что статистика недоступна.",12,0xff879b8e,false),lp(20,0));
 }
 Button button(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextColor(0xff06120d);b.setBackground(shape(0xff35d879,12));return b;}
 String fetch(String u)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();c.setConnectTimeout(15000);c.setReadTimeout(20000);try(InputStream in=c.getInputStream();ByteArrayOutputStream o=new ByteArrayOutputStream()){byte[] b=new byte[8192];int n;while((n=in.read(b))>0)o.write(b,0,n);return o.toString("UTF-8");}finally{c.disconnect();}}
 List<String[]> csv(String s){List<String[]> out=new ArrayList<>();BufferedReader r=new BufferedReader(new StringReader(s));try{String l;while((l=r.readLine())!=null)out.add(split(l));}catch(Exception ignored){}return out;}
 String[] split(String s){ArrayList<String>a=new ArrayList<>();StringBuilder b=new StringBuilder();boolean q=false;for(int i=0;i<s.length();i++){char c=s.charAt(i);if(c=='"'){if(q&&i+1<s.length()&&s.charAt(i+1)=='"'){b.append('"');i++;}else q=!q;}else if(c==','&&!q){a.add(b.toString());b.setLength(0);}else b.append(c);}a.add(b.toString());return a.toArray(new String[0]);}
 void load(){status.setText("Загружаю данные сезона 2026/27…");cards.removeAllViews();final String l=league,d=day;worker.execute(()->{try{
  List<String[]> f=csv(fetch(BASE+l+"/fixtures_2627.csv")),r=csv(fetch(BASE+l+"/results_2627.csv"));
  String today=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());Calendar c=Calendar.getInstance();c.add(5,1);String tom=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(c.getTime());
  List<String[]> found=new ArrayList<>();for(int i=1;i<f.size();i++){String[] x=f.get(i);if(x.length<5)continue;if(d.equals("today")&&!x[1].equals(today))continue;if(d.equals("tomorrow")&&!x[1].equals(tom))continue;found.add(x);}
  ui.post(()->{status.setText("Матчей найдено: "+found.size());if(found.isEmpty()){cards.addView(label("На эту дату матчей нет в выбранной лиге. Выбери «Все матчи» или другую лигу.",15,Color.WHITE,false));return;}for(String[] x:found)addCard(x,r);});
 }catch(Exception e){ui.post(()->status.setText("Ошибка загрузки: "+e.getMessage()));}});}
 void addCard(String[] m,List<String[]> results){LinearLayout box=new LinearLayout(this);box.setOrientation(1);box.setPadding(dp(14),dp(13),dp(14),dp(13));box.setBackground(shape(0xff12251b,15));cards.addView(box,lp(0,10));
  box.addView(label(m[1]+"  "+m[2],12,0xff9bb4a5,true));box.addView(label(m[3]+"  —  "+m[4],18,Color.WHITE,true),lp(5,8));
  Button a=button("АНАЛИЗ ПОСЛЕДНИХ ИГР");box.addView(a);TextView out=label("",13,0xffd9e7de,false);box.addView(out,lp(7,0));
  a.setOnClickListener(v->{a.setEnabled(false);out.setText("Считаю…");worker.execute(()->{String s=report(m[3],m[4],results);ui.post(()->{out.setText(s);a.setEnabled(true);});});});
 }
 Map<String,Integer> index(String[] h){Map<String,Integer> m=new HashMap<>();for(int i=0;i<h.length;i++)m.put(h[i].trim(),i);return m;}
 String val(String[] row,Map<String,Integer> ix,String key){Integer i=ix.get(key);return i==null||i>=row.length?null:row[i].trim();}
 String report(String home,String away,List<String[]> rows){if(rows.isEmpty())return "Нет результатов для анализа.";Map<String,Integer> ix=index(rows.get(0));return "ПОСЛЕДНИЕ 10 МАТЧЕЙ\n"+home+": "+team(home,rows,ix)+"\n"+away+": "+team(away,rows,ix)+"\n\nСредние рассчитаны по доступным завершённым матчам сезона. Нет данных = источник не предоставил показатель.";}
 String team(String name,List<String[]> rows,Map<String,Integer> ix){int n=0,gf=0,ga=0;String[] keys={"corners","yellow","fouls","sot"};double[] sums=new double[4];int[] counts=new int[4];
  for(int j=rows.size()-1;j>=1&&n<10;j--){String[] x=rows.get(j);String h=val(x,ix,"home"),a=val(x,ix,"away");boolean isH=name.equalsIgnoreCase(h),isA=name.equalsIgnoreCase(a);if(!isH&&!isA)continue;try{gf+=Integer.parseInt(val(x,ix,isH?"ft_home":"ft_away"));ga+=Integer.parseInt(val(x,ix,isH?"ft_away":"ft_home"));n++;String side=isH?"home_":"away_";String[] cols={side+"corners",side+"yellow",side+"fouls",side+"shots_on_target"};for(int k=0;k<4;k++){String z=val(x,ix,cols[k]);if(z!=null&&!z.isEmpty()){sums[k]+=Double.parseDouble(z);counts[k]++;}}}catch(Exception ignored){}}
  if(n==0)return "нет завершённых матчей";StringBuilder b=new StringBuilder("матчей "+n+" · голы "+fmt(gf,n)+"/"+fmt(ga,n));String[] names={"угловые","жёлтые","фолы","удары в створ"};for(int k=0;k<4;k++)b.append(" · ").append(names[k]).append(": ").append(counts[k]==0?"нет данных":fmt(sums[k],counts[k]));return b.toString();}
 String fmt(double a,int n){return String.format(Locale.US,"%.1f",a/n);}
 public void onDestroy(){super.onDestroy();worker.shutdownNow();}
}
