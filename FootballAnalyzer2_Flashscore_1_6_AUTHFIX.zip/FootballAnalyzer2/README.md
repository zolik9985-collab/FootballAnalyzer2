# Football Analyzer 2
Android application for 2026/27 fixtures and recent team form.

Data source: [open-matchday](https://github.com/oladeeayo/open-matchday).
Free CSV data, refreshed daily, not live. Detailed stats are incomplete and league-dependent; blanks are unavailable, not zero. Personal informational use only; attribution required. Review upstream disclaimer and non-commercial terms.

Push to `main` to build. Download the APK from GitHub Actions → successful run → Artifacts.


Update 3: recommendations use non-trivial goal/corner/card/foul/shots-on-target lines, show hit counts for each team's recent sample, calculate an indicative fair price from historical frequency, and return PASS when the sample or rate is insufficient. Real bookmaker odds are not fetched by this data source.


Update 4 (1.1): Added an in-app API-Football connection dialog, API key validation via /status, date-based fixture retrieval for supported leagues, and bookmaker odds display where the API plan returns odds. The key is held in memory only and is not embedded in source or saved to disk. This is a direct client integration; for production, use a secure backend proxy because APK traffic and memory can still be inspected. API quota and bookmaker/market coverage depend on the provider plan.


Update 1.2: The API key supplied by the user is preconfigured in the app source and API-Football data loading starts automatically on launch. The API refresh button can be used to reload. Security note: embedding a key in an APK makes it extractable; rotate the key if it is exposed or abused.


Update 1.3: Fixed malformed Java newline in the API key declaration that prevented compilation. League selection and Today/Tomorrow/All controls now request API-Football data rather than the legacy CSV feed. All means the next 7 days. This source archive has passed text/static checks only; it has NOT been compiled with Gradle in this environment. API-Football fixture and odds availability depends on subscription, league, bookmaker coverage, and quota. This version displays odds returned by API-Football; it does not guarantee 1xBet specifically and does not yet replace historical-statistics analysis with API-Football historical statistics.


Update 1.4: Switched match feed from API-Football to API.SH Flashscore endpoints. Loads today's fixtures, tomorrow's fixtures, or the next 8 days for All. Added per-match Flashscore statistics and pre-match Over/Under odds lookup for Norway bookmaker country code NO, plus best-effort H2H lookup. The app shows source-returned odds only; it does not fabricate prices. API.SH key is embedded as requested, which exposes it to APK extraction; rotate the key if exposed. Response field variations may require adjustment after testing against the live account.

Update 1.5: Refresh button now reloads Flashscore instead of the old CSV feed. Odds output prioritizes 1xBet when it appears in the returned bookmaker list and otherwise labels the available bookmakers. Note: response payload field names can vary by bet market; verify live responses before treating the odds parser as final.

Update 1.6: Fixed remaining API-Football button branding, removed duplicate startup request (spinner initial selection performs the first fetch), and added readable API.SH authentication/rate-limit errors. HTTP 401 means API.SH rejected the supplied key; no client-side code change can make an invalid key valid. A newly generated active API.SH key is required.
