# Football Analyzer 2
Android application for 2026/27 fixtures and recent team form.

Data source: [open-matchday](https://github.com/oladeeayo/open-matchday).
Free CSV data, refreshed daily, not live. Detailed stats are incomplete and league-dependent; blanks are unavailable, not zero. Personal informational use only; attribution required. Review upstream disclaimer and non-commercial terms.

Push to `main` to build. Download the APK from GitHub Actions → successful run → Artifacts.


Update 3: recommendations use non-trivial goal/corner/card/foul/shots-on-target lines, show hit counts for each team's recent sample, calculate an indicative fair price from historical frequency, and return PASS when the sample or rate is insufficient. Real bookmaker odds are not fetched by this data source.


Update 4 (1.1): Added an in-app API-Football connection dialog, API key validation via /status, date-based fixture retrieval for supported leagues, and bookmaker odds display where the API plan returns odds. The key is held in memory only and is not embedded in source or saved to disk. This is a direct client integration; for production, use a secure backend proxy because APK traffic and memory can still be inspected. API quota and bookmaker/market coverage depend on the provider plan.


Update 1.2: The API key supplied by the user is preconfigured in the app source and API-Football data loading starts automatically on launch. The API refresh button can be used to reload. Security note: embedding a key in an APK makes it extractable; rotate the key if it is exposed or abused.


Update 1.3: Fixed malformed Java newline in the API key declaration that prevented compilation. League selection and Today/Tomorrow/All controls now request API-Football data rather than the legacy CSV feed. All means the next 7 days. This source archive has passed text/static checks only; it has NOT been compiled with Gradle in this environment. API-Football fixture and odds availability depends on subscription, league, bookmaker coverage, and quota. This version displays odds returned by API-Football; it does not guarantee 1xBet specifically and does not yet replace historical-statistics analysis with API-Football historical statistics.


Update 1.4: Switched match feed from API-Football to API.SH Flashscore endpoints. Loads today's fixtures, tomorrow's fixtures, or the next 8 days for All. Added per-match Flashscore statistics and pre-match Over/Under odds lookup for Norway bookmaker country code NO, plus best-effort H2H lookup. The app shows source-returned odds only; it does not fabricate prices. API.SH key is embedded as requested, which exposes it to APK extraction; rotate the key if exposed. Response field variations may require adjustment after testing against the live account.

Update 1.5: Refresh button now reloads Flashscore instead of the old CSV feed. Odds output prioritizes 1xBet when it appears in the returned bookmaker list and otherwise labels the available bookmakers. Note: response payload field names can vary by bet market; verify live responses before treating the odds parser as final.

Update 1.6: Fixed remaining API-Football button branding, removed duplicate startup request (spinner initial selection performs the first fetch), and added readable API.SH authentication/rate-limit errors. HTTP 401 means API.SH rejected the supplied key; no client-side code change can make an invalid key valid. A newly generated active API.SH key is required.

Update 1.7: Replaced the rejected API.SH key with the newly supplied key. No API endpoints or parsing logic changed in this key refresh.


Update 1.8: Reworked match details based on API.SH docs. Scheduled matches explicitly say live match stats are unavailable before kickoff. Finished/live match statistics are parsed more defensively, with unknown item payloads shown rather than silently discarded. Added last-10 completed team results via /team/results, a transparent goals-only historical estimate (with sample size and hit rates), and separate odds requests for OVER_UNDER and HOME_DRAW_AWAY in Norway plus an additional RU bookmaker region to check for 1xBet. Odds render each returned bookmaker and market price; no fabricated prices. API availability is market/region/match dependent. Each clicked match can consume multiple API credits.

Update 1.9: Fixed competition selection. Previous logic used substring matching, so selecting UEFA Champions League could include CAF Champions League Women. New logic requires an exact normalized tournament name, excludes women's/youth/reserve competitions, and checks category/country metadata when provided by API.SH. The all-tournaments option remains unfiltered.


Update 2.0: Reworked match detail into a structured Russian-language analytical report. It includes each team's last 10 results, recent match statistics (up to 5 completed games per team) for corners, yellow cards, fouls and shots on target when present in API responses, average values, historical line hit rates, and model-implied fair odds clearly labelled as modelled. Real API.SH bookmaker odds remain separate. API.SH documents real odds bet types such as 1X2 and Over/Under; it does not document dedicated bookmaker odds markets for corners/cards/fouls/shots-on-target in this endpoint, so those are not presented as real bookmaker prices. Historical stats requests use one API call per prior match and can consume credits. Insufficient data results in SKIP rather than invented recommendations.

Update 2.1: Fixed zero-match national league filtering for the actual API.SH Flashscore response schema. Prefer tournament.league over prefixed tournament.name (e.g. 'FRANCE: Ligue 1'), read tournament.country directly, and use the documented matches endpoint country filter before applying a local exact league check. Women/youth/reserve exclusions remain.


Update 2.2: Replaced raw JSON odds dumping with structured parsing of API.SH match-odds response. OVER_UNDER odds are read from odds[].opportunities[] with handicap.value and over/under.value; 1X2 prices are rendered as P1/X/P2. Shows bookmaker, line, current price and opening price movement, hides raw JSON. Added historical display/picks for offsides, throw-ins and goal kicks when the match statistics endpoint supplies those fields. Medical-team attendance is explicitly marked unavailable rather than guessed. All model prices are labelled model-derived and kept separate from bookmaker prices. Odds API currently documents 1X2 and Over/Under bet types; it does not document dedicated corner/cards/fouls/shots-on-target bet types in this endpoint.


Update 2.3: Rebuilt market prediction logic. Historical totals for corners/cards/fouls/shots/offsides/throw-ins/goal kicks now sum home+away values per previous match and de-duplicate matches shared by both teams. Goal totals are also de-duplicated. Prediction selection evaluates both Over and Under but excludes trivial/extreme hit rates outside 65%-85%; requires at least 8 completed match samples; prints hits/sample count and historical frequency; never reports 100% or a fake 1.00 model price. Removed inverse-frequency model odds. Real bookmaker prices remain separate from model statistics. This is a conservative historical filter, not a calibrated probability model or guarantee.


Update 2.4: Fixed competition matching for Flashscore tournament aliases (including LaLiga/La Liga and UEFA Europa League naming variants), avoids country scoping for UEFA tournaments, and retries the general documented day feed when a national country-filtered request returns no matches. Empty results now distinguish an empty API feed from local tournament-filter rejection and show raw/selected counts. Added persistent language preference with English default and selectable Russian, Norwegian, German, French and Spanish for the primary interface/status controls. Added an account-registration entry explaining that real online registration/subscriptions require a secure authentication backend; no fake local password storage is used. The match list and report text still need a full translation pass before commercial multilingual release. This source has static checks only and has not been Gradle-built or live-tested against the user's API.SH key.

Update 2.5: Added a local persistent prediction archive with date picker, saved fixture IDs, market/line/sample details, daily win/loss/pending/PASS counts, and hit-rate calculation. The history screen can refresh a selected date: for the last seven days it refreshes the fixture feed, and it requests match statistics by saved fixture ID. Settlement uses the same Flashscore statistics schema (periods/groups/items, home+away totals) as the analysis engine. A market remains pending when the provider has not supplied the required finished-match score/statistic; the app does not guess a result. The archive is stored in SharedPreferences on the device. Version 2.5 source has static checks only; Gradle/Android SDK are unavailable in this build environment, so an APK has not been compiled here.


Update 2.6: Hardened competition filtering against API.SH tournament metadata variations: checks tournament/competition/league objects, name/league/slug and serialized metadata; removes brittle country equality rejection after the country-scoped query; preserves women/youth/reserve exclusions. This addresses feeds where all matches arrive but a strict field/country comparison incorrectly selected zero. Static checks only; live API response validation and Gradle build are still required.

Update 2.8: Reworked tournament-name normalization and matching. Flashscore region prefixes such as `EUROPE:` and `BELGIUM:` are stripped before comparison; selected competitions now require exact normalized title matches instead of substring matches. Tournament search also rejects Women/youth/reserve and explicit non-UEFA confederations before accepting a tournament ID. This prevents CAF Champions League Women or other similarly named competitions from being selected as UEFA Champions League. The All Flashscore feed remains unfiltered. Static checks only; this archive has not been compiled with Android Gradle or live-tested against the user's API.SH key. Tomorrow's `day=1` feed still requires confirmation against the user's API.SH account.


## Version 2.9 — Russia and Ukraine competitions

Added competition choices for Russia Premier League, Russia First League, Russia Cup, Ukraine Premier League, and Ukraine Cup. Tournament lookup now resolves the selected competition through API.SH tournament search and uses the country-scoped feed as a fallback. Matching accepts known competition-name aliases while checking country metadata when the feed provides it. Today/tomorrow/all date modes and the local prediction history remain in place.
