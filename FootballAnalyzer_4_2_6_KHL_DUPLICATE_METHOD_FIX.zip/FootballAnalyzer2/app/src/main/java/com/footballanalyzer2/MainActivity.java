package com.footballanalyzer2;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.AlertDialog;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.widget.*;
import android.text.InputType;
import android.content.SharedPreferences;
import java.net.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;
import org.json.*;

public class MainActivity extends Activity {
    private static final String RAW = "https://raw.githubusercontent.com/oladeeayo/open-matchday/master/data/";
    private static final String CDN = "https://cdn.jsdelivr.net/gh/oladeeayo/open-matchday@master/data/";
    private static final String SEASON = "2627";
    private static final int BG = 0xff06120d, GREEN = 0xff35d879, PANEL = 0xff12251b, MUTED = 0xff9bb4a5;

    private static class League {
        final String title, folder;
        League(String title, String folder) { this.title = title; this.folder = folder; }
        public String toString() { return title; }
    }

    // Only competitions confirmed in the public open-matchday index are listed.
    private final League[] leagues = new League[] {
        new League("🏆 Лига чемпионов UEFA", "UEFA_1_champions-league"),
        new League("🏆 Лига Европы UEFA", "UEFA_1_europa-league"),
        new League("🏆 Лига конференций UEFA", "UEFA_1_conference-league"),
        new League("Англия · FA Cup", "ENG_CUP_fa-cup"),
        new League("Англия · EFL Cup", "ENG_CUP_efl-cup"),
        new League("Испания · Copa del Rey", "ESP_CUP_copa-del-rey"),
        new League("Италия · Coppa Italia", "ITA_CUP_coppa-italia"),
        new League("Германия · DFB-Pokal", "GER_CUP_dfb-pokal"),
        new League("Нидерланды · KNVB Beker", "NED_CUP_knvb-beker"),
        new League("Англия · Premier League", "ENG_1_premier-league"),
        new League("Испания · La Liga", "ESP_1_la-liga"),
        new League("Германия · Bundesliga", "GER_1_bundesliga"),
        new League("Италия · Serie A", "ITA_1_serie-a"),
        new League("Франция · Ligue 1", "FRA_1_ligue-1"),
        new League("Нидерланды · Eredivisie", "NED_1_eredivisie"),
        new League("Португалия · Primeira Liga", "POR_1_primeira-liga"),
        new League("Бельгия · Pro League", "BEL_1_pro-league"),
        new League("Турция · Süper Lig", "TUR_1_super-lig"),
        new League("Греция · Super League", "GRE_1_super-league"),
        new League("Россия · Премьер-лига", "RUS_1_premier-liga"),
        new League("Украина · Премьер-лига", "UKR_1_premier-league"),
        new League("Норвегия · Eliteserien", "NOR_1_eliteserien"),
        new League("Шотландия · Premiership", "SCO_1_premiership"),
        new League("Польша · Ekstraklasa", "POL_1_ekstraklasa"),
        new League("Англия · Championship", "ENG_2_championship"),
        new League("Англия · League One", "ENG_3_league-one"),
        new League("Англия · League Two", "ENG_4_league-two"),
        new League("Шотландия · Championship", "SCO_2_championship"),
        new League("Шотландия · League One", "SCO_3_league-one"),
        new League("Шотландия · League Two", "SCO_4_league-two"),
        new League("Шотландия · Кубок", "SCO_CUP_scottish-cup"),
        new League("Шотландия · Кубок лиги", "SCO_CUP_league-cup"),
        new League("Португалия · Кубок", "POR_CUP_taca-de-portugal"),
        new League("Австрия · Bundesliga", "AUT_1_bundesliga"),
        new League("Австрия · Кубок", "AUT_CUP_ofb-cup"),
        new League("Швейцария · Super League", "SUI_1_super-league"),
        new League("Швейцария · Кубок", "SUI_CUP_swiss-cup"),
        new League("Дания · Superliga", "DEN_1_superliga"),
        new League("Швеция · Allsvenskan", "SWE_1_allsvenskan"),
        new League("Румыния · Liga I", "ROU_1_liga-1"),
        new League("Ирландия · First Division", "IRE_2_first-division"),
        new League("Ирландия · National League", "IRE_3_national-league"),
        new League("Польша · I Liga", "POL_2_division-1"),
        new League("Польша · II Liga", "POL_3_division-2"),
        new League("Бельгия · U21 Pro League", "BEL_U21_pro-league"),
        new League("Уэльс · Cymru Premier", "WAL_1_cymru-premier"),
        new League("Уэльс · Cymru North", "WAL_2_cymru-north"),
        new League("Уэльс · Cymru South", "WAL_3_cymru-south"),
        new League("Хорватия · HNL", "CRO_1_hnl"),
        new League("Чехия · Chance Liga", "CZE_1_chance-liga"),
        new League("Кипр · First Division", "CYP_1_first-division"),
        new League("Словакия · Nike Liga", "SVK_1_nike-liga"),
        new League("Словения · Prva Liga", "SVN_1_prva-liga"),
        new League("Финляндия · Veikkausliiga", "FIN_1_veikkausliiga"),
        new League("Казахстан · Премьер-лига", "KAZ_1_premier-league"),
        new League("Испания · Segunda División", "ESP_2_segunda-division"),
        new League("Италия · Serie B", "ITA_2_serie-b"),
        new League("Франция · Ligue 2", "FRA_2_ligue-2"),
        new League("Нидерланды · Eerste Divisie", "NED_2_eerste-divisie"),
        new League("Бразилия · Série A", "BRA_1_serie-a"),
        new League("Бразилия · Série B", "BRA_2_serie-b"),
        new League("Аргентина · Liga Profesional", "ARG_1_liga-profesional"),
        new League("Аргентина · Primera Nacional", "ARG_2_primera-nacional"),
        new League("Мексика · Liga MX", "MEX_1_liga-mx"),
        new League("Мексика · Liga de Expansión", "MEX_2_liga-expansion"),
        new League("США · MLS", "USA_1_mls"),
        new League("Япония · J1 League", "JPN_1_j1-league"),
        new League("Австралия · A-League", "AUS_1_a-league"),
        new League("Китай · Super League", "CHN_1_super-league")
    };

    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final Handler ui = new Handler(Looper.getMainLooper());
    private LinearLayout root, cards;
    private TextView status, selectedDateText;
    private Spinner leagueSpinner;
    private int selectedLeague = 0;
    private List<League> leagueOptions;
    private String mode = "today";
    private String chosenDate;
    private boolean dateWasChosen = false;
    private String appLanguage = "ru";
    private int analysisMatchCount = 10;
    private boolean hockeyMode = false;
    private Spinner hockeyLeagueSpinner;
    private String hockeyLeagueFilter = "Все хоккейные лиги";
    private boolean hockeyLastLiveOnly = true;
    private SharedPreferences appPrefs;

    private String tr(String key) {
        String lang = appLanguage;
        String[][] words = {
            {"settings","Настройки","Settings","Innstillinger","Налаштування"},
            {"history","📅 ИСТОРИЯ СОХРАНЁННЫХ ПРОГНОЗОВ","📅 SAVED ANALYSIS HISTORY","📅 LAGRET ANALYSEHISTORIKK","📅 ІСТОРІЯ ЗБЕРЕЖЕНИХ ПРОГНОЗІВ"},
            {"choose_league","ВЫБЕРИ ТУРНИР","CHOOSE LEAGUE","VELG LIGA","ОБЕРИ ЛІГУ"},
            {"today","Сегодня","Today","I dag","Сьогодні"},
            {"tomorrow","Завтра","Tomorrow","I morgen","Завтра"},
            {"all","Все матчи","All matches","Alle kamper","Усі матчі"},
            {"choose_date","📅 ВЫБРАТЬ ДАТУ","📅 CHOOSE DATE","📅 VELG DATO","📅 ОБРАТИ ДАТУ"},
            {"refresh","ОБНОВИТЬ МАТЧИ","REFRESH MATCHES","OPPDATER KAMPER","ОНОВИТИ МАТЧІ"},
            {"loading","Подключаюсь к бесплатному источнику…","Connecting to free data source…","Kobler til gratis datakilde…","Підключаюся до безкоштовного джерела…"},
            {"date","Дата: ","Date: ","Dato: ","Дата: "},
            {"api_title","API-ключ SportsAPI Pro","SportsAPI Pro API token","SportsAPI Pro API-token","API-токен SportsAPI Pro"},
            {"api_hint","Токен сохраняется в настройках приложения. Подключение API требует проверки документации SportsAPI Pro.","Token is saved in app settings. API integration requires verifying SportsAPI Pro documentation.","Token lagres i appinnstillingene. API-integrasjon krever kontroll av SportsAPI Pro-dokumentasjonen.","Токен зберігається в налаштуваннях. Інтеграція потребує перевірки документації SportsAPI Pro."},
            {"language","Язык приложения","App language","Appspråk","Мова програми"},
            {"save","Сохранить","Save","Lagre","Зберегти"},
            {"test_api","Проверить подключение","Test connection","Test tilkobling","Перевірити підключення"},
            {"cancel","Отмена","Cancel","Avbryt","Скасувати"},
            {"token_label","API-токен (вставьте новый токен)","API token (paste your new token)","API-token (lim inn ny token)","API-токен (вставте новий токен)"},
            {"source_note","Источники: open-matchday + резервный ESPN API. Данные для личного некоммерческого использования.","Sources: open-matchday + ESPN fallback. Personal, non-commercial use only.","Kilder: open-matchday + ESPN reserve. Kun personlig, ikke-kommersiell bruk.","Джерела: open-matchday + резервний ESPN API. Для особистого некомерційного використання."}
        };
        int col = lang.equals("en") ? 2 : lang.equals("no") ? 3 : lang.equals("uk") ? 4 : 1;
        for (String[] row : words) if (row[0].equals(key)) return row[col];
        return key;
    }

    private void showSettings() {
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(20), dp(8), dp(20), dp(4));
        TextView langLabel = label(tr("language"), 14, Color.WHITE, true); box.addView(langLabel);
        Spinner langs = new Spinner(this);
        String[] names = {"Русский", "English", "Norsk", "Українська"};
        String[] codes = {"ru", "en", "no", "uk"};
        ArrayAdapter<String> ad = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, names); ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item); langs.setAdapter(ad);
        int selected = Arrays.asList(codes).indexOf(appLanguage); langs.setSelection(Math.max(0, selected)); box.addView(langs, lp(4, 12));
        TextView sampleLabel = label("Количество последних матчей для анализа (3–10)", 14, Color.WHITE, true); box.addView(sampleLabel, lp(8, 2));
        Spinner sampleSpinner = new Spinner(this);
        Integer[] sampleCounts = {3, 5, 7, 10};
        ArrayAdapter<Integer> sampleAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, sampleCounts); sampleAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item); sampleSpinner.setAdapter(sampleAdapter);
        int samplePos = Arrays.asList(sampleCounts).indexOf(analysisMatchCount); sampleSpinner.setSelection(Math.max(0, samplePos)); box.addView(sampleSpinner, lp(2, 12));
        TextView tokenLabel = label(tr("token_label"), 14, Color.WHITE, true); box.addView(tokenLabel);
        EditText token = new EditText(this); token.setSingleLine(true); token.setTextSize(14); token.setHint("xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"); token.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        token.setText(appPrefs.getString("sportsapi_token", "")); box.addView(token);
        box.addView(label(tr("api_hint"), 12, MUTED, false), lp(4, 0));
        final EditText tokenField = token;
        new AlertDialog.Builder(this).setTitle(tr("settings")).setView(box)
            .setPositiveButton(tr("save"), (d,w) -> { appLanguage = codes[langs.getSelectedItemPosition()]; appPrefs.edit().putString("language", appLanguage).putString("sportsapi_token", tokenField.getText().toString().trim()).putInt("analysis_match_count", (Integer) sampleSpinner.getSelectedItem()).apply(); analysisMatchCount = (Integer) sampleSpinner.getSelectedItem(); buildUi(); loadFixtures(); })
            .setNeutralButton(tr("test_api"), (d,w) -> {
                String candidate = tokenField.getText().toString().trim();
                if (candidate.isEmpty()) { Toast.makeText(this, "Сначала вставь API-токен", Toast.LENGTH_LONG).show(); return; }
                Toast.makeText(this, "Проверяю SportsAPI Pro…", Toast.LENGTH_SHORT).show();
                worker.execute(() -> {
                    String result;
                    try { result = testSportsApi(candidate); }
                    catch (Exception e) { result = "Ошибка подключения: " + (e.getMessage()==null?e.toString():e.getMessage()); }
                    final String message = result;
                    ui.post(() -> new AlertDialog.Builder(this).setTitle("SportsAPI Pro").setMessage(message).setPositiveButton("OK", null).show());
                });
            })
            .setNegativeButton(tr("cancel"), null).show();
    }

    private String testSportsApi(String token) throws Exception {
        HttpURLConnection c = null;
        try {
            URL url = new URL("https://api.sportsapipro.com/v2/football/api/live");
            c = (HttpURLConnection) url.openConnection();
            c.setRequestMethod("GET"); c.setConnectTimeout(10000); c.setReadTimeout(15000);
            c.setRequestProperty("x-api-key", token);
            c.setRequestProperty("Accept", "application/json");
            c.setRequestProperty("User-Agent", "FootballAnalyzer/4.0");
            int code = c.getResponseCode();
            InputStream in = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            if (in != null) { try (InputStream stream = in) { byte[] b = new byte[8192]; int n; while ((n=stream.read(b))!=-1) out.write(b,0,n); } }
            String body = out.toString("UTF-8");
            if (code == 401 || code == 403) return "Ключ отклонён сервером (HTTP " + code + "). Проверь токен и статус аккаунта.";
            if (code == 429) return "Ключ принят, но превышен лимит запросов (HTTP 429). Попробуй позже.";
            if (code < 200 || code >= 300) return "Сервер вернул HTTP " + code + ": " + body.substring(0, Math.min(350, body.length()));
            JSONObject json = new JSONObject(body);
            JSONArray events = json.optJSONArray("events");
            if (events == null) {
                JSONObject data = json.optJSONObject("data");
                if (data != null) events = data.optJSONArray("events");
            }
            int count = events == null ? json.optInt("count", -1) : events.length();
            StringBuilder msg = new StringBuilder("Подключение успешно (HTTP 200).\nAPI-ключ принят сервером.");
            if (count >= 0) msg.append("\nТекущих live-матчей: ").append(count);
            else msg.append("\nСервер вернул корректный JSON-ответ.");
            msg.append("\n\nЭто проверяет авторизацию и доступ к live endpoint. Наличие угловых, фолов, карточек и ударов проверяется отдельно на конкретном матче.");
            return msg.toString();
        } finally { if (c != null) c.disconnect(); }
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density); }
    private GradientDrawable shape(int color, int radius) { GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d; }
    private TextView label(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(null, Typeface.BOLD); return t;
    }
    private LinearLayout.LayoutParams lp(int top, int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.setMargins(0, dp(top), 0, dp(bottom)); return p;
    }
    private Button button(String s) {
        Button b = new Button(this); b.setText(s); b.setAllCaps(false); b.setTextColor(BG); b.setTextSize(16); b.setTypeface(null, Typeface.BOLD); b.setBackground(shape(GREEN, 13)); return b;
    }
    private String today() { return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date()); }
    private String tomorrow() { Calendar cal=Calendar.getInstance(); cal.add(Calendar.DAY_OF_YEAR,1); return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(cal.getTime()); }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG);
        appPrefs = getSharedPreferences("football_analyzer_settings", MODE_PRIVATE);
        appLanguage = appPrefs.getString("language", "ru");
        analysisMatchCount = appPrefs.getInt("analysis_match_count", 10);
        if (analysisMatchCount != 3 && analysisMatchCount != 5 && analysisMatchCount != 7 && analysisMatchCount != 10) analysisMatchCount = 10;
        chosenDate = today();
        buildUi();
        loadFixtures();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(22), dp(18), dp(28)); root.setBackgroundColor(BG);
        scroll.addView(root); setContentView(scroll);

        LinearLayout top = new LinearLayout(this); top.setOrientation(LinearLayout.HORIZONTAL); top.setGravity(android.view.Gravity.CENTER_VERTICAL);
        TextView appTitle = label("⚽ FOOTBALL ANALYZER 4.1.5", 22, GREEN, true); top.addView(appTitle, new LinearLayout.LayoutParams(0, -2, 1));
        Button settings = button("⚙ " + tr("settings")); settings.setTextSize(12); top.addView(settings); settings.setOnClickListener(v -> showSettings()); root.addView(top, lp(0, 8));
        Button hockey = button("🏒 ОТКРЫТЬ РАЗДЕЛ ХОККЕЙ");
        root.addView(hockey, lp(0, 8));
        hockey.setOnClickListener(v -> buildHockeyUi());
        root.addView(label("Matches · open-matchday (all available competitions) + ESPN · 2026/27", 14, 0xffb8c9bf, true), lp(4, 16));

        Button history = button(tr("history")); root.addView(history, lp(0, 8));
        history.setOnClickListener(v -> showHistory());

        root.addView(label(tr("choose_league"), 15, GREEN, true), lp(4, 6));
        leagueSpinner = new Spinner(this);
        leagueOptions = new ArrayList<>();
        leagueOptions.add(new League("🌍 Все матчи", ""));
        leagueOptions.addAll(Arrays.asList(leagues));
        ArrayAdapter<League> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, leagueOptions);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        leagueSpinner.setAdapter(adapter); leagueSpinner.setBackground(shape(PANEL, 12)); root.addView(leagueSpinner, lp(0, 12));

        LinearLayout modes = new LinearLayout(this);
        String[][] choices = {{tr("today"), "today"}, {tr("tomorrow"), "tomorrow"}};
        for (String[] c : choices) {
            Button b = button(c[0]); LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(48), 1); p.setMargins(dp(2), 0, dp(2), 0); modes.addView(b, p);
            b.setOnClickListener(v -> { mode = c[1]; dateWasChosen = false; loadFixtures(); });
        }
        root.addView(modes, lp(0, 8));

        Button date = button(tr("choose_date")); root.addView(date, lp(0, 8));
        selectedDateText = label(tr("date") + chosenDate, 15, Color.WHITE, true); root.addView(selectedDateText, lp(0, 12));
        date.setOnClickListener(v -> openDatePicker());

        Button refresh = button(tr("refresh")); root.addView(refresh, lp(0, 8)); refresh.setOnClickListener(v -> loadFixtures());
        status = label(tr("loading"), 14, 0xffc3d2c9, false); root.addView(status, lp(0, 10));
        cards = new LinearLayout(this); cards.setOrientation(LinearLayout.VERTICAL); root.addView(cards);
        root.addView(label(tr("source_note"), 12, 0xff879b8e, false), lp(18, 0));

        leagueSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onNothingSelected(android.widget.AdapterView<?> parent) {}
            public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) { selectedLeague = position; loadFixtures(); }
        });
    }


    private void buildHockeyUi() {
        hockeyMode = true;
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(22), dp(18), dp(28)); root.setBackgroundColor(BG);
        scroll.addView(root); setContentView(scroll);
        LinearLayout top = new LinearLayout(this); top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(android.view.Gravity.CENTER_VERTICAL);
        TextView title = label("🏒 HOCKEY ANALYZER", 23, GREEN, true);
        top.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        Button back = button("⚽ ФУТБОЛ"); top.addView(back);
        back.setOnClickListener(v -> { hockeyMode = false; buildUi(); loadFixtures(); });
        root.addView(top, lp(0, 12));
        root.addView(label("NHL · КХЛ · ВХЛ · МХЛ · Европа · Северная Америка", 13, MUTED, false), lp(4, 14));
        root.addView(label("ВЫБЕРИ ТУРНИР", 14, GREEN, true), lp(8, 6));
        hockeyLeagueSpinner = new Spinner(this);
        String[] leagues = {
            "Все хоккейные лиги", "NHL", "AHL", "ECHL", "КХЛ", "ВХЛ", "МХЛ",
            "Швеция · SHL", "Швеция · HockeyAllsvenskan", "Финляндия · Liiga",
            "Чехия · Extraliga", "Словакия · Extraliga", "Швейцария · National League",
            "Германия · DEL", "Австрия · ICE Hockey League", "Норвегия · EHL",
            "Польша · Polska Hokej Liga", "Франция · Ligue Magnus",
            "Канада · OHL", "Канада · WHL", "Канада · QMJHL",
            "США · NCAA", "PWHL", "IIHF · Чемпионат мира", "Champions Hockey League"
        };
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, leagues);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        hockeyLeagueSpinner.setAdapter(adapter); hockeyLeagueSpinner.setBackground(shape(PANEL, 12));
        root.addView(hockeyLeagueSpinner, lp(0, 12));
        LinearLayout controls = new LinearLayout(this); controls.setOrientation(LinearLayout.HORIZONTAL);
        Button live = button("LIVE"); Button schedule = button("РАСПИСАНИЕ");
        controls.addView(live, new LinearLayout.LayoutParams(0, dp(48), 1));
        controls.addView(schedule, new LinearLayout.LayoutParams(0, dp(48), 1));
        root.addView(controls, lp(0, 8));
        Button refresh = button("ОБНОВИТЬ"); root.addView(refresh, lp(0, 8));
        status = label("Загружаю хоккейные матчи…", 14, Color.WHITE, false); root.addView(status, lp(8, 8));
        cards = new LinearLayout(this); cards.setOrientation(LinearLayout.VERTICAL); root.addView(cards);
        hockeyLeagueSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onNothingSelected(AdapterView<?> p) {}
            public void onItemSelected(AdapterView<?> p, View v, int position, long id) {
                hockeyLeagueFilter = (String)p.getItemAtPosition(position); loadHockey(true);
            }
        });
        live.setOnClickListener(v -> loadHockey(true));
        schedule.setOnClickListener(v -> loadHockey(false));
        refresh.setOnClickListener(v -> loadHockey(true));
        loadHockey(true);
    }

    private String hockeyCompetitionName(JSONObject event) {
        // Providers may place competition metadata under different keys.
        String[] objectKeys = {"tournament", "league", "competition", "uniqueTournament"};
        for (String key : objectKeys) {
            JSONObject obj = event.optJSONObject(key);
            if (obj != null) {
                String name = obj.optString("name", "");
                if (!name.isEmpty()) return name;
                String slug = obj.optString("slug", "");
                if (!slug.isEmpty()) return slug;
                JSONObject nested = obj.optJSONObject("uniqueTournament");
                if (nested != null && !nested.optString("name", "").isEmpty())
                    return nested.optString("name");
                JSONObject category = obj.optJSONObject("category");
                if (category != null && !category.optString("name", "").isEmpty())
                    return category.optString("name");
            }
            Object raw = event.opt(key);
            if (raw instanceof String && !((String)raw).trim().isEmpty())
                return ((String)raw).trim();
        }
        JSONObject context = event.optJSONObject("sportEventContext");
        if (context != null) {
            JSONObject tournament = context.optJSONObject("tournament");
            if (tournament != null) {
                String name = tournament.optString("name", "");
                if (!name.isEmpty()) return name;
                JSONObject unique = tournament.optJSONObject("uniqueTournament");
                if (unique != null) return unique.optString("name", "");
            }
        }
        return "";
    }

    private boolean hockeyLeagueMatches(String selected, String competition) {
        if (selected == null || selected.equals("Все хоккейные лиги")) return true;
        String c = competition == null ? "" : competition.toLowerCase(Locale.ROOT)
                .replace("ё", "е").replaceAll("[^\\p{L}\\p{N}]+", " ").trim();
        String f = selected.toLowerCase(Locale.ROOT).replace("ё", "е");
        String[] aliases;
        if (f.contains("кхл")) aliases = new String[]{"khl", "kontinental hockey league", "континентальная хоккейная лига"};
        else if (f.contains("вхл")) aliases = new String[]{"vhl", "supreme hockey league", "высшая хоккейная лига"};
        else if (f.contains("мхл")) aliases = new String[]{"mhl", "junior hockey league", "молодежная хоккейная лига"};
        else if (f.contains("nhl")) aliases = new String[]{"nhl", "national hockey league"};
        else if (f.contains("ahl")) aliases = new String[]{"ahl", "american hockey league"};
        else if (f.contains("echl")) aliases = new String[]{"echl", "east coast hockey league"};
        else if (f.contains("shl")) aliases = new String[]{"shl", "swedish hockey league"};
        else if (f.contains("hockeyallsvenskan")) aliases = new String[]{"hockeyallsvenskan", "allsvenskan"};
        else if (f.contains("liiga")) aliases = new String[]{"liiga", "sm liiga", "sm-liiga"};
        else if (f.contains("чехия")) aliases = new String[]{"extraliga", "czech extraliga", "tipsport extraliga"};
        else if (f.contains("словакия")) aliases = new String[]{"slovak extraliga", "tipsport liga"};
        else if (f.contains("швейцария")) aliases = new String[]{"national league", "swiss national league"};
        else if (f.contains("германия")) aliases = new String[]{"del", "deutsche eishockey liga"};
        else if (f.contains("австрия")) aliases = new String[]{"ice hockey league", "icehl", "ebel"};
        else if (f.contains("норвегия")) aliases = new String[]{"elitehockey ligaen", "ehl", "fjordkraft ligaen"};
        else if (f.contains("польша")) aliases = new String[]{"polska hokej liga", "pko bp ekstraliga"};
        else if (f.contains("франция")) aliases = new String[]{"ligue magnus"};
        else if (f.contains("канад")) aliases = new String[]{"ohl", "whl", "qmjhl"};
        else if (f.contains("ncaa")) aliases = new String[]{"ncaa"};
        else if (f.contains("pwhl")) aliases = new String[]{"pwhl", "professional womens hockey league"};
        else if (f.contains("iihf")) aliases = new String[]{"iihf", "world championship", "worlds"};
        else if (f.contains("champions hockey")) aliases = new String[]{"champions hockey league", "chl"};
        else {
            String cleaned = f.replaceAll("^[^·]+·\\s*", "").replaceAll("[^\\p{L}\\p{N}]+", " ").trim();
            return !cleaned.isEmpty() && c.contains(cleaned);
        }
        for (String alias : aliases) {
            String a = alias.toLowerCase(Locale.ROOT).replaceAll("[^\\p{L}\\p{N}]+", " ").trim();
            if (!a.isEmpty() && c.contains(a)) return true;
        }
        return false;
    }


    private JSONObject hockeyRequest(String path, String token) throws Exception {
        HttpURLConnection conn = null;
        try {
            URL url = new URL("https://api.sportsapipro.com/v2/hockey" + path);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(12000); conn.setReadTimeout(18000);
            conn.setRequestProperty("x-api-key", token);
            conn.setRequestProperty("Accept", "application/json");
            int code = conn.getResponseCode();
            InputStream in = code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream();
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            if (in != null) {
                try (InputStream stream = in) {
                    byte[] buf = new byte[8192]; int n;
                    while ((n = stream.read(buf)) != -1) out.write(buf, 0, n);
                }
            }
            String body = out.toString("UTF-8");
            if (code < 200 || code >= 300)
                throw new IOException("HTTP " + code + ": " + body.substring(0, Math.min(300, body.length())));
            return new JSONObject(body);
        } finally { if (conn != null) conn.disconnect(); }
    }

    private JSONArray hockeyFindArray(Object value) {
        if (value instanceof JSONArray) return (JSONArray)value;
        if (value instanceof JSONObject) {
            JSONObject obj = (JSONObject)value;
            String[] likely = {"statistics", "data", "events", "results", "matches", "items", "response"};
            for (String key : likely) {
                Object child = obj.opt(key);
                if (child instanceof JSONArray) return (JSONArray)child;
            }
            java.util.Iterator<String> keys = obj.keys();
            while (keys.hasNext()) {
                String key = keys.next();
                JSONArray found = hockeyFindArray(obj.opt(key));
                if (found != null) return found;
            }
        }
        return null;
    }

    private void hockeyFlatten(Object value, String prefix, List<String> lines) {
        if (value instanceof JSONObject) {
            JSONObject obj = (JSONObject)value;
            java.util.Iterator<String> keys = obj.keys();
            while (keys.hasNext()) {
                String key = keys.next();
                Object child = obj.opt(key);
                String name = prefix.isEmpty() ? key : prefix + " · " + key;
                if (child instanceof JSONObject || child instanceof JSONArray) hockeyFlatten(child, name, lines);
                else if (child != null && child != JSONObject.NULL) {
                    String v = String.valueOf(child);
                    if (!v.trim().isEmpty() && !"null".equals(v)) lines.add(name + ": " + v);
                }
            }
        } else if (value instanceof JSONArray) {
            JSONArray arr = (JSONArray)value;
            for (int i=0;i<arr.length();i++) hockeyFlatten(arr.opt(i), prefix, lines);
        }
    }


    private JSONArray hockeyRecentEvents(int teamId, String token) throws Exception {
        JSONObject j = hockeyRequest("/api/teams/" + teamId + "/events/last/0", token);
        JSONArray a = hockeyFindArray(j);
        return a == null ? new JSONArray() : a;
    }

    private double hockeyAverageGoals(JSONArray events, int teamId) {
        double total = 0; int count = 0;
        for (int i=0;i<events.length();i++) {
            JSONObject e = events.optJSONObject(i); if (e == null) continue;
            JSONObject h = e.optJSONObject("homeTeam"), a = e.optJSONObject("awayTeam");
            JSONObject hs = e.optJSONObject("homeScore"), as = e.optJSONObject("awayScore");
            if (h == null || a == null || hs == null || as == null) continue;
            int homeGoals = hs.optInt("current", hs.optInt("display", -1));
            int awayGoals = as.optInt("current", as.optInt("display", -1));
            if (homeGoals < 0 || awayGoals < 0) continue;
            total += h.optInt("id", -2) == teamId ? homeGoals : awayGoals;
            count++;
        }
        return count == 0 ? -1 : total / count;
    }

    private String hockeyPretty(String key) {
        String k = key.toLowerCase(Locale.ROOT).replace("_", "").replace("-", "").replace(" ", "");
        if (k.contains("shotsongoal") || k.equals("shots")) return "Броски в створ";
        if (k.contains("save")) return "Сейвы";
        if (k.contains("powerplay")) return "Большинство";
        if (k.contains("penaltyminutes") || k.equals("pim")) return "Штрафные минуты";
        if (k.contains("faceoff")) return "Вбрасывания";
        if (k.contains("blockedshot")) return "Блокированные броски";
        if (k.equals("hits")) return "Силовые приёмы";
        if (k.contains("goal")) return "Голы";
        if (k.contains("period1")) return "1-й период";
        if (k.contains("period2")) return "2-й период";
        if (k.contains("period3")) return "3-й период";
        return key;
    }


    private static class HockeyMetrics {
        double goalsFor, goalsAgainst, shotsFor, shotsAgainst, pimFor, pimAgainst, penaltiesFor, penaltiesAgainst;
        double[] periodGoals = new double[3];
        double[] periodShots = new double[3];
        double powerPlayGoals, powerPlayChances, savesFor, savesAgainst;
        boolean hasShots, hasPim, hasPenalties, hasPeriods, hasPeriodShots, hasPowerPlay, hasSaves;
        int games, goalGames, shotGames, pimGames, penaltyGames, periodGames, periodShotGames, powerPlayGames, saveGames;
    }

    private JSONObject hockeyFindStatArray(Object value) {
        if (value instanceof JSONObject) {
            JSONObject o=(JSONObject)value;
            Object n=o.opt("name");
            if (n != null && !JSONObject.NULL.equals(n) && (o.has("home") || o.has("homeValue") || o.has("away") || o.has("awayValue"))) return o;
            java.util.Iterator<String> it=o.keys();
            while(it.hasNext()) { Object child=o.opt(it.next()); JSONObject found=hockeyFindStatArray(child); if(found!=null)return found; }
        } else if(value instanceof JSONArray) {
            JSONArray a=(JSONArray)value;
            for(int i=0;i<a.length();i++){JSONObject found=hockeyFindStatArray(a.opt(i));if(found!=null)return found;}
        }
        return null;
    }

    private void hockeyCollectStatObjects(Object value, List<JSONObject> out) {
        if(value instanceof JSONObject) {
            JSONObject o=(JSONObject)value;
            if(o.has("name") && (o.has("home") || o.has("homeValue") || o.has("away") || o.has("awayValue"))) out.add(o);
            java.util.Iterator<String> it=o.keys();
            while(it.hasNext()) hockeyCollectStatObjects(o.opt(it.next()),out);
        } else if(value instanceof JSONArray) {
            JSONArray a=(JSONArray)value;
            for(int i=0;i<a.length();i++) hockeyCollectStatObjects(a.opt(i),out);
        }
    }

    private double hockeyNum(JSONObject o, String... keys) {
        for(String k:keys) {
            Object v=o.opt(k);
            if(v instanceof Number) return ((Number)v).doubleValue();
            if(v!=null && !JSONObject.NULL.equals(v)) {
                try { return Double.parseDouble(String.valueOf(v).replace("%","").trim()); } catch(Exception ignored) {}
            }
        }
        return -1;
    }

    private double[] hockeyExtractMatchStats(JSONObject json, int teamId, int homeId, int awayId) {
        // shots h/a, PIM h/a, penalty count h/a, saves h/a, PP goals h/a, PP chances h/a, period shots h/a x 3
        double[] out=new double[18]; java.util.Arrays.fill(out,-1);
        List<JSONObject> stats=new ArrayList<>(); hockeyCollectStatObjects(json,stats);
        for(JSONObject st:stats) {
            String n=st.optString("name","").toLowerCase(Locale.ROOT);
            String group=st.optString("groupName","").toLowerCase(Locale.ROOT);
            String period=st.optString("period","").toLowerCase(Locale.ROOT);
            double h=hockeyNum(st,"home","homeValue"), a=hockeyNum(st,"away","awayValue");
            if(n.contains("shot") && (n.contains("goal") || n.equals("shots"))) {
                out[0]=h; out[1]=a;
                int p=period.contains("1")?0:period.contains("2")?1:period.contains("3")?2:-1;
                if(p>=0){out[12+p*2]=h;out[13+p*2]=a;}
            }
            if(n.contains("penalt") && (n.contains("minute") || n.contains("pim") || n.contains("time"))) { out[2]=h; out[3]=a; }
            else if(n.contains("penalt")) { out[4]=h; out[5]=a; }
            if(n.contains("save")) { out[6]=h; out[7]=a; }
            if(n.contains("power") && (n.contains("goal") || n.contains("scored"))) { out[8]=h; out[9]=a; }
            if(n.contains("power") && (n.contains("opportun") || n.contains("chances"))) { out[10]=h; out[11]=a; }
            if(group.contains("power play") && n.contains("goal")) { out[8]=h;out[9]=a; }
            if(group.contains("power play") && (n.contains("opportun")||n.contains("chances"))) {out[10]=h;out[11]=a;}
        }
        return out;
    }

    private double hockeyScore(JSONObject score, String... keys) {
        if(score==null)return -1;
        for(String k:keys) { double v=hockeyNum(score,k); if(v>=0)return v; }
        return -1;
    }

    private HockeyMetrics hockeyAnalyzeRecent(JSONArray events, int teamId, String token) throws Exception {
        HockeyMetrics m=new HockeyMetrics();
        int limit=Math.min(10,events.length());
        for(int i=0;i<limit;i++) {
            JSONObject e=events.optJSONObject(i); if(e==null)continue;
            JSONObject home=e.optJSONObject("homeTeam"), away=e.optJSONObject("awayTeam");
            if(home==null||away==null)continue;
            int hid=home.optInt("id",-1), aid=away.optInt("id",-1);
            boolean isHome=hid==teamId;
            if(!isHome && aid!=teamId)continue;
            JSONObject hs=e.optJSONObject("homeScore"), as=e.optJSONObject("awayScore");
            double hg=hockeyScore(hs,"current","display"), ag=hockeyScore(as,"current","display");
            if(hg>=0&&ag>=0) {m.goalsFor+=isHome?hg:ag;m.goalsAgainst+=isHome?ag:hg;m.goalGames++;}
            double p1h=hockeyScore(hs,"period1","firstPeriod","p1"),p1a=hockeyScore(as,"period1","firstPeriod","p1");
            double p2h=hockeyScore(hs,"period2","secondPeriod","p2"),p2a=hockeyScore(as,"period2","secondPeriod","p2");
            double p3h=hockeyScore(hs,"period3","thirdPeriod","p3"),p3a=hockeyScore(as,"period3","thirdPeriod","p3");
            if(p1h>=0&&p1a>=0&&p2h>=0&&p2a>=0&&p3h>=0&&p3a>=0) {
                m.periodGoals[0]+=isHome?p1h:p1a; m.periodGoals[1]+=isHome?p2h:p2a; m.periodGoals[2]+=isHome?p3h:p3a; m.hasPeriods=true; m.periodGames++;
            }
            long id=e.optLong("id",-1);
            if(id>0) {
                try {
                    JSONObject sj=hockeyRequest("/api/match/"+id+"/statistics",token);
                    double[] vals=hockeyExtractMatchStats(sj,teamId,hid,aid);
                    if(vals[0]>=0&&vals[1]>=0) {m.shotsFor+=isHome?vals[0]:vals[1];m.shotsAgainst+=isHome?vals[1]:vals[0];m.hasShots=true;m.shotGames++;}
                    if(vals[2]>=0&&vals[3]>=0) {m.pimFor+=isHome?vals[2]:vals[3];m.pimAgainst+=isHome?vals[3]:vals[2];m.hasPim=true;m.pimGames++;}
                    if(vals[4]>=0&&vals[5]>=0) {m.penaltiesFor+=isHome?vals[4]:vals[5];m.penaltiesAgainst+=isHome?vals[5]:vals[4];m.hasPenalties=true;m.penaltyGames++;}
                    if(vals[6]>=0&&vals[7]>=0) {m.savesFor+=isHome?vals[6]:vals[7];m.savesAgainst+=isHome?vals[7]:vals[6];m.hasSaves=true;m.saveGames++;}
                    if(vals[8]>=0&&vals[9]>=0&&vals[10]>=0&&vals[11]>=0) {
                        m.powerPlayGoals+=isHome?vals[8]:vals[9]; m.powerPlayChances+=isHome?vals[10]:vals[11]; m.hasPowerPlay=true; m.powerPlayGames++;
                    }
                    boolean allPeriodShots=true;
                    for(int pi=0;pi<3;pi++){
                        double ps=vals[12+pi*2], pa=vals[13+pi*2];
                        if(ps<0||pa<0)allPeriodShots=false;
                        else m.periodShots[pi]+=isHome?ps:pa;
                    }
                    if(allPeriodShots){m.hasPeriodShots=true;m.periodShotGames++;}
                } catch(Exception ignored) {}
            }
            m.games++;
        }
        if(m.goalGames>0){m.goalsFor/=m.goalGames;m.goalsAgainst/=m.goalGames;}
        if(m.shotGames>0){m.shotsFor/=m.shotGames;m.shotsAgainst/=m.shotGames;}
        if(m.pimGames>0){m.pimFor/=m.pimGames;m.pimAgainst/=m.pimGames;}
        if(m.penaltyGames>0){m.penaltiesFor/=m.penaltyGames;m.penaltiesAgainst/=m.penaltyGames;}
        if(m.saveGames>0){m.savesFor/=m.saveGames;m.savesAgainst/=m.saveGames;}
        if(m.powerPlayGames>0){m.powerPlayGoals/=m.powerPlayGames;m.powerPlayChances/=m.powerPlayGames;}
        if(m.periodShotGames>0)for(int k=0;k<3;k++)m.periodShots[k]/=m.periodShotGames;
        if(m.periodGames>0)for(int k=0;k<3;k++)m.periodGoals[k]/=m.periodGames;
        return m;
    }

    private String hockeyFmt(double v) { return v<0?"—":String.format(Locale.US,"%.1f",v); }
    private int hockeyProbability(double mean, double line, boolean over) {
        if(mean<0)return -1;
        // Poisson approximation using the mean from the available recent-match sample.
        int cutoff=(int)Math.floor(line);
        double term=Math.exp(-mean), cumulative=term;
        for(int k=1;k<=Math.max(0,cutoff);k++){term*=mean/k;cumulative+=term;}
        double pOver=1.0-cumulative;
        int p=(int)Math.round((over?pOver:1.0-pOver)*100.0);
        return Math.max(1,Math.min(99,p));
    }

    private String hockeyBestPick(String label, double mean, double[] lines) {
        if(mean<0)return label+": недостаточно статистики";
        int best=0;double bestLine=0;boolean over=true;
        for(double line:lines){
            int po=hockeyProbability(mean,line,true),pu=100-po;
            if(po>best){best=po;bestLine=line;over=true;}
            if(pu>best){best=pu;bestLine=line;over=false;}
        }
        return label+": "+(over?"ТБ ":"ТМ ")+bestLine+" · около "+best+"%";
    }

    private LinearLayout hockeyPanel(LinearLayout parent, String heading, String sub) {
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(14),dp(13),dp(14),dp(13)); box.setBackground(shape(PANEL,16));
        parent.addView(box,lp(0,10));
        TextView h=label(heading,16,GREEN,true); box.addView(h,lp(0,3));
        if(sub!=null&&!sub.isEmpty())box.addView(label(sub,12,MUTED,false),lp(0,8));
        return box;
    }

    private void hockeyMetricRow(LinearLayout panel,String name,String home,String away) {
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(android.view.Gravity.CENTER_VERTICAL);
        TextView l=label(home,14,Color.WHITE,true);l.setGravity(android.view.Gravity.CENTER);
        TextView mid=label(name,12,MUTED,false);mid.setGravity(android.view.Gravity.CENTER);
        TextView r=label(away,14,Color.WHITE,true);r.setGravity(android.view.Gravity.CENTER);
        row.addView(l,new LinearLayout.LayoutParams(0,-2,1));row.addView(mid,new LinearLayout.LayoutParams(0,-2,2));row.addView(r,new LinearLayout.LayoutParams(0,-2,1));
        panel.addView(row,lp(3,7));
    }

    private void showHockeyMatchDetails(JSONObject event) {
        String publicSource=event.optString("source","");
        if("nhl".equals(publicSource)||"espn".equals(publicSource)){showHockeyPublicNhlDetails(event);return;}
        if("khl_webcaster".equals(publicSource)){showHockeyPublicKhlDetails(event);return;}
        final long matchId=event.optLong("id",-1);
        if(matchId<0){Toast.makeText(this,"У матча нет ID",Toast.LENGTH_SHORT).show();return;}
        JSONObject home=event.optJSONObject("homeTeam"),away=event.optJSONObject("awayTeam");
        final String homeName=home==null?"Хозяева":home.optString("name","Хозяева");
        final String awayName=away==null?"Гости":away.optString("name","Гости");
        final int homeId=home==null?-1:home.optInt("id",-1),awayId=away==null?-1:away.optInt("id",-1);
        final String token=appPrefs.getString("sportsapi_token","").trim();

        ScrollView scroll=new ScrollView(this);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16),dp(16),dp(16),dp(28));root.setBackgroundColor(BG);scroll.addView(root);setContentView(scroll);
        Button back=button("←  К МАТЧАМ");root.addView(back,lp(0,12));back.setOnClickListener(v->buildHockeyUi());
        LinearLayout hero=hockeyPanel(root,"🏒  "+homeName+"  —  "+awayName,"LIVE · матч ID "+matchId);
        JSONObject hscore=event.optJSONObject("homeScore"),ascore=event.optJSONObject("awayScore");
        String score=(hscore==null?"—":String.valueOf(hscore.opt("current")))+"  :  "+(ascore==null?"—":String.valueOf(ascore.opt("current")));
        TextView scoreView=label(score,30,Color.WHITE,true);scoreView.setGravity(android.view.Gravity.CENTER);hero.addView(scoreView,lp(5,4));
        TextView status=label("⏳ Загружаю статистику матча и последние 10 игр…",13,MUTED,false);root.addView(status,lp(3,10));
        LinearLayout content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);root.addView(content);

        worker.execute(()->{
            JSONObject stats=null,h2h=null;JSONArray hr=new JSONArray(),ar=new JSONArray();
            HockeyMetrics hm=new HockeyMetrics(),am=new HockeyMetrics();
            StringBuilder errors=new StringBuilder();
            try{stats=hockeyRequest("/api/match/"+matchId+"/statistics",token);}catch(Exception ex){errors.append("Матчевая статистика: ").append(ex.getMessage()).append("\n");}
            try{h2h=hockeyRequest("/api/match/"+matchId+"/h2h",token);}catch(Exception ex){errors.append("Личные встречи: ").append(ex.getMessage()).append("\n");}
            try{if(homeId>0)hr=hockeyRecentEvents(homeId,token);}catch(Exception ex){errors.append("История хозяев: ").append(ex.getMessage()).append("\n");}
            try{if(awayId>0)ar=hockeyRecentEvents(awayId,token);}catch(Exception ex){errors.append("История гостей: ").append(ex.getMessage()).append("\n");}
            try{hm=hockeyAnalyzeRecent(hr,homeId,token);}catch(Exception ex){errors.append("Расчёт хозяев: ").append(ex.getMessage()).append("\n");}
            try{am=hockeyAnalyzeRecent(ar,awayId,token);}catch(Exception ex){errors.append("Расчёт гостей: ").append(ex.getMessage()).append("\n");}
            final JSONObject fs=stats,fh=h2h;final HockeyMetrics H=hm,A=am;final String err=errors.toString();
            ui.post(()->{
                content.removeAllViews();
                List<JSONObject> currentStats=new ArrayList<>();if(fs!=null)hockeyCollectStatObjects(fs,currentStats);
                double liveShotsHome=-1,liveShotsAway=-1,livePimHome=-1,livePimAway=-1,livePenHome=-1,livePenAway=-1,liveSavesHome=-1,liveSavesAway=-1,livePPGoalsHome=-1,livePPGoalsAway=-1,livePPChHome=-1,livePPChAway=-1,possH=-1,possA=-1;
                for(JSONObject st:currentStats){
                    String n=st.optString("name","").toLowerCase(Locale.ROOT);
                    double h=hockeyNum(st,"home","homeValue"),a=hockeyNum(st,"away","awayValue");
                    if(n.contains("shot")&&(n.contains("goal")||n.equals("shots"))){liveShotsHome=h;liveShotsAway=a;}
                    if(n.contains("penalt")&&(n.contains("minute")||n.contains("pim")||n.contains("time"))){livePimHome=h;livePimAway=a;}
                    else if(n.contains("penalt")){livePenHome=h;livePenAway=a;}
                    if(n.contains("save")){liveSavesHome=h;liveSavesAway=a;}
                    if(n.contains("power")&&(n.contains("goal")||n.contains("scored"))){livePPGoalsHome=h;livePPGoalsAway=a;}
                    if(n.contains("power")&&(n.contains("opportun")||n.contains("chances"))){livePPChHome=h;livePPChAway=a;}
                    if(n.contains("possession")){possH=h;possA=a;}
                }
                LinearLayout live=hockeyPanel(content,"📊  СТАТИСТИКА СЕЙЧАС","Показатели из SportsAPI Pro");
                hockeyMetricRow(live,"🎯 Броски в створ",hockeyFmt(liveShotsHome),hockeyFmt(liveShotsAway));
                hockeyMetricRow(live,"🚨 Удаления",hockeyFmt(livePenHome),hockeyFmt(livePenAway));
                hockeyMetricRow(live,"⏱ Штрафные минуты",hockeyFmt(livePimHome),hockeyFmt(livePimAway));
                hockeyMetricRow(live,"🧤 Сейвы вратарей",hockeyFmt(liveSavesHome),hockeyFmt(liveSavesAway));
                hockeyMetricRow(live,"⚡ Большинство (голы)",hockeyFmt(livePPGoalsHome),hockeyFmt(livePPGoalsAway));
                hockeyMetricRow(live,"⚡ Большинство (попытки)",hockeyFmt(livePPChHome),hockeyFmt(livePPChAway));
                hockeyMetricRow(live,"🏒 Владение шайбой",possH<0?"—":hockeyFmt(possH)+"%",possA<0?"—":hockeyFmt(possA)+"%");

                LinearLayout recent=hockeyPanel(content,"📚  ПОСЛЕДНИЕ 10 МАТЧЕЙ","Средние значения за доступные игры · хозяева слева, гости справа");
                hockeyMetricRow(recent,"Забито за матч",hockeyFmt(H.goalsFor),hockeyFmt(A.goalsFor));
                hockeyMetricRow(recent,"Пропущено за матч",hockeyFmt(H.goalsAgainst),hockeyFmt(A.goalsAgainst));
                hockeyMetricRow(recent,"Броски в створ",hockeyFmt(H.hasShots?H.shotsFor:-1),hockeyFmt(A.hasShots?A.shotsFor:-1));
                hockeyMetricRow(recent,"Броски соперника",hockeyFmt(H.hasShots?H.shotsAgainst:-1),hockeyFmt(A.hasShots?A.shotsAgainst:-1));
                hockeyMetricRow(recent,"Удаления",hockeyFmt(H.hasPenalties?H.penaltiesFor:-1),hockeyFmt(A.hasPenalties?A.penaltiesFor:-1));
                hockeyMetricRow(recent,"Штрафные минуты",hockeyFmt(H.hasPim?H.pimFor:-1),hockeyFmt(A.hasPim?A.pimFor:-1));
                hockeyMetricRow(recent,"Сейвы вратарей",hockeyFmt(H.hasSaves?H.savesFor:-1),hockeyFmt(A.hasSaves?A.savesFor:-1));
                hockeyMetricRow(recent,"Голы в большинстве",hockeyFmt(H.hasPowerPlay?H.powerPlayGoals:-1),hockeyFmt(A.hasPowerPlay?A.powerPlayGoals:-1));
                hockeyMetricRow(recent,"Попытки большинства",hockeyFmt(H.hasPowerPlay?H.powerPlayChances:-1),hockeyFmt(A.hasPowerPlay?A.powerPlayChances:-1));
                recent.addView(label("Матчи: "+H.games+"/"+A.games+" · голы: "+H.goalGames+"/"+A.goalGames+" · броски: "+H.shotGames+"/"+A.shotGames+" · удаления: "+H.penaltyGames+"/"+A.penaltyGames+" · сейвы: "+H.saveGames+"/"+A.saveGames+" · большинство: "+H.powerPlayGames+"/"+A.powerPlayGames,11,MUTED,false),lp(3,2));

                LinearLayout goals=hockeyPanel(content,"🥅  ПРОГНОЗ ПО ШАЙБАМ","Ориентир по средним забитым и пропущенным за последние матчи");
                double expectedHome=H.games>0&&A.games>0?(H.goalsFor+A.goalsAgainst)/2:-1;
                double expectedAway=H.games>0&&A.games>0?(A.goalsFor+H.goalsAgainst)/2:-1;
                double expectedTotal=expectedHome>=0&&expectedAway>=0?expectedHome+expectedAway:-1;
                hockeyMetricRow(goals,"Ожидаемые голы",hockeyFmt(expectedHome),hockeyFmt(expectedAway));
                if(expectedTotal>=0){
                    goals.addView(label("Общий ориентир: "+hockeyFmt(expectedTotal)+" шайбы",15,Color.WHITE,true),lp(0,6));
                    for(double line:new double[]{3.5,4.5,5.5,6.5}){
                        int over=hockeyProbability(expectedTotal,line,true),under=100-over;
                        goals.addView(label("ТБ "+line+"  ·  ~"+over+"%     |     ТМ "+line+"  ·  ~"+under+"%",13,over>=55?GREEN:Color.WHITE,false),lp(0,4));
                    }
                    goals.addView(label("🏠 "+homeName+" · ориентир "+hockeyFmt(expectedHome)+" шайб",13,Color.WHITE,true),lp(3,3));
                    for(double line:new double[]{1.5,2.5,3.5}){
                        int p=hockeyProbability(expectedHome,line,true);
                        goals.addView(label("ИТБ "+line+" ~"+p+"%  ·  ИТМ "+line+" ~"+(100-p)+"%",12,MUTED,false),lp(0,2));
                    }
                    goals.addView(label("✈️ "+awayName+" · ориентир "+hockeyFmt(expectedAway)+" шайб",13,Color.WHITE,true),lp(5,3));
                    for(double line:new double[]{1.5,2.5,3.5}){
                        int p=hockeyProbability(expectedAway,line,true);
                        goals.addView(label("ИТБ "+line+" ~"+p+"%  ·  ИТМ "+line+" ~"+(100-p)+"%",12,MUTED,false),lp(0,2));
                    }
                }else goals.addView(label("Недостаточно истории для расчёта.",13,MUTED,false),lp(0,4));

                LinearLayout shots=hockeyPanel(content,"🎯  ПРОГНОЗ ПО БРОСКАМ В СТВОР","Средние броски за матч на выборке последних 10 игр");
                if(H.hasShots&&A.hasShots){
                    double expShots=H.shotsFor+A.shotsFor;
                    hockeyMetricRow(shots,"Ожидаемые броски",hockeyFmt(H.shotsFor),hockeyFmt(A.shotsFor));
                    shots.addView(label("Общий ориентир: "+hockeyFmt(expShots)+" бросков",15,Color.WHITE,true),lp(0,5));
                    for(double line:new double[]{49.5,54.5,59.5,64.5,69.5}){
                        int over=hockeyProbability(expShots,line,true);
                        shots.addView(label("ТБ "+line+" ~"+over+"%   ·   ТМ "+line+" ~"+(100-over)+"%",13,Color.WHITE,false),lp(0,4));
                    }
                    shots.addView(label("🏠 "+homeName+" · ИТБ/ИТМ бросков",13,Color.WHITE,true),lp(4,3));
                    for(double line:new double[]{19.5,22.5,24.5,27.5}){
                        int p=hockeyProbability(H.shotsFor,line,true);
                        shots.addView(label(line+": больше ~"+p+"% · меньше ~"+(100-p)+"%",12,MUTED,false),lp(0,2));
                    }
                    shots.addView(label("✈️ "+awayName+" · ИТБ/ИТМ бросков",13,Color.WHITE,true),lp(4,3));
                    for(double line:new double[]{19.5,22.5,24.5,27.5}){
                        int p=hockeyProbability(A.shotsFor,line,true);
                        shots.addView(label(line+": больше ~"+p+"% · меньше ~"+(100-p)+"%",12,MUTED,false),lp(0,2));
                    }
                }else shots.addView(label("Провайдер не отдал историю бросков по прошлым матчам. Текущие броски выше показаны отдельно, если доступны.",13,MUTED,false),lp(0,4));

                LinearLayout penalties=hockeyPanel(content,"🚨  ПРОГНОЗ ПО УДАЛЕНИЯМ","Штрафные минуты в среднем за матч");
                if(H.hasPim&&A.hasPim){
                    double expPim=H.pimFor+A.pimFor;
                    hockeyMetricRow(penalties,"Штрафные минуты",hockeyFmt(H.pimFor),hockeyFmt(A.pimFor));
                    penalties.addView(label("Общий ориентир: "+hockeyFmt(expPim)+" минут",15,Color.WHITE,true),lp(0,5));
                    for(double line:new double[]{8.5,10.5,12.5,14.5,16.5}){
                        int over=hockeyProbability(expPim,line,true);
                        penalties.addView(label("ТБ "+line+" ~"+over+"%   ·   ТМ "+line+" ~"+(100-over)+"%",13,Color.WHITE,false),lp(0,4));
                    }
                    penalties.addView(label("ИТБ / ИТМ штрафных минут",13,Color.WHITE,true),lp(4,3));
                    for(double line:new double[]{3.5,4.5,5.5,6.5}){
                        int ph=hockeyProbability(H.pimFor,line,true),pa=hockeyProbability(A.pimFor,line,true);
                        penalties.addView(label(homeName+" "+line+": "+ph+"% / "+(100-ph)+"%   ·   "+awayName+": "+pa+"% / "+(100-pa)+"%",11,MUTED,false),lp(0,3));
                    }
                }else penalties.addView(label("История штрафных минут недоступна в ответах API.",13,MUTED,false),lp(0,4));

                LinearLayout penaltyCount=hockeyPanel(content,"🚨  КОЛИЧЕСТВО УДАЛЕНИЙ","Среднее число удалений за матч");
                if(H.hasPenalties&&A.hasPenalties){
                    double totalPens=H.penaltiesFor+A.penaltiesFor;
                    hockeyMetricRow(penaltyCount,"Удаления",hockeyFmt(H.penaltiesFor),hockeyFmt(A.penaltiesFor));
                    penaltyCount.addView(label("Общий ориентир: "+hockeyFmt(totalPens)+" удалений",14,Color.WHITE,true),lp(0,4));
                    for(double line:new double[]{3.5,4.5,5.5,6.5,7.5}){
                        int over=hockeyProbability(totalPens,line,true);
                        penaltyCount.addView(label("ТБ "+line+" ~"+over+"% · ТМ "+line+" ~"+(100-over)+"%",12,Color.WHITE,false),lp(0,3));
                    }
                }else penaltyCount.addView(label("История количества удалений недоступна.",12,MUTED,false),lp(0,3));

                LinearLayout pp=hockeyPanel(content,"⚡  БОЛЬШИНСТВО","Среднее число голов и попыток большинства за матч");
                if(H.hasPowerPlay&&A.hasPowerPlay){
                    double hp=H.powerPlayChances>0?100.0*H.powerPlayGoals/H.powerPlayChances:0;
                    double ap=A.powerPlayChances>0?100.0*A.powerPlayGoals/A.powerPlayChances:0;
                    hockeyMetricRow(pp,"Голы / попытки",hockeyFmt(H.powerPlayGoals)+" / "+hockeyFmt(H.powerPlayChances),hockeyFmt(A.powerPlayGoals)+" / "+hockeyFmt(A.powerPlayChances));
                    hockeyMetricRow(pp,"Реализация",String.format(Locale.US,"%.1f%%",hp),String.format(Locale.US,"%.1f%%",ap));
                }else pp.addView(label("История большинства не предоставлена API для части матчей.",12,MUTED,false),lp(0,3));

                LinearLayout saves=hockeyPanel(content,"🧤  ВРАТАРИ","Средние сейвы за матч по доступной истории");
                if(H.hasSaves&&A.hasSaves){
                    hockeyMetricRow(saves,"Сейвы в среднем",hockeyFmt(H.savesFor),hockeyFmt(A.savesFor));
                }else saves.addView(label("Статистика сейвов вратарей недоступна в части исторических ответов.",12,MUTED,false),lp(0,3));

                LinearLayout periods=hockeyPanel(content,"⏱  ГОЛЫ ПО ПЕРИОДАМ","Средние забитые шайбы за период по последним матчам");
                if(H.hasPeriods&&A.hasPeriods){
                    for(int k=0;k<3;k++){
                        double periodTotal=H.periodGoals[k]+A.periodGoals[k];
                        hockeyMetricRow(periods,(k+1)+"-й период",hockeyFmt(H.periodGoals[k]),hockeyFmt(A.periodGoals[k]));
                        periods.addView(label("Тотал периода ~"+hockeyFmt(periodTotal)+" · ТБ 0,5 ~"+hockeyProbability(periodTotal,0.5,true)+"% · ТБ 1,5 ~"+hockeyProbability(periodTotal,1.5,true)+"%",12,Color.WHITE,false),lp(0,5));
                    }
                }else periods.addView(label("API не вернул разбивку прошлых матчей по периодам. Данные не подменяются общими средними.",13,MUTED,false),lp(0,4));

                LinearLayout periodShots=hockeyPanel(content,"🎯  БРОСКИ ПО ПЕРИОДАМ","Средние броски в створ каждой команды по периодам");
                if(H.hasPeriodShots&&A.hasPeriodShots){
                    for(int k=0;k<3;k++)hockeyMetricRow(periodShots,(k+1)+"-й период",hockeyFmt(H.periodShots[k]),hockeyFmt(A.periodShots[k]));
                }else periodShots.addView(label("Провайдер не передал разбивку бросков по периодам для последних матчей.",12,MUTED,false),lp(0,3));

                if(fh!=null){
                    LinearLayout h2hPanel=hockeyPanel(content,"🤝  ЛИЧНЫЕ ВСТРЕЧИ","По данным SportsAPI Pro");
                    List<String> lines=new ArrayList<>();hockeyFlatten(fh,"",lines);
                    for(String line:lines){if(line.startsWith("success:")||line.startsWith("matchId:")||line.startsWith("endpoint:")||line.startsWith("source:")||line.startsWith("cacheHit:")||line.startsWith("timezone"))continue;
                        if(line.toLowerCase(Locale.ROOT).contains("homewins")||line.toLowerCase(Locale.ROOT).contains("awaywins")||line.toLowerCase(Locale.ROOT).contains("draws"))
                            h2hPanel.addView(label("• "+line,13,Color.WHITE,false),lp(0,3));
                    }
                }
                LinearLayout note=hockeyPanel(content,"ℹ️  КАК ЧИТАТЬ ПРОЦЕНТЫ","Это приблизительная модельная оценка, не гарантия результата и не букмекерская вероятность.");
                note.addView(label("Проценты рассчитаны по средним показателям доступной истории. Чем меньше матчей и чем больше пропусков в статистике, тем ниже надёжность. Для ставки сравнивай линию букмекера с этим ориентиром.",12,MUTED,false),lp(0,2));
                LinearLayout summary=hockeyPanel(content,"🎟️  СВОДКА ПО РЫНКАМ","Самые выраженные ориентиры модели по доступной истории");
                summary.addView(label(hockeyBestPick("🥅 Голы",expectedTotal,new double[]{3.5,4.5,5.5,6.5}),13,Color.WHITE,true),lp(0,5));
                summary.addView(label(hockeyBestPick("🎯 Броски",H.hasShots&&A.hasShots?H.shotsFor+A.shotsFor:-1,new double[]{49.5,54.5,59.5,64.5,69.5}),13,Color.WHITE,true),lp(0,5));
                summary.addView(label(hockeyBestPick("🚨 Удаления",H.hasPenalties&&A.hasPenalties?H.penaltiesFor+A.penaltiesFor:-1,new double[]{3.5,4.5,5.5,6.5,7.5}),13,Color.WHITE,true),lp(0,5));
                summary.addView(label(hockeyBestPick("⏱ Штрафные минуты",H.hasPim&&A.hasPim?H.pimFor+A.pimFor:-1,new double[]{8.5,10.5,12.5,14.5,16.5}),13,Color.WHITE,true),lp(0,5));
                summary.addView(label("⚡ Реализация большинства: "+(H.hasPowerPlay&&H.powerPlayChances>0?String.format(Locale.US,"%.1f%%",100*H.powerPlayGoals/H.powerPlayChances):"—")+" / "+(A.hasPowerPlay&&A.powerPlayChances>0?String.format(Locale.US,"%.1f%%",100*A.powerPlayGoals/A.powerPlayChances):"—"),13,Color.WHITE,true),lp(0,5));
                summary.addView(label("Не ставь только по максимальному проценту: сравни оценку с коэффициентом и учитывай составы, вратарей и ход матча.",11,MUTED,false),lp(2,2));
                if(!err.isEmpty()){
                    LinearLayout diag=hockeyPanel(content,"⚙️  ДИАГНОСТИКА ДАННЫХ","Некоторые показатели не удалось загрузить.");
                    diag.addView(label(err,11,MUTED,false),lp(0,2));
                }
                status.setText("✅ Анализ загружен · история до 10 матчей на команду");
            });
        });
    }


    // Public, key-free hockey providers. The NHL endpoints are undocumented public feeds;
    // ESPN is a second independent NHL scoreboard source.


    private Object hockeyPublicGetAny(String address) throws Exception {
        HttpURLConnection conn=null;
        try {
            conn=(HttpURLConnection)new URL(address).openConnection();
            conn.setRequestMethod("GET"); conn.setConnectTimeout(10000); conn.setReadTimeout(15000);
            conn.setRequestProperty("Accept","application/json");
            conn.setRequestProperty("User-Agent","FootballAnalyzer/4.2.5 Android");
            int code=conn.getResponseCode();
            InputStream in=code>=200&&code<300?conn.getInputStream():conn.getErrorStream();
            ByteArrayOutputStream out=new ByteArrayOutputStream();
            if(in!=null)try(InputStream stream=in){byte[] b=new byte[8192];int n;while((n=stream.read(b))!=-1)out.write(b,0,n);}
            String body=out.toString("UTF-8").trim();
            if(code<200||code>=300)throw new IOException("HTTP "+code+" "+body.substring(0,Math.min(180,body.length())));
            if(body.startsWith("["))return new JSONArray(body);
            return new JSONObject(body);
        } finally {if(conn!=null)conn.disconnect();}
    }

    private JSONObject hockeyPublicGet(String address) throws Exception {
        Object value=hockeyPublicGetAny(address);
        if(value instanceof JSONObject)return (JSONObject)value;
        throw new Exception("Ожидался JSON-объект, получен массив");
    }

    private JSONObject hockeyNhlTeam(JSONObject team) {
        JSONObject t=new JSONObject();
        try {
            t.put("id",team.optInt("id",-1));
            JSONObject place=team.optJSONObject("placeName");
            JSONObject common=team.optJSONObject("commonName");
            String name=common==null?"":common.optString("default","");
            if(name.isEmpty()&&place!=null)name=place.optString("default","");
            if(name.isEmpty())name=team.optString("abbrev","Team");
            t.put("name",name);
        } catch(Exception ignored){}
        return t;
    }

    private JSONObject hockeyNhlEvent(JSONObject game) {
        JSONObject e=new JSONObject();
        try {
            e.put("id",game.optLong("id",-1));
            e.put("source","nhl");
            e.put("homeTeam",hockeyNhlTeam(game.optJSONObject("homeTeam")==null?new JSONObject():game.optJSONObject("homeTeam")));
            e.put("awayTeam",hockeyNhlTeam(game.optJSONObject("awayTeam")==null?new JSONObject():game.optJSONObject("awayTeam")));
            JSONObject hs=new JSONObject(),as=new JSONObject();
            JSONObject h=game.optJSONObject("homeTeam"),a=game.optJSONObject("awayTeam");
            hs.put("current",h==null?JSONObject.NULL:h.opt("score"));
            as.put("current",a==null?JSONObject.NULL:a.opt("score"));
            e.put("homeScore",hs);e.put("awayScore",as);
            JSONObject tournament=new JSONObject();tournament.put("name","NHL · NHL public API");e.put("tournament",tournament);
            JSONObject st=new JSONObject();
            String state=game.optString("gameState",game.optString("gameScheduleState",""));
            st.put("description",state);e.put("status",st);
            e.put("gameDate",game.optString("gameDate",""));
        } catch(Exception ignored){}
        return e;
    }

    private JSONArray hockeyNhlGames(String date, boolean liveOnly) throws Exception {
        String safe=date==null||date.isEmpty()?today():date;
        JSONObject root=hockeyPublicGet("https://api-web.nhle.com/v1/schedule/"+safe);
        JSONArray weeks=root.optJSONArray("gameWeek"), result=new JSONArray();
        if(weeks==null)return result;
        for(int i=0;i<weeks.length();i++){
            JSONObject week=weeks.optJSONObject(i);if(week==null)continue;
            if(!safe.equals(week.optString("date",safe)))continue;
            JSONArray games=week.optJSONArray("games");if(games==null)continue;
            for(int j=0;j<games.length();j++){
                JSONObject game=games.optJSONObject(j);if(game==null)continue;
                String state=game.optString("gameState","").toUpperCase(Locale.ROOT);
                boolean live=state.equals("LIVE")||state.equals("CRIT")||state.equals("IN_PROGRESS");
                if(!liveOnly||live)result.put(hockeyNhlEvent(game));
            }
        }
        return result;
    }

    private JSONArray hockeyEspnNhlGames(String date, boolean liveOnly) throws Exception {
        String digits=(date==null?today():date).replace("-","");
        JSONObject root=hockeyPublicGet("https://site.api.espn.com/apis/site/v2/sports/hockey/nhl/scoreboard?dates="+digits);
        JSONArray events=root.optJSONArray("events"), result=new JSONArray();
        if(events==null)return result;
        for(int i=0;i<events.length();i++){
            JSONObject event=events.optJSONObject(i);if(event==null)continue;
            JSONArray comps=event.optJSONArray("competitions");JSONObject comp=comps==null||comps.length()==0?null:comps.optJSONObject(0);
            JSONArray competitors=comp==null?null:comp.optJSONArray("competitors");if(competitors==null||competitors.length()<2)continue;
            JSONObject home=null,away=null;
            for(int j=0;j<competitors.length();j++){
                JSONObject c=competitors.optJSONObject(j);if(c==null)continue;
                JSONObject team=c.optJSONObject("team");JSONObject t=new JSONObject();
                t.put("id",team==null?-1:team.optString("id","-1"));
                t.put("name",team==null?"Team":team.optString("displayName","Team"));
                if("home".equalsIgnoreCase(c.optString("homeAway")))home=t;else away=t;
                if(home!=null)home.put("score",c.optString("score",""));
                if(away!=null)away.put("score",c.optString("score",""));
            }
            if(home==null||away==null)continue;
            JSONObject e=new JSONObject();e.put("id",event.optString("id","-1"));e.put("source","espn");
            e.put("homeTeam",home);e.put("awayTeam",away);
            JSONObject hs=new JSONObject(),as=new JSONObject();hs.put("current",home.optString("score",""));as.put("current",away.optString("score",""));
            e.put("homeScore",hs);e.put("awayScore",as);
            JSONObject t=new JSONObject();t.put("name","NHL · ESPN");e.put("tournament",t);
            JSONObject st=new JSONObject();
            JSONObject status=comp.optJSONObject("status");
            if(status==null)status=event.optJSONObject("status");
            JSONObject typ=status==null?null:status.optJSONObject("type");
            String state=typ==null?"":typ.optString("state","").toLowerCase(Locale.ROOT);
            String typeName=typ==null?"":typ.optString("name","").toLowerCase(Locale.ROOT);
            String description=typ==null?"":typ.optString("shortDetail",typ.optString("detail",""));
            st.put("description",description);e.put("status",st);
            // ESPN sends type.state as text ("pre", "in", "post"), not a boolean.
            boolean isLive=state.equals("in")||state.equals("live")||state.equals("in_progress")
                    ||typeName.contains("in_progress")||typeName.contains("live");
            if(!liveOnly||isLive)result.put(e);
        }
        return result;
    }


    // KHL Webcaster is a public keyless JSON feed. Current stage id is discovered
    // from data.json; 407 is only a last-resort 2026/27 fallback documented by SportsDataverse.
    private int hockeyKhlFindStageId(Object value, int season, String stageType) {
        if(value instanceof JSONObject) {
            JSONObject o=(JSONObject)value;
            int s=o.optInt("season",-1);
            String type=o.optString("type",o.optString("stage_type","")).toLowerCase(Locale.ROOT);
            int id=o.optInt("stage_id",-1);
            if(id>0 && s==season && (type.isEmpty() || type.contains(stageType))) return id;
            java.util.Iterator<String> it=o.keys();
            while(it.hasNext()){int found=hockeyKhlFindStageId(o.opt(it.next()),season,stageType);if(found>0)return found;}
        } else if(value instanceof JSONArray) {
            JSONArray a=(JSONArray)value;
            for(int i=0;i<a.length();i++){int found=hockeyKhlFindStageId(a.opt(i),season,stageType);if(found>0)return found;}
        }
        return -1;
    }

    private void hockeyKhlCollectEvents(Object value, JSONArray out) {
        if(value instanceof JSONObject) {
            JSONObject o=(JSONObject)value;
            if(o.optJSONObject("event")!=null) {
                hockeyKhlCollectEvents(o.optJSONObject("event"),out);
                return;
            }
            if((o.has("khl_id") || o.has("match_id")) && (o.has("team_a") || o.has("team_a_name") || o.has("team_b_name") || o.has("name"))) {
                out.put(o); return;
            }
            java.util.Iterator<String> it=o.keys();
            while(it.hasNext()) hockeyKhlCollectEvents(o.opt(it.next()),out);
        } else if(value instanceof JSONArray) {
            JSONArray a=(JSONArray)value;
            for(int i=0;i<a.length();i++) hockeyKhlCollectEvents(a.opt(i),out);
        }
    }

    private String hockeyKhlScorePart(String raw, int index) {
        if(raw==null || raw.trim().isEmpty() || "null".equalsIgnoreCase(raw)) return "–";
        String[] p=raw.trim().split(":");
        if(p.length<2)return "–";
        return p[index].trim();
    }

    private JSONObject hockeyKhlNormalizeEvent(JSONObject raw) throws Exception {
        JSONObject e=new JSONObject();
        long id=raw.optLong("khl_id",raw.optLong("match_id",raw.optLong("id",-1)));
        if(id<0)id=raw.optLong("id",-1);
        e.put("id",id);e.put("source","khl_webcaster");
        JSONObject home=new JSONObject(),away=new JSONObject();
        JSONObject teamA=raw.optJSONObject("team_a"),teamB=raw.optJSONObject("team_b");
        home.put("id",raw.optLong("team_a_khl_id",raw.optLong("team_a_id",teamA==null?-1:teamA.optLong("khl_id",teamA.optLong("id",-1)))));
        home.put("name",raw.optString("team_a_name",teamA==null?"Хозяева":teamA.optString("name","Хозяева")));
        away.put("id",raw.optLong("team_b_khl_id",raw.optLong("team_b_id",teamB==null?-1:teamB.optLong("khl_id",teamB.optLong("id",-1)))));
        away.put("name",raw.optString("team_b_name",teamB==null?"Гости":teamB.optString("name","Гости")));
        e.put("homeTeam",home);e.put("awayTeam",away);
        String score=raw.optString("score","");
        JSONObject hs=new JSONObject(),as=new JSONObject();
        hs.put("current",hockeyKhlScorePart(score,0));as.put("current",hockeyKhlScorePart(score,1));
        e.put("homeScore",hs);e.put("awayScore",as);
        JSONObject tournament=new JSONObject();tournament.put("name","КХЛ · бесплатный Webcaster API");e.put("tournament",tournament);
        JSONObject st=new JSONObject();
        String state=raw.optString("game_state_key",raw.optString("status",""));
        int period=raw.optInt("period",0);
        if(state.isEmpty())state=period>0?"Идёт матч · период "+period:"Расписание / статус не указан";
        else if(period>0 && !state.toLowerCase(Locale.ROOT).contains("finished"))state+=" · период "+period;
        st.put("description",state);e.put("status",st);
        JSONObject scores=raw.optJSONObject("scores");
        e.put("period1",raw.optString("scores_first_period",scores==null?"":scores.optString("first_period","")));
        e.put("period2",raw.optString("scores_second_period",scores==null?"":scores.optString("second_period","")));
        e.put("period3",raw.optString("scores_third_period",scores==null?"":scores.optString("third_period","")));
        e.put("overtime",raw.optString("scores_overtime",scores==null?"":scores.optString("overtime","")));
        e.put("shootout",raw.optString("scores_bullitt",scores==null?"":scores.optString("bullitt","")));
        e.put("startAt",raw.optLong("event_start_at",raw.optLong("start_at",0)));
        e.put("stageName",raw.optString("stage_name",""));
        return e;
    }

    private JSONArray hockeyKhlGames(String date, boolean liveOnly) throws Exception {
        int season=Calendar.getInstance().get(Calendar.YEAR);
        // KHL season is named by its ending year; after summer, current year is the end year.
        JSONObject stageData=hockeyPublicGet("https://khl.api.webcaster.pro/api/khl_mobile/data.json");
        int stageId=hockeyKhlFindStageId(stageData,season,"regular");
        if(stageId<0)stageId=407; // documented 2026/27 regular-stage fallback
        long now=System.currentTimeMillis()/1000L;
        long after=now-24L*60L*60L;
        long before=now+48L*60L*60L;
        String url="https://khl.api.webcaster.pro/api/khl_mobile/events_v2.json?stage_id="+stageId
                +"&page=1&locale=ru&start_after="+after+"&start_before="+before;
        Object root=hockeyPublicGetAny(url);
        JSONArray rawEvents=new JSONArray();hockeyKhlCollectEvents(root,rawEvents);
        JSONArray result=new JSONArray();
        String wanted=date==null||date.isEmpty()?today():date;
        SimpleDateFormat dayFmt=new SimpleDateFormat("yyyy-MM-dd",Locale.US);
        for(int i=0;i<rawEvents.length();i++){
            JSONObject raw=rawEvents.optJSONObject(i);if(raw==null)continue;
            long start=raw.optLong("event_start_at",raw.optLong("start_at",0));
            if(start>0){
                String eventDay=dayFmt.format(new Date(start>100000000000L?start:start*1000L));
                if(!wanted.equals(eventDay))continue;
            }
            String state=raw.optString("game_state_key",raw.optString("status","")).toLowerCase(Locale.ROOT);
            int period=raw.optInt("period",0);
            boolean finished=state.contains("finish")||state.contains("final")||state.contains("заверш");
            boolean live=state.contains("live")||state.contains("progress")||state.contains("playing")||state.contains("started")||(period>0&&!finished);
            if(liveOnly&&!live)continue;
            result.put(hockeyKhlNormalizeEvent(raw));
        }
        return result;
    }

    private void showHockeyPublicKhlDetails(JSONObject event) {
        ScrollView scroll=new ScrollView(this);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16),dp(16),dp(16),dp(24));root.setBackgroundColor(BG);scroll.addView(root);setContentView(scroll);
        Button back=button("←  К МАТЧАМ");root.addView(back,lp(0,12));back.setOnClickListener(v->buildHockeyUi());
        JSONObject h=event.optJSONObject("homeTeam"),a=event.optJSONObject("awayTeam");
        String hn=h==null?"Хозяева":h.optString("name"),an=a==null?"Гости":a.optString("name");
        LinearLayout panel=hockeyPanel(root,"🏒 "+hn+" — "+an,"Источник: KHL Webcaster · бесплатно · без ключа");
        JSONObject hs=event.optJSONObject("homeScore"),as=event.optJSONObject("awayScore");
        TextView score=label((hs==null?"–":hs.optString("current","–"))+" : "+(as==null?"–":as.optString("current","–")),30,Color.WHITE,true);
        score.setGravity(android.view.Gravity.CENTER);panel.addView(score,lp(0,6));
        hockeyMetricRow(panel,"1-й период",hockeyKhlScorePart(event.optString("period1",""),0),hockeyKhlScorePart(event.optString("period1",""),1));
        hockeyMetricRow(panel,"2-й период",hockeyKhlScorePart(event.optString("period2",""),0),hockeyKhlScorePart(event.optString("period2",""),1));
        hockeyMetricRow(panel,"3-й период",hockeyKhlScorePart(event.optString("period3",""),0),hockeyKhlScorePart(event.optString("period3",""),1));
        if(!event.optString("overtime","").isEmpty())hockeyMetricRow(panel,"Овертайм",hockeyKhlScorePart(event.optString("overtime",""),0),hockeyKhlScorePart(event.optString("overtime",""),1));
        if(!event.optString("shootout","").isEmpty())hockeyMetricRow(panel,"Буллиты",hockeyKhlScorePart(event.optString("shootout",""),0),hockeyKhlScorePart(event.optString("shootout",""),1));
        root.addView(label("ℹ️ Бесплатный источник сейчас подтверждён для расписания, счёта и разбивки голов по периодам. Для бросков, удалений, большинства и сейвов потребуется отдельный запрос статистики матча; эти показатели здесь пока не подменяются догадками.",12,MUTED,false),lp(0,10));
    }

    private void loadHockeyFreeSources(final boolean liveOnly, final String filter, final String date, final String reason) {
        worker.execute(()->{
            JSONArray combined=new JSONArray();StringBuilder providers=new StringBuilder();
            Exception last=null;
            String f=filter==null?"":filter.toLowerCase(Locale.ROOT);
            boolean all=filter==null||f.contains("все");
            boolean wantsNhl=all||f.contains("nhl")||f.contains("нхл");
            boolean wantsKhl=all||f.contains("кхл")||f.contains("khl");
            if(wantsKhl){
                try{
                    JSONArray khl=hockeyKhlGames(date,liveOnly);
                    for(int i=0;i<khl.length();i++)combined.put(khl.get(i));
                    if(khl.length()>0)providers.append("KHL Webcaster");
                }catch(Exception ex){last=ex;}
            }
            if(wantsNhl){
                try{
                    JSONArray nhl=hockeyNhlGames(date,liveOnly);
                    if(nhl.length()==0)nhl=hockeyEspnNhlGames(date,liveOnly);
                    for(int i=0;i<nhl.length();i++)combined.put(nhl.get(i));
                    if(nhl.length()>0){if(providers.length()>0)providers.append(" + ");providers.append("NHL API/ESPN");}
                }catch(Exception ex){
                    last=ex;
                    try{
                        JSONArray espn=hockeyEspnNhlGames(date,liveOnly);
                        for(int i=0;i<espn.length();i++)combined.put(espn.get(i));
                        if(espn.length()>0){if(providers.length()>0)providers.append(" + ");providers.append("ESPN");}
                    }catch(Exception ex2){last=ex2;}
                }
            }
            final JSONArray found=combined;final String used=providers.toString();final Exception error=last;
            ui.post(()->{
                if(cards==null||status==null)return;
                cards.removeAllViews();
                if(found.length()==0){
                    status.setText("Бесплатные источники: нет данных для выбранной лиги");
                    String extra=error==null?"":("\nОшибка последнего источника: "+error.getMessage());
                    String supported=wantsKhl?"КХЛ: пробовали KHL Webcaster без ключа. ":"";
                    cards.addView(label(supported+"Бесплатные источники без ключа: NHL API / ESPN для НХЛ; KHL Webcaster для КХЛ. ВХЛ и остальные европейские лиги пока требуют отдельных адаптеров."+extra+"\n\nОсновной SportsAPI Pro: "+reason,13,MUTED,false),lp(8,8));
                    return;
                }
                status.setText("🟢 Бесплатные источники · "+used+" · матчей: "+found.length()+"\nSportsAPI Pro: "+reason);
                for(int i=0;i<found.length();i++){
                    JSONObject e=found.optJSONObject(i);if(e==null)continue;
                    String comp=hockeyCompetitionName(e);
                    JSONObject h=e.optJSONObject("homeTeam"),a=e.optJSONObject("awayTeam");
                    JSONObject hs=e.optJSONObject("homeScore"),as=e.optJSONObject("awayScore"),st=e.optJSONObject("status");
                    String row=comp+"\n"+(h==null?"Хозяева":h.optString("name"))+"  "+(hs==null?"–":hs.optString("current","–"))+" : "+(as==null?"–":as.optString("current","–"))+"  "+(a==null?"Гости":a.optString("name"))+"\n"+(st==null?"":st.optString("description"))+"\nИсточник: "+("khl_webcaster".equals(e.optString("source"))?"KHL Webcaster":e.optString("source").equals("espn")?"ESPN":"NHL API");
                    TextView card=label(row,15,Color.WHITE,true);card.setPadding(dp(14),dp(14),dp(14),dp(14));card.setBackground(shape(PANEL,14));
                    card.setOnClickListener(v->showHockeyMatchDetails(e));cards.addView(card,lp(0,8));
                }
            });
        });
    }

    private void showHockeyPublicNhlDetails(JSONObject event) {
        long id=event.optLong("id",-1);
        ScrollView scroll=new ScrollView(this);LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16),dp(16),dp(16),dp(24));root.setBackgroundColor(BG);scroll.addView(root);setContentView(scroll);
        Button back=button("←  К МАТЧАМ");root.addView(back,lp(0,12));back.setOnClickListener(v->buildHockeyUi());
        JSONObject h=event.optJSONObject("homeTeam"),a=event.optJSONObject("awayTeam");
        String providerLabel="espn".equals(event.optString("source",""))?"ESPN public API":"NHL public API";
        LinearLayout panel=hockeyPanel(root,"🏒 "+(h==null?"":h.optString("name"))+" — "+(a==null?"":a.optString("name")),"Источник: "+providerLabel+" · без ключа");
        TextView loading=label("Загружаю boxscore и игровые события…",13,MUTED,false);panel.addView(loading,lp(0,8));
        worker.execute(()->{
            JSONObject box=null,pbp=null;String error="";
            boolean espn="espn".equals(event.optString("source",""));
            try{
                if(espn) box=hockeyPublicGet("https://site.api.espn.com/apis/site/v2/sports/hockey/nhl/summary?event="+id);
                else box=hockeyPublicGet("https://api-web.nhle.com/v1/gamecenter/"+id+"/boxscore");
            }catch(Exception ex){error=ex.getMessage();}
            if(!espn)try{pbp=hockeyPublicGet("https://api-web.nhle.com/v1/gamecenter/"+id+"/play-by-play");}catch(Exception ex){if(error.isEmpty())error=ex.getMessage();}
            else if(box!=null)pbp=box.optJSONObject("plays");
            final JSONObject fb=box,fp=pbp;final String fe=error;
            ui.post(()->{
                panel.removeView(loading);
                if(fb!=null){
                    LinearLayout stats=hockeyPanel(root,"📊 ОФИЦИАЛЬНЫЙ BOXSCORE","Данные NHL; доступные поля показываются без выдумывания значений");
                    List<String> lines=new ArrayList<>();hockeyFlatten(fb,"",lines);int shown=0;
                    for(String line:lines){String low=line.toLowerCase(Locale.ROOT);
                        if(low.contains("shots")||low.contains("save")||low.contains("powerplay")||low.contains("penalt")||low.contains("goals")||low.contains("score")){
                            stats.addView(label("• "+line,12,Color.WHITE,false),lp(0,3));if(++shown>=45)break;
                        }
                    }
                    if(shown==0)stats.addView(label("Boxscore получен, но формат статистики требует отдельного разбора.",12,MUTED,false),lp(0,3));
                }
                if(fp!=null){
                    LinearLayout plays=hockeyPanel(root,"⏱ ИГРОВЫЕ СОБЫТИЯ","Play-by-play NHL");
                    JSONArray arr=fp.optJSONArray("plays");int shown=0;
                    if(arr!=null)for(int i=Math.max(0,arr.length()-25);i<arr.length();i++){
                        JSONObject play=arr.optJSONObject(i);if(play==null)continue;
                        String type=play.optString("typeDescKey","");JSONObject details=play.optJSONObject("details");
                        plays.addView(label("• "+play.optString("periodDescriptor","")+" "+play.optString("timeInPeriod","")+" · "+type+(details==null?"":" · "+details.toString()),11,Color.WHITE,false),lp(0,3));shown++;
                    }
                    if(shown==0)plays.addView(label("Нет доступных игровых событий.",12,MUTED,false),lp(0,3));
                }
                if(!fe.isEmpty())root.addView(label("Часть статистики не загрузилась: "+fe,12,MUTED,false),lp(0,8));
                root.addView(label("ℹ️ Бесплатные NHL/ESPN feeds не покрывают КХЛ/ВХЛ и не гарантируют одинаковый набор статистики для всех матчей.",12,MUTED,false),lp(0,8));
            });
        });
    }

    private void loadHockey(boolean liveOnly) {
        if (!hockeyMode || cards == null || status == null) return;
        hockeyLastLiveOnly = liveOnly;
        final String filter = hockeyLeagueFilter;
        final String date = today();
        status.setText("Подключаю хоккейный источник SportsAPI Pro…"); cards.removeAllViews();
        final String token = appPrefs.getString("sportsapi_token", "").trim();
        if (token.isEmpty()) {
            loadHockeyFreeSources(liveOnly, filter, date, "ключ не задан");
            return;
        }
        worker.execute(() -> {
            try {
                String path = liveOnly ? "/api/live" : "/api/schedule/" + URLEncoder.encode(date, "UTF-8");
                JSONObject json = hockeyRequest(path, token);
                JSONArray events = json.optJSONArray("events");
                if (events == null && json.optJSONObject("data") != null) events = json.optJSONObject("data").optJSONArray("events");
                if (events == null && json.optJSONArray("data") != null) events = json.optJSONArray("data");
                if (events == null) throw new IOException("Источник ответил, но формат списка матчей отличается.");
                int sourceCount = events.length();
                List<JSONObject> result = new ArrayList<>();
                for (int i=0;i<events.length();i++) {
                    JSONObject e = events.optJSONObject(i); if (e == null) continue;
                    String competition = hockeyCompetitionName(e);
                    if (competition.isEmpty()) competition = "Турнир не указан";
                    if (!hockeyLeagueMatches(filter, competition)) continue;
                    result.add(e);
                }
                final List<JSONObject> matches = result;
                ui.post(() -> {
                    status.setText("SportsAPI Pro · получено: " + sourceCount + " · по фильтру: " + matches.size());
                    if (matches.isEmpty()) {
                        String hint = sourceCount == 0
                            ? "Сейчас API не вернул матчи в этом режиме. Попробуй расписание."
                            : "API вернул " + sourceCount + " матч(ей), но выбранная лига не совпала. Выбери «Все хоккейные лиги».";
                        cards.addView(label(hint, 14, Color.WHITE, false), lp(8, 8));
                    }
                    for (JSONObject e : matches) {
                        String competition = hockeyCompetitionName(e);
                        if (competition.isEmpty()) competition = "Хоккей";
                        JSONObject home = e.optJSONObject("homeTeam"), away = e.optJSONObject("awayTeam");
                        String hn = home == null ? "Хозяева" : home.optString("name", "Хозяева");
                        String an = away == null ? "Гости" : away.optString("name", "Гости");
                        JSONObject hs = e.optJSONObject("homeScore"), as = e.optJSONObject("awayScore");
                        String hscore = hs == null ? "–" : hs.has("current") ? String.valueOf(hs.opt("current")) : "–";
                        String ascore = as == null ? "–" : as.has("current") ? String.valueOf(as.opt("current")) : "–";
                        JSONObject st = e.optJSONObject("status");
                        String state = st == null ? "" : st.optString("description", "");
                        long id = e.optLong("id", -1);
                        String row = competition + "\n" + hn + "  " + hscore + " : " + ascore + "  " + an
                                + "\n" + state + (id >= 0 ? "  · ID " + id : "")
                                + "\nНажми, чтобы открыть статистику и анализ";
                        TextView card = label(row, 15, Color.WHITE, true);
                        card.setPadding(dp(14),dp(14),dp(14),dp(14));
                        card.setBackground(shape(PANEL, 14));
                        card.setOnClickListener(v -> showHockeyMatchDetails(e));
                        cards.addView(card, lp(0, 8));
                    }
                });
            } catch (Exception ex) {
                String msg = ex.getMessage() == null ? ex.toString() : ex.getMessage();
                // Any primary-provider failure (429, timeout, server error, invalid token)
                // activates the keyless league adapters instead of stopping the screen.
                loadHockeyFreeSources(liveOnly, filter, date, msg);
            }
        });
    }

    private void openDatePicker() {
        Calendar c = Calendar.getInstance();
        try { c.setTime(new SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(chosenDate)); } catch (Exception ignored) {}
        DatePickerDialog dlg = new DatePickerDialog(this, (picker, y, m, d) -> {
            Calendar picked = Calendar.getInstance(); picked.set(y, m, d);
            chosenDate = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(picked.getTime());
            dateWasChosen = true; mode = "custom"; selectedDateText.setText(tr("date") + chosenDate); loadFixtures();
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH));
        dlg.show();
    }

    private String fetchWithFallback(String path) throws Exception {
        Exception last = null;
        for (String base : new String[]{RAW, CDN}) {
            HttpURLConnection conn = null;
            try {
                URL url = new URL(base + path);
                conn = (HttpURLConnection) url.openConnection();
                conn.setConnectTimeout(12000); conn.setReadTimeout(18000);
                conn.setRequestProperty("User-Agent", "FootballAnalyzer3/3.0");
                conn.setRequestProperty("Accept", "text/csv,*/*");
                int code = conn.getResponseCode();
                InputStream in = (code >= 200 && code < 300) ? conn.getInputStream() : conn.getErrorStream();
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                if (in != null) { try (InputStream stream = in) { byte[] buf = new byte[8192]; int n; while ((n = stream.read(buf)) != -1) out.write(buf, 0, n); } }
                String body = out.toString("UTF-8");
                if (code == 404) throw new FileNotFoundException("Для этого турнира файл пока не опубликован: " + path);
                if (code < 200 || code >= 300) throw new IOException("HTTP " + code + " при загрузке CSV");
                if (body.trim().isEmpty()) throw new IOException("Источник вернул пустой CSV: " + path);
                return body;
            } catch (Exception e) { last = e; }
            finally { if (conn != null) conn.disconnect(); }
        }
        throw last == null ? new IOException("Не удалось подключиться к open-matchday") : last;
    }

    private List<String[]> parseCsv(String csv) throws IOException {
        List<String[]> rows = new ArrayList<>();
        BufferedReader reader = new BufferedReader(new StringReader(csv));
        String line;
        while ((line = reader.readLine()) != null) {
            if (line.trim().isEmpty()) continue;
            ArrayList<String> cells = new ArrayList<>(); StringBuilder cell = new StringBuilder(); boolean quoted = false;
            for (int i = 0; i < line.length(); i++) {
                char ch = line.charAt(i);
                if (ch == '"') {
                    if (quoted && i + 1 < line.length() && line.charAt(i + 1) == '"') { cell.append('"'); i++; }
                    else quoted = !quoted;
                } else if (ch == ',' && !quoted) { cells.add(cell.toString()); cell.setLength(0); }
                else cell.append(ch);
            }
            cells.add(cell.toString()); rows.add(cells.toArray(new String[0]));
        }
        return rows;
    }

    private Map<String, Integer> headerIndex(String[] header) {
        Map<String, Integer> map = new HashMap<>();
        for (int i = 0; i < header.length; i++) map.put(header[i].trim().toLowerCase(Locale.US), i);
        return map;
    }
    private String val(String[] row, Map<String, Integer> ix, String key) {
        Integer i = ix.get(key.toLowerCase(Locale.US)); return i == null || i < 0 || i >= row.length ? "" : row[i].trim();
    }
    private Double number(String[] row, Map<String, Integer> ix, String key) {
        try { String s = val(row, ix, key); return s.isEmpty() ? null : Double.parseDouble(s); } catch (Exception e) { return null; }
    }

    private static class MatchGroup {
        League league; List<String[]> found; List<String[]> results; Map<String,Integer> ix; int fixtureCount, resultCount;
        MatchGroup(League l, List<String[]> f, List<String[]> r, Map<String,Integer> i, int fc, int rc) { league=l; found=f; results=r; ix=i; fixtureCount=fc; resultCount=rc; }
    }

    private String fetchQuickFixtures(String path) throws Exception {
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL(RAW + path).openConnection();
            conn.setConnectTimeout(3500); conn.setReadTimeout(4500);
            conn.setRequestProperty("User-Agent", "FootballAnalyzer/4.1.3");
            conn.setRequestProperty("Accept", "text/csv,*/*");
            int code=conn.getResponseCode();
            if(code<200 || code>=300) throw new IOException("HTTP " + code);
            try(InputStream in=conn.getInputStream(); ByteArrayOutputStream out=new ByteArrayOutputStream()) {
                byte[] b=new byte[8192]; int n; while((n=in.read(b))!=-1) out.write(b,0,n);
                return out.toString("UTF-8");
            }
        } finally { if(conn!=null) conn.disconnect(); }
    }

    private MatchGroup loadOneLeagueToday(League league, String target) throws Exception {
        List<String[]> fixtures=parseCsv(fetchQuickFixtures(league.folder + "/fixtures_" + SEASON + ".csv"));
        if(fixtures.isEmpty()) return null;
        Map<String,Integer> ix=headerIndex(fixtures.get(0));
        if(!ix.containsKey("date") || !ix.containsKey("home") || !ix.containsKey("away")) return null;
        List<String[]> found=new ArrayList<>();
        for(int i=1;i<fixtures.size();i++) { String[] row=fixtures.get(i); if(val(row,ix,"date").equals(target)) found.add(row); }
        if(found.isEmpty()) return null;
        found.sort((a,b)->val(a,ix,"date").concat(val(a,ix,"time")).compareTo(val(b,ix,"date").concat(val(b,ix,"time"))));
        return new MatchGroup(league,found,new ArrayList<>(),ix,fixtures.size()-1,0);
    }

    private void loadAllToday() {
        final String target = mode.equals("custom") ? chosenDate : mode.equals("tomorrow") ? tomorrow() : today();
        status.setText("Загружаю матчи всех турниров на " + target + "…"); cards.removeAllViews();
        worker.execute(() -> {
            ExecutorService pool=Executors.newFixedThreadPool(8);
            CompletionService<MatchGroup> completion=new ExecutorCompletionService<>(pool);
            for(League l:leagues) completion.submit(() -> loadOneLeagueToday(l,target));
            List<MatchGroup> groups=new ArrayList<>();
            try {
                for(int i=0;i<leagues.length;i++) {
                    Future<MatchGroup> f=completion.poll(25,TimeUnit.SECONDS);
                    if(f==null) break;
                    try { MatchGroup g=f.get(); if(g!=null && !g.found.isEmpty()) groups.add(g); }
                    catch(Exception ignored) { }
                }
            } catch(InterruptedException interrupted) { Thread.currentThread().interrupt(); }
            finally { pool.shutdownNow(); }
            groups.sort((a,b)->a.league.title.compareToIgnoreCase(b.league.title));
            int total=0; for(MatchGroup g:groups) total+=g.found.size();
            final int count=total; final List<MatchGroup> ready=groups;
            ui.post(() -> {
                status.setText(target + " · найдено матчей: " + count + " · турниров: " + ready.size());
                if(ready.isEmpty()) { cards.addView(label("На " + target + " в доступных опубликованных расписаниях матчей не найдено.",15,Color.WHITE,true),lp(8,8)); return; }
                for(MatchGroup g:ready) {
                    TextView heading=label(g.league.title,16,GREEN,true); cards.addView(heading,lp(10,5));
                    for(String[] row:g.found) addMatchCard(g.league,row,g.ix,g.results);
                }
            });
        });
    }

    private void loadFixtures() {
        if (status == null || cards == null) return;
        if(selectedLeague==0) { loadAllToday(); return; }
        final League league = leagues[selectedLeague-1]; final String selectedMode = mode; final String date = chosenDate;
        status.setText("Загружаю CSV: " + league.title + "…"); cards.removeAllViews();
        worker.execute(() -> {
            try {
                String folder = league.folder + "/";
                List<String[]> fixtures = parseCsv(fetchWithFallback(folder + "fixtures_" + SEASON + ".csv"));
                List<String[]> results;
                try { results = parseCsv(fetchWithFallback(folder + "results_" + SEASON + ".csv")); }
                catch (Exception unavailable) { results = new ArrayList<>(); }
                if (fixtures.isEmpty()) throw new IOException("CSV расписания не содержит заголовка и матчей.");
                Map<String, Integer> fixIx = headerIndex(fixtures.get(0));
                if (!fixIx.containsKey("date") || !fixIx.containsKey("home") || !fixIx.containsKey("away")) throw new IOException("Неожиданный формат CSV расписания.");
                String target = date;
                if (selectedMode.equals("today")) target = today();
                else if (selectedMode.equals("tomorrow")) target = tomorrow();
                final String filterDate = target;
                List<String[]> found = new ArrayList<>();
                for (int i = 1; i < fixtures.size(); i++) {
                    String[] row = fixtures.get(i); String rowDate = val(row, fixIx, "date");
                    if (rowDate.equals(filterDate)) found.add(row);
                }
                found.sort((a,b) -> (val(a,fixIx,"date") + val(a,fixIx,"time")).compareTo(val(b,fixIx,"date") + val(b,fixIx,"time")));
                List<String[]> finalResults = results; int fixtureCount = fixtures.size() - 1; int resultCount = Math.max(0, results.size() - 1);
                ui.post(() -> renderMatches(league, found, finalResults, fixIx, filterDate, selectedMode, fixtureCount, resultCount));
            } catch (Exception e) {
                String message = e.getMessage() == null ? e.toString() : e.getMessage();
                ui.post(() -> { status.setText("Ошибка open-matchday: " + message); cards.removeAllViews(); });
            }
        });
    }

    private void renderMatches(League league, List<String[]> found, List<String[]> results, Map<String,Integer> fixIx,
                               String date, String selectedMode, int fixtureCount, int resultCount) {
        status.setText("open-matchday · расписание: " + fixtureCount + " · сыграно: " + resultCount + " · найдено: " + found.size());
        if (found.isEmpty()) {
            String msg = selectedMode.equals("all") ? "В опубликованном файле расписания пока нет будущих матчей." : "На " + date + " матчей в опубликованном расписании этого турнира нет. Это не ошибка API.";
            cards.addView(label(msg, 15, Color.WHITE, true), lp(8, 8));
            return;
        }
        for (String[] row : found) addMatchCard(league, row, fixIx, results);
    }

    // Дополнительный источник статистики: публичный ESPN Site API (без ключа).
    // Используется только как резерв, когда поле отсутствует в open-matchday.
    private String espnLeague(League league) {
        String f = league.folder;
        if (f.equals("UEFA_1_champions-league")) return "uefa.champions";
        if (f.equals("UEFA_1_europa-league")) return "uefa.europa";
        if (f.equals("UEFA_1_conference-league")) return "uefa.europa.conf";
        if (f.startsWith("ENG_1_")) return "eng.1";
        if (f.startsWith("ENG_2_")) return "eng.2";
        if (f.startsWith("ENG_3_")) return "eng.3";
        if (f.startsWith("ENG_4_")) return "eng.4";
        if (f.startsWith("ESP_1_")) return "esp.1";
        if (f.startsWith("ESP_2_")) return "esp.2";
        if (f.startsWith("GER_1_")) return "ger.1";
        if (f.startsWith("ITA_1_")) return "ita.1";
        if (f.startsWith("ITA_2_")) return "ita.2";
        if (f.startsWith("FRA_1_")) return "fra.1";
        if (f.startsWith("FRA_2_")) return "fra.2";
        if (f.startsWith("NED_1_")) return "ned.1";
        if (f.startsWith("POR_1_")) return "por.1";
        if (f.startsWith("BEL_1_")) return "bel.1";
        if (f.startsWith("TUR_1_")) return "tur.1";
        if (f.startsWith("GRE_1_")) return "gre.1";
        if (f.startsWith("SCO_1_")) return "sco.1";
        if (f.startsWith("POL_1_")) return "pol.1";
        if (f.startsWith("NOR_1_")) return "nor.1";
        if (f.startsWith("AUT_1_")) return "aut.1";
        if (f.startsWith("SUI_1_")) return "sui.1";
        if (f.startsWith("DEN_1_")) return "den.1";
        if (f.startsWith("SWE_1_")) return "swe.1";
        if (f.startsWith("BRA_1_")) return "bra.1";
        if (f.startsWith("USA_1_")) return "usa.1";
        if (f.startsWith("JPN_1_")) return "jpn.1";
        if (f.startsWith("AUS_1_")) return "aus.1";
        return "";
    }

    private JSONObject fetchJson(String urlText) throws Exception {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(urlText).openConnection();
            c.setConnectTimeout(5000); c.setReadTimeout(7000);
            c.setRequestProperty("User-Agent", "Mozilla/5.0 FootballAnalyzer/3.8");
            c.setRequestProperty("Accept", "application/json");
            int code = c.getResponseCode();
            InputStream in = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
            if (in == null) throw new IOException("ESPN HTTP " + code);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            try (InputStream stream = in) { byte[] b = new byte[8192]; int n; while ((n=stream.read(b))!=-1) out.write(b,0,n); }
            if (code < 200 || code >= 300) throw new IOException("ESPN HTTP " + code);
            return new JSONObject(out.toString("UTF-8"));
        } finally { if (c != null) c.disconnect(); }
    }

    private String normTeam(String name) {
        String n = java.text.Normalizer.normalize(name == null ? "" : name, java.text.Normalizer.Form.NFD)
                .replaceAll("\\p{M}+", "").toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", "");
        n = n.replace("fc", "").replace("afc", "").replace("cf", "");
        return n;
    }
    private boolean sameTeam(String a, String b) {
        String x=normTeam(a), y=normTeam(b);
        return !x.isEmpty() && !y.isEmpty() && (x.equals(y) || (x.length()>=3 && y.length()>=3 && (x.contains(y)||y.contains(x))));
    }
    private String statName(JSONObject stat) {
        return (stat.optString("name", "") + " " + stat.optString("displayName", "") + " " + stat.optString("abbreviation", "")).toLowerCase(Locale.ROOT).replaceAll("[^a-z]", "");
    }
    private Double espnStat(JSONArray stats, String wanted) {
        if (stats == null) return null;
        for (int i=0;i<stats.length();i++) {
            JSONObject st=stats.optJSONObject(i); if(st==null) continue;
            String n=statName(st); boolean match=false;
            if (wanted.equals("corners")) match=n.contains("woncorners")||n.equals("corners")||n.contains("cornerkicks");
            else if (wanted.equals("yellow")) match=n.contains("yellowcards")||n.equals("yellowcard");
            else if (wanted.equals("target")) match=n.contains("shotsontarget")||n.contains("shotsongoal");
            else if (wanted.equals("shots")) match=n.equals("totalshots")||n.equals("shots")||n.equals("totalshot");
            else if (wanted.equals("fouls")) match=n.contains("foulscommitted")||n.equals("fouls");
            if (match) {
                String v=st.optString("displayValue", "");
                if(v.isEmpty()) v=st.optString("value", "");
                try { return Double.parseDouble(v.replace(",", "")); } catch(Exception ignored) {}
            }
        }
        return null;
    }
    private Map<String,Double> parseEspnTeamStats(JSONObject teamBox) {
        Map<String,Double> m=new HashMap<>();
        JSONArray stats=teamBox.optJSONArray("statistics");
        for(String key:new String[]{"corners","yellow","target","shots","fouls"}) {
            Double v=espnStat(stats,key); if(v!=null)m.put(key,v);
        }
        return m;
    }
    private String matchKey(String date,String home,String away) { return date+"|"+normTeam(home)+"|"+normTeam(away); }

    private Map<String,Map<String,Double>> loadEspnFallback(League league, String home, String away, List<String[]> rows, Map<String,Integer> ix) {
        Map<String,Map<String,Double>> out=new HashMap<>();
        String slug=espnLeague(league); if(slug.isEmpty()) return out;
        LinkedHashMap<String,String[]> candidates=new LinkedHashMap<>();
        for(String team:new String[]{home,away}) {
            ArrayList<String[]> apps=new ArrayList<>();
            for(int i=1;i<rows.size();i++) { String[] r=rows.get(i); if(team.equalsIgnoreCase(val(r,ix,"home"))||team.equalsIgnoreCase(val(r,ix,"away"))) apps.add(r); }
            apps.sort((a,b)->val(b,ix,"date").compareTo(val(a,ix,"date")));
            int count=0; for(String[] r:apps) { if(count>=10)break; String key=matchKey(val(r,ix,"date"),val(r,ix,"home"),val(r,ix,"away")); candidates.put(key,r); count++; }
        }
        // Один запрос табло на весь интервал последних матчей, затем отдельные summary только для совпавших игр.
        String minDate=null,maxDate=null;
        for(String[] r:candidates.values()) { String d=val(r,ix,"date"); if(d.length()==10) { if(minDate==null||d.compareTo(minDate)<0)minDate=d; if(maxDate==null||d.compareTo(maxDate)>0)maxDate=d; } }
        JSONObject board=null;
        if(minDate!=null) try { board=fetchJson("https://site.api.espn.com/apis/site/v2/sports/soccer/"+slug+"/scoreboard?dates="+minDate.replace("-","")+"-"+maxDate.replace("-","")); } catch(Exception ignored) {}
        for(String[] r:candidates.values()) {
            String date=val(r,ix,"date"), rh=val(r,ix,"home"), ra=val(r,ix,"away");
            if(date.length()!=10 || board==null) continue;
            String key=matchKey(date,rh,ra);
            boolean need=false;
            for(String prefix:new String[]{"home_","away_"}) for(String field:new String[]{"corners","yellow","target","shots","fouls"}) if(number(r,ix,prefix+field)==null) need=true;
            if(!need) continue;
            try {
                JSONArray events=board.optJSONArray("events"); String eventId=null;
                if(events!=null) for(int ei=0;ei<events.length();ei++) {
                    JSONObject ev=events.optJSONObject(ei); if(ev==null)continue;
                    JSONArray comps=ev.optJSONArray("competitions"); if(comps==null||comps.length()==0)continue;
                    JSONArray sides=comps.optJSONObject(0).optJSONArray("competitors"); if(sides==null)continue;
                    String eh="",ea="";
                    for(int si=0;si<sides.length();si++) { JSONObject side=sides.optJSONObject(si); JSONObject t=side==null?null:side.optJSONObject("team"); if(t==null)continue; if("home".equalsIgnoreCase(side.optString("homeAway")))eh=t.optString("displayName",t.optString("name","")); else ea=t.optString("displayName",t.optString("name","")); }
                    if(sameTeam(rh,eh)&&sameTeam(ra,ea)) { eventId=ev.optString("id",null); break; }
                }
                if(eventId==null) continue;
                JSONObject summary=fetchJson("https://site.api.espn.com/apis/site/v2/sports/soccer/"+slug+"/summary?event="+eventId);
                JSONObject box=summary.optJSONObject("boxscore"); JSONArray teams=box==null?null:box.optJSONArray("teams");
                if(teams==null)continue;
                for(int ti=0;ti<teams.length();ti++) {
                    JSONObject tb=teams.optJSONObject(ti); if(tb==null)continue;
                    JSONObject t=tb.optJSONObject("team"); String tn=t==null?"":t.optString("displayName",t.optString("name",""));
                    String side=sameTeam(rh,tn)?"home":sameTeam(ra,tn)?"away":""; if(side.isEmpty())continue;
                    Map<String,Double> vals=parseEspnTeamStats(tb); if(!vals.isEmpty()) out.put(key+"|"+side,vals);
                }
            } catch(Exception ignored) { /* резервный источник может не покрывать турнир/матч */ }
        }
        return out;
    }

    private static class TeamStats {
        int played, wins, draws, losses;
        double goalsFor, goalsAgainst;
        final Map<String, ArrayList<Double>> metrics = new HashMap<>();
        void addMetric(String key, Double value) {
            if (value == null) return;
            if (!metrics.containsKey(key)) metrics.put(key, new ArrayList<>());
            metrics.get(key).add(value);
        }
        ArrayList<Double> values(String key) { return metrics.get(key); }
        double metricSum(String key) { ArrayList<Double> v=values(key); if(v==null)return 0; double s=0; for(double x:v)s+=x; return s; }
        double metricAvg(String key) { ArrayList<Double> v=values(key); return v==null||v.isEmpty()?Double.NaN:metricSum(key)/v.size(); }
        double avgGoalsFor() { return played == 0 ? 0 : goalsFor / played; }
        double avgGoalsAgainst() { return played == 0 ? 0 : goalsAgainst / played; }
        String form() { return "В-Н-П: " + wins + "-" + draws + "-" + losses; }
    }

    private void addMatchCard(League league, String[] match, Map<String,Integer> fixIx, List<String[]> resultRows) {
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(14),dp(13),dp(14),dp(13)); box.setBackground(shape(PANEL,15)); cards.addView(box,lp(0,10));
        String date = val(match,fixIx,"date"), time = val(match,fixIx,"time"), home = val(match,fixIx,"home"), away = val(match,fixIx,"away"), round = val(match,fixIx,"gw");
        box.addView(label(date + (time.isEmpty()?"":" · "+time) + (round.isEmpty()?"":" · тур "+round),12,MUTED,true));
        box.addView(label(home + " — " + away,20,Color.WHITE,true),lp(5,8));
        TextView report = label("Нажми кнопку ниже: покажу итоги последних матчей, средние показатели и прогнозы тоталов.",14,0xffe1eee6,false); report.setLineSpacing(dp(3),1.0f); box.addView(report,lp(5,8));
        final String[] cachedReport = {""};
        Button analyze = button("📊 ПОЛНЫЙ АНАЛИЗ И ПРОГНОЗ"); box.addView(analyze);
        analyze.setOnClickListener(v -> {
            analyze.setEnabled(false); report.setText("Собираю статистику последних " + analysisMatchCount + " матчей…");
            worker.execute(() -> {
                String text = makeReport(league, home, away, resultRows);
                ui.post(() -> { cachedReport[0] = text; report.setText(text); analyze.setEnabled(true); });
            });
        });
        Button save = button("💾 СОХРАНИТЬ АНАЛИЗ В ИСТОРИЮ"); box.addView(save,lp(7,0));
        save.setOnClickListener(v -> {
            String saved = date + " · " + league.title + "\n" + home + " — " + away + (cachedReport[0].isEmpty() ? "\nАнализ ещё не рассчитан" : "\n" + cachedReport[0]);
            saveHistory(saved); Toast.makeText(this,"Матч и анализ сохранены",Toast.LENGTH_SHORT).show();
        });
    }

    // Загружает историю команды не только из выбранного турнира, но и из остальных
    // опубликованных турниров open-matchday. Матчи без итогового счёта отбрасываются.
    private List<String[]> collectHistoryAcrossCompetitions(League currentLeague, String home, String away, List<String[]> currentRows) {
        if (currentRows == null || currentRows.isEmpty()) return currentRows;
        final String[] header = currentRows.get(0);
        final Map<String,Integer> targetIx = headerIndex(header);
        final LinkedHashMap<String,String[]> unique = new LinkedHashMap<>();
        for (int i=1;i<currentRows.size();i++) {
            String[] r=currentRows.get(i);
            if (sameTeam(val(r,targetIx,"home"),home) || sameTeam(val(r,targetIx,"away"),home) ||
                sameTeam(val(r,targetIx,"home"),away) || sameTeam(val(r,targetIx,"away"),away)) {
                unique.put(matchKey(val(r,targetIx,"date"),val(r,targetIx,"home"),val(r,targetIx,"away")),r);
            }
        }
        ExecutorService pool=Executors.newFixedThreadPool(6);
        ArrayList<Future<List<String[]>>> jobs=new ArrayList<>();
        for (League league : leagues) {
            if (currentLeague != null && league.folder.equals(currentLeague.folder)) continue;
            jobs.add(pool.submit(() -> {
                try {
                    List<String[]> csv=parseCsv(fetchQuickFixtures(league.folder + "/results_" + SEASON + ".csv"));
                    if(csv.size()<2) return Collections.emptyList();
                    Map<String,Integer> sourceIx=headerIndex(csv.get(0));
                    if(!sourceIx.containsKey("date") || !sourceIx.containsKey("home") || !sourceIx.containsKey("away") ||
                       !sourceIx.containsKey("ft_home") || !sourceIx.containsKey("ft_away")) return Collections.emptyList();
                    ArrayList<String[]> matched=new ArrayList<>();
                    for(int i=1;i<csv.size();i++) {
                        String[] r=csv.get(i);
                        boolean relevant=sameTeam(val(r,sourceIx,"home"),home) || sameTeam(val(r,sourceIx,"away"),home) ||
                                        sameTeam(val(r,sourceIx,"home"),away) || sameTeam(val(r,sourceIx,"away"),away);
                        if(!relevant || number(r,sourceIx,"ft_home")==null || number(r,sourceIx,"ft_away")==null) continue;
                        String[] mapped=new String[header.length];
                        for(int c=0;c<header.length;c++) mapped[c]=val(r,sourceIx,header[c].trim().toLowerCase(Locale.US));
                        matched.add(mapped);
                    }
                    return matched;
                } catch(Exception ignored) { return Collections.emptyList(); }
            }));
        }
        long deadline=System.currentTimeMillis()+15000;
        for(Future<List<String[]>> job:jobs) {
            try {
                long left=deadline-System.currentTimeMillis(); if(left<=0) { job.cancel(true); continue; }
                for(String[] r:job.get(left,TimeUnit.MILLISECONDS)) {
                    String key=matchKey(val(r,targetIx,"date"),val(r,targetIx,"home"),val(r,targetIx,"away"));
                    unique.put(key,r);
                }
            } catch(Exception ignored) { job.cancel(true); }
        }
        pool.shutdownNow();
        ArrayList<String[]> merged=new ArrayList<>(); merged.add(header);
        merged.addAll(unique.values());
        merged.subList(1,merged.size()).sort((a,b)->val(b,targetIx,"date").compareTo(val(a,targetIx,"date")));
        return merged;
    }

    private TeamStats collectTeam(String team, List<String[]> rows, Map<String,Integer> ix, Map<String,Map<String,Double>> supplemental) {
        ArrayList<String[]> appearances = new ArrayList<>();
        for (int i=1; i<rows.size(); i++) {
            String[] r=rows.get(i);
            if (sameTeam(val(r,ix,"home"),team) || sameTeam(val(r,ix,"away"),team)) appearances.add(r);
        }
        appearances.sort((a,b) -> val(b,ix,"date").compareTo(val(a,ix,"date")));
        TeamStats st = new TeamStats();
        for (String[] r : appearances) {
            if (st.played >= analysisMatchCount) break;
            boolean atHome = sameTeam(team, val(r,ix,"home"));
            Double gf=number(r,ix,atHome?"ft_home":"ft_away");
            Double ga=number(r,ix,atHome?"ft_away":"ft_home");
            if (gf==null || ga==null) continue;
            st.played++; st.goalsFor+=gf; st.goalsAgainst+=ga;
            if (gf>ga) st.wins++; else if (gf.equals(ga)) st.draws++; else st.losses++;
            String side = atHome ? "home" : "away";
            String key = matchKey(val(r,ix,"date"),val(r,ix,"home"),val(r,ix,"away")) + "|" + side;
            Map<String,Double> extra = supplemental == null ? null : supplemental.get(key);
            for (String metric : new String[]{"corners","yellow","target","shots","fouls"}) {
                Double value = number(r,ix,side+"_"+metric);
                if (value == null && extra != null) value = extra.get(metric);
                st.addMetric(metric,value);
            }
        }
        return st;
    }

    private String oneDecimal(double v) { return String.format(Locale.US,"%.1f",v); }
    private String metricTeamLine(String team, TeamStats st, String key) {
        ArrayList<Double> vals=st.values(key);
        if(vals==null||vals.isEmpty()) return "   " + team + ": нет опубликованных данных";
        return "   " + team + ": всего " + oneDecimal(st.metricSum(key)) + " · в среднем " + oneDecimal(st.metricAvg(key)) + " за матч (данные по " + vals.size() + " матчам)";
    }
    private String metricSection(String emoji, String title, String key, TeamStats h, TeamStats a, String home, String away) {
        return emoji + " " + title + "\n" + metricTeamLine(home,h,key) + "\n" + metricTeamLine(away,a,key) + "\n";
    }
    private String market(String title, double lambda, int line, String unit) {
        if (Double.isNaN(lambda) || lambda <= 0) return "   " + title + ": недостаточно статистики\n";
        double under=poissonCdf((int)Math.floor(line+0.5),lambda);
        return "   " + title + " — линия " + line + ".5 " + unit + "\n" +
               "      🔼 Больше: " + pct(1-under) + "   🔽 Меньше: " + pct(under) + "\n";
    }
    private double combinedAvg(TeamStats h, TeamStats a, String key) {
        if(h.values(key)==null||a.values(key)==null||h.values(key).size()<3||a.values(key).size()<3) return Double.NaN;
        return h.metricAvg(key)+a.metricAvg(key);
    }
    private String makeReport(League league, String home, String away, List<String[]> rows) {
        if (rows == null || rows.size() < 2) return "⚠️ АНАЛИЗ НЕВОЗМОЖЕН\nНет опубликованных сыгранных матчей этой лиги.";
        Map<String,Integer> ix = headerIndex(rows.get(0));
        List<String[]> historyRows = collectHistoryAcrossCompetitions(league,home,away,rows);
        Map<String,Map<String,Double>> supplemental = loadEspnFallback(league,home,away,rows,ix);
        TeamStats h=collectTeam(home,historyRows,ix,supplemental), a=collectTeam(away,historyRows,ix,supplemental);
        StringBuilder out = new StringBuilder();
        out.append("━━━━━━━━━━━━━━━━━━\n⚽ АНАЛИЗ МАТЧА\n").append(home).append(" — ").append(away).append("\n━━━━━━━━━━━━━━━━━━\n\n");
        out.append("📈 1. ГОЛЫ И ФОРМА КОМАНД\n");
        out.append("🏠 ").append(home).append("\n");
        out.append("   Сыграно матчей: ").append(h.played).append(" из ").append(analysisMatchCount).append("\n");
        out.append("   Забито: ").append(oneDecimal(h.goalsFor)).append(" всего · ").append(oneDecimal(h.avgGoalsFor())).append(" за матч\n");
        out.append("   Пропущено: ").append(oneDecimal(h.goalsAgainst)).append(" всего · ").append(oneDecimal(h.avgGoalsAgainst())).append(" за матч\n");
        out.append("   Результаты: ").append(h.form()).append("\n\n");
        out.append("✈️ ").append(away).append("\n");
        out.append("   Сыграно матчей: ").append(a.played).append(" из ").append(analysisMatchCount).append("\n");
        out.append("   Забито: ").append(oneDecimal(a.goalsFor)).append(" всего · ").append(oneDecimal(a.avgGoalsFor())).append(" за матч\n");
        out.append("   Пропущено: ").append(oneDecimal(a.goalsAgainst)).append(" всего · ").append(oneDecimal(a.avgGoalsAgainst())).append(" за матч\n");
        out.append("   Результаты: ").append(a.form()).append("\n\n");
        out.append("📊 2. ДЕТАЛЬНАЯ СТАТИСТИКА ПО КОМАНДАМ\n");
        out.append(metricSection("🚩","Угловые","corners",h,a,home,away)).append("\n");
        out.append(metricSection("🟨","Жёлтые карточки","yellow",h,a,home,away)).append("\n");
        out.append(metricSection("🎯","Удары в створ","target",h,a,home,away)).append("\n");
        out.append(metricSection("🥅","Все удары по воротам","shots",h,a,home,away)).append("\n");
        out.append(metricSection("🤼","Фолы","fouls",h,a,home,away)).append("\n");
        out.append("↗️ Вбрасывания из аута\n   Источник open-matchday не публикует эту статистику — цифры не подставляются.\n\n");
        out.append("🔮 3. ПРОГНОЗЫ ТОТАЛОВ НА МАТЧ\n");
        if(h.played<3||a.played<3) {
            out.append("⚠️ Для надёжного расчёта пока мало матчей: нужно минимум 3 сыгранных матча каждой команды.\n");
        } else {
            double expH=Math.max(0.1,Math.min(4.5,(h.avgGoalsFor()+a.avgGoalsAgainst())/2.0));
            double expA=Math.max(0.1,Math.min(4.5,(a.avgGoalsFor()+h.avgGoalsAgainst())/2.0));
            double[] probs=poissonOutcome(expH,expA);
            out.append("⚽ ГОЛЫ · ожидаемый счёт: ").append(home).append(" ").append(fmt(expH)).append(" : ").append(fmt(expA)).append(" ").append(away).append("\n");
            out.append("   1X2: ").append(home).append(" ").append(pct(probs[0])).append(" · ничья ").append(pct(probs[1])).append(" · ").append(away).append(" ").append(pct(probs[2])).append("\n");
            out.append(market("Тотал голов",expH+expA,2,"голов"));
            out.append(market("Тотал голов",expH+expA,3,"голов"));
            out.append("\n🚩 УГЛОВЫЕ\n").append(market("Тотал угловых",combinedAvg(h,a,"corners"),8,"угловых"));
            out.append(market("Тотал угловых",combinedAvg(h,a,"corners"),9,"угловых"));
            out.append("\n🟨 ЖЁЛТЫЕ КАРТОЧКИ\n").append(market("Тотал карточек",combinedAvg(h,a,"yellow"),3,"карточек"));
            out.append(market("Тотал карточек",combinedAvg(h,a,"yellow"),4,"карточек"));
            out.append("\n🤼 ФОЛЫ\n").append(market("Тотал фолов",combinedAvg(h,a,"fouls"),21,"фолов"));
            out.append(market("Тотал фолов",combinedAvg(h,a,"fouls"),23,"фолов"));
            out.append("\n🎯 УДАРЫ В СТВОР\n").append(market("Тотал ударов в створ",combinedAvg(h,a,"target"),7,"ударов"));
            out.append(market("Тотал ударов в створ",combinedAvg(h,a,"target"),8,"ударов"));
            out.append("\n🥅 ВСЕ УДАРЫ\n").append(market("Тотал всех ударов",combinedAvg(h,a,"shots"),21,"ударов"));
            out.append(market("Тотал всех ударов",combinedAvg(h,a,"shots"),23,"ударов"));
        }
        out.append("\n━━━━━━━━━━━━━━━━━━\nℹ️ КАК ЧИТАТЬ ПРОГНОЗ\n🔼 Больше — вероятность превышения указанной линии. 🔽 Меньше — вероятность остаться ниже неё. Это математическая оценка по средним показателям последних матчей, не гарантия и не букмекерские коэффициенты.\n");
        out.append("Сначала используются данные open-matchday; если отдельные показатели отсутствуют, приложение пытается найти их в публичном ESPN API без ключа. Если ESPN не покрывает матч или турнир, статистика остаётся пустой. Угловые, карточки, удары и фолы доступны не для всех матчей. Вбрасывания из аута в этом источнике отсутствуют.\n");
        out.append("Выборка: ").append(h.played).append(" матчей — ").append(home).append("; ").append(a.played).append(" — ").append(away).append(". История ищется во всех доступных турнирах open-matchday; результаты обновляются примерно раз в сутки; резервная статистика ESPN может обновляться чаще. Источники: open-matchday и ESPN.");
        return out.toString();
    }

    private double[] poissonOutcome(double lh,double la) {
        double home=0,draw=0,away=0;
        for(int i=0;i<=12;i++) for(int j=0;j<=12;j++) {
            double p=poisson(i,lh)*poisson(j,la);
            if(i>j) home+=p; else if(i==j) draw+=p; else away+=p;
        }
        double sum=home+draw+away; return new double[]{home/sum,draw/sum,away/sum};
    }
    private double poisson(int k,double lambda) { return Math.exp(-lambda)*Math.pow(lambda,k)/factorial(k); }
    private double factorial(int n) { double x=1; for(int i=2;i<=n;i++)x*=i; return x; }
    private double poissonCdf(int max,double lambda) { double p=0; for(int i=0;i<=max;i++)p+=poisson(i,lambda); return Math.max(0,Math.min(1,p)); }
    private String pct(double v) { return String.format(Locale.US,"%.0f%%",v*100); }
    private String fmt(double v) { return String.format(Locale.US,"%.2f",v); }
    private String avg(List<Double> a) { if(a==null||a.isEmpty())return "нет данных"; double s=0; for(double v:a)s+=v; return String.format(Locale.US,"%.1f",s/a.size()); }

    private void saveHistory(String item) {
        SharedPreferences p = getSharedPreferences("football_history", MODE_PRIVATE);
        try { JSONArray arr = new JSONArray(p.getString("items","[]")); arr.put(0,item); while(arr.length()>100) arr.remove(arr.length()-1); p.edit().putString("items",arr.toString()).apply(); }
        catch(Exception e) { p.edit().putString("items",new JSONArray().put(item).toString()).apply(); }
    }
    private void showHistory() {
        SharedPreferences p = getSharedPreferences("football_history", MODE_PRIVATE);
        try {
            JSONArray arr = new JSONArray(p.getString("items","[]"));
            if(arr.length()==0) { new AlertDialog.Builder(this).setTitle("История").setMessage("Пока нет сохранённых матчей.").setPositiveButton("OK",null).show(); return; }
            String[] items = new String[arr.length()]; for(int i=0;i<arr.length();i++) items[i]=arr.optString(i);
            new AlertDialog.Builder(this).setTitle("Сохранённые матчи").setItems(items,null).setPositiveButton("Закрыть",null).setNeutralButton("Очистить",(d,w)->p.edit().remove("items").apply()).show();
        } catch(Exception e) { new AlertDialog.Builder(this).setTitle("История").setMessage("Не удалось прочитать историю.").setPositiveButton("OK",null).show(); }
    }

    @Override protected void onDestroy() { super.onDestroy(); worker.shutdownNow(); }
}
