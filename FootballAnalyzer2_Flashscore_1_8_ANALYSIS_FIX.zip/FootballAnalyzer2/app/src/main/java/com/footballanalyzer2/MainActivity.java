package com.footballanalyzer2;

import android.app.*; import android.os.*; import android.graphics.Color; import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable; import android.view.*; import android.widget.*;
import java.net.*; import java.io.*; import java.text.*; import java.util.*; import java.util.concurrent.*; import org.json.*;

public class MainActivity extends Activity {
 static final String BASE="https://raw.githubusercontent.com/oladeeayo/open-matchday/master/data/";
 String league="ALL", day="today";
 String apiKey="ash_live_zy49s9z2TTYYnL3KuxwNcnE8CHpJDkN5";
 String[][] leagues={{"Все турниры Flashscore","ALL"},{"Англия · Premier League","ENG_1_premier-league"},{"Испания · La Liga","ESP_1_la-liga"},{"Германия · Bundesliga","GER_1_bundesliga"},{"Италия · Serie A","ITA_1_serie-a"},{"Франция · Ligue 1","FRA_1_ligue-1"},{"Нидерланды · Eredivisie","NED_1_eredivisie"},{"Португалия · Primeira Liga","POR_1_primeira-liga"},{"Бельгия · Pro League","BEL_1_pro-league"},{"Турция · Süper Lig","TUR_1_super-lig"},{"Греция · Super League","GRE_1_super-league"},{"🏆 Лига чемпионов","UEFA_1_champions-league"},{"🏆 Лига Европы","UEFA_1_europa-league"},{"🏆 Лига конференций","UEFA_1_conference-league"},{"🏆 Кубок Англии","ENG_CUP_fa-cup"},{"🏆 Кубок английской лиги","ENG_CUP_efl-cup"},{"🏆 Кубок Испании","ESP_CUP_copa-del-rey"},{"🏆 Кубок Италии","ITA_CUP_coppa-italia"},{"Англия · Championship","ENG_2_championship"}};
 ExecutorService worker=Executors.newSingleThreadExecutor(); Handler ui=new Handler(Looper.getMainLooper());
 LinearLayout root,cards; TextView status;
 int dp(float x){return (int)(x*getResources().getDisplayMetrics().density);}
 GradientDrawable shape(int c,int r){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(dp(r));return d;}
 TextView label(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
 LinearLayout.LayoutParams lp(int top,int bottom){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,dp(top),0,dp(bottom));return p;}
 public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(0xff06120d);getWindow().setNavigationBarColor(0xff06120d);ui();}
 void ui(){
  ScrollView sc=new ScrollView(this);root=new LinearLayout(this);root.setOrientation(1);root.setPadding(dp(18),dp(22),dp(18),dp(28));root.setBackgroundColor(0xff06120d);sc.addView(root);setContentView(sc);
  root.addView(label("⚽ FOOTBALL ANALYZER 2",25,0xff35d879,true));
  root.addView(label("Матчи и статистика сезона 2026/27",14,0xffb8c9bf,true),lp(4,18));
  root.addView(label("ВЫБЕРИ ЛИГУ",14,0xff35d879,true),lp(0,6));
  Spinner sp=new Spinner(this);String[] names=new String[leagues.length];for(int i=0;i<names.length;i++)names[i]=leagues[i][0];
  sp.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,names));sp.setBackground(shape(0xff12251b,12));root.addView(sp,lp(0,12));
  sp.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> a){}public void onItemSelected(android.widget.AdapterView<?> a,View v,int p,long id){league=leagues[p][1];loadApi();}});
  LinearLayout tabs=new LinearLayout(this);for(String[] x:new String[][]{{"Сегодня","today"},{"Завтра","tomorrow"},{"Все матчи","all"}}){Button b=button(x[0]);LinearLayout.LayoutParams q=new LinearLayout.LayoutParams(0,dp(46),1);q.setMargins(dp(2),0,dp(2),0);tabs.addView(b,q);b.setOnClickListener(v->{day=x[1];loadApi();});}root.addView(tabs,lp(0,12));
  Button reload=button("ОБНОВИТЬ");root.addView(reload,lp(0,8));reload.setOnClickListener(v->loadApi());
  Button api=button("⚽ FLASHSCORE: ОБНОВИТЬ МАТЧИ И КОЭФФИЦИЕНТЫ");root.addView(api,lp(0,12));
  api.setOnClickListener(v->loadApi());
  status=label("Подключение к Flashscore через API.SH…",14,0xffc3d2c9,false);root.addView(status,lp(0,10));cards=new LinearLayout(this);cards.setOrientation(1);root.addView(cards);
  root.addView(label("Источник: Flashscore через API.SH. При ошибке 401 требуется действующий API Key API.SH.",12,0xff879b8e,false),lp(20,0));
 }
 Button button(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextColor(0xff06120d);b.setBackground(shape(0xff35d879,12));return b;}
 String fetch(String u)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();c.setConnectTimeout(15000);c.setReadTimeout(20000);try(InputStream in=c.getInputStream();ByteArrayOutputStream o=new ByteArrayOutputStream()){byte[] b=new byte[8192];int n;while((n=in.read(b))>0)o.write(b,0,n);return o.toString("UTF-8");}finally{c.disconnect();}}
 List<String[]> csv(String s){List<String[]> out=new ArrayList<>();BufferedReader r=new BufferedReader(new StringReader(s));try{String l;while((l=r.readLine())!=null)out.add(split(l));}catch(Exception ignored){}return out;}
 String[] split(String s){ArrayList<String>a=new ArrayList<>();StringBuilder b=new StringBuilder();boolean q=false;for(int i=0;i<s.length();i++){char c=s.charAt(i);if(c=='"'){if(q&&i+1<s.length()&&s.charAt(i+1)=='"'){b.append('"');i++;}else q=!q;}else if(c==','&&!q){a.add(b.toString());b.setLength(0);}else b.append(c);}a.add(b.toString());return a.toArray(new String[0]);}
 void load(){status.setText("Загружаю данные сезона 2026/27…");cards.removeAllViews();final String l=league,d=day;worker.execute(()->{try{
  List<String[]> f=csv(fetch(BASE+l+"/fixtures_2627.csv")),r=csv(fetch(BASE+l+"/results_2627.csv"));
  String today=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());Calendar c=Calendar.getInstance();c.add(5,1);String tom=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(c.getTime());
  List<String[]> found=new ArrayList<>();for(int i=1;i<f.size();i++){String[] x=f.get(i);if(x.length<5)continue;if(d.equals("today")&&!x[1].equals(today))continue;if(d.equals("tomorrow")&&!x[1].equals(tom))continue;found.add(x);}
  ui.post(()->{status.setText("Матчей найдено: "+found.size());if(found.isEmpty()){cards.addView(label("На эту дату матчей нет в выбранной лиге. Выбери «Все матчи» или другую лигу.",15,Color.WHITE,false));return;}for(String[] x:found)addCard(x,r);});
 }catch(Exception e){ui.post(()->status.setText("Ошибка загрузки: "+e.getMessage()));}});}
 void addCard(String[] m,List<String[]> results){LinearLayout box=new LinearLayout(this);box.setOrientation(1);box.setPadding(dp(14),dp(13),dp(14),dp(13));box.setBackground(shape(0xff12251b,15));cards.addView(box,lp(0,10));
  box.addView(label(m[1]+"  "+m[2],12,0xff9bb4a5,true));box.addView(label(m[3]+"  —  "+m[4],18,Color.WHITE,true),lp(5,8));
  Button a=button("АНАЛИЗ ПОСЛЕДНИХ ИГР");box.addView(a);TextView out=label("",13,0xffd9e7de,false);box.addView(out,lp(7,0));
  a.setOnClickListener(v->{a.setEnabled(false);out.setText("Считаю…");worker.execute(()->{String s=report(m[3],m[4],results);ui.post(()->{out.setText(s);a.setEnabled(true);});});});
 }
 Map<String,Integer> index(String[] h){Map<String,Integer> m=new HashMap<>();for(int i=0;i<h.length;i++)m.put(h[i].trim(),i);return m;}
 String val(String[] row,Map<String,Integer> ix,String key){Integer i=ix.get(key);return i==null||i>=row.length?null:row[i].trim();}

 static class TeamStats {
  int matches; ArrayList<Double> goals=new ArrayList<>(); ArrayList<Double>[] markets=new ArrayList[4];
  TeamStats(){for(int i=0;i<4;i++)markets[i]=new ArrayList<>();}
 }
 int col(Map<String,Integer> ix,String... keys){for(String k:keys){Integer n=ix.get(k);if(n!=null)return n;}return -1;}
 Double num(String[] row,int i){if(i<0||i>=row.length)return null;try{String s=row[i].trim();if(s.isEmpty()||s.equalsIgnoreCase("null"))return null;return Double.parseDouble(s);}catch(Exception e){return null;}}
 TeamStats teamStats(String name,List<String[]> rows,Map<String,Integer> ix){
  TeamStats t=new TeamStats();int hg=col(ix,"ft_home"),ag=col(ix,"ft_away");
  int[] hc={col(ix,"home_corners"),col(ix,"home_yellow","home_yellows","home_yellow_cards"),col(ix,"home_fouls"),col(ix,"home_target","home_shots_on_target","home_sot")};
  int[] ac={col(ix,"away_corners"),col(ix,"away_yellow","away_yellows","away_yellow_cards"),col(ix,"away_fouls"),col(ix,"away_target","away_shots_on_target","away_sot")};
  for(int j=rows.size()-1;j>=1&&t.matches<10;j--){String[] x=rows.get(j);String h=val(x,ix,"home"),a=val(x,ix,"away");if(!name.equalsIgnoreCase(h)&&!name.equalsIgnoreCase(a))continue;
   Double gh=num(x,hg),ga=num(x,ag);if(gh==null||ga==null)continue;t.goals.add(gh+ga);t.matches++;
   for(int k=0;k<4;k++){Double hv=num(x,hc[k]),av=num(x,ac[k]);if(hv!=null&&av!=null)t.markets[k].add(hv+av);}
  }return t;
 }
 double average(ArrayList<Double> values){if(values.size()==0)return Double.NaN;double s=0;for(double v:values)s+=v;return s/values.size();}
 String hitCount(ArrayList<Double> values,double line,boolean over){
  int hits=0,total=0;
  for(double v:values){if(v==line)continue;total++;if(over?v>line:v<line)hits++;}
  return hits+"/"+total;
 }
 double hitRate(ArrayList<Double> values,double line,boolean over){
  int hits=0,total=0;
  for(double v:values){if(v==line)continue;total++;if(over?v>line:v<line)hits++;}
  return total==0?0:hits/(double)total;
 }
 String recommendation(String title,ArrayList<Double> samples,double[] standardLines,
                      ArrayList<Double> homeSamples,ArrayList<Double> awaySamples,
                      ArrayList<Double> h2hSamples){
  if(samples.size()<8)return title+": ПРОПУСТИТЬ — только "+samples.size()+" матчей со статистикой.";
  double mean=average(samples),bestP=0,bestLine=0;String bestSide="";
  // Оставляем только содержательные линии. Низкие тоталы вроде ТБ 0.5 исключены.
  for(double line:standardLines){
   double po=hitRate(samples,line,true),pu=hitRate(samples,line,false);
   if(po>bestP){bestP=po;bestLine=line;bestSide="ТБ";}
   if(pu>bestP){bestP=pu;bestLine=line;bestSide="ТМ";}
  }
  // Без букмекерского коэффициента это только историческая оценка, не подтверждённая value-ставка.
  if(bestP<0.55 || bestP>0.78 || samples.size()<12)
   return title+": ПРОПУСТИТЬ — нет подходящего соотношения вероятности и линии. Среднее "+
    fmt(mean,1)+", выборка "+samples.size()+".";
  double fairOdds=1.0/bestP;
  StringBuilder out=new StringBuilder();
  out.append(title).append(": ").append(bestSide).append(" ")
    .append(String.format(Locale.US,"%.1f",bestLine))
    .append(" · проход ").append(Math.round(bestP*100)).append("%")
    .append(" · расчётный кэф ").append(String.format(Locale.US,"%.2f",fairOdds))
    .append(" · среднее ").append(fmt(mean,1)).append(" · выборка ").append(samples.size());
  if(homeSamples!=null)out.append("\n").append("  ").append("Домашняя команда: ")
    .append(hitCount(homeSamples,bestLine,bestSide.equals("ТБ"))).append(" проходов");
  if(awaySamples!=null)out.append(" | Гостевая: ")
    .append(hitCount(awaySamples,bestLine,bestSide.equals("ТБ"))).append(" проходов");
  if(h2hSamples!=null)out.append(" | H2H: ")
    .append(hitCount(h2hSamples,bestLine,bestSide.equals("ТБ"))).append(" проходов");
  out.append("\n  ").append("Сравни с реальным кэфом букмекера: он должен быть выше расчётного, иначе ставку пропустить.");
  return out.toString();
 }

 String report(String home,String away,List<String[]> rows){
  if(rows.size()<2)return "⚠️ Недостаточно завершённых матчей для анализа.";
  Map<String,Integer> ix=index(rows.get(0));
  TeamStats h=teamStats(home,rows,ix),a=teamStats(away,rows,ix);
  if(h.matches<3||a.matches<3)return "⚠️ Недостаточно истории даже для предварительного анализа: "+home+" — "+h.matches+", "+away+" — "+a.matches+". Нужно хотя бы 3 матча на команду.";
  StringBuilder b=new StringBuilder();
  b.append("⚽ ПРОГНОЗ НА МАТЧ\n").append(home).append(" — ").append(away).append("\n\n");
  b.append("📊 ОБЩАЯ ФОРМА КОМАНД\n");
  b.append("Последние матчи: ").append(home).append(" — ").append(h.matches).append(", ").append(away).append(" — ").append(a.matches).append(".\n");
  if(h.matches<5||a.matches<5)b.append("⚠️ Внимание: выборка небольшая, выводы предварительные.\n");
  b.append("Отбор: только содержательные линии. Нужна выборка от 12 матчей и исторический проход 55–78%; иначе — ПРОПУСТИТЬ.\nРасчётный кэф — обратная историческая частота, а не котировка букмекера.\n\n");
  ArrayList<Double> goals=new ArrayList<>();goals.addAll(h.goals);goals.addAll(a.goals);
  b.append("⚽ ГОЛЫ\n");
  b.append("Среднее за матч: ").append(home).append(" — ").append(fmt(average(h.goals),1)).append(", ").append(away).append(" — ").append(fmt(average(a.goals),1)).append(".\n");
  b.append(recommendation("🎯 Рекомендация",goals,new double[]{1.5,2.5,3.5},h.goals,a.goals,null)).append("\n\n");
  String[] titles={"🚩 УГЛОВЫЕ","🟨 ЖЁЛТЫЕ КАРТОЧКИ","🤼 ФОЛЫ","🥅 УДАРЫ В СТВОР"};
  double[][] lines={{8.5,9.5,10.5,11.5},{3.5,4.5,5.5,6.5},{19.5,21.5,23.5,25.5},{7.5,8.5,9.5,10.5}};
  for(int k=0;k<4;k++){
   ArrayList<Double> samples=new ArrayList<>();samples.addAll(h.markets[k]);samples.addAll(a.markets[k]);
   b.append(titles[k]).append("\n");
   b.append("Среднее: ").append(home).append(" — ").append(fmt(average(h.markets[k]),1)).append(", ").append(away).append(" — ").append(fmt(average(a.markets[k]),1)).append(".\n");
   b.append(recommendation("🎯 Рекомендация",samples,lines[k],h.markets[k],a.markets[k],null)).append("\n\n");
  }
  // Head-to-head within the selected competition's available season history.
  ArrayList<Double> hg2h=new ArrayList<>();
  ArrayList<Double>[] h2hMarkets=new ArrayList[4];
  for(int k=0;k<4;k++)h2hMarkets[k]=new ArrayList<>();
  int h2hCount=0;
  int[] homeCols={col(ix,"home_corners"),col(ix,"home_yellow"),col(ix,"home_fouls"),col(ix,"home_target")};
  int[] awayCols={col(ix,"away_corners"),col(ix,"away_yellow"),col(ix,"away_fouls"),col(ix,"away_target")};
  for(int j=1;j<rows.size();j++){
   String[] row=rows.get(j);
   String rh=val(row,ix,"home"),ra=val(row,ix,"away");
   if(!((home.equalsIgnoreCase(rh)&&away.equalsIgnoreCase(ra))||(home.equalsIgnoreCase(ra)&&away.equalsIgnoreCase(rh))))continue;
   Double gh=num(row,col(ix,"ft_home")),ga=num(row,col(ix,"ft_away"));
   if(gh==null||ga==null)continue;
   hg2h.add(gh+ga);h2hCount++;
   for(int k=0;k<4;k++){Double x=num(row,homeCols[k]),y=num(row,awayCols[k]);if(x!=null&&y!=null)h2hMarkets[k].add(x+y);}
  }
  b.append("🤝 ОЧНЫЕ ВСТРЕЧИ\n");
  if(h2hCount==0)b.append("В доступной базе выбранного турнира очные встречи не найдены. Это не означает, что их не было.\n");
  else{
   b.append("Найдено очных матчей: ").append(h2hCount).append(".\n");
   b.append("⚽ Голы: среднее ").append(fmt(average(hg2h),1)).append(".\n");
   b.append(recommendation("🎯 Тотал голов",hg2h,new double[]{1.5,2.5,3.5},null,null,hg2h)).append("\n");
   String[] hn={"🚩 Угловые","🟨 Жёлтые","🤼 Фолы","🥅 Удары в створ"};
   for(int k=0;k<4;k++){
    b.append(hn[k]).append(": среднее ").append(fmt(average(h2hMarkets[k]),1)).append(".\n");
    b.append(recommendation("🎯 Тотал",h2hMarkets[k],lines[k],null,null,h2hMarkets[k])).append("\n");
   }
  }
  b.append("\nℹ️ Исторический процент не гарантирует результат. Для ставки сравни реальный коэффициент с расчётным: реальный должен быть выше. Без котировки букмекера приложение не подтверждает value. Пустая статистика не считается нулём.");
  return b.toString();
 }

 String apiLeagueId(String key){
  if(key.equals("ENG_1_premier-league"))return "39";
  if(key.equals("ESP_1_la-liga"))return "140";
  if(key.equals("GER_1_bundesliga"))return "78";
  if(key.equals("ITA_1_serie-a"))return "135";
  if(key.equals("FRA_1_ligue-1"))return "61";
  if(key.equals("NED_1_eredivisie"))return "88";
  if(key.equals("POR_1_primeira-liga"))return "94";
  if(key.equals("BEL_1_pro-league"))return "144";
  if(key.equals("TUR_1_super-lig"))return "203";
  if(key.equals("GRE_1_super-league"))return "197";
  if(key.equals("UEFA_1_champions-league"))return "2";
  if(key.equals("UEFA_1_europa-league"))return "3";
  if(key.equals("UEFA_1_conference-league"))return "848";
  if(key.equals("ENG_CUP_fa-cup"))return "45";
  if(key.equals("ENG_CUP_efl-cup"))return "48";
  if(key.equals("ESP_CUP_copa-del-rey"))return "143";
  if(key.equals("ITA_CUP_coppa-italia"))return "137";
  if(key.equals("ENG_2_championship"))return "40";
  return "";
 }
 String apiGet(String path,String key)throws Exception{
  HttpURLConnection c=(HttpURLConnection)new URL("https://api.api.sh/flashscore/v1/"+path).openConnection();
  c.setRequestProperty("x-api-key",key);c.setRequestProperty("Accept","application/json");
  c.setConnectTimeout(15000);c.setReadTimeout(25000);
  int statusCode=c.getResponseCode();InputStream in=statusCode>=200&&statusCode<300?c.getInputStream():c.getErrorStream();
  ByteArrayOutputStream o=new ByteArrayOutputStream();
  if(in!=null){try(InputStream stream=in){byte[] b=new byte[8192];int n;while((n=stream.read(b))>0)o.write(b,0,n);}}
  String body=o.toString("UTF-8");c.disconnect();
  if(statusCode==401)throw new Exception("HTTP 401 — API.SH отклонил ключ (invalid api key). Это не ошибка Flashscore-запроса. Создай новый API Key в кабинете API.SH и замени ключ в проекте.");
  if(statusCode==403)throw new Exception("HTTP 403 — у ключа нет доступа к этому endpoint или исчерпан/не активирован тариф.");
  if(statusCode==429)throw new Exception("HTTP 429 — превышен лимит запросов API.SH. Подожди и повтори.");
  if(statusCode<200||statusCode>=300)throw new Exception("HTTP "+statusCode+": "+body);
  JSONObject parsed=new JSONObject(body);
  if(parsed.has("success")&&!parsed.optBoolean("success",true))
   throw new Exception(parsed.optString("error","API.SH вернул ошибку"));
  return body;
 }
 String leagueNeedle(String key){
  if(key.equals("ENG_1_premier-league"))return "premier league";
  if(key.equals("ESP_1_la-liga"))return "la liga";
  if(key.equals("GER_1_bundesliga"))return "bundesliga";
  if(key.equals("ITA_1_serie-a"))return "serie a";
  if(key.equals("FRA_1_ligue-1"))return "ligue 1";
  if(key.equals("NED_1_eredivisie"))return "eredivisie";
  if(key.equals("POR_1_primeira-liga"))return "primeira liga";
  if(key.equals("BEL_1_pro-league"))return "pro league";
  if(key.equals("TUR_1_super-lig"))return "super lig";
  if(key.equals("GRE_1_super-league"))return "super league";
  if(key.equals("UEFA_1_champions-league"))return "champions league";
  if(key.equals("UEFA_1_europa-league"))return "europa league";
  if(key.equals("UEFA_1_conference-league"))return "conference league";
  if(key.equals("ENG_CUP_fa-cup"))return "fa cup";
  if(key.equals("ENG_CUP_efl-cup"))return "efl cup";
  if(key.equals("ESP_CUP_copa-del-rey"))return "copa del rey";
  if(key.equals("ITA_CUP_coppa-italia"))return "coppa italia";
  if(key.equals("ENG_2_championship"))return "championship";
  return "";
 }
 void apiDialog(){
  EditText input=new EditText(this);input.setSingleLine(true);input.setHint("Вставь API Key");
  input.setInputType( android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
  if(!apiKey.isEmpty())input.setText(apiKey);
  new AlertDialog.Builder(this).setTitle("API-Football")
   .setMessage("Ключ хранится только в памяти приложения до его закрытия. Не вставляй его в GitHub или исходный код.")
   .setView(input).setNegativeButton("Отмена",null)
   .setPositiveButton("Проверить и загрузить",(d,w)->{
    String candidate=input.getText().toString().trim();
    if(candidate.isEmpty()){status.setText("Введи API Key.");return;}
    apiKey=candidate;loadApi();
   }).show();
 }
 void loadApi(){
  if(apiKey.isEmpty()){status.setText("Не настроен ключ API.SH.");return;}
  status.setText("Загружаю матчи Flashscore…");cards.removeAllViews();
  final String selected=league,selectedDay=day,key=apiKey;
  worker.execute(()->{try{
   int[] offsets;
   if(selectedDay.equals("tomorrow"))offsets=new int[]{1};
   else if(selectedDay.equals("all"))offsets=new int[]{0,1,2,3,4,5,6,7};
   else offsets=new int[]{0};
   ArrayList<JSONObject> all=new ArrayList<>();
   for(int off:offsets){
    JSONObject rootJson=new JSONObject(apiGet("matches?sport=football&day="+off,key));
    JSONArray arr=rootJson.optJSONArray("matches");
    if(arr==null)arr=rootJson.optJSONArray("response");
    if(arr!=null)for(int i=0;i<arr.length();i++){
     JSONObject match=arr.optJSONObject(i);if(match==null)continue;
     if(!selected.equals("ALL")){
      JSONObject tournament=match.optJSONObject("tournament");
      String name=tournament==null?"":tournament.optString("name","").toLowerCase(Locale.ROOT);
      String needle=leagueNeedle(selected);
      if(!needle.isEmpty()&&!name.contains(needle))continue;
     }
     all.add(match);
    }
   }
   final ArrayList<JSONObject> matches=all;
   ui.post(()->{
    status.setText("Flashscore подключён · найдено матчей: "+matches.size()+" · источник API.SH");
    if(matches.isEmpty()){
     cards.addView(label("Flashscore не вернул матчи для выбранного периода/турнира. Нажми «ОБНОВИТЬ» или выбери «Все турниры».",14,Color.WHITE,false));
     return;
    }
    for(JSONObject match:matches)addFlashscoreCard(match,key);
   });
  }catch(Exception e){ui.post(()->status.setText("Ошибка Flashscore API: "+e.getMessage()));}});
 }
 void addFlashscoreCard(JSONObject match,String key){
  LinearLayout box=new LinearLayout(this);box.setOrientation(1);box.setPadding(dp(14),dp(13),dp(14),dp(13));box.setBackground(shape(0xff12251b,15));cards.addView(box,lp(0,10));
  JSONObject home=match.optJSONObject("home_team"),away=match.optJSONObject("away_team"),tournament=match.optJSONObject("tournament");
  String homeName=home==null?"Команда 1":home.optString("name","Команда 1");
  String awayName=away==null?"Команда 2":away.optString("name","Команда 2");
  String tour=tournament==null?"":tournament.optString("name","");
  String date=match.optString("start_time",match.optString("date",""));
  String statusText=match.optString("status","");
  String score=(match.isNull("home_score")||!match.has("home_score"))?"":match.optString("home_score")+" : "+match.optString("away_score");
  box.addView(label(date+" · "+tour+" · "+statusText,11,0xff9bb4a5,true));
  box.addView(label(homeName+" — "+awayName+(score.isEmpty()?"":"   "+score),17,Color.WHITE,true),lp(4,7));
  Button detail=button("📊 АНАЛИЗ, СТАТИСТИКА И КОЭФФИЦИЕНТЫ");box.addView(detail);
  TextView output=label("",12,0xffd9e7de,false);box.addView(output,lp(7,0));
  String id=match.optString("id","");
  String homeId=home==null?"":home.optString("id","");
  String awayId=away==null?"":away.optString("id","");
  detail.setOnClickListener(v->{detail.setEnabled(false);output.setText("Загружаю статистику, последние матчи и реальные котировки…");worker.execute(()->{
   String result;
   try{
    String statsJson="",oddsOU="",odds1x2="",oddsRU="",homeResults="",awayResults="",h2hJson="";
    if(!statusText.equalsIgnoreCase("scheduled")){
     try{statsJson=apiGet("match/statistics?match_id="+URLEncoder.encode(id,"UTF-8"),key);}catch(Exception ignored){}
    }
    try{oddsOU=apiGet("match/odds?match_id="+URLEncoder.encode(id,"UTF-8")+"&bet_type=OVER_UNDER&country=NO",key);}catch(Exception ignored){}
    try{odds1x2=apiGet("match/odds?match_id="+URLEncoder.encode(id,"UTF-8")+"&bet_type=HOME_DRAW_AWAY&country=NO",key);}catch(Exception ignored){}
    try{oddsRU=apiGet("match/odds?match_id="+URLEncoder.encode(id,"UTF-8")+"&bet_type=OVER_UNDER&country=RU",key);}catch(Exception ignored){}
    try{if(!homeId.isEmpty())homeResults=apiGet("team/results?team_id="+URLEncoder.encode(homeId,"UTF-8")+"&sport=football&page=0",key);}catch(Exception ignored){}
    try{if(!awayId.isEmpty())awayResults=apiGet("team/results?team_id="+URLEncoder.encode(awayId,"UTF-8")+"&sport=football&page=0",key);}catch(Exception ignored){}
    try{h2hJson=apiGet("match/h2h?match_id="+URLEncoder.encode(id,"UTF-8"),key);}catch(Exception ignored){}
    result=formatFlashscoreDetails(statsJson,oddsOU,odds1x2,oddsRU,homeResults,awayResults,h2hJson,statusText,homeName,awayName);
   }catch(Exception ex){result="Ошибка загрузки данных: "+ex.getMessage();}
   final String finalResult=result;ui.post(()->{output.setText(finalResult);detail.setEnabled(true);});
  });});
 }
 String statValue(JSONObject item,String... keys){
  for(String k:keys){Object v=item.opt(k);if(v!=null&&v!=JSONObject.NULL){if(v instanceof JSONObject){JSONObject o=(JSONObject)v;String s=o.optString("value",o.optString("display",""));if(!s.isEmpty())return s;}else return String.valueOf(v);}}
  return "";
 }
 void appendOdds(StringBuilder b,String json,String title){
  b.append("\n").append(title).append("\n");
  if(json==null||json.isEmpty()){b.append("Котировки не вернулись от API для этого рынка.\n");return;}
  try{
   JSONObject root=new JSONObject(json);JSONArray odds=root.optJSONArray("odds"),books=root.optJSONArray("bookmakers");
   if(odds==null||odds.length()==0){b.append("Flashscore/API.SH не предоставил котировки для этого матча.\n");return;}
   boolean found1x=false;
   for(int i=0;i<odds.length();i++){JSONObject row=odds.optJSONObject(i);if(row!=null&&row.optString("bookmaker","").toLowerCase(Locale.ROOT).contains("1xbet"))found1x=true;}
   if(found1x)b.append("1xBet присутствует в ответе.\n");
   for(int i=0;i<odds.length();i++){
    JSONObject row=odds.optJSONObject(i);if(row==null)continue;
    String bookmaker=row.optString("bookmaker","Букмекер");
    b.append(bookmaker).append(": ");
    String[] keys={"home","draw","away","over","under"};
    boolean first=true;
    for(String k:keys){JSONObject v=row.optJSONObject(k);if(v==null)continue;
     String price=v.optString("value","");String opening=v.optString("opening","");
     String line=v.optString("handicap",v.optString("line",""));
     if(!first)b.append(" | ");first=false;
     b.append(k.toUpperCase(Locale.ROOT));
     if(!line.isEmpty())b.append(" ").append(line);
     b.append(" @ ").append(price.isEmpty()?"нет цены":price);
     if(!opening.isEmpty())b.append(" (откр. ").append(opening).append(")");
    }
    if(first)b.append("Данные рынка: ").append(row.toString());
    b.append("\n");
   }
   if(!found1x)b.append("1xBet в списке этой страны (NO) не найден. Показаны только букмекеры, реально вернувшиеся из API.\n");
  }catch(Exception e){b.append("Не удалось разобрать ответ коэффициентов: ").append(e.getMessage()).append("\n");}
 }
 String teamForm(String json,String teamName){
  if(json==null||json.isEmpty())return teamName+": история недоступна.\n";
  try{
   JSONArray arr=new JSONObject(json).optJSONArray("matches");
   if(arr==null||arr.length()==0)return teamName+": API не вернул завершённые матчи.\n";
   int n=0,goalsFor=0,goalsAgainst=0,over15=0,over25=0,wins=0,draws=0,losses=0;
   StringBuilder recent=new StringBuilder();
   for(int i=0;i<arr.length()&&n<10;i++){
    JSONObject m=arr.optJSONObject(i);if(m==null||!m.optString("status","").equalsIgnoreCase("finished"))continue;
    JSONObject h=m.optJSONObject("home_team"),a=m.optJSONObject("away_team");
    if(h==null||a==null||m.isNull("home_score")||m.isNull("away_score"))continue;
    int hs=m.optInt("home_score"),as=m.optInt("away_score");boolean isHome=teamName.equals(h.optString("name"));
    int gf=isHome?hs:as,ga=isHome?as:hs;goalsFor+=gf;goalsAgainst+=ga;
    if(gf+ga>=2)over15++;if(gf+ga>=3)over25++;
    if(gf>ga)wins++;else if(gf==ga)draws++;else losses++;
    if(n<5)recent.append("\n  ").append(h.optString("name")).append(" ").append(hs).append(":").append(as).append(" ").append(a.optString("name"));
    n++;
   }
   if(n==0)return teamName+": нет завершённых матчей в истории API.\n";
   StringBuilder b=new StringBuilder();
   b.append(teamName).append(" — последние ").append(n).append(" матчей: В-Н-П ").append(wins).append("-").append(draws).append("-").append(losses)
    .append("; голы забито/пропущено ").append(goalsFor).append("/").append(goalsAgainst)
    .append("; средний тотал матча ").append(String.format(Locale.US,"%.2f",(goalsFor+goalsAgainst)/(double)n))
    .append("; ТБ1.5 проходил ").append(Math.round(100*over15/(double)n)).append("%, ТБ2.5 — ").append(Math.round(100*over25/(double)n)).append("%")
    .append(recent).append("\n");
   return b.toString();
  }catch(Exception e){return teamName+": ошибка чтения формы — "+e.getMessage()+"\n";}
 }

 String goalRecommendation(String homeJson,String awayJson){
  ArrayList<Integer> totals=new ArrayList<>();
  for(String json:new String[]{homeJson,awayJson}){
   if(json==null||json.isEmpty())continue;
   try{JSONArray arr=new JSONObject(json).optJSONArray("matches");if(arr==null)continue;int n=0;
    for(int i=0;i<arr.length()&&n<10;i++){JSONObject m=arr.optJSONObject(i);if(m==null||!m.optString("status","").equalsIgnoreCase("finished")||m.isNull("home_score")||m.isNull("away_score"))continue;totals.add(m.optInt("home_score")+m.optInt("away_score"));n++;}
   }catch(Exception ignored){}
  }
  if(totals.size()<8)return "Голы: ПРОПУСТИТЬ — мало завершённых матчей в выборке ("+totals.size()+").\n";
  int over15=0,over25=0;double avg=0;
  for(int v:totals){avg+=v;if(v>=2)over15++;if(v>=3)over25++;}
  avg/=totals.size();double p15=over15*100.0/totals.size(),p25=over25*100.0/totals.size();
  String pick="ПРОПУСТИТЬ — нет достаточно сильного исторического сигнала.";
  if(p25>=65)pick="ТБ 2.5 голов — исторический проход "+Math.round(p25)+"%.";
  else if(p15>=75)pick="ТБ 1.5 голов — исторический проход "+Math.round(p15)+"%.";
  else if(p25<=35)pick="ТМ 2.5 голов — исторический проход "+Math.round(100-p25)+"%.";
  return "Голы: "+pick+" Средний тотал выборки "+String.format(Locale.US,"%.2f",avg)+" ("+totals.size()+" матчей). Это статистическая оценка, не гарантия и не замена проверке коэффициента букмекера.\n";
 }
 String formatFlashscoreDetails(String statsJson,String oddsOU,String odds1x2,String oddsRU,String homeResults,String awayResults,String h2hJson,String status,String homeName,String awayName){
  StringBuilder b=new StringBuilder();
  b.append("📊 СТАТИСТИКА МАТЧА\n");
  if(status.equalsIgnoreCase("scheduled"))b.append("Матч ещё не начался: текущих игровых статистик пока нет. Ниже — форма команд и предматчевые коэффициенты.\n");
  else if(statsJson==null||statsJson.isEmpty())b.append("Статистика матча не предоставлена API для этой игры.\n");
  else try{
   JSONObject root=new JSONObject(statsJson);JSONArray periods=root.optJSONArray("periods");boolean any=false;
   if(periods!=null)for(int p=0;p<periods.length();p++){
    JSONObject period=periods.optJSONObject(p);if(period==null)continue;
    if(p>0)continue;
    JSONArray groups=period.optJSONArray("groups");if(groups==null)continue;
    for(int g=0;g<groups.length();g++){
     JSONObject group=groups.optJSONObject(g);if(group==null)continue;
     JSONArray items=group.optJSONArray("items");if(items==null)continue;
     b.append(group.optString("name","Статистика")).append(":\n");
     for(int i=0;i<items.length();i++){JSONObject item=items.optJSONObject(i);if(item==null)continue;
      String name=statValue(item,"name","label","title","type");
      String hv=statValue(item,"home","home_value","homeValue","home_team","value_home");
      String av=statValue(item,"away","away_value","awayValue","away_team","value_away");
      if(name.isEmpty())name="Показатель";
      if(!hv.isEmpty()||!av.isEmpty()){b.append("  ").append(name).append(": ").append(hv.isEmpty()?"—":hv).append(" — ").append(av.isEmpty()?"—":av).append("\n");any=true;}
      else {b.append("  ").append(item.toString()).append("\n");any=true;}
     }
    }
   }
   if(!any)b.append("Ответ API не содержит игровых показателей для этого матча.\n");
  }catch(Exception e){b.append("Ошибка чтения статистики: ").append(e.getMessage()).append("\n");}
  b.append("\n📈 ФОРМА КОМАНД (последние матчи)\n").append(teamForm(homeResults,homeName)).append(teamForm(awayResults,awayName));
  b.append("\n💹 РЕАЛЬНЫЕ КОЭФФИЦИЕНТЫ — без выдуманных значений\n");
  appendOdds(b,oddsOU,"ТОТАЛЫ БОЛЬШЕ/МЕНЬШЕ");
  appendOdds(b,odds1x2,"ПОБЕДА / НИЧЬЯ / ПОБЕДА — букмекеры страны NO");
  appendOdds(b,oddsRU,"ТОТАЛЫ — букмекеры страны RU (проверка наличия 1xBet)");
  if(h2hJson!=null&&!h2hJson.isEmpty()){
   try{JSONObject h=new JSONObject(h2hJson);JSONArray matches=h.optJSONArray("matches");b.append("\n🤝 ОЧНЫЕ ВСТРЕЧИ\n");
    if(matches!=null&&matches.length()>0){for(int i=0;i<Math.min(5,matches.length());i++){JSONObject m=matches.optJSONObject(i);if(m==null)continue;JSONObject ht=m.optJSONObject("home_team"),at=m.optJSONObject("away_team");b.append(ht==null?"":ht.optString("name")).append(" ").append(m.optString("home_score","-")).append(":").append(m.optString("away_score","-")).append(" ").append(at==null?"":at.optString("name")).append("\n");}}
    else b.append("В API нет доступных очных встреч.\n");
   }catch(Exception ignored){b.append("\n🤝 Очные встречи: API вернул данные, формат не распознан.\n");}
  }
  b.append("\n🎯 ВЫВОД\n");
  b.append(goalRecommendation(homeResults,awayResults));
  b.append("По угловым, карточкам и фолам пока не выдаю ставку без фактической истории этих показателей.\\n");
  b.append("\nИсточник: Flashscore через API.SH. Коэффициенты показываются только при наличии в ответе API.");
  return b.toString();
 }
 String fmt(double a,int n){return String.format(Locale.US,"%.1f",a/n);}
 public void onDestroy(){super.onDestroy();worker.shutdownNow();}
}
