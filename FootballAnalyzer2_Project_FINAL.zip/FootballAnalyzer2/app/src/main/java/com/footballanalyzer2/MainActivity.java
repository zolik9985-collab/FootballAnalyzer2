package com.footballanalyzer2;

import android.app.*; import android.os.*; import android.graphics.Color; import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable; import android.view.*; import android.widget.*;
import java.net.*; import java.io.*; import java.text.*; import java.util.*; import java.util.concurrent.*;

public class MainActivity extends Activity {
 static final String BASE="https://raw.githubusercontent.com/oladeeayo/open-matchday/master/data/";
 String league="ENG_1_premier-league", day="today";
 String[][] leagues={{"Англия · Premier League","ENG_1_premier-league"},{"Испания · La Liga","ESP_1_la-liga"},{"Германия · Bundesliga","GER_1_bundesliga"},{"Италия · Serie A","ITA_1_serie-a"},{"Франция · Ligue 1","FRA_1_ligue-1"},{"Нидерланды · Eredivisie","NED_1_eredivisie"},{"Португалия · Primeira Liga","POR_1_primeira-liga"},{"Бельгия · Pro League","BEL_1_pro-league"},{"Турция · Süper Lig","TUR_1_super-lig"},{"Греция · Super League","GRE_1_super-league"},{"🏆 Лига чемпионов","UEFA_1_champions-league"},{"🏆 Лига Европы","UEFA_1_europa-league"},{"🏆 Лига конференций","UEFA_1_conference-league"},{"🏆 Кубок Англии","ENG_CUP_fa-cup"},{"🏆 Кубок английской лиги","ENG_CUP_efl-cup"},{"🏆 Кубок Испании","ESP_CUP_copa-del-rey"},{"🏆 Кубок Италии","ITA_CUP_coppa-italia"},{"Англия · Championship","ENG_2_championship"}};
 ExecutorService worker=Executors.newSingleThreadExecutor(); Handler ui=new Handler(Looper.getMainLooper());
 LinearLayout root,cards; TextView status;
 int dp(float x){return (int)(x*getResources().getDisplayMetrics().density);}
 GradientDrawable shape(int c,int r){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(dp(r));return d;}
 TextView label(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
 LinearLayout.LayoutParams lp(int top,int bottom){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,dp(top),0,dp(bottom));return p;}
 public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(0xff06120d);getWindow().setNavigationBarColor(0xff06120d);ui();}
 void ui(){
  ScrollView sc=new ScrollView(this);root=new LinearLayout(this);root.setOrientation(1);root.setPadding(dp(18),dp(22),dp(18),dp(28));root.setBackgroundColor(0xff06120d);sc.addView(root);setContentView(sc);
  root.addView(label("⚽ FOOTBALL ANALYZER 2",25,0xff35d879,true));
  root.addView(label("Матчи и статистика сезона 2026/27",14,0xffb8c9bf,true),lp(4,18));
  root.addView(label("ВЫБЕРИ ЛИГУ",14,0xff35d879,true),lp(0,6));
  Spinner sp=new Spinner(this);String[] names=new String[leagues.length];for(int i=0;i<names.length;i++)names[i]=leagues[i][0];
  sp.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,names));sp.setBackground(shape(0xff12251b,12));root.addView(sp,lp(0,12));
  sp.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> a){}public void onItemSelected(android.widget.AdapterView<?> a,View v,int p,long id){league=leagues[p][1];load();}});
  LinearLayout tabs=new LinearLayout(this);for(String[] x:new String[][]{{"Сегодня","today"},{"Завтра","tomorrow"},{"Все матчи","all"}}){Button b=button(x[0]);LinearLayout.LayoutParams q=new LinearLayout.LayoutParams(0,dp(46),1);q.setMargins(dp(2),0,dp(2),0);tabs.addView(b,q);b.setOnClickListener(v->{day=x[1];load();});}root.addView(tabs,lp(0,12));
  Button reload=button("ОБНОВИТЬ");root.addView(reload,lp(0,12));reload.setOnClickListener(v->load());
  status=label("Загружаю расписание…",14,0xffc3d2c9,false);root.addView(status,lp(0,10));cards=new LinearLayout(this);cards.setOrientation(1);root.addView(cards);
  root.addView(label("Источник: open-matchday. Обновляется ежедневно, не в реальном времени. Пустые значения означают, что статистика недоступна.",12,0xff879b8e,false),lp(20,0));
 }
 Button button(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextColor(0xff06120d);b.setBackground(shape(0xff35d879,12));return b;}
 String fetch(String u)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();c.setConnectTimeout(15000);c.setReadTimeout(20000);try(InputStream in=c.getInputStream();ByteArrayOutputStream o=new ByteArrayOutputStream()){byte[] b=new byte[8192];int n;while((n=in.read(b))>0)o.write(b,0,n);return o.toString("UTF-8");}finally{c.disconnect();}}
 List<String[]> csv(String s){List<String[]> out=new ArrayList<>();BufferedReader r=new BufferedReader(new StringReader(s));try{String l;while((l=r.readLine())!=null)out.add(split(l));}catch(Exception ignored){}return out;}
 String[] split(String s){ArrayList<String>a=new ArrayList<>();StringBuilder b=new StringBuilder();boolean q=false;for(int i=0;i<s.length();i++){char c=s.charAt(i);if(c=='"'){if(q&&i+1<s.length()&&s.charAt(i+1)=='"'){b.append('"');i++;}else q=!q;}else if(c==','&&!q){a.add(b.toString());b.setLength(0);}else b.append(c);}a.add(b.toString());return a.toArray(new String[0]);}
 void load(){status.setText("Загружаю данные сезона 2026/27…");cards.removeAllViews();final String l=league,d=day;worker.execute(()->{try{
  List<String[]> f=csv(fetch(BASE+l+"/fixtures_2627.csv")),r=csv(fetch(BASE+l+"/results_2627.csv"));
  String today=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());Calendar c=Calendar.getInstance();c.add(5,1);String tom=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(c.getTime());
  List<String[]> found=new ArrayList<>();for(int i=1;i<f.size();i++){String[] x=f.get(i);if(x.length<5)continue;if(d.equals("today")&&!x[1].equals(today))continue;if(d.equals("tomorrow")&&!x[1].equals(tom))continue;found.add(x);}
  ui.post(()->{status.setText("Матчей найдено: "+found.size());if(found.isEmpty()){cards.addView(label("На эту дату матчей нет в выбранной лиге. Выбери «Все матчи» или другую лигу.",15,Color.WHITE,false));return;}for(String[] x:found)addCard(x,r);});
 }catch(Exception e){ui.post(()->status.setText("Ошибка загрузки: "+e.getMessage()));}});}
 void addCard(String[] m,List<String[]> results){LinearLayout box=new LinearLayout(this);box.setOrientation(1);box.setPadding(dp(14),dp(13),dp(14),dp(13));box.setBackground(shape(0xff12251b,15));cards.addView(box,lp(0,10));
  box.addView(label(m[1]+"  "+m[2],12,0xff9bb4a5,true));box.addView(label(m[3]+"  —  "+m[4],18,Color.WHITE,true),lp(5,8));
  Button a=button("АНАЛИЗ ПОСЛЕДНИХ ИГР");box.addView(a);TextView out=label("",13,0xffd9e7de,false);box.addView(out,lp(7,0));
  a.setOnClickListener(v->{a.setEnabled(false);out.setText("Считаю…");worker.execute(()->{String s=report(m[3],m[4],results);ui.post(()->{out.setText(s);a.setEnabled(true);});});});
 }
 Map<String,Integer> index(String[] h){Map<String,Integer> m=new HashMap<>();for(int i=0;i<h.length;i++)m.put(h[i].trim(),i);return m;}
 String val(String[] row,Map<String,Integer> ix,String key){Integer i=ix.get(key);return i==null||i>=row.length?null:row[i].trim();}

 static class TeamStats {
  int matches; ArrayList<Double> goals=new ArrayList<>(); ArrayList<Double>[] markets=new ArrayList[4];
  TeamStats(){for(int i=0;i<4;i++)markets[i]=new ArrayList<>();}
 }
 int col(Map<String,Integer> ix,String... keys){for(String k:keys){Integer n=ix.get(k);if(n!=null)return n;}return -1;}
 Double num(String[] row,int i){if(i<0||i>=row.length)return null;try{String s=row[i].trim();if(s.isEmpty()||s.equalsIgnoreCase("null"))return null;return Double.parseDouble(s);}catch(Exception e){return null;}}
 TeamStats teamStats(String name,List<String[]> rows,Map<String,Integer> ix){
  TeamStats t=new TeamStats();int hg=col(ix,"ft_home"),ag=col(ix,"ft_away");
  int[] hc={col(ix,"home_corners"),col(ix,"home_yellow","home_yellows","home_yellow_cards"),col(ix,"home_fouls"),col(ix,"home_target","home_shots_on_target","home_sot")};
  int[] ac={col(ix,"away_corners"),col(ix,"away_yellow","away_yellows","away_yellow_cards"),col(ix,"away_fouls"),col(ix,"away_target","away_shots_on_target","away_sot")};
  for(int j=rows.size()-1;j>=1&&t.matches<10;j--){String[] x=rows.get(j);String h=val(x,ix,"home"),a=val(x,ix,"away");if(!name.equalsIgnoreCase(h)&&!name.equalsIgnoreCase(a))continue;
   Double gh=num(x,hg),ga=num(x,ag);if(gh==null||ga==null)continue;t.goals.add(gh+ga);t.matches++;
   for(int k=0;k<4;k++){Double hv=num(x,hc[k]),av=num(x,ac[k]);if(hv!=null&&av!=null)t.markets[k].add(hv+av);}
  }return t;
 }
 double average(ArrayList<Double> values){if(values.size()==0)return Double.NaN;double s=0;for(double v:values)s+=v;return s/values.size();}
 String recommendation(String title,ArrayList<Double> samples,double[] standardLines){
  if(samples.size()<8)return title+": НЕТ ПРОГНОЗА — только "+samples.size()+" матчей со статистикой.";
  double mean=average(samples),bestP=0,bestLine=0;String bestSide="";
  for(double line:standardLines){int over=0,under=0;for(double v:samples){if(v>line)over++;else if(v<line)under++;}double po=over/(double)samples.size(),pu=under/(double)samples.size();if(po>bestP){bestP=po;bestLine=line;bestSide="ТБ";}if(pu>bestP){bestP=pu;bestLine=line;bestSide="ТМ";}}
  if(bestP<0.65)return title+": ПРОПУСТИТЬ — нет достаточного перевеса. Среднее "+fmt(mean,1)+", выборка "+samples.size()+".";
  return title+": "+bestSide+" "+String.format(Locale.US,"%.1f",bestLine)+" · исторический проход "+Math.round(bestP*100)+"% матчей выборки · среднее "+fmt(mean,1)+" · выборка "+samples.size()+".";
 }

 String report(String home,String away,List<String[]> rows){
  if(rows.size()<2)return "⚠️ Недостаточно завершённых матчей для анализа.";
  Map<String,Integer> ix=index(rows.get(0));
  TeamStats h=teamStats(home,rows,ix),a=teamStats(away,rows,ix);
  if(h.matches<3||a.matches<3)return "⚠️ Недостаточно истории даже для предварительного анализа: "+home+" — "+h.matches+", "+away+" — "+a.matches+". Нужно хотя бы 3 матча на команду.";
  StringBuilder b=new StringBuilder();
  b.append("⚽ ПРОГНОЗ НА МАТЧ\n").append(home).append(" — ").append(away).append("\n\n");
  b.append("📊 ОБЩАЯ ФОРМА КОМАНД\n");
  b.append("Последние матчи: ").append(home).append(" — ").append(h.matches).append(", ").append(away).append(" — ").append(a.matches).append(".\n");
  if(h.matches<5||a.matches<5)b.append("⚠️ Внимание: выборка небольшая, выводы предварительные.\n");
  b.append("Рекомендации выбираются по частоте прохода тотала в исторической выборке.\n\n");
  ArrayList<Double> goals=new ArrayList<>();goals.addAll(h.goals);goals.addAll(a.goals);
  b.append("⚽ ГОЛЫ\n");
  b.append("Среднее за матч: ").append(home).append(" — ").append(fmt(average(h.goals),1)).append(", ").append(away).append(" — ").append(fmt(average(a.goals),1)).append(".\n");
  b.append(recommendation("🎯 Рекомендация",goals,new double[]{0.5,1.5,2.5,3.5,4.5,5.5})).append("\n\n");
  String[] titles={"🚩 УГЛОВЫЕ","🟨 ЖЁЛТЫЕ КАРТОЧКИ","🤼 ФОЛЫ","🥅 УДАРЫ В СТВОР"};
  double[][] lines={{6.5,7.5,8.5,9.5,10.5,11.5,12.5,13.5},{1.5,2.5,3.5,4.5,5.5,6.5,7.5},{15.5,17.5,19.5,21.5,23.5,25.5,27.5,29.5},{4.5,5.5,6.5,7.5,8.5,9.5,10.5,11.5,12.5}};
  for(int k=0;k<4;k++){
   ArrayList<Double> samples=new ArrayList<>();samples.addAll(h.markets[k]);samples.addAll(a.markets[k]);
   b.append(titles[k]).append("\n");
   b.append("Среднее: ").append(home).append(" — ").append(fmt(average(h.markets[k]),1)).append(", ").append(away).append(" — ").append(fmt(average(a.markets[k]),1)).append(".\n");
   b.append(recommendation("🎯 Рекомендация",samples,lines[k])).append("\n\n");
  }
  // Head-to-head within the selected competition's available season history.
  ArrayList<Double> hg2h=new ArrayList<>();
  ArrayList<Double>[] h2hMarkets=new ArrayList[4];
  for(int k=0;k<4;k++)h2hMarkets[k]=new ArrayList<>();
  int h2hCount=0;
  int[] homeCols={col(ix,"home_corners"),col(ix,"home_yellow"),col(ix,"home_fouls"),col(ix,"home_target")};
  int[] awayCols={col(ix,"away_corners"),col(ix,"away_yellow"),col(ix,"away_fouls"),col(ix,"away_target")};
  for(int j=1;j<rows.size();j++){
   String[] row=rows.get(j);
   String rh=val(row,ix,"home"),ra=val(row,ix,"away");
   if(!((home.equalsIgnoreCase(rh)&&away.equalsIgnoreCase(ra))||(home.equalsIgnoreCase(ra)&&away.equalsIgnoreCase(rh))))continue;
   Double gh=num(row,col(ix,"ft_home")),ga=num(row,col(ix,"ft_away"));
   if(gh==null||ga==null)continue;
   hg2h.add(gh+ga);h2hCount++;
   for(int k=0;k<4;k++){Double x=num(row,homeCols[k]),y=num(row,awayCols[k]);if(x!=null&&y!=null)h2hMarkets[k].add(x+y);}
  }
  b.append("🤝 ОЧНЫЕ ВСТРЕЧИ\n");
  if(h2hCount==0)b.append("В доступной базе выбранного турнира очные встречи не найдены. Это не означает, что их не было.\n");
  else{
   b.append("Найдено очных матчей: ").append(h2hCount).append(".\n");
   b.append("⚽ Голы: среднее ").append(fmt(average(hg2h),1)).append(".\n");
   b.append(recommendation("🎯 Тотал голов",hg2h,new double[]{0.5,1.5,2.5,3.5,4.5,5.5})).append("\n");
   String[] hn={"🚩 Угловые","🟨 Жёлтые","🤼 Фолы","🥅 Удары в створ"};
   for(int k=0;k<4;k++){
    b.append(hn[k]).append(": среднее ").append(fmt(average(h2hMarkets[k]),1)).append(".\n");
    b.append(recommendation("🎯 Тотал",h2hMarkets[k],lines[k])).append("\n");
   }
  }
  b.append("\nℹ️ Процент показывает, как часто выбранный вариант проходил в доступных прошлых матчах. Это не гарантия результата. Пустая статистика не считается нулём.");
  return b.toString();
 }
 String fmt(double a,int n){return String.format(Locale.US,"%.1f",a/n);}
 public void onDestroy(){super.onDestroy();worker.shutdownNow();}
}
