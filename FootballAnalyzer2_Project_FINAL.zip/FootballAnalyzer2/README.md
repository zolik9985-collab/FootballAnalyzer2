# Football Analyzer 2
Android application for 2026/27 fixtures and recent team form.

Data source: [open-matchday](https://github.com/oladeeayo/open-matchday).
Free CSV data, refreshed daily, not live. Detailed stats are incomplete and league-dependent; blanks are unavailable, not zero. Personal informational use only; attribution required. Review upstream disclaimer and non-commercial terms.

Push to `main` to build. Download the APK from GitHub Actions → successful run → Artifacts.
