package com.footballanalyzer2;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.AlertDialog;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.widget.*;
import android.content.SharedPreferences;
import java.net.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;
import org.json.*;

public class MainActivity extends Activity {
    private static final String RAW = "https://raw.githubusercontent.com/oladeeayo/open-matchday/master/data/";
    private static final String CDN = "https://cdn.jsdelivr.net/gh/oladeeayo/open-matchday@master/data/";
    private static final String SEASON = "2627";
    private static final int BG = 0xff06120d, GREEN = 0xff35d879, PANEL = 0xff12251b, MUTED = 0xff9bb4a5;

    private static class League {
        final String title, folder;
        League(String title, String folder) { this.title = title; this.folder = folder; }
        public String toString() { return title; }
    }

    // Only competitions confirmed in the public open-matchday index are listed.
    private final League[] leagues = new League[] {
        new League("🏆 Лига чемпионов UEFA", "UEFA_1_champions-league"),
        new League("🏆 Лига Европы UEFA", "UEFA_1_europa-league"),
        new League("🏆 Лига конференций UEFA", "UEFA_1_conference-league"),
        new League("🌍 Лига наций UEFA", "UEFA_NATIONS_LEAGUE"),
        new League("Англия · FA Cup", "ENG_CUP_fa-cup"),
        new League("Англия · EFL Cup", "ENG_CUP_efl-cup"),
        new League("Испания · Copa del Rey", "ESP_CUP_copa-del-rey"),
        new League("Италия · Coppa Italia", "ITA_CUP_coppa-italia"),
        new League("Германия · DFB-Pokal", "GER_CUP_dfb-pokal"),
        new League("Нидерланды · KNVB Beker", "NED_CUP_knvb-beker"),
        new League("Англия · Premier League", "ENG_1_premier-league"),
        new League("Испания · La Liga", "ESP_1_la-liga"),
        new League("Германия · Bundesliga", "GER_1_bundesliga"),
        new League("Италия · Serie A", "ITA_1_serie-a"),
        new League("Франция · Ligue 1", "FRA_1_ligue-1"),
        new League("Нидерланды · Eredivisie", "NED_1_eredivisie"),
        new League("Португалия · Primeira Liga", "POR_1_primeira-liga"),
        new League("Бельгия · Pro League", "BEL_1_pro-league"),
        new League("Турция · Süper Lig", "TUR_1_super-lig"),
        new League("Греция · Super League", "GRE_1_super-league"),
        new League("Россия · Премьер-лига", "RUS_1_premier-liga"),
        new League("Украина · Премьер-лига", "UKR_1_premier-league"),
        new League("Норвегия · Eliteserien", "NOR_1_eliteserien"),
        new League("Шотландия · Premiership", "SCO_1_premiership"),
        new League("Польша · Ekstraklasa", "POL_1_ekstraklasa"),
        new League("Англия · Championship", "ENG_2_championship"),
        new League("Англия · League One", "ENG_3_league-one"),
        new League("Англия · League Two", "ENG_4_league-two"),
        new League("Шотландия · Championship", "SCO_2_championship"),
        new League("Шотландия · League One", "SCO_3_league-one"),
        new League("Шотландия · League Two", "SCO_4_league-two"),
        new League("Шотландия · Кубок", "SCO_CUP_scottish-cup"),
        new League("Шотландия · Кубок лиги", "SCO_CUP_league-cup"),
        new League("Португалия · Кубок", "POR_CUP_taca-de-portugal"),
        new League("Австрия · Bundesliga", "AUT_1_bundesliga"),
        new League("Австрия · Кубок", "AUT_CUP_ofb-cup"),
        new League("Швейцария · Super League", "SUI_1_super-league"),
        new League("Швейцария · Кубок", "SUI_CUP_swiss-cup"),
        new League("Дания · Superliga", "DEN_1_superliga"),
        new League("Швеция · Allsvenskan", "SWE_1_allsvenskan"),
        new League("Румыния · Liga I", "ROU_1_liga-1"),
        new League("Ирландия · First Division", "IRE_2_first-division"),
        new League("Ирландия · National League", "IRE_3_national-league"),
        new League("Польша · I Liga", "POL_2_division-1"),
        new League("Польша · II Liga", "POL_3_division-2"),
        new League("Бельгия · U21 Pro League", "BEL_U21_pro-league"),
        new League("Уэльс · Cymru Premier", "WAL_1_cymru-premier"),
        new League("Уэльс · Cymru North", "WAL_2_cymru-north"),
        new League("Уэльс · Cymru South", "WAL_3_cymru-south"),
        new League("Хорватия · HNL", "CRO_1_hnl"),
        new League("Чехия · Chance Liga", "CZE_1_chance-liga"),
        new League("Кипр · First Division", "CYP_1_first-division"),
        new League("Словакия · Nike Liga", "SVK_1_nike-liga"),
        new League("Словения · Prva Liga", "SVN_1_prva-liga"),
        new League("Финляндия · Veikkausliiga", "FIN_1_veikkausliiga"),
        new League("Казахстан · Премьер-лига", "KAZ_1_premier-league"),
        new League("Испания · Segunda División", "ESP_2_segunda-division"),
        new League("Италия · Serie B", "ITA_2_serie-b"),
        new League("Франция · Ligue 2", "FRA_2_ligue-2"),
        new League("Нидерланды · Eerste Divisie", "NED_2_eerste-divisie"),
        new League("Бразилия · Série A", "BRA_1_serie-a"),
        new League("Бразилия · Série B", "BRA_2_serie-b"),
        new League("Аргентина · Liga Profesional", "ARG_1_liga-profesional"),
        new League("Аргентина · Primera Nacional", "ARG_2_primera-nacional"),
        new League("Мексика · Liga MX", "MEX_1_liga-mx"),
        new League("Мексика · Liga de Expansión", "MEX_2_liga-expansion"),
        new League("США · MLS", "USA_1_mls"),
        new League("Япония · J1 League", "JPN_1_j1-league"),
        new League("Австралия · A-League", "AUS_1_a-league"),
        new League("Китай · Super League", "CHN_1_super-league")
    };

    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final Handler ui = new Handler(Looper.getMainLooper());
    private LinearLayout root, cards;
    private TextView status, selectedDateText;
    private Spinner leagueSpinner;
    private SharedPreferences apiPrefs;
    private EditText apiKeyField;
    private int selectedLeague = 0;
    private String mode = "today";
    private String chosenDate;
    private boolean dateWasChosen = false;

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density); }
    private GradientDrawable shape(int color, int radius) { GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d; }
    private TextView label(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(null, Typeface.BOLD); return t;
    }
    private LinearLayout.LayoutParams lp(int top, int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.setMargins(0, dp(top), 0, dp(bottom)); return p;
    }
    private Button button(String s) {
        Button b = new Button(this); b.setText(s); b.setAllCaps(false); b.setTextColor(BG); b.setTextSize(16); b.setTypeface(null, Typeface.BOLD); b.setBackground(shape(GREEN, 13)); return b;
    }
    private String today() { return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date()); }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG);
        chosenDate = today();
        apiPrefs = getSharedPreferences("football_analyzer", MODE_PRIVATE);
        buildUi();
        loadFixtures();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(22), dp(18), dp(28)); root.setBackgroundColor(BG);
        scroll.addView(root); setContentView(scroll);

        root.addView(label("⚽ FOOTBALL ANALYZER 4.0", 25, GREEN, true));
        root.addView(label("Матчи · статистика open-matchday + ESPN + API-Football", 14, 0xffb8c9bf, true), lp(4, 12));

        root.addView(label("🔑 API-FOOTBALL — КЛЮЧ ДЛЯ СТАТИСТИКИ", 14, GREEN, true), lp(2, 6));
        apiKeyField = new EditText(this);
        apiKeyField.setSingleLine(true);
        apiKeyField.setTextSize(14);
        apiKeyField.setTextColor(Color.WHITE);
        apiKeyField.setHintTextColor(MUTED);
        apiKeyField.setHint("Вставь сюда API-Football ключ");
        apiKeyField.setInputType(129);
        apiKeyField.setPadding(dp(13), dp(8), dp(13), dp(8));
        apiKeyField.setBackground(shape(PANEL, 12));
        apiKeyField.setText(apiPrefs.getString("api_football_key", ""));
        root.addView(apiKeyField, lp(0, 6));

        LinearLayout keyButtons = new LinearLayout(this);
        Button saveKey = button("СОХРАНИТЬ КЛЮЧ");
        Button testKey = button("ПРОВЕРИТЬ КЛЮЧ");
        LinearLayout.LayoutParams keyButtonParams = new LinearLayout.LayoutParams(0, dp(46), 1);
        keyButtonParams.setMargins(dp(2), 0, dp(2), 0);
        keyButtons.addView(saveKey, keyButtonParams);
        LinearLayout.LayoutParams testParams = new LinearLayout.LayoutParams(0, dp(46), 1);
        testParams.setMargins(dp(2), 0, dp(2), 0);
        keyButtons.addView(testKey, testParams);
        root.addView(keyButtons, lp(0, 14));
        saveKey.setOnClickListener(v -> {
            String k = apiKeyField.getText().toString().trim();
            if (k.isEmpty()) { Toast.makeText(this, "Вставь API-Football ключ", Toast.LENGTH_LONG).show(); return; }
            apiPrefs.edit().putString("api_football_key", k).apply();
            Toast.makeText(this, "Ключ сохранён на телефоне", Toast.LENGTH_LONG).show();
        });
        testKey.setOnClickListener(v -> testApiFootballKey());

        Button history = button("📅 ИСТОРИЯ СОХРАНЁННЫХ ПРОГНОЗОВ"); root.addView(history, lp(0, 8));
        history.setOnClickListener(v -> showHistory());

        root.addView(label("ВЫБЕРИ ТУРНИР", 15, GREEN, true), lp(4, 6));
        leagueSpinner = new Spinner(this);
        ArrayAdapter<League> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, leagues);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        leagueSpinner.setAdapter(adapter); leagueSpinner.setBackground(shape(PANEL, 12)); root.addView(leagueSpinner, lp(0, 12));

        LinearLayout modes = new LinearLayout(this);
        String[][] choices = {{"Сегодня", "today"}, {"Завтра", "tomorrow"}, {"Все матчи", "all"}};
        for (String[] c : choices) {
            Button b = button(c[0]); LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(48), 1); p.setMargins(dp(2), 0, dp(2), 0); modes.addView(b, p);
            b.setOnClickListener(v -> { mode = c[1]; dateWasChosen = false; loadFixtures(); });
        }
        root.addView(modes, lp(0, 8));

        Button date = button("📅 ВЫБРАТЬ ДАТУ"); root.addView(date, lp(0, 8));
        selectedDateText = label("Дата: " + chosenDate, 15, Color.WHITE, true); root.addView(selectedDateText, lp(0, 12));
        date.setOnClickListener(v -> openDatePicker());

        Button refresh = button("ОБНОВИТЬ МАТЧИ"); root.addView(refresh, lp(0, 8)); refresh.setOnClickListener(v -> loadFixtures());
        status = label("Подключаюсь к бесплатному источнику…", 14, 0xffc3d2c9, false); root.addView(status, lp(0, 10));
        cards = new LinearLayout(this); cards.setOrientation(LinearLayout.VERTICAL); root.addView(cards);
        root.addView(label("Источники: open-matchday + ESPN + API-Football (если добавлен ключ). Покрытие статистики зависит от лиги и тарифа API.", 12, 0xff879b8e, false), lp(18, 0));

        leagueSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onNothingSelected(android.widget.AdapterView<?> parent) {}
            public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) { selectedLeague = position; loadFixtures(); }
        });
    }

    private void openDatePicker() {
        Calendar c = Calendar.getInstance();
        try { c.setTime(new SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(chosenDate)); } catch (Exception ignored) {}
        DatePickerDialog dlg = new DatePickerDialog(this, (picker, y, m, d) -> {
            Calendar picked = Calendar.getInstance(); picked.set(y, m, d);
            chosenDate = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(picked.getTime());
            dateWasChosen = true; mode = "custom"; selectedDateText.setText("Дата: " + chosenDate); loadFixtures();
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH));
        dlg.show();
    }

    private String fetchWithFallback(String path) throws Exception {
        Exception last = null;
        for (String base : new String[]{RAW, CDN}) {
            HttpURLConnection conn = null;
            try {
                URL url = new URL(base + path);
                conn = (HttpURLConnection) url.openConnection();
                conn.setConnectTimeout(12000); conn.setReadTimeout(18000);
                conn.setRequestProperty("User-Agent", "FootballAnalyzer3/3.0");
                conn.setRequestProperty("Accept", "text/csv,*/*");
                int code = conn.getResponseCode();
                InputStream in = (code >= 200 && code < 300) ? conn.getInputStream() : conn.getErrorStream();
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                if (in != null) { try (InputStream stream = in) { byte[] buf = new byte[8192]; int n; while ((n = stream.read(buf)) != -1) out.write(buf, 0, n); } }
                String body = out.toString("UTF-8");
                if (code == 404) throw new FileNotFoundException("Для этого турнира файл пока не опубликован: " + path);
                if (code < 200 || code >= 300) throw new IOException("HTTP " + code + " при загрузке CSV");
                if (body.trim().isEmpty()) throw new IOException("Источник вернул пустой CSV: " + path);
                return body;
            } catch (Exception e) { last = e; }
            finally { if (conn != null) conn.disconnect(); }
        }
        throw last == null ? new IOException("Не удалось подключиться к open-matchday") : last;
    }

    private List<String[]> parseCsv(String csv) throws IOException {
        List<String[]> rows = new ArrayList<>();
        BufferedReader reader = new BufferedReader(new StringReader(csv));
        String line;
        while ((line = reader.readLine()) != null) {
            if (line.trim().isEmpty()) continue;
            ArrayList<String> cells = new ArrayList<>(); StringBuilder cell = new StringBuilder(); boolean quoted = false;
            for (int i = 0; i < line.length(); i++) {
                char ch = line.charAt(i);
                if (ch == '"') {
                    if (quoted && i + 1 < line.length() && line.charAt(i + 1) == '"') { cell.append('"'); i++; }
                    else quoted = !quoted;
                } else if (ch == ',' && !quoted) { cells.add(cell.toString()); cell.setLength(0); }
                else cell.append(ch);
            }
            cells.add(cell.toString()); rows.add(cells.toArray(new String[0]));
        }
        return rows;
    }

    private Map<String, Integer> headerIndex(String[] header) {
        Map<String, Integer> map = new HashMap<>();
        for (int i = 0; i < header.length; i++) map.put(header[i].trim().toLowerCase(Locale.US), i);
        return map;
    }
    private String val(String[] row, Map<String, Integer> ix, String key) {
        Integer i = ix.get(key.toLowerCase(Locale.US)); return i == null || i < 0 || i >= row.length ? "" : row[i].trim();
    }
    private Double number(String[] row, Map<String, Integer> ix, String key) {
        try { String s = val(row, ix, key); return s.isEmpty() ? null : Double.parseDouble(s); } catch (Exception e) { return null; }
    }

    private void loadFixtures() {
        if (status == null || cards == null) return;
        final League league = leagues[selectedLeague]; final String selectedMode = mode; final String date = chosenDate;
        status.setText("Загружаю CSV: " + league.title + "…"); cards.removeAllViews();
        worker.execute(() -> {
            try {
                if ("UEFA_NATIONS_LEAGUE".equals(league.folder)) {
                    // ESPN removed support for long YYYYMMDD-YYYYMMDD ranges (returns HTTP 400).
                    // Request each month separately using the supported YYYYMM format.
                    String target = date;
                    if (selectedMode.equals("today")) target = today();
                    else if (selectedMode.equals("tomorrow")) { Calendar cal = Calendar.getInstance(); cal.add(Calendar.DAY_OF_YEAR, 1); target = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.getTime()); }

                    LinkedHashMap<String,String[]> unique = new LinkedHashMap<>();
                    Calendar monthCursor = Calendar.getInstance();
                    monthCursor.setTime(new SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(today()));
                    int monthsBack = selectedMode.equals("all") ? 11 : 2;
                    monthCursor.add(Calendar.MONTH, -monthsBack);
                    SimpleDateFormat monthFmt = new SimpleDateFormat("yyyyMM", Locale.US);
                    for (int mi=0; mi<=monthsBack; mi++) {
                        String month = monthFmt.format(monthCursor.getTime());
                        JSONObject monthly = fetchJson("https://site.api.espn.com/apis/site/v2/sports/soccer/uefa.nations/scoreboard?dates=" + month);
                        List<String[]> monthRows = nationsRows(monthly);
                        for (int ri=1; ri<monthRows.size(); ri++) {
                            String[] r=monthRows.get(ri);
                            String eventKey = r[1] + "|" + r[3] + "|" + r[4];
                            unique.put(eventKey,r);
                        }
                        monthCursor.add(Calendar.MONTH,1);
                    }
                    // Include the chosen month too, if a custom date is outside the rolling window.
                    String targetMonth = target.replace("-","");
                    if (targetMonth.length() >= 6) {
                        String ym=targetMonth.substring(0,6);
                        boolean present=false;
                        for(String k:unique.keySet()) if(k.startsWith(ym.substring(0,4)+"-"+ym.substring(4,6))) { present=true; break; }
                        if(!present) {
                            JSONObject customMonth=fetchJson("https://site.api.espn.com/apis/site/v2/sports/soccer/uefa.nations/scoreboard?dates="+ym);
                            List<String[]> extra=nationsRows(customMonth);
                            for(int ri=1;ri<extra.size();ri++){String[] r=extra.get(ri);unique.put(r[1]+"|"+r[3]+"|"+r[4],r);}
                        }
                    }
                    List<String[]> allRows = new ArrayList<>();
                    allRows.add(new String[]{"gw","date","time","home","away","ft_home","ft_away","ft_result",
                        "home_corners","away_corners","home_yellow","away_yellow","home_target","away_target",
                        "home_shots","away_shots","home_fouls","away_fouls"});
                    allRows.addAll(unique.values());
                    List<String[]> fixtures = new ArrayList<>();
                    List<String[]> results = new ArrayList<>();
                    fixtures.add(allRows.get(0)); results.add(allRows.get(0));
                    for (int ri = 1; ri < allRows.size(); ri++) {
                        String[] r = allRows.get(ri);
                        boolean played = !r[5].isEmpty() && !r[6].isEmpty();
                        if (played) results.add(r);
                        if ((selectedMode.equals("all") && !played) || (!selectedMode.equals("all") && r[1].equals(target))) fixtures.add(r);
                    }
                    Map<String,Integer> fixIx = headerIndex(fixtures.get(0));
                    List<String[]> found = new ArrayList<>();
                    for (int fi = 1; fi < fixtures.size(); fi++) found.add(fixtures.get(fi));
                    found.sort((a,b) -> (val(a,fixIx,"date")+val(a,fixIx,"time")).compareTo(val(b,fixIx,"date")+val(b,fixIx,"time")));
                    List<String[]> finalResults = results;
                    int fixtureCount = fixtures.size()-1, resultCount = Math.max(0, results.size()-1);
                    ui.post(() -> renderMatches(league, found, finalResults, fixIx, date, selectedMode, fixtureCount, resultCount));
                    return;
                }
                String folder = league.folder + "/";
                List<String[]> fixtures = parseCsv(fetchWithFallback(folder + "fixtures_" + SEASON + ".csv"));
                List<String[]> results;
                try { results = parseCsv(fetchWithFallback(folder + "results_" + SEASON + ".csv")); }
                catch (Exception unavailable) { results = new ArrayList<>(); }
                if (fixtures.isEmpty()) throw new IOException("CSV расписания не содержит заголовка и матчей.");
                Map<String, Integer> fixIx = headerIndex(fixtures.get(0));
                if (!fixIx.containsKey("date") || !fixIx.containsKey("home") || !fixIx.containsKey("away")) throw new IOException("Неожиданный формат CSV расписания.");
                String target = date;
                if (selectedMode.equals("today")) target = today();
                else if (selectedMode.equals("tomorrow")) { Calendar cal = Calendar.getInstance(); cal.add(Calendar.DAY_OF_YEAR, 1); target = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.getTime()); }
                final String filterDate = target;
                List<String[]> found = new ArrayList<>();
                for (int i = 1; i < fixtures.size(); i++) {
                    String[] row = fixtures.get(i); String rowDate = val(row, fixIx, "date");
                    if (selectedMode.equals("all") || rowDate.equals(filterDate)) found.add(row);
                }
                found.sort((a,b) -> (val(a,fixIx,"date") + val(a,fixIx,"time")).compareTo(val(b,fixIx,"date") + val(b,fixIx,"time")));
                List<String[]> finalResults = results; int fixtureCount = fixtures.size() - 1; int resultCount = Math.max(0, results.size() - 1);
                ui.post(() -> renderMatches(league, found, finalResults, fixIx, filterDate, selectedMode, fixtureCount, resultCount));
            } catch (Exception e) {
                String message = e.getMessage() == null ? e.toString() : e.getMessage();
                ui.post(() -> { status.setText("Ошибка open-matchday: " + message); cards.removeAllViews(); });
            }
        });
    }

    private void renderMatches(League league, List<String[]> found, List<String[]> results, Map<String,Integer> fixIx,
                               String date, String selectedMode, int fixtureCount, int resultCount) {
        status.setText("open-matchday · расписание: " + fixtureCount + " · сыграно: " + resultCount + " · найдено: " + found.size());
        if (found.isEmpty()) {
            String msg = selectedMode.equals("all") ? "В опубликованном файле расписания пока нет будущих матчей." : "На " + date + " матчей в опубликованном расписании этого турнира нет. Это не ошибка API.";
            cards.addView(label(msg, 15, Color.WHITE, true), lp(8, 8));
            return;
        }
        for (String[] row : found) addMatchCard(league, row, fixIx, results);
    }

    // Дополнительный источник статистики: публичный ESPN Site API (без ключа).
    // Используется только как резерв, когда поле отсутствует в open-matchday.
    private String espnLeague(League league) {
        String f = league.folder;
        if (f.equals("UEFA_1_champions-league")) return "uefa.champions";
        if (f.equals("UEFA_1_europa-league")) return "uefa.europa";
        if (f.equals("UEFA_1_conference-league")) return "uefa.europa.conf";
        if (f.equals("UEFA_NATIONS_LEAGUE")) return "uefa.nations";
        if (f.startsWith("ENG_1_")) return "eng.1";
        if (f.startsWith("ENG_2_")) return "eng.2";
        if (f.startsWith("ENG_3_")) return "eng.3";
        if (f.startsWith("ENG_4_")) return "eng.4";
        if (f.startsWith("ESP_1_")) return "esp.1";
        if (f.startsWith("ESP_2_")) return "esp.2";
        if (f.startsWith("GER_1_")) return "ger.1";
        if (f.startsWith("ITA_1_")) return "ita.1";
        if (f.startsWith("ITA_2_")) return "ita.2";
        if (f.startsWith("FRA_1_")) return "fra.1";
        if (f.startsWith("FRA_2_")) return "fra.2";
        if (f.startsWith("NED_1_")) return "ned.1";
        if (f.startsWith("POR_1_")) return "por.1";
        if (f.startsWith("BEL_1_")) return "bel.1";
        if (f.startsWith("TUR_1_")) return "tur.1";
        if (f.startsWith("GRE_1_")) return "gre.1";
        if (f.startsWith("SCO_1_")) return "sco.1";
        if (f.startsWith("POL_1_")) return "pol.1";
        if (f.startsWith("NOR_1_")) return "nor.1";
        if (f.startsWith("AUT_1_")) return "aut.1";
        if (f.startsWith("SUI_1_")) return "sui.1";
        if (f.startsWith("DEN_1_")) return "den.1";
        if (f.startsWith("SWE_1_")) return "swe.1";
        if (f.startsWith("BRA_1_")) return "bra.1";
        if (f.startsWith("USA_1_")) return "usa.1";
        if (f.startsWith("JPN_1_")) return "jpn.1";
        if (f.startsWith("AUS_1_")) return "aus.1";
        return "";
    }

    // ESPN schedule/results adapter for UEFA Nations League (not present in open-matchday CSV registry).
    private List<String[]> nationsRows(JSONObject board) {
        List<String[]> rows = new ArrayList<>();
        rows.add(new String[]{"gw","date","time","home","away","ft_home","ft_away","ft_result",
                "home_corners","away_corners","home_yellow","away_yellow","home_target","away_target",
                "home_shots","away_shots","home_fouls","away_fouls"});
        JSONArray events = board == null ? null : board.optJSONArray("events");
        if (events == null) return rows;
        for (int i=0; i<events.length(); i++) {
            JSONObject ev = events.optJSONObject(i); if (ev == null) continue;
            JSONArray comps = ev.optJSONArray("competitions"); if (comps == null || comps.length()==0) continue;
            JSONObject comp = comps.optJSONObject(0); if (comp == null) continue;
            JSONArray sides = comp.optJSONArray("competitors"); if (sides == null) continue;
            String home="", away="", hs="", as="";
            for (int j=0; j<sides.length(); j++) {
                JSONObject side=sides.optJSONObject(j); if(side==null)continue;
                JSONObject team=side.optJSONObject("team");
                String name=team==null?"":team.optString("displayName",team.optString("name",""));
                if ("home".equalsIgnoreCase(side.optString("homeAway"))) { home=name; hs=side.optString("score",""); }
                else { away=name; as=side.optString("score",""); }
            }
            if(home.isEmpty()||away.isEmpty()) continue;
            String date=ev.optString("date","");
            if(date.length()>=10) date=date.substring(0,10);
            String time="";
            if(date.length()==10) {
                try { time=new SimpleDateFormat("HH:mm",Locale.US).format(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm",Locale.US).parse(ev.optString("date").substring(0,16))); } catch(Exception ignored) {}
            }
            String round=comp.optString("series",""); 
            String completed=comp.optJSONObject("status")==null?"":comp.optJSONObject("status").optJSONObject("type")==null?"":comp.optJSONObject("status").optJSONObject("type").optString("completed","");
            String result="";
            if(!hs.isEmpty()&&!as.isEmpty()) {
                try { int h=Integer.parseInt(hs), a=Integer.parseInt(as); result=h>a?"H":h<a?"A":"D"; } catch(Exception ignored) { hs=""; as=""; }
            }
            rows.add(new String[]{round,date,time,home,away,hs,as,result,"","","","","","","","","",""});
        }
        rows.sort((a,b)->(a[1]+a[2]).compareTo(b[1]+b[2]));
        return rows;
    }

    private JSONObject fetchJson(String urlText) throws Exception {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(urlText).openConnection();
            c.setConnectTimeout(5000); c.setReadTimeout(7000);
            c.setRequestProperty("User-Agent", "Mozilla/5.0 FootballAnalyzer/3.8");
            c.setRequestProperty("Accept", "application/json");
            int code = c.getResponseCode();
            InputStream in = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
            if (in == null) throw new IOException("ESPN HTTP " + code);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            try (InputStream stream = in) { byte[] b = new byte[8192]; int n; while ((n=stream.read(b))!=-1) out.write(b,0,n); }
            if (code < 200 || code >= 300) throw new IOException("ESPN HTTP " + code);
            return new JSONObject(out.toString("UTF-8"));
        } finally { if (c != null) c.disconnect(); }
    }

    private String normTeam(String name) {
        String n = java.text.Normalizer.normalize(name == null ? "" : name, java.text.Normalizer.Form.NFD)
                .replaceAll("\\p{M}+", "").toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", "");
        n = n.replace("fc", "").replace("afc", "").replace("cf", "");
        return n;
    }
    private boolean sameTeam(String a, String b) {
        String x=normTeam(a), y=normTeam(b);
        return !x.isEmpty() && !y.isEmpty() && (x.equals(y) || (x.length()>=3 && y.length()>=3 && (x.contains(y)||y.contains(x))));
    }
    private String statName(JSONObject stat) {
        return (stat.optString("name", "") + " " + stat.optString("displayName", "") + " " + stat.optString("abbreviation", "")).toLowerCase(Locale.ROOT).replaceAll("[^a-z]", "");
    }
    private Double espnStat(JSONArray stats, String wanted) {
        if (stats == null) return null;
        for (int i=0;i<stats.length();i++) {
            JSONObject st=stats.optJSONObject(i); if(st==null) continue;
            String n=statName(st); boolean match=false;
            if (wanted.equals("corners")) match=n.contains("woncorners")||n.equals("corners")||n.contains("cornerkicks");
            else if (wanted.equals("yellow")) match=n.contains("yellowcards")||n.equals("yellowcard");
            else if (wanted.equals("target")) match=n.contains("shotsontarget")||n.contains("shotsongoal");
            else if (wanted.equals("shots")) match=n.equals("totalshots")||n.equals("shots")||n.equals("totalshot");
            else if (wanted.equals("fouls")) match=n.contains("foulscommitted")||n.equals("fouls");
            if (match) {
                String v=st.optString("displayValue", "");
                if(v.isEmpty()) v=st.optString("value", "");
                try { return Double.parseDouble(v.replace(",", "")); } catch(Exception ignored) {}
            }
        }
        return null;
    }
    private Map<String,Double> parseEspnTeamStats(JSONObject teamBox) {
        Map<String,Double> m=new HashMap<>();
        JSONArray stats=teamBox.optJSONArray("statistics");
        for(String key:new String[]{"corners","yellow","target","shots","fouls"}) {
            Double v=espnStat(stats,key); if(v!=null)m.put(key,v);
        }
        return m;
    }
    private String matchKey(String date,String home,String away) { return date+"|"+normTeam(home)+"|"+normTeam(away); }

    private Map<String,Map<String,Double>> loadEspnFallback(League league, String home, String away, List<String[]> rows, Map<String,Integer> ix) {
        Map<String,Map<String,Double>> out=new HashMap<>();
        String slug=espnLeague(league); if(slug.isEmpty()) return out;
        LinkedHashMap<String,String[]> candidates=new LinkedHashMap<>();
        for(String team:new String[]{home,away}) {
            ArrayList<String[]> apps=new ArrayList<>();
            for(int i=1;i<rows.size();i++) { String[] r=rows.get(i); if(team.equalsIgnoreCase(val(r,ix,"home"))||team.equalsIgnoreCase(val(r,ix,"away"))) apps.add(r); }
            apps.sort((a,b)->val(b,ix,"date").compareTo(val(a,ix,"date")));
            int count=0; for(String[] r:apps) { if(count>=10)break; String key=matchKey(val(r,ix,"date"),val(r,ix,"home"),val(r,ix,"away")); candidates.put(key,r); count++; }
        }
        // Один запрос табло на весь интервал последних матчей, затем отдельные summary только для совпавших игр.
        String minDate=null,maxDate=null;
        for(String[] r:candidates.values()) { String d=val(r,ix,"date"); if(d.length()==10) { if(minDate==null||d.compareTo(minDate)<0)minDate=d; if(maxDate==null||d.compareTo(maxDate)>0)maxDate=d; } }
        JSONObject board=null;
        if(minDate!=null) try { board=fetchJson("https://site.api.espn.com/apis/site/v2/sports/soccer/"+slug+"/scoreboard?dates="+minDate.replace("-","")+"-"+maxDate.replace("-","")); } catch(Exception ignored) {}
        for(String[] r:candidates.values()) {
            String date=val(r,ix,"date"), rh=val(r,ix,"home"), ra=val(r,ix,"away");
            if(date.length()!=10 || board==null) continue;
            String key=matchKey(date,rh,ra);
            boolean need=false;
            for(String prefix:new String[]{"home_","away_"}) for(String field:new String[]{"corners","yellow","target","shots","fouls"}) if(number(r,ix,prefix+field)==null) need=true;
            if(!need) continue;
            try {
                JSONArray events=board.optJSONArray("events"); String eventId=null;
                if(events!=null) for(int ei=0;ei<events.length();ei++) {
                    JSONObject ev=events.optJSONObject(ei); if(ev==null)continue;
                    JSONArray comps=ev.optJSONArray("competitions"); if(comps==null||comps.length()==0)continue;
                    JSONArray sides=comps.optJSONObject(0).optJSONArray("competitors"); if(sides==null)continue;
                    String eh="",ea="";
                    for(int si=0;si<sides.length();si++) { JSONObject side=sides.optJSONObject(si); JSONObject t=side==null?null:side.optJSONObject("team"); if(t==null)continue; if("home".equalsIgnoreCase(side.optString("homeAway")))eh=t.optString("displayName",t.optString("name","")); else ea=t.optString("displayName",t.optString("name","")); }
                    if(sameTeam(rh,eh)&&sameTeam(ra,ea)) { eventId=ev.optString("id",null); break; }
                }
                if(eventId==null) continue;
                JSONObject summary=fetchJson("https://site.api.espn.com/apis/site/v2/sports/soccer/"+slug+"/summary?event="+eventId);
                JSONObject box=summary.optJSONObject("boxscore"); JSONArray teams=box==null?null:box.optJSONArray("teams");
                if(teams==null)continue;
                for(int ti=0;ti<teams.length();ti++) {
                    JSONObject tb=teams.optJSONObject(ti); if(tb==null)continue;
                    JSONObject t=tb.optJSONObject("team"); String tn=t==null?"":t.optString("displayName",t.optString("name",""));
                    String side=sameTeam(rh,tn)?"home":sameTeam(ra,tn)?"away":""; if(side.isEmpty())continue;
                    Map<String,Double> vals=parseEspnTeamStats(tb); if(!vals.isEmpty()) out.put(key+"|"+side,vals);
                }
            } catch(Exception ignored) { /* резервный источник может не покрывать турнир/матч */ }
        }
        return out;
    }

    private static class TeamStats {
        int played, wins, draws, losses;
        double goalsFor, goalsAgainst;
        final Map<String, ArrayList<Double>> metrics = new HashMap<>();
        void addMetric(String key, Double value) {
            if (value == null) return;
            if (!metrics.containsKey(key)) metrics.put(key, new ArrayList<>());
            metrics.get(key).add(value);
        }
        ArrayList<Double> values(String key) { return metrics.get(key); }
        double metricSum(String key) { ArrayList<Double> v=values(key); if(v==null)return 0; double s=0; for(double x:v)s+=x; return s; }
        double metricAvg(String key) { ArrayList<Double> v=values(key); return v==null||v.isEmpty()?Double.NaN:metricSum(key)/v.size(); }
        double avgGoalsFor() { return played == 0 ? 0 : goalsFor / played; }
        double avgGoalsAgainst() { return played == 0 ? 0 : goalsAgainst / played; }
        String form() { return "В-Н-П: " + wins + "-" + draws + "-" + losses; }
    }

    private void addMatchCard(League league, String[] match, Map<String,Integer> fixIx, List<String[]> resultRows) {
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(14),dp(13),dp(14),dp(13)); box.setBackground(shape(PANEL,15)); cards.addView(box,lp(0,10));
        String date = val(match,fixIx,"date"), time = val(match,fixIx,"time"), home = val(match,fixIx,"home"), away = val(match,fixIx,"away"), round = val(match,fixIx,"gw");
        box.addView(label(date + (time.isEmpty()?"":" · "+time) + (round.isEmpty()?"":" · тур "+round),12,MUTED,true));
        box.addView(label(home + " — " + away,20,Color.WHITE,true),lp(5,8));
        TextView report = label("Нажми кнопку ниже: покажу итоги последних 10 матчей, средние показатели и прогнозы тоталов.",14,0xffe1eee6,false); report.setLineSpacing(dp(3),1.0f); box.addView(report,lp(5,8));
        final String[] cachedReport = {""};
        Button analyze = button("📊 ПОЛНЫЙ АНАЛИЗ И ПРОГНОЗ"); box.addView(analyze);
        analyze.setOnClickListener(v -> {
            analyze.setEnabled(false); report.setText("Собираю статистику последних 10 матчей…");
            worker.execute(() -> {
                String text = makeReport(league, home, away, resultRows);
                ui.post(() -> { cachedReport[0] = text; report.setText(text); analyze.setEnabled(true); });
            });
        });
        Button save = button("💾 СОХРАНИТЬ АНАЛИЗ В ИСТОРИЮ"); box.addView(save,lp(7,0));
        save.setOnClickListener(v -> {
            String saved = date + " · " + league.title + "\n" + home + " — " + away + (cachedReport[0].isEmpty() ? "\nАнализ ещё не рассчитан" : "\n" + cachedReport[0]);
            saveHistory(saved); Toast.makeText(this,"Матч и анализ сохранены",Toast.LENGTH_SHORT).show();
        });
    }

    private TeamStats collectTeam(String team, List<String[]> rows, Map<String,Integer> ix, Map<String,Map<String,Double>> supplemental) {
        ArrayList<String[]> appearances = new ArrayList<>();
        for (int i=1; i<rows.size(); i++) {
            String[] r=rows.get(i);
            if (team.equalsIgnoreCase(val(r,ix,"home")) || team.equalsIgnoreCase(val(r,ix,"away"))) appearances.add(r);
        }
        appearances.sort((a,b) -> val(b,ix,"date").compareTo(val(a,ix,"date")));
        TeamStats st = new TeamStats();
        for (String[] r : appearances) {
            if (st.played >= 10) break;
            boolean atHome = team.equalsIgnoreCase(val(r,ix,"home"));
            Double gf=number(r,ix,atHome?"ft_home":"ft_away");
            Double ga=number(r,ix,atHome?"ft_away":"ft_home");
            if (gf==null || ga==null) continue;
            st.played++; st.goalsFor+=gf; st.goalsAgainst+=ga;
            if (gf>ga) st.wins++; else if (gf.equals(ga)) st.draws++; else st.losses++;
            String side = atHome ? "home" : "away";
            String key = matchKey(val(r,ix,"date"),val(r,ix,"home"),val(r,ix,"away")) + "|" + side;
            Map<String,Double> extra = supplemental == null ? null : supplemental.get(key);
            for (String metric : new String[]{"corners","yellow","target","shots","fouls"}) {
                Double value = number(r,ix,side+"_"+metric);
                if (value == null && extra != null) value = extra.get(metric);
                st.addMetric(metric,value);
            }
        }
        return st;
    }

    private String oneDecimal(double v) { return String.format(Locale.US,"%.1f",v); }
    private String metricTeamLine(String team, TeamStats st, String key) {
        ArrayList<Double> vals=st.values(key);
        if(vals==null||vals.isEmpty()) return "   " + team + ": нет опубликованных данных";
        return "   " + team + ": всего " + oneDecimal(st.metricSum(key)) + " · в среднем " + oneDecimal(st.metricAvg(key)) + " за матч (данные по " + vals.size() + " матчам)";
    }
    private String metricSection(String emoji, String title, String key, TeamStats h, TeamStats a, String home, String away) {
        return emoji + " " + title + "\n" + metricTeamLine(home,h,key) + "\n" + metricTeamLine(away,a,key) + "\n";
    }
    private String market(String title, double lambda, int line, String unit) {
        if (Double.isNaN(lambda) || lambda <= 0) return "   " + title + ": недостаточно статистики\n";
        double under=poissonCdf((int)Math.floor(line+0.5),lambda);
        return "   " + title + " — линия " + line + ".5 " + unit + "\n" +
               "      🔼 Больше: " + pct(1-under) + "   🔽 Меньше: " + pct(under) + "\n";
    }
    private double combinedAvg(TeamStats h, TeamStats a, String key) {
        if(h.values(key)==null||a.values(key)==null||h.values(key).size()<3||a.values(key).size()<3) return Double.NaN;
        return h.metricAvg(key)+a.metricAvg(key);
    }

    // API-Football key is stored locally on this device, never embedded in the APK.
    private String apiFootballKey() {
        return apiPrefs == null ? "" : apiPrefs.getString("api_football_key", "");
    }

    private JSONObject apiFootballRequest(String path) throws Exception {
        String k = apiFootballKey();
        if (k.isEmpty()) throw new IOException("Не введён API-Football ключ. Вставь его вверху приложения и нажми «Сохранить ключ».");
        HttpURLConnection c = null;
        try {
            URL url = new URL("https://v3.football.api-sports.io/" + path);
            c = (HttpURLConnection) url.openConnection();
            c.setRequestMethod("GET");
            c.setConnectTimeout(12000);
            c.setReadTimeout(18000);
            c.setRequestProperty("x-apisports-key", k);
            c.setRequestProperty("Accept", "application/json");
            int code = c.getResponseCode();
            InputStream in = (code >= 200 && code < 300) ? c.getInputStream() : c.getErrorStream();
            if (in == null) throw new IOException("API-Football HTTP " + code);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            try (InputStream stream = in) {
                byte[] buf = new byte[8192]; int n;
                while ((n = stream.read(buf)) != -1) out.write(buf, 0, n);
            }
            JSONObject j = new JSONObject(out.toString("UTF-8"));
            if (code < 200 || code >= 300) throw new IOException("API-Football HTTP " + code + ": " + j.opt("errors"));
            Object errors = j.opt("errors");
            if (errors != null && errors != JSONObject.NULL && !errors.toString().equals("{}") && !errors.toString().equals("[]"))
                throw new IOException("API-Football: " + errors.toString());
            return j;
        } finally { if (c != null) c.disconnect(); }
    }

    private void testApiFootballKey() {
        String k = apiKeyField == null ? "" : apiKeyField.getText().toString().trim();
        if (k.isEmpty()) { Toast.makeText(this, "Сначала вставь API-Football ключ", Toast.LENGTH_LONG).show(); return; }
        apiPrefs.edit().putString("api_football_key", k).apply();
        Toast.makeText(this, "Проверяю ключ…", Toast.LENGTH_SHORT).show();
        worker.execute(() -> {
            try {
                JSONObject j = apiFootballRequest("status");
                JSONObject response = j.optJSONObject("response");
                String msg = "API-Football подключён";
                if (response != null) {
                    JSONObject requests = response.optJSONObject("requests");
                    if (requests != null) msg += ". Запросов сегодня: " + requests.optInt("current") + "/" + requests.optInt("limit_day");
                }
                final String result = msg;
                ui.post(() -> Toast.makeText(this, result, Toast.LENGTH_LONG).show());
            } catch (Exception e) {
                final String msg = "Ошибка API-Football: " + e.getMessage();
                ui.post(() -> Toast.makeText(this, msg, Toast.LENGTH_LONG).show());
            }
        });
    }

    private String apiNorm(String name) {
        return java.text.Normalizer.normalize(name == null ? "" : name, java.text.Normalizer.Form.NFD)
                .replaceAll("\\p{M}+", "").toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", "");
    }

    private JSONObject apiFindTeam(String name) throws Exception {
        JSONObject j = apiFootballRequest("teams?search=" + URLEncoder.encode(name, "UTF-8"));
        JSONArray arr = j.optJSONArray("response");
        if (arr == null || arr.length() == 0) throw new IOException("API-Football не нашёл команду: " + name);
        JSONObject selected = null;
        for (int i=0; i<arr.length(); i++) {
            JSONObject team = arr.optJSONObject(i) == null ? null : arr.optJSONObject(i).optJSONObject("team");
            if (team == null) continue;
            if (name.equalsIgnoreCase(team.optString("name")) || apiNorm(name).equals(apiNorm(team.optString("name")))) {
                selected = team; break;
            }
            if (selected == null) selected = team;
        }
        if (selected == null) throw new IOException("Не удалось определить команду: " + name);
        return selected;
    }

    private Double apiStatValue(JSONArray stats, String... names) {
        if (stats == null) return null;
        for (int i=0; i<stats.length(); i++) {
            JSONObject st = stats.optJSONObject(i); if (st == null) continue;
            String type = st.optString("type", "");
            boolean wanted = false;
            for (String n : names) if (n.equalsIgnoreCase(type)) wanted = true;
            if (!wanted) continue;
            Object value = st.opt("value");
            if (value == null || value == JSONObject.NULL) return null;
            try { return Double.parseDouble(value.toString().replace("%", "").replace(",", "")); }
            catch (Exception ignored) { return null; }
        }
        return null;
    }

    private Map<String,Map<String,Double>> loadApiFootballFallback(String home, String away) {
        Map<String,Map<String,Double>> out = new HashMap<>();
        if (apiFootballKey().isEmpty()) return out;
        try {
            for (String requestedTeam : new String[]{home, away}) {
                JSONObject team = apiFindTeam(requestedTeam);
                int teamId = team.optInt("id");
                if (teamId <= 0) continue;
                int season = Calendar.getInstance().get(Calendar.YEAR);
                if (Calendar.getInstance().get(Calendar.MONTH) < Calendar.JULY) season--;
                JSONObject fixturesJson = apiFootballRequest("fixtures?team=" + teamId + "&last=10&season=" + season);
                JSONArray fixtures = fixturesJson.optJSONArray("response");
                if (fixtures == null || fixtures.length() == 0) {
                    fixturesJson = apiFootballRequest("fixtures?team=" + teamId + "&last=10&season=" + (season - 1));
                    fixtures = fixturesJson.optJSONArray("response");
                }
                if (fixtures == null) continue;
                for (int i=0; i<fixtures.length(); i++) {
                    JSONObject fixture = fixtures.optJSONObject(i); if (fixture == null) continue;
                    JSONObject fx = fixture.optJSONObject("fixture");
                    JSONObject teams = fixture.optJSONObject("teams");
                    if (fx == null || teams == null) continue;
                    int fixtureId = fx.optInt("id");
                    JSONObject ht = teams.optJSONObject("home"), at = teams.optJSONObject("away");
                    if (fixtureId <= 0 || ht == null || at == null) continue;
                    String hName = ht.optString("name"), aName = at.optString("name");
                    String date = fx.optString("date", "");
                    if (date.length() < 10) continue;
                    date = date.substring(0, 10);
                    JSONObject statJson = apiFootballRequest("fixtures/statistics?fixture=" + fixtureId);
                    JSONArray statRows = statJson.optJSONArray("response");
                    if (statRows == null) continue;
                    for (int si=0; si<statRows.length(); si++) {
                        JSONObject side = statRows.optJSONObject(si); if (side == null) continue;
                        JSONObject sideTeam = side.optJSONObject("team");
                        if (sideTeam == null) continue;
                        String sideName = sideTeam.optString("name");
                        String sideKey = apiNorm(sideName).equals(apiNorm(hName)) ? "home" :
                                apiNorm(sideName).equals(apiNorm(aName)) ? "away" : "";
                        if (sideKey.isEmpty()) continue;
                        JSONArray values = side.optJSONArray("statistics");
                        Map<String,Double> vals = new HashMap<>();
                        Double v = apiStatValue(values, "Corner Kicks", "Corners");
                        if (v != null) vals.put("corners", v);
                        v = apiStatValue(values, "Yellow Cards");
                        if (v != null) vals.put("yellow", v);
                        v = apiStatValue(values, "Shots on Goal", "Shots on Target");
                        if (v != null) vals.put("target", v);
                        v = apiStatValue(values, "Total Shots", "Shots");
                        if (v != null) vals.put("shots", v);
                        v = apiStatValue(values, "Fouls");
                        if (v != null) vals.put("fouls", v);
                        if (!vals.isEmpty()) {
                            String key = matchKey(date, hName, aName) + "|" + sideKey;
                            out.put(key, vals);
                        }
                    }
                }
            }
        } catch (Exception e) {
            // Keep other data sources usable; report the API-Football issue only in analysis text.
            if (!out.isEmpty()) return out;
        }
        return out;
    }

    private String makeReport(League league, String home, String away, List<String[]> rows) {
        if (rows == null || rows.size() < 2) return "⚠️ АНАЛИЗ НЕВОЗМОЖЕН\nНет опубликованных сыгранных матчей этой лиги.";
        Map<String,Integer> ix = headerIndex(rows.get(0));
        Map<String,Map<String,Double>> supplemental = loadEspnFallback(league,home,away,rows,ix);
        Map<String,Map<String,Double>> apiStats = loadApiFootballFallback(home, away);
        for (Map.Entry<String,Map<String,Double>> entry : apiStats.entrySet()) {
            Map<String,Double> existing = supplemental.get(entry.getKey());
            if (existing == null) supplemental.put(entry.getKey(), entry.getValue());
            else for (Map.Entry<String,Double> metric : entry.getValue().entrySet()) existing.putIfAbsent(metric.getKey(), metric.getValue());
        }
        TeamStats h=collectTeam(home,rows,ix,supplemental), a=collectTeam(away,rows,ix,supplemental);
        StringBuilder out = new StringBuilder();
        out.append("━━━━━━━━━━━━━━━━━━\n⚽ АНАЛИЗ МАТЧА\n").append(home).append(" — ").append(away).append("\n━━━━━━━━━━━━━━━━━━\n\n");
        out.append("📈 1. ГОЛЫ И ФОРМА КОМАНД\n");
        out.append("🏠 ").append(home).append("\n");
        out.append("   Сыграно матчей: ").append(h.played).append(" из 10\n");
        out.append("   Забито: ").append(oneDecimal(h.goalsFor)).append(" всего · ").append(oneDecimal(h.avgGoalsFor())).append(" за матч\n");
        out.append("   Пропущено: ").append(oneDecimal(h.goalsAgainst)).append(" всего · ").append(oneDecimal(h.avgGoalsAgainst())).append(" за матч\n");
        out.append("   Результаты: ").append(h.form()).append("\n\n");
        out.append("✈️ ").append(away).append("\n");
        out.append("   Сыграно матчей: ").append(a.played).append(" из 10\n");
        out.append("   Забито: ").append(oneDecimal(a.goalsFor)).append(" всего · ").append(oneDecimal(a.avgGoalsFor())).append(" за матч\n");
        out.append("   Пропущено: ").append(oneDecimal(a.goalsAgainst)).append(" всего · ").append(oneDecimal(a.avgGoalsAgainst())).append(" за матч\n");
        out.append("   Результаты: ").append(a.form()).append("\n\n");
        out.append("📊 2. ДЕТАЛЬНАЯ СТАТИСТИКА ПО КОМАНДАМ\n");
        out.append(metricSection("🚩","Угловые","corners",h,a,home,away)).append("\n");
        out.append(metricSection("🟨","Жёлтые карточки","yellow",h,a,home,away)).append("\n");
        out.append(metricSection("🎯","Удары в створ","target",h,a,home,away)).append("\n");
        out.append(metricSection("🥅","Все удары по воротам","shots",h,a,home,away)).append("\n");
        out.append(metricSection("🤼","Фолы","fouls",h,a,home,away)).append("\n");
        out.append("↗️ Вбрасывания из аута\n   Источник open-matchday не публикует эту статистику — цифры не подставляются.\n\n");
        out.append("🔮 3. ПРОГНОЗЫ ТОТАЛОВ НА МАТЧ\n");
        if(h.played<3||a.played<3) {
            out.append("⚠️ Для надёжного расчёта пока мало матчей: нужно минимум 3 сыгранных матча каждой команды.\n");
        } else {
            double expH=Math.max(0.1,Math.min(4.5,(h.avgGoalsFor()+a.avgGoalsAgainst())/2.0));
            double expA=Math.max(0.1,Math.min(4.5,(a.avgGoalsFor()+h.avgGoalsAgainst())/2.0));
            double[] probs=poissonOutcome(expH,expA);
            out.append("⚽ ГОЛЫ · ожидаемый счёт: ").append(home).append(" ").append(fmt(expH)).append(" : ").append(fmt(expA)).append(" ").append(away).append("\n");
            out.append("   1X2: ").append(home).append(" ").append(pct(probs[0])).append(" · ничья ").append(pct(probs[1])).append(" · ").append(away).append(" ").append(pct(probs[2])).append("\n");
            out.append(market("Тотал голов",expH+expA,2,"голов"));
            out.append(market("Тотал голов",expH+expA,3,"голов"));
            out.append("\n🚩 УГЛОВЫЕ\n").append(market("Тотал угловых",combinedAvg(h,a,"corners"),8,"угловых"));
            out.append(market("Тотал угловых",combinedAvg(h,a,"corners"),9,"угловых"));
            out.append("\n🟨 ЖЁЛТЫЕ КАРТОЧКИ\n").append(market("Тотал карточек",combinedAvg(h,a,"yellow"),3,"карточек"));
            out.append(market("Тотал карточек",combinedAvg(h,a,"yellow"),4,"карточек"));
            out.append("\n🤼 ФОЛЫ\n").append(market("Тотал фолов",combinedAvg(h,a,"fouls"),21,"фолов"));
            out.append(market("Тотал фолов",combinedAvg(h,a,"fouls"),23,"фолов"));
            out.append("\n🎯 УДАРЫ В СТВОР\n").append(market("Тотал ударов в створ",combinedAvg(h,a,"target"),7,"ударов"));
            out.append(market("Тотал ударов в створ",combinedAvg(h,a,"target"),8,"ударов"));
            out.append("\n🥅 ВСЕ УДАРЫ\n").append(market("Тотал всех ударов",combinedAvg(h,a,"shots"),21,"ударов"));
            out.append(market("Тотал всех ударов",combinedAvg(h,a,"shots"),23,"ударов"));
        }
        out.append("\n━━━━━━━━━━━━━━━━━━\nℹ️ КАК ЧИТАТЬ ПРОГНОЗ\n🔼 Больше — вероятность превышения указанной линии. 🔽 Меньше — вероятность остаться ниже неё. Это математическая оценка по средним показателям последних матчей, не гарантия и не букмекерские коэффициенты.\n");
        out.append("Сначала используются данные open-matchday; если отдельные показатели отсутствуют, приложение пытается найти их в публичном ESPN API без ключа. Если ESPN не покрывает матч или турнир, статистика остаётся пустой. Угловые, карточки, удары и фолы доступны не для всех матчей. Вбрасывания из аута в этом источнике отсутствуют.\n");
        out.append("Выборка: ").append(h.played).append(" матчей — ").append(home).append("; ").append(a.played).append(" — ").append(away).append(". Результаты open-matchday обновляются примерно раз в сутки; резервная статистика ESPN может обновляться чаще. Источники: open-matchday и ESPN.");
        return out.toString();
    }

    private double[] poissonOutcome(double lh,double la) {
        double home=0,draw=0,away=0;
        for(int i=0;i<=12;i++) for(int j=0;j<=12;j++) {
            double p=poisson(i,lh)*poisson(j,la);
            if(i>j) home+=p; else if(i==j) draw+=p; else away+=p;
        }
        double sum=home+draw+away; return new double[]{home/sum,draw/sum,away/sum};
    }
    private double poisson(int k,double lambda) { return Math.exp(-lambda)*Math.pow(lambda,k)/factorial(k); }
    private double factorial(int n) { double x=1; for(int i=2;i<=n;i++)x*=i; return x; }
    private double poissonCdf(int max,double lambda) { double p=0; for(int i=0;i<=max;i++)p+=poisson(i,lambda); return Math.max(0,Math.min(1,p)); }
    private String pct(double v) { return String.format(Locale.US,"%.0f%%",v*100); }
    private String fmt(double v) { return String.format(Locale.US,"%.2f",v); }
    private String avg(List<Double> a) { if(a==null||a.isEmpty())return "нет данных"; double s=0; for(double v:a)s+=v; return String.format(Locale.US,"%.1f",s/a.size()); }

    private void saveHistory(String item) {
        SharedPreferences p = getSharedPreferences("football_history", MODE_PRIVATE);
        try { JSONArray arr = new JSONArray(p.getString("items","[]")); arr.put(0,item); while(arr.length()>100) arr.remove(arr.length()-1); p.edit().putString("items",arr.toString()).apply(); }
        catch(Exception e) { p.edit().putString("items",new JSONArray().put(item).toString()).apply(); }
    }
    private void showHistory() {
        SharedPreferences p = getSharedPreferences("football_history", MODE_PRIVATE);
        try {
            JSONArray arr = new JSONArray(p.getString("items","[]"));
            if(arr.length()==0) { new AlertDialog.Builder(this).setTitle("История").setMessage("Пока нет сохранённых матчей.").setPositiveButton("OK",null).show(); return; }
            String[] items = new String[arr.length()]; for(int i=0;i<arr.length();i++) items[i]=arr.optString(i);
            new AlertDialog.Builder(this).setTitle("Сохранённые матчи").setItems(items,null).setPositiveButton("Закрыть",null).setNeutralButton("Очистить",(d,w)->p.edit().remove("items").apply()).show();
        } catch(Exception e) { new AlertDialog.Builder(this).setTitle("История").setMessage("Не удалось прочитать историю.").setPositiveButton("OK",null).show(); }
    }

    @Override protected void onDestroy() { super.onDestroy(); worker.shutdownNow(); }
}
