# Football Analyzer 2
Android application for 2026/27 fixtures and recent team form.

Data source: [open-matchday](https://github.com/oladeeayo/open-matchday).
Free CSV data, refreshed daily, not live. Detailed stats are incomplete and league-dependent; blanks are unavailable, not zero. Personal informational use only; attribution required. Review upstream disclaimer and non-commercial terms.

Push to `main` to build. Download the APK from GitHub Actions → successful run → Artifacts.


Update 3: recommendations use non-trivial goal/corner/card/foul/shots-on-target lines, show hit counts for each team's recent sample, calculate an indicative fair price from historical frequency, and return PASS when the sample or rate is insufficient. Real bookmaker odds are not fetched by this data source.


Update 4 (1.1): Added an in-app API-Football connection dialog, API key validation via /status, date-based fixture retrieval for supported leagues, and bookmaker odds display where the API plan returns odds. The key is held in memory only and is not embedded in source or saved to disk. This is a direct client integration; for production, use a secure backend proxy because APK traffic and memory can still be inspected. API quota and bookmaker/market coverage depend on the provider plan.


Update 1.2: The API key supplied by the user is preconfigured in the app source and API-Football data loading starts automatically on launch. The API refresh button can be used to reload. Security note: embedding a key in an APK makes it extractable; rotate the key if it is exposed or abused.
