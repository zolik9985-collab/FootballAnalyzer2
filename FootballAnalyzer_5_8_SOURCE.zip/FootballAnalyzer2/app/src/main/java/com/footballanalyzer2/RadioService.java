package com.footballanalyzer2;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

/**
 * Радио как foreground-сервис: продолжает играть после закрытия диалога, сворачивания и смахивания приложения.
 * Выключается кнопкой в приложении или кнопкой «Стоп» в уведомлении.
 */
public class RadioService extends Service {
    static final String ACTION_STOP = "com.footballanalyzer2.RADIO_STOP";
    private static final String CHANNEL_ID = "radio";
    private static final int NOTIF_ID = 4711;
    private static final int MAX_RECONNECTS = 3;

    // Состояние для интерфейса: 0 выключено, 1 подключение, 2 играет, 3 ошибка (все потоки недоступны)
    static volatile int state = 0;
    static volatile String info = "";
    static volatile Runnable listener;
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    private static final String[] URLS = {
            "http://stream.europeanhitradio.com:8000/Stream_05.aac",
            "http://stream.europeanhitradio.com:8000/Stream_03.mp3",
            "http://stream.europeanhitradio.com:8000/ehr.mp3"
    };
    private static final String[] NAMES = {"FRESH", "TOP 40", "EUROPEAN HIT RADIO"};

    private final Handler handler = new Handler(Looper.getMainLooper());
    private MediaPlayer player;
    private AudioManager audio;
    private WifiManager.WifiLock wifiLock;
    private int index = 0;
    private int reconnects = 0;
    private boolean pausedByFocus = false;
    private boolean running = false;

    private final AudioManager.OnAudioFocusChangeListener focusListener = change -> {
        if (player == null) return;
        if (change == AudioManager.AUDIOFOCUS_LOSS) {
            stopSelf();
        } else if (change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) {
            try { if (player.isPlaying()) { player.pause(); pausedByFocus = true; } } catch (Exception ignored) { }
        } else if (change == AudioManager.AUDIOFOCUS_GAIN && pausedByFocus) {
            try { player.start(); } catch (Exception ignored) { }
            pausedByFocus = false;
        }
    };

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? null : intent.getAction();
        // startForeground нужно вызвать сразу, даже если сейчас остановимся
        startForegroundCompat("Подключаюсь…");
        if (ACTION_STOP.equals(action)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (!running) {
            running = true;
            index = 0;
            reconnects = 0;
            acquireWifiLock();
            requestFocus();
            tryStream();
        }
        return START_NOT_STICKY;
    }

    private void publish(int newState, String newInfo) {
        state = newState;
        info = newInfo == null ? "" : newInfo;
        Runnable l = listener;
        if (l != null) MAIN.post(l);
    }

    private Notification buildNotification(String text) {
        Intent open = new Intent(this, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent openPi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Intent stop = new Intent(this, RadioService.class);
        stop.setAction(ACTION_STOP);
        PendingIntent stopPi = PendingIntent.getService(this, 1, stop, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "Radio", NotificationManager.IMPORTANCE_LOW);
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.createNotificationChannel(ch);
            b = new Notification.Builder(this, CHANNEL_ID);
        } else {
            b = new Notification.Builder(this);
        }
        b.setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle("📻 Football Analyzer Radio")
                .setContentText(Lang.translate(text))
                .setContentIntent(openPi)
                .setOngoing(true);
        b.addAction(android.R.drawable.ic_media_pause, Lang.translate("Выключить"), stopPi);
        return b.build();
    }

    private void startForegroundCompat(String text) {
        Notification n = buildNotification(text);
        if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        else startForeground(NOTIF_ID, n);
    }

    private void updateNotification(String text) {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.notify(NOTIF_ID, buildNotification(text));
        } catch (Exception ignored) { }
    }

    private void acquireWifiLock() {
        try {
            WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (wm != null) {
                wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "footballanalyzer:radio");
                wifiLock.acquire();
            }
        } catch (Exception ignored) { }
    }

    private void requestFocus() {
        try {
            audio = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            if (audio != null) audio.requestAudioFocus(focusListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
        } catch (Exception ignored) { }
    }

    private void releasePlayer() {
        MediaPlayer mp = player;
        player = null;
        if (mp != null) {
            try { mp.setOnPreparedListener(null); mp.setOnErrorListener(null); } catch (Exception ignored) { }
            try { mp.reset(); } catch (Exception ignored) { }
            try { mp.release(); } catch (Exception ignored) { }
        }
    }

    private void tryStream() {
        if (!running) return;
        releasePlayer();
        if (index >= URLS.length) {
            if (reconnects < MAX_RECONNECTS) {
                reconnects++;
                publish(1, "Переподключение…");
                updateNotification("Переподключение…");
                handler.postDelayed(() -> { if (running) { index = 0; tryStream(); } }, 3000);
            } else {
                publish(3, "");
                stopSelf();
            }
            return;
        }
        final int attempt = index;
        publish(1, NAMES[attempt]);
        try {
            MediaPlayer mp = new MediaPlayer();
            player = mp;
            mp.setAudioAttributes(new AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .setUsage(AudioAttributes.USAGE_MEDIA).build());
            mp.setWakeMode(getApplicationContext(), android.os.PowerManager.PARTIAL_WAKE_LOCK);
            mp.setDataSource(URLS[attempt]);
            mp.setOnPreparedListener(m -> {
                if (player != m || !running) return;
                m.start();
                reconnects = 0;
                publish(2, NAMES[attempt]);
                updateNotification("Играет: " + NAMES[attempt]);
            });
            mp.setOnErrorListener((m, what, extra) -> {
                if (player != m || !running) return true;
                index = attempt + 1;
                tryStream();
                return true;
            });
            mp.prepareAsync();
        } catch (Exception e) {
            index = attempt + 1;
            tryStream();
        }
    }

    @Override public void onDestroy() {
        running = false;
        handler.removeCallbacksAndMessages(null);
        releasePlayer();
        try { if (wifiLock != null && wifiLock.isHeld()) wifiLock.release(); } catch (Exception ignored) { }
        try { if (audio != null) audio.abandonAudioFocus(focusListener); } catch (Exception ignored) { }
        stopForeground(true);
        if (state != 3) publish(0, "");
        super.onDestroy();
    }
}
