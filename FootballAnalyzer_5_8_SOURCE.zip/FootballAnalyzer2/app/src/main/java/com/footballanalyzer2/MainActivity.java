package com.footballanalyzer2;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.AlertDialog;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.text.TextUtils;
import android.widget.*;
import android.content.SharedPreferences;
import java.net.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.text.Normalizer;
import java.util.*;
import java.util.concurrent.*;
import org.json.*;

public class MainActivity extends Activity {
    private TextView radioBtn, radioInfo;
    private TextView[] chips;
    private static final String RAW = "https://raw.githubusercontent.com/oladeeayo/open-matchday/master/data/";
    private static final String CDN = "https://cdn.jsdelivr.net/gh/oladeeayo/open-matchday@master/data/";
    private static final int BG = 0xff0b1722, GREEN = 0xff35d879, PANEL = 0xff132434, PANEL2 = 0xff1b3248, MUTED = 0xff8aa0b4;

    // Лиги, где open-matchday публикует угловые, карточки, удары и фолы (проверено по данным репозитория)
    private static final Set<String> STATS_FOLDERS = new HashSet<>(Arrays.asList(
        "ENG_1_premier-league","ESP_1_la-liga","GER_1_bundesliga","ITA_1_serie-a","FRA_1_ligue-1","NED_1_eredivisie",
        "POR_1_primeira-liga","BEL_1_pro-league","TUR_1_super-lig","GRE_1_super-league","SCO_1_premiership",
        "ENG_2_championship","ENG_3_league-one","ENG_4_league-two","SCO_2_championship","SCO_3_league-one","SCO_4_league-two"));

    private static class League {
        final String title, folder;
        League(String title, String folder) { this.title = title; this.folder = folder; }
        public String toString() { return Lang.translate(title) + (STATS_FOLDERS.contains(folder) ? "  📊" : ""); }
    }

    // Only competitions confirmed in the public open-matchday index are listed.
    private final League[] leagues = new League[] {
        new League("🏆 Лига чемпионов UEFA", "UEFA_1_champions-league"),
        new League("🏆 Лига Европы UEFA", "UEFA_1_europa-league"),
        new League("🏆 Лига конференций UEFA", "UEFA_1_conference-league"),
        new League("🌍 Лига наций UEFA", "UEFA_NATIONS_LEAGUE"),
        new League("Англия · FA Cup", "ENG_CUP_fa-cup"),
        new League("Англия · EFL Cup", "ENG_CUP_efl-cup"),
        new League("Испания · Copa del Rey", "ESP_CUP_copa-del-rey"),
        new League("Италия · Coppa Italia", "ITA_CUP_coppa-italia"),
        new League("Германия · DFB-Pokal", "GER_CUP_dfb-pokal"),
        new League("Нидерланды · KNVB Beker", "NED_CUP_knvb-beker"),
        new League("Англия · Premier League", "ENG_1_premier-league"),
        new League("Испания · La Liga", "ESP_1_la-liga"),
        new League("Германия · Bundesliga", "GER_1_bundesliga"),
        new League("Италия · Serie A", "ITA_1_serie-a"),
        new League("Франция · Ligue 1", "FRA_1_ligue-1"),
        new League("Нидерланды · Eredivisie", "NED_1_eredivisie"),
        new League("Португалия · Primeira Liga", "POR_1_primeira-liga"),
        new League("Бельгия · Pro League", "BEL_1_pro-league"),
        new League("Турция · Süper Lig", "TUR_1_super-lig"),
        new League("Греция · Super League", "GRE_1_super-league"),
        new League("Россия · Премьер-лига", "RUS_1_premier-liga"),
        new League("Украина · Премьер-лига", "UKR_1_premier-league"),
        new League("Норвегия · Eliteserien", "NOR_1_eliteserien"),
        new League("Шотландия · Premiership", "SCO_1_premiership"),
        new League("Польша · Ekstraklasa", "POL_1_ekstraklasa"),
        new League("Англия · Championship", "ENG_2_championship"),
        new League("Англия · League One", "ENG_3_league-one"),
        new League("Англия · League Two", "ENG_4_league-two"),
        new League("Шотландия · Championship", "SCO_2_championship"),
        new League("Шотландия · League One", "SCO_3_league-one"),
        new League("Шотландия · League Two", "SCO_4_league-two"),
        new League("Шотландия · Кубок", "SCO_CUP_scottish-cup"),
        new League("Шотландия · Кубок лиги", "SCO_CUP_league-cup"),
        new League("Португалия · Кубок", "POR_CUP_taca-de-portugal"),
        new League("Австрия · Bundesliga", "AUT_1_bundesliga"),
        new League("Австрия · Кубок", "AUT_CUP_ofb-cup"),
        new League("Швейцария · Super League", "SUI_1_super-league"),
        new League("Швейцария · Кубок", "SUI_CUP_swiss-cup"),
        new League("Дания · Superliga", "DEN_1_superliga"),
        new League("Швеция · Allsvenskan", "SWE_1_allsvenskan"),
        new League("Румыния · Liga I", "ROU_1_liga-1"),
        new League("Ирландия · First Division", "IRE_2_first-division"),
        new League("Ирландия · National League", "IRE_3_national-league"),
        new League("Польша · I Liga", "POL_2_division-1"),
        new League("Польша · II Liga", "POL_3_division-2"),
        new League("Бельгия · U21 Pro League", "BEL_U21_pro-league"),
        new League("Уэльс · Cymru Premier", "WAL_1_cymru-premier"),
        new League("Уэльс · Cymru North", "WAL_2_cymru-north"),
        new League("Уэльс · Cymru South", "WAL_3_cymru-south"),
        new League("Хорватия · HNL", "CRO_1_hnl"),
        new League("Чехия · Chance Liga", "CZE_1_chance-liga"),
        new League("Кипр · First Division", "CYP_1_first-division"),
        new League("Словакия · Nike Liga", "SVK_1_nike-liga"),
        new League("Словения · Prva Liga", "SVN_1_prva-liga"),
        new League("Финляндия · Veikkausliiga", "FIN_1_veikkausliiga"),
        new League("Казахстан · Премьер-лига", "KAZ_1_premier-league"),
        new League("Испания · Segunda División", "ESP_2_segunda-division"),
        new League("Италия · Serie B", "ITA_2_serie-b"),
        new League("Франция · Ligue 2", "FRA_2_ligue-2"),
        new League("Нидерланды · Eerste Divisie", "NED_2_eerste-divisie"),
        new League("Бразилия · Série A", "BRA_1_serie-a"),
        new League("Бразилия · Série B", "BRA_2_serie-b"),
        new League("Аргентина · Liga Profesional", "ARG_1_liga-profesional"),
        new League("Аргентина · Primera Nacional", "ARG_2_primera-nacional"),
        new League("Мексика · Liga MX", "MEX_1_liga-mx"),
        new League("Мексика · Liga de Expansión", "MEX_2_liga-expansion"),
        new League("США · MLS", "USA_1_mls"),
        new League("Япония · J1 League", "JPN_1_j1-league"),
        new League("Австралия · A-League", "AUS_1_a-league"),
        new League("Китай · Super League", "CHN_1_super-league")
    };

    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final Handler ui = new Handler(Looper.getMainLooper());
    private LinearLayout root, cards;
    private TextView status, selectedDateText;
    private Spinner leagueSpinner;
    private SharedPreferences apiPrefs;
    private EditText apiKeyField;
    private Spinner matchCountSpinner;
    private int selectedMatchCount = 5;
    private volatile String apiFootballDiagnostic = "API-Football: проверка ещё не выполнялась";
    private int selectedLeague = 0;
    private String mode = "today";
    private String chosenDate;
    private boolean dateWasChosen = false;


    private String currentLanguage() { return apiPrefs.getString("app_language", "ru"); }
    private String tr(String text) { return Lang.translate(text); }
    private String translateReport(String report) { return Lang.translate(report); }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density); }
    private GradientDrawable shape(int color, int radius) { GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d; }
    private TextView label(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(tr(s)); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(null, Typeface.BOLD); return t;
    }
    private LinearLayout.LayoutParams lp(int top, int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.setMargins(0, dp(top), 0, dp(bottom)); return p;
    }
    private Button button(String s) {
        Button b = new Button(this); b.setText(tr(s)); b.setAllCaps(false); b.setTextColor(BG); b.setTextSize(15); b.setTypeface(null, Typeface.BOLD); b.setBackground(shape(GREEN, 10)); return b;
    }
    private Button smallButton(String s) {
        Button b = new Button(this); b.setText(tr(s)); b.setAllCaps(false); b.setTextColor(BG); b.setTextSize(12); b.setTypeface(null, Typeface.BOLD);
        b.setBackground(shape(GREEN, 8)); b.setPadding(dp(8), 0, dp(8), 0); b.setMinHeight(0); b.setMinimumHeight(0); b.setMinWidth(0); b.setMinimumWidth(0);
        return b;
    }
    private TextView iconButton(String glyph, View.OnClickListener l) {
        TextView t = new TextView(this); t.setText(glyph); t.setTextSize(17); t.setGravity(Gravity.CENTER); t.setTextColor(Color.WHITE);
        t.setBackground(shape(PANEL2, 10)); t.setOnClickListener(l); return t;
    }
    private LinearLayout.LayoutParams iconParams() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(38), dp(38)); p.setMargins(dp(6), 0, 0, 0); return p;
    }
    private void toast(String s) { Toast.makeText(this, tr(s), Toast.LENGTH_SHORT).show(); }
    private void setStatus(String s) { if (status != null) status.setText(tr(s)); }
    private String today() { return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date()); }

    private String effectiveDate() {
        if ("today".equals(mode)) return today();
        if ("tomorrow".equals(mode)) { Calendar c = Calendar.getInstance(); c.add(Calendar.DAY_OF_YEAR, 1); return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(c.getTime()); }
        return chosenDate;
    }

    private void styleSpinnerText(TextView t, boolean dropdown, boolean arrow) {
        t.setTextColor(Color.WHITE); t.setTextSize(14);
        if (dropdown) { t.setBackgroundColor(PANEL2); t.setPadding(dp(14), dp(10), dp(14), dp(10)); }
        else { t.setPadding(dp(12), dp(8), dp(12), dp(8)); if (arrow) t.setText(t.getText() + "  ▾"); }
    }

    private <T> ArrayAdapter<T> spinnerAdapter(T[] items, final boolean arrow) {
        return new ArrayAdapter<T>(this, android.R.layout.simple_spinner_item, items) {
            @Override public View getView(int position, View convertView, ViewGroup parent) {
                TextView t = (TextView) super.getView(position, convertView, parent); styleSpinnerText(t, false, arrow); return t;
            }
            @Override public View getDropDownView(int position, View convertView, ViewGroup parent) {
                TextView t = (TextView) super.getDropDownView(position, convertView, parent); styleSpinnerText(t, true, false); return t;
            }
        };
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG);
        chosenDate = today();
        apiPrefs = getSharedPreferences("football_analyzer", MODE_PRIVATE);
        Lang.current = apiPrefs.getString("app_language", "ru");
        buildUi();
        loadFixtures();
    }

    @Override protected void onResume() {
        super.onResume();
        RadioService.listener = () -> updateRadioUi();
        updateRadioUi();
    }

    @Override protected void onPause() {
        RadioService.listener = null;
        super.onPause();
    }

    // ---------- радио (работает в фоне через RadioService) ----------
    private void toggleRadio() {
        int st = RadioService.state;
        if (st == 1 || st == 2) {
            stopService(new Intent(this, RadioService.class));
            return;
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 77);
        Intent i = new Intent(this, RadioService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
    }

    private void updateRadioUi() {
        if (radioBtn == null || radioInfo == null) return;
        int st = RadioService.state;
        radioBtn.setText(st == 1 || st == 2 ? "⏹" : "📻");
        if (st == 0) { radioInfo.setVisibility(View.GONE); return; }
        radioInfo.setVisibility(View.VISIBLE);
        if (st == 1) radioInfo.setText(tr("📻 Подключаюсь…") + (RadioService.info.isEmpty() ? "" : " " + RadioService.info));
        else if (st == 2) radioInfo.setText(tr("📻 Играет: ") + RadioService.info + tr(" · нажми, чтобы выключить"));
        else radioInfo.setText(tr("📻 Нет соединения ни с одним потоком. Нажми, чтобы повторить."));
    }

    // ---------- меню и настройки ----------
    private void showToolsMenu() {
        String[] items = { tr("📅 История сохранённых прогнозов"), tr("🧠 Обучение и разбор ошибок") };
        new AlertDialog.Builder(this)
            .setTitle(tr("Дополнительные функции"))
            .setItems(items, (dialog, which) -> { if (which == 0) showHistory(); else if (which == 1) showLearning(); })
            .setNegativeButton(tr("Закрыть"), null)
            .show();
    }

    private void showSettings() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(18), dp(8), dp(18), dp(4));
        panel.addView(label("Язык приложения / App language", 14, GREEN, true));
        final Spinner language = new Spinner(this);
        final String[] names = {"Русский", "English", "Español", "Deutsch", "Italiano"};
        final String[] codes = {"ru", "en", "es", "de", "it"};
        language.setAdapter(spinnerAdapter(names, true));
        language.setBackground(shape(PANEL2, 10));
        String current = currentLanguage(); int selected = 0;
        for (int i = 0; i < codes.length; i++) if (codes[i].equals(current)) selected = i;
        language.setSelection(selected);
        panel.addView(language, lp(4, 0));

        panel.addView(label("API-Football key", 14, GREEN, true), lp(14, 4));
        apiKeyField = new EditText(this);
        apiKeyField.setSingleLine(true); apiKeyField.setTextSize(14);
        apiKeyField.setTextColor(Color.WHITE); apiKeyField.setHintTextColor(MUTED);
        apiKeyField.setHint(tr("Вставь сюда API-Football ключ"));
        apiKeyField.setInputType(129); apiKeyField.setPadding(dp(13), dp(8), dp(13), dp(8));
        apiKeyField.setBackground(shape(PANEL2, 10));
        apiKeyField.setText(apiPrefs.getString("api_football_key", ""));
        panel.addView(apiKeyField, lp(0, 8));

        LinearLayout actions = new LinearLayout(this);
        Button save = smallButton("СОХРАНИТЬ КЛЮЧ"), test = smallButton("ПРОВЕРИТЬ КЛЮЧ");
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(0, dp(40), 1); ap.setMargins(dp(2), 0, dp(2), 0);
        actions.addView(save, ap);
        actions.addView(test, ap);
        panel.addView(actions);
        final AlertDialog dialog = new AlertDialog.Builder(this).setTitle(tr("⚙️ НАСТРОЙКИ")).setView(panel)
            .setNegativeButton(tr("Закрыть"), null)
            .setPositiveButton(tr("Сохранить настройки"), null).create();
        save.setOnClickListener(v -> {
            String key = apiKeyField.getText().toString().trim();
            if (!key.isEmpty()) apiPrefs.edit().putString("api_football_key", key).apply();
            toast("Ключ сохранён");
        });
        test.setOnClickListener(v -> testApiFootballKey());
        dialog.setOnShowListener(v -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(w -> {
            String key = apiKeyField.getText().toString().trim();
            if (!key.isEmpty()) apiPrefs.edit().putString("api_football_key", key).apply();
            String code = codes[language.getSelectedItemPosition()];
            apiPrefs.edit().putString("app_language", code).apply();
            Lang.current = code;
            dialog.dismiss();
            buildUi();
            loadFixtures();
        }));
        dialog.show();
    }

    // ---------- главный экран (компактный, тёмно-синий стиль) ----------
    private void buildUi() {
        final ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        scroll.setOnApplyWindowInsetsListener((v, insets) -> {
            v.setPadding(0, insets.getSystemWindowInsetTop(), 0, insets.getSystemWindowInsetBottom());
            return insets;
        });
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(12), dp(10), dp(12), dp(20)); root.setBackgroundColor(BG);
        scroll.addView(root); setContentView(scroll);

        // верхняя панель
        LinearLayout bar = new LinearLayout(this); bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.addView(label("⚽ FOOTBALL ANALYZER", 17, Color.WHITE, true), new LinearLayout.LayoutParams(0, -2, 1f));
        radioBtn = iconButton("📻", v -> toggleRadio());
        bar.addView(radioBtn, iconParams());
        bar.addView(iconButton("⚙️", v -> showSettings()), iconParams());
        bar.addView(iconButton("☰", v -> showToolsMenu()), iconParams());
        root.addView(bar, lp(0, 2));
        root.addView(label("v5.8 · open-matchday · ESPN · API-Football", 10, MUTED, false), lp(0, 8));

        radioInfo = label("", 12, GREEN, true);
        radioInfo.setPadding(dp(10), dp(7), dp(10), dp(7)); radioInfo.setBackground(shape(PANEL2, 8));
        radioInfo.setVisibility(View.GONE); radioInfo.setOnClickListener(v -> toggleRadio());
        root.addView(radioInfo, lp(0, 8));

        // турнир
        leagueSpinner = new Spinner(this);
        leagueSpinner.setAdapter(spinnerAdapter(leagues, true));
        leagueSpinner.setBackground(shape(PANEL2, 10));
        leagueSpinner.setSelection(selectedLeague);
        root.addView(leagueSpinner, lp(0, 2));
        root.addView(label("📊 — в данных есть угловые, карточки, удары и фолы", 10, MUTED, false), lp(0, 8));

        // дата: компактные «чипы»
        LinearLayout chipRow = new LinearLayout(this);
        String[] chipText = {"Сегодня", "Завтра", "Все матчи", "📅"};
        final String[] chipMode = {"today", "tomorrow", "all", "custom"};
        chips = new TextView[4];
        for (int i = 0; i < 4; i++) {
            final String m = chipMode[i];
            TextView chip = new TextView(this);
            chip.setText(tr(chipText[i])); chip.setTextSize(13); chip.setGravity(Gravity.CENTER);
            chip.setTypeface(null, Typeface.BOLD); chip.setPadding(dp(4), dp(9), dp(4), dp(9));
            chip.setOnClickListener(v -> {
                if ("custom".equals(m)) { openDatePicker(); return; }
                mode = m; dateWasChosen = false; refreshChips(); loadFixtures();
            });
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, -2, i == 3 ? 1.1f : 1f); cp.setMargins(dp(2), 0, dp(2), 0);
            chipRow.addView(chip, cp); chips[i] = chip;
        }
        root.addView(chipRow, lp(0, 4));
        selectedDateText = label("", 11, MUTED, false); root.addView(selectedDateText, lp(0, 8));

        // сколько матчей брать в статистику
        LinearLayout cnt = new LinearLayout(this); cnt.setGravity(Gravity.CENTER_VERTICAL);
        cnt.addView(label("📊 Матчей для статистики (на команду)", 12, MUTED, false), new LinearLayout.LayoutParams(0, -2, 1f));
        matchCountSpinner = new Spinner(this);
        final String[] matchCountOptions = {"2", "5", "6", "8", "10"};
        final int[] counts = {2, 5, 6, 8, 10};
        matchCountSpinner.setAdapter(spinnerAdapter(matchCountOptions, true));
        matchCountSpinner.setBackground(shape(PANEL2, 10));
        selectedMatchCount = apiPrefs.getInt("analysis_match_count", 5);
        int initialCountPosition = 1;
        for (int ci = 0; ci < counts.length; ci++) if (counts[ci] == selectedMatchCount) initialCountPosition = ci;
        matchCountSpinner.setSelection(initialCountPosition);
        matchCountSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onNothingSelected(AdapterView<?> parent) {}
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedMatchCount = counts[position];
                apiPrefs.edit().putInt("analysis_match_count", selectedMatchCount).apply();
            }
        });
        cnt.addView(matchCountSpinner, new LinearLayout.LayoutParams(dp(92), dp(38)));
        root.addView(cnt, lp(0, 8));

        // статус + обновить
        LinearLayout statusRow = new LinearLayout(this); statusRow.setGravity(Gravity.CENTER_VERTICAL);
        status = label("Подключаюсь к бесплатному источнику…", 12, MUTED, false);
        statusRow.addView(status, new LinearLayout.LayoutParams(0, -2, 1f));
        statusRow.addView(iconButton("↻", v -> loadFixtures()), iconParams());
        root.addView(statusRow, lp(0, 8));

        cards = new LinearLayout(this); cards.setOrientation(LinearLayout.VERTICAL); root.addView(cards);
        root.addView(label("Источники: open-matchday + ESPN + API-Football (если добавлен ключ). Покрытие статистики зависит от лиги и тарифа API. Прогноз — оценка модели, а не гарантия.", 10, 0xff6f8498, false), lp(14, 0));

        leagueSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onNothingSelected(AdapterView<?> parent) {}
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position == selectedLeague) return;   // начальный вызов: расписание уже грузится
                selectedLeague = position; loadFixtures();
            }
        });
        refreshChips();
        updateRadioUi();
    }

    private void refreshChips() {
        if (chips == null) return;
        String[] modes = {"today", "tomorrow", "all", "custom"};
        for (int i = 0; i < chips.length; i++) {
            boolean on = modes[i].equals(mode);
            chips[i].setBackground(shape(on ? GREEN : PANEL2, 8));
            chips[i].setTextColor(on ? BG : Color.WHITE);
        }
        chips[3].setText("custom".equals(mode) ? "📅 " + chosenDate.substring(5) : "📅");
        selectedDateText.setText("all".equals(mode) ? tr("Все будущие матчи") : tr("Дата: ") + effectiveDate());
    }

    private void openDatePicker() {
        Calendar c = Calendar.getInstance();
        try { c.setTime(new SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(chosenDate)); } catch (Exception ignored) {}
        DatePickerDialog dlg = new DatePickerDialog(this, (picker, y, m, d) -> {
            Calendar picked = Calendar.getInstance(); picked.set(y, m, d);
            chosenDate = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(picked.getTime());
            dateWasChosen = true; mode = "custom"; refreshChips(); loadFixtures();
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH));
        dlg.show();
    }

    // Код сезона по дате: с июля 2026 это 2627. Если файла нет, пробуем следующий и предыдущий сезон.
    private List<String> seasonCandidates() {
        Calendar c = Calendar.getInstance();
        int start = c.get(Calendar.MONTH) >= Calendar.JULY ? c.get(Calendar.YEAR) : c.get(Calendar.YEAR) - 1;
        List<String> out = new ArrayList<>();
        for (int y : new int[]{start, start + 1, start - 1}) out.add(String.format(Locale.US, "%02d%02d", y % 100, (y + 1) % 100));
        return out;
    }

    private String fetchWithFallback(String path) throws Exception {
        Exception last = null;
        for (String base : new String[]{RAW, CDN}) {
            HttpURLConnection conn = null;
            try {
                URL url = new URL(base + path);
                conn = (HttpURLConnection) url.openConnection();
                conn.setConnectTimeout(12000); conn.setReadTimeout(18000);
                conn.setRequestProperty("User-Agent", "FootballAnalyzer3/3.0");
                conn.setRequestProperty("Accept", "text/csv,*/*");
                int code = conn.getResponseCode();
                InputStream in = (code >= 200 && code < 300) ? conn.getInputStream() : conn.getErrorStream();
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                if (in != null) { try (InputStream stream = in) { byte[] buf = new byte[8192]; int n; while ((n = stream.read(buf)) != -1) out.write(buf, 0, n); } }
                String body = out.toString("UTF-8");
                if (code == 404) throw new FileNotFoundException("Для этого турнира файл пока не опубликован: " + path);
                if (code < 200 || code >= 300) throw new IOException("HTTP " + code + " при загрузке CSV");
                if (body.trim().isEmpty()) throw new IOException("Источник вернул пустой CSV: " + path);
                return body;
            } catch (Exception e) { last = e; }
            finally { if (conn != null) conn.disconnect(); }
        }
        throw last == null ? new IOException("Не удалось подключиться к open-matchday") : last;
    }

    private List<String[]> parseCsv(String csv) throws IOException {
        List<String[]> rows = new ArrayList<>();
        BufferedReader reader = new BufferedReader(new StringReader(csv));
        String line;
        while ((line = reader.readLine()) != null) {
            if (line.trim().isEmpty()) continue;
            ArrayList<String> cells = new ArrayList<>(); StringBuilder cell = new StringBuilder(); boolean quoted = false;
            for (int i = 0; i < line.length(); i++) {
                char ch = line.charAt(i);
                if (ch == '"') {
                    if (quoted && i + 1 < line.length() && line.charAt(i + 1) == '"') { cell.append('"'); i++; }
                    else quoted = !quoted;
                } else if (ch == ',' && !quoted) { cells.add(cell.toString()); cell.setLength(0); }
                else cell.append(ch);
            }
            cells.add(cell.toString()); rows.add(cells.toArray(new String[0]));
        }
        return rows;
    }

    private Map<String, Integer> headerIndex(String[] header) {
        Map<String, Integer> map = new HashMap<>();
        for (int i = 0; i < header.length; i++) map.put(header[i].trim().toLowerCase(Locale.US), i);
        return map;
    }
    private String val(String[] row, Map<String, Integer> ix, String key) {
        Integer i = ix.get(key.toLowerCase(Locale.US)); return i == null || i < 0 || i >= row.length ? "" : row[i].trim();
    }
    private Double number(String[] row, Map<String, Integer> ix, String key) {
        try { String s = val(row, ix, key); return s.isEmpty() ? null : Double.parseDouble(s); } catch (Exception e) { return null; }
    }

    private void loadFixtures() {
        if (status == null || cards == null) return;
        final League league = leagues[selectedLeague]; final String selectedMode = mode; final String date = chosenDate;
        setStatus("Загружаю CSV: " + league.title + "…"); cards.removeAllViews();
        worker.execute(() -> {
            try {
                if ("UEFA_NATIONS_LEAGUE".equals(league.folder)) {
                    // ESPN removed support for long YYYYMMDD-YYYYMMDD ranges (returns HTTP 400).
                    // Request each month separately using the supported YYYYMM format.
                    String target = date;
                    if (selectedMode.equals("today")) target = today();
                    else if (selectedMode.equals("tomorrow")) { Calendar cal = Calendar.getInstance(); cal.add(Calendar.DAY_OF_YEAR, 1); target = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.getTime()); }

                    LinkedHashMap<String,String[]> unique = new LinkedHashMap<>();
                    Calendar monthCursor = Calendar.getInstance();
                    monthCursor.setTime(new SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(today()));
                    int monthsBack = selectedMode.equals("all") ? 11 : 2;
                    monthCursor.add(Calendar.MONTH, -monthsBack);
                    SimpleDateFormat monthFmt = new SimpleDateFormat("yyyyMM", Locale.US);
                    for (int mi=0; mi<=monthsBack; mi++) {
                        String month = monthFmt.format(monthCursor.getTime());
                        JSONObject monthly = fetchJson("https://site.api.espn.com/apis/site/v2/sports/soccer/uefa.nations/scoreboard?dates=" + month);
                        List<String[]> monthRows = nationsRows(monthly);
                        for (int ri=1; ri<monthRows.size(); ri++) {
                            String[] r=monthRows.get(ri);
                            String eventKey = r[1] + "|" + r[3] + "|" + r[4];
                            unique.put(eventKey,r);
                        }
                        monthCursor.add(Calendar.MONTH,1);
                    }
                    // Include the chosen month too, if a custom date is outside the rolling window.
                    String targetMonth = target.replace("-","");
                    if (targetMonth.length() >= 6) {
                        String ym=targetMonth.substring(0,6);
                        boolean present=false;
                        for(String k:unique.keySet()) if(k.startsWith(ym.substring(0,4)+"-"+ym.substring(4,6))) { present=true; break; }
                        if(!present) {
                            JSONObject customMonth=fetchJson("https://site.api.espn.com/apis/site/v2/sports/soccer/uefa.nations/scoreboard?dates="+ym);
                            List<String[]> extra=nationsRows(customMonth);
                            for(int ri=1;ri<extra.size();ri++){String[] r=extra.get(ri);unique.put(r[1]+"|"+r[3]+"|"+r[4],r);}
                        }
                    }
                    List<String[]> allRows = new ArrayList<>();
                    allRows.add(new String[]{"gw","date","time","home","away","ft_home","ft_away","ft_result",
                        "home_corners","away_corners","home_yellow","away_yellow","home_target","away_target",
                        "home_shots","away_shots","home_fouls","away_fouls"});
                    allRows.addAll(unique.values());
                    List<String[]> fixtures = new ArrayList<>();
                    List<String[]> results = new ArrayList<>();
                    fixtures.add(allRows.get(0)); results.add(allRows.get(0));
                    for (int ri = 1; ri < allRows.size(); ri++) {
                        String[] r = allRows.get(ri);
                        boolean played = !r[5].isEmpty() && !r[6].isEmpty();
                        if (played) results.add(r);
                        if ((selectedMode.equals("all") && !played) || (!selectedMode.equals("all") && r[1].equals(target))) fixtures.add(r);
                    }
                    Map<String,Integer> fixIx = headerIndex(fixtures.get(0));
                    List<String[]> found = new ArrayList<>();
                    for (int fi = 1; fi < fixtures.size(); fi++) found.add(fixtures.get(fi));
                    found.sort((a,b) -> (val(a,fixIx,"date")+val(a,fixIx,"time")).compareTo(val(b,fixIx,"date")+val(b,fixIx,"time")));
                    List<String[]> finalResults = results;
                    int fixtureCount = fixtures.size()-1, resultCount = Math.max(0, results.size()-1);
                    ui.post(() -> renderMatches(league, found, finalResults, fixIx, date, selectedMode, fixtureCount, resultCount));
                    return;
                }
                String folder = league.folder + "/";
                String season = null, fixturesCsv = null; Exception seasonError = null;
                for (String code : seasonCandidates()) {
                    try { fixturesCsv = fetchWithFallback(folder + "fixtures_" + code + ".csv"); season = code; break; }
                    catch (Exception e) { seasonError = e; }
                }
                if (fixturesCsv == null) throw seasonError == null ? new IOException("Не удалось загрузить расписание") : seasonError;
                List<String[]> fixtures = parseCsv(fixturesCsv);
                List<String[]> results;
                try { results = parseCsv(fetchWithFallback(folder + "results_" + season + ".csv")); }
                catch (Exception unavailable) { results = new ArrayList<>(); }
                if (fixtures.isEmpty()) throw new IOException("CSV расписания не содержит заголовка и матчей.");
                Map<String, Integer> fixIx = headerIndex(fixtures.get(0));
                if (!fixIx.containsKey("date") || !fixIx.containsKey("home") || !fixIx.containsKey("away")) throw new IOException("Неожиданный формат CSV расписания.");
                String target = date;
                if (selectedMode.equals("today")) target = today();
                else if (selectedMode.equals("tomorrow")) { Calendar cal = Calendar.getInstance(); cal.add(Calendar.DAY_OF_YEAR, 1); target = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.getTime()); }
                final String filterDate = target;
                List<String[]> found = new ArrayList<>();
                for (int i = 1; i < fixtures.size(); i++) {
                    String[] row = fixtures.get(i); String rowDate = val(row, fixIx, "date");
                    if (selectedMode.equals("all") || rowDate.equals(filterDate)) found.add(row);
                }
                found.sort((a,b) -> (val(a,fixIx,"date") + val(a,fixIx,"time")).compareTo(val(b,fixIx,"date") + val(b,fixIx,"time")));
                List<String[]> finalResults = results; int fixtureCount = fixtures.size() - 1; int resultCount = Math.max(0, results.size() - 1);
                ui.post(() -> renderMatches(league, found, finalResults, fixIx, filterDate, selectedMode, fixtureCount, resultCount));
            } catch (Exception e) {
                String message = e.getMessage() == null ? e.toString() : e.getMessage();
                ui.post(() -> { setStatus("Ошибка open-matchday: " + message); cards.removeAllViews(); });
            }
        });
    }

    private void renderMatches(League league, List<String[]> found, List<String[]> results, Map<String,Integer> fixIx,
                               String date, String selectedMode, int fixtureCount, int resultCount) {
        setStatus("open-matchday · расписание: " + fixtureCount + " · сыграно: " + resultCount + " · найдено: " + found.size());
        if (found.isEmpty()) {
            String msg = selectedMode.equals("all") ? "В опубликованном файле расписания пока нет будущих матчей." : "Матчей на дату " + date + " в опубликованном расписании этого турнира нет. Это не ошибка API.";
            cards.addView(label(msg, 15, Color.WHITE, true), lp(8, 8));
            return;
        }
        for (String[] row : found) addMatchCard(league, row, fixIx, results);
    }

    // Дополнительный источник статистики: публичный ESPN Site API (без ключа).
    // Используется только как резерв, когда поле отсутствует в open-matchday.
    // Коды лиг в публичном ESPN Site API. Если код для лиги не существует, запрос просто вернёт пустой ответ.
    private static final Map<String,String> ESPN = new HashMap<>();
    static {
        String[][] m = {
            {"UEFA_1_champions-league","uefa.champions"},{"UEFA_1_europa-league","uefa.europa"},{"UEFA_1_conference-league","uefa.europa.conf"},
            {"UEFA_NATIONS_LEAGUE","uefa.nations"},
            {"ENG_CUP_fa-cup","eng.fa"},{"ENG_CUP_efl-cup","eng.league_cup"},{"ESP_CUP_copa-del-rey","esp.copa_del_rey"},
            {"ITA_CUP_coppa-italia","ita.coppa_italia"},{"GER_CUP_dfb-pokal","ger.dfb_pokal"},{"NED_CUP_knvb-beker","ned.cup"},
            {"POR_CUP_taca-de-portugal","por.taca.portugal"},{"SCO_CUP_scottish-cup","sco.tennents"},{"SCO_CUP_league-cup","sco.cis"},
            {"ENG_1_premier-league","eng.1"},{"ESP_1_la-liga","esp.1"},{"GER_1_bundesliga","ger.1"},{"ITA_1_serie-a","ita.1"},
            {"FRA_1_ligue-1","fra.1"},{"NED_1_eredivisie","ned.1"},{"POR_1_primeira-liga","por.1"},{"BEL_1_pro-league","bel.1"},
            {"TUR_1_super-lig","tur.1"},{"GRE_1_super-league","gre.1"},{"RUS_1_premier-liga","rus.1"},{"UKR_1_premier-league","ukr.1"},
            {"NOR_1_eliteserien","nor.1"},{"SCO_1_premiership","sco.1"},{"POL_1_ekstraklasa","pol.1"},
            {"ENG_2_championship","eng.2"},{"ENG_3_league-one","eng.3"},{"ENG_4_league-two","eng.4"},
            {"SCO_2_championship","sco.2"},{"SCO_3_league-one","sco.3"},{"SCO_4_league-two","sco.4"},
            {"AUT_1_bundesliga","aut.1"},{"SUI_1_super-league","sui.1"},{"DEN_1_superliga","den.1"},{"SWE_1_allsvenskan","swe.1"},
            {"ROU_1_liga-1","rou.1"},{"CRO_1_hnl","cro.1"},{"CZE_1_chance-liga","cze.1"},{"CYP_1_first-division","cyp.1"},
            {"SVK_1_nike-liga","svk.1"},{"SVN_1_prva-liga","svn.1"},{"FIN_1_veikkausliiga","fin.1"},{"KAZ_1_premier-league","kaz.1"},
            {"ESP_2_segunda-division","esp.2"},{"ITA_2_serie-b","ita.2"},{"FRA_2_ligue-2","fra.2"},{"NED_2_eerste-divisie","ned.2"},
            {"BRA_1_serie-a","bra.1"},{"BRA_2_serie-b","bra.2"},{"ARG_1_liga-profesional","arg.1"},{"ARG_2_primera-nacional","arg.2"},
            {"MEX_1_liga-mx","mex.1"},{"USA_1_mls","usa.1"},{"JPN_1_j1-league","jpn.1"},{"AUS_1_a-league","aus.1"},{"CHN_1_super-league","chn.1"}
        };
        for (String[] e : m) ESPN.put(e[0], e[1]);
    }
    private String espnLeague(League league) { String v = ESPN.get(league.folder); return v == null ? "" : v; }

    // true, если в строке CSV не хватает хотя бы одного показателя (тогда имеет смысл спрашивать ESPN)
    private boolean missingStats(String[] r, Map<String,Integer> ix) {
        for (String m : new String[]{"corners","yellow","target","shots","fouls"})
            if (number(r, ix, "home_" + m) == null || number(r, ix, "away_" + m) == null) return true;
        return false;
    }
    private boolean noStats(TeamStats t) {
        for (String m : new String[]{"corners","yellow","target","shots","fouls"}) { ArrayList<Double> v = t.values(m); if (v != null && !v.isEmpty()) return false; }
        return true;
    }

    // ESPN schedule/results adapter for UEFA Nations League (not present in open-matchday CSV registry).
    private List<String[]> nationsRows(JSONObject board) {
        List<String[]> rows = new ArrayList<>();
        rows.add(new String[]{"gw","date","time","home","away","ft_home","ft_away","ft_result",
                "home_corners","away_corners","home_yellow","away_yellow","home_target","away_target",
                "home_shots","away_shots","home_fouls","away_fouls"});
        JSONArray events = board == null ? null : board.optJSONArray("events");
        if (events == null) return rows;
        for (int i=0; i<events.length(); i++) {
            JSONObject ev = events.optJSONObject(i); if (ev == null) continue;
            JSONArray comps = ev.optJSONArray("competitions"); if (comps == null || comps.length()==0) continue;
            JSONObject comp = comps.optJSONObject(0); if (comp == null) continue;
            JSONArray sides = comp.optJSONArray("competitors"); if (sides == null) continue;
            String home="", away="", hs="", as="";
            for (int j=0; j<sides.length(); j++) {
                JSONObject side=sides.optJSONObject(j); if(side==null)continue;
                JSONObject team=side.optJSONObject("team");
                String name=team==null?"":team.optString("displayName",team.optString("name",""));
                if ("home".equalsIgnoreCase(side.optString("homeAway"))) { home=name; hs=side.optString("score",""); }
                else { away=name; as=side.optString("score",""); }
            }
            if(home.isEmpty()||away.isEmpty()) continue;
            String date=ev.optString("date","");
            if(date.length()>=10) date=date.substring(0,10);
            String time="";
            if(date.length()==10) {
                try { time=new SimpleDateFormat("HH:mm",Locale.US).format(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm",Locale.US).parse(ev.optString("date").substring(0,16))); } catch(Exception ignored) {}
            }
            String round=comp.optString("series",""); 
            String completed=comp.optJSONObject("status")==null?"":comp.optJSONObject("status").optJSONObject("type")==null?"":comp.optJSONObject("status").optJSONObject("type").optString("completed","");
            String result="";
            if(!hs.isEmpty()&&!as.isEmpty()) {
                try { int h=Integer.parseInt(hs), a=Integer.parseInt(as); result=h>a?"H":h<a?"A":"D"; } catch(Exception ignored) { hs=""; as=""; }
            }
            rows.add(new String[]{round,date,time,home,away,hs,as,result,"","","","","","","","","",""});
        }
        List<String[]> body = new ArrayList<>(rows.subList(1, rows.size()));
        Collections.sort(body, (a,b)->(a[1]+a[2]).compareTo(b[1]+b[2]));
        rows.subList(1, rows.size()).clear();
        rows.addAll(body);
        return rows;
    }

    private JSONObject fetchJson(String urlText) throws Exception {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(urlText).openConnection();
            c.setConnectTimeout(5000); c.setReadTimeout(7000);
            c.setRequestProperty("User-Agent", "Mozilla/5.0 FootballAnalyzer/3.8");
            c.setRequestProperty("Accept", "application/json");
            int code = c.getResponseCode();
            InputStream in = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
            if (in == null) throw new IOException("ESPN HTTP " + code);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            try (InputStream stream = in) { byte[] b = new byte[8192]; int n; while ((n=stream.read(b))!=-1) out.write(b,0,n); }
            if (code < 200 || code >= 300) throw new IOException("ESPN HTTP " + code);
            return new JSONObject(out.toString("UTF-8"));
        } finally { if (c != null) c.disconnect(); }
    }

    private String normTeam(String name) {
        String n = java.text.Normalizer.normalize(name == null ? "" : name, java.text.Normalizer.Form.NFD)
                .replaceAll("\\p{M}+", "").toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", "");
        n = n.replace("fc", "").replace("afc", "").replace("cf", "");
        if (n.equals("turkiye") || n.equals("turkiyea")) n = "turkey";
        if (n.equals("czechrepublic")) n = "czechia";
        if (n.equals("korearepublic")) n = "southkorea";
        if (n.equals("iriran")) n = "iran";
        return n;
    }
    private boolean sameTeam(String a, String b) {
        String x=normTeam(a), y=normTeam(b);
        return !x.isEmpty() && !y.isEmpty() && (x.equals(y) || (x.length()>=3 && y.length()>=3 && (x.contains(y)||y.contains(x))));
    }
    private String statName(JSONObject stat) {
        return (stat.optString("name", "") + " " + stat.optString("displayName", "") + " " + stat.optString("abbreviation", "")).toLowerCase(Locale.ROOT).replaceAll("[^a-z]", "");
    }
    private Double espnStat(JSONArray stats, String wanted) {
        if (stats == null) return null;
        for (int i=0;i<stats.length();i++) {
            JSONObject st=stats.optJSONObject(i); if(st==null) continue;
            String n=statName(st); boolean match=false;
            if (wanted.equals("corners")) match=n.contains("woncorners")||n.equals("corners")||n.contains("cornerkicks");
            else if (wanted.equals("yellow")) match=n.contains("yellowcards")||n.equals("yellowcard");
            else if (wanted.equals("target")) match=n.contains("shotsontarget")||n.contains("shotsongoal");
            else if (wanted.equals("shots")) match=n.equals("totalshots")||n.equals("shots")||n.equals("totalshot");
            else if (wanted.equals("fouls")) match=n.contains("foulscommitted")||n.equals("fouls");
            if (match) {
                String v=st.optString("displayValue", "");
                if(v.isEmpty()) v=st.optString("value", "");
                try { return Double.parseDouble(v.replace(",", "")); } catch(Exception ignored) {}
            }
        }
        return null;
    }
    private Map<String,Double> parseEspnTeamStats(JSONObject teamBox) {
        Map<String,Double> m=new HashMap<>();
        JSONArray stats=teamBox.optJSONArray("statistics");
        for(String key:new String[]{"corners","yellow","target","shots","fouls"}) {
            Double v=espnStat(stats,key); if(v!=null)m.put(key,v);
        }
        return m;
    }

    // ESPN scoreboard events often include team statistics directly on competitors.
    // Use this before requesting /summary so UCL/UEL matches do not lose available data.
    private Map<String,Double> parseEspnCompetitorStats(JSONObject competitor) {
        Map<String,Double> m = new HashMap<>();
        JSONArray stats = competitor.optJSONArray("statistics");
        for (String key : new String[]{"corners","target","shots","fouls"}) {
            Double value = espnStat(stats, key);
            if (value != null) m.put(key, value);
        }
        return m;
    }

    private Map<String,Integer> parseEspnYellowCards(JSONObject event) {
        Map<String,Integer> cards = new HashMap<>();
        JSONArray competitions = event.optJSONArray("competitions");
        if (competitions == null || competitions.length() == 0) return cards;
        JSONArray competitors = competitions.optJSONObject(0).optJSONArray("competitors");
        if (competitors == null) return cards;
        String homeId = "", awayId = "";
        for (int i=0; i<competitors.length(); i++) {
            JSONObject c = competitors.optJSONObject(i);
            if (c == null) continue;
            if ("home".equalsIgnoreCase(c.optString("homeAway"))) homeId = c.optString("id","");
            else awayId = c.optString("id","");
        }
        int homeCards = 0, awayCards = 0;
        JSONArray details = event.optJSONArray("details");
        if (details == null && competitions.optJSONObject(0) != null)
            details = competitions.optJSONObject(0).optJSONArray("details");
        if (details != null) for (int i=0; i<details.length(); i++) {
            JSONObject d = details.optJSONObject(i);
            if (d == null) continue;
            boolean yellow = d.optBoolean("yellowCard", false)
                    || "Yellow Card".equalsIgnoreCase(d.optJSONObject("type") == null ? "" : d.optJSONObject("type").optString("text",""));
            if (!yellow) continue;
            JSONObject team = d.optJSONObject("team");
            String id = team == null ? "" : team.optString("id","");
            if (!homeId.isEmpty() && homeId.equals(id)) homeCards++;
            else if (!awayId.isEmpty() && awayId.equals(id)) awayCards++;
        }
        if (details == null || details.length() == 0) return cards; // no event details => unknown, not 0
        if (!homeId.isEmpty()) cards.put(homeId, homeCards);
        if (!awayId.isEmpty()) cards.put(awayId, awayCards);
        return cards;
    }
    private String matchKey(String date,String home,String away) { return date+"|"+normTeam(home)+"|"+normTeam(away); }

    private String shiftIsoDate(String isoDate, int days) {
        try {
            SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
            fmt.setTimeZone(TimeZone.getTimeZone("UTC"));
            Date d = fmt.parse(isoDate);
            Calendar c = Calendar.getInstance(TimeZone.getTimeZone("UTC"), Locale.US);
            c.setTime(d);
            c.add(Calendar.DAY_OF_MONTH, days);
            return fmt.format(c.getTime());
        } catch (Exception e) {
            return isoDate;
        }
    }

    private JSONObject findEspnEvent(JSONObject board, String rowHome, String rowAway) {
        JSONArray events = board == null ? null : board.optJSONArray("events");
        if (events == null) return null;
        for (int i=0; i<events.length(); i++) {
            JSONObject ev = events.optJSONObject(i);
            if (ev == null) continue;
            JSONArray comps = ev.optJSONArray("competitions");
            if (comps == null || comps.length()==0) continue;
            JSONObject comp = comps.optJSONObject(0);
            JSONArray sides = comp == null ? null : comp.optJSONArray("competitors");
            if (sides == null) continue;
            String eh="", ea="";
            for (int j=0; j<sides.length(); j++) {
                JSONObject side=sides.optJSONObject(j);
                JSONObject team=side==null?null:side.optJSONObject("team");
                if (team==null) continue;
                String n=team.optString("displayName",team.optString("name",""));
                if ("home".equalsIgnoreCase(side.optString("homeAway"))) eh=n; else ea=n;
            }
            if (sameTeam(rowHome,eh) && sameTeam(rowAway,ea)) return ev;
        }
        return null;
    }

    private void mergeEspnStats(Map<String,Double> target, Map<String,Double> source) {
        if (source == null) return;
        for (String k : new String[]{"corners","yellow","target","shots","fouls"}) {
            if (source.containsKey(k)) target.put(k, source.get(k));
        }
    }

    private Map<String,Map<String,Double>> loadEspnFallback(League league, String home, String away, List<String[]> rows, Map<String,Integer> ix) {
        Map<String,Map<String,Double>> out=new HashMap<>();
        String slug=espnLeague(league);
        if (slug.isEmpty()) return out;

        LinkedHashMap<String,String[]> candidates=new LinkedHashMap<>();
        for (String team : new String[]{home,away}) {
            ArrayList<String[]> apps=new ArrayList<>();
            for (int i=1;i<rows.size();i++) {
                String[] r=rows.get(i);
                if (sameTeam(team,val(r,ix,"home")) || sameTeam(team,val(r,ix,"away"))) apps.add(r);
            }
            apps.sort((a,b)->val(b,ix,"date").compareTo(val(a,ix,"date")));
            int count=0;
            for (String[] r:apps) {
                if (count>=selectedMatchCount) break;
                String k=matchKey(val(r,ix,"date"),val(r,ix,"home"),val(r,ix,"away"));
                if (missingStats(r,ix)) candidates.put(k,r);
                count++;
            }
        }

        // UEFA competitions can span many months. A single wide ESPN scoreboard
        // range is truncated/incomplete, so query each match date (free ESPN endpoint).
        Map<String,JSONObject> scoreboards = new HashMap<>();
        int misses = 0;
        for (String[] r : candidates.values()) {
            String date=val(r,ix,"date"), rh=val(r,ix,"home"), ra=val(r,ix,"away");
            if (date.length()!=10) continue;
            String key=matchKey(date,rh,ra);
            try {
                JSONObject event=null;
                for (int offset=-1; offset<=1 && event==null; offset++) {
                    String queryDate=shiftIsoDate(date,offset);
                    JSONObject board=scoreboards.get(queryDate);
                    if (board==null) {
                        board=cachedBoard(slug,queryDate.replace("-",""),queryDate.compareTo(today())<0);
                        if (board==null) board=new JSONObject();
                        scoreboards.put(queryDate,board);
                    }
                    event=findEspnEvent(board,rh,ra);
                }
                if (event==null) { misses++; if (misses>=4 && out.isEmpty()) break; continue; }

                Map<String,Map<String,Double>> perSide=new HashMap<>();
                perSide.put("home",new HashMap<String,Double>());
                perSide.put("away",new HashMap<String,Double>());

                // Read any values embedded in scoreboard competitors.
                JSONArray comps=event.optJSONArray("competitions");
                JSONArray sides=(comps==null||comps.length()==0||comps.optJSONObject(0)==null)
                        ? null : comps.optJSONObject(0).optJSONArray("competitors");
                Map<String,Integer> yellowById=parseEspnYellowCards(event);
                if (sides!=null) for (int j=0;j<sides.length();j++) {
                    JSONObject side=sides.optJSONObject(j);
                    if (side==null) continue;
                    JSONObject team=side.optJSONObject("team");
                    String teamName=team==null?"":team.optString("displayName",team.optString("name",""));
                    String sideName=sameTeam(rh,teamName)?"home":sameTeam(ra,teamName)?"away":"";
                    if (sideName.isEmpty()) continue;
                    mergeEspnStats(perSide.get(sideName),parseEspnCompetitorStats(side));
                    String teamId=side.optString("id","");
                    if (yellowById.containsKey(teamId)) perSide.get(sideName).put("yellow",(double)yellowById.get(teamId));
                }

                // Always read summary too and merge field-by-field. Previously, one
                // scoreboard value could prevent summary from filling the other metrics.
                String eventId=event.optString("id","");
                if (!eventId.isEmpty()) {
                    try {
                        JSONObject summary=fetchJson("https://site.api.espn.com/apis/site/v2/sports/soccer/"+slug+"/summary?event="+eventId);
                        JSONObject box=summary.optJSONObject("boxscore");
                        JSONArray teams=box==null?null:box.optJSONArray("teams");
                        if (teams!=null) for (int j=0;j<teams.length();j++) {
                            JSONObject tb=teams.optJSONObject(j);
                            if (tb==null) continue;
                            JSONObject t=tb.optJSONObject("team");
                            String tn=t==null?"":t.optString("displayName",t.optString("name",""));
                            String sideName=sameTeam(rh,tn)?"home":sameTeam(ra,tn)?"away":"";
                            if (!sideName.isEmpty()) mergeEspnStats(perSide.get(sideName),parseEspnTeamStats(tb));
                        }
                    } catch(Exception ignored) { }
                }

                for (String sideName : new String[]{"home","away"}) {
                    if (!perSide.get(sideName).isEmpty()) out.put(key+"|"+sideName,perSide.get(sideName));
                }
            } catch(Exception ignored) { /* ESPN may not publish stats for every match */ }
        }
        return out;
    }

    private static class TeamStats {
        int played, wins, draws, losses;
        double goalsFor, goalsAgainst;
        final Map<String, ArrayList<Double>> metrics = new HashMap<>();
        final Map<String, ArrayList<Double>> conceded = new HashMap<>();
        void addConceded(String key, Double value) { if (value == null) return; if (!conceded.containsKey(key)) conceded.put(key, new ArrayList<>()); conceded.get(key).add(value); }
        ArrayList<Double> concededValues(String key) { return conceded.get(key); }
        void addMetric(String key, Double value) {
            if (value == null) return;
            if (!metrics.containsKey(key)) metrics.put(key, new ArrayList<>());
            metrics.get(key).add(value);
        }
        ArrayList<Double> values(String key) { return metrics.get(key); }
        double metricSum(String key) { ArrayList<Double> v=values(key); if(v==null)return 0; double s=0; for(double x:v)s+=x; return s; }
        double metricAvg(String key) { ArrayList<Double> v=values(key); return v==null||v.isEmpty()?Double.NaN:metricSum(key)/v.size(); }
        double avgGoalsFor() { return played == 0 ? 0 : goalsFor / played; }
        double avgGoalsAgainst() { return played == 0 ? 0 : goalsAgainst / played; }
        String form() { return "В-Н-П: " + wins + "-" + draws + "-" + losses; }
    }

    private TextView teamLine(String name) {
        TextView t = label(name, 15, Color.WHITE, true);
        t.setSingleLine(true); t.setEllipsize(TextUtils.TruncateAt.END);
        return t;
    }

    private void addMatchCard(League league, String[] match, Map<String,Integer> fixIx, List<String[]> resultRows) {
        final LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(12), dp(9), dp(12), dp(9)); box.setBackground(shape(PANEL, 10)); cards.addView(box, lp(0, 6));
        final String date = val(match,fixIx,"date"), time = val(match,fixIx,"time"), home = val(match,fixIx,"home"), away = val(match,fixIx,"away"), round = val(match,fixIx,"gw");

        LinearLayout top = new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout teams = new LinearLayout(this); teams.setOrientation(LinearLayout.VERTICAL);
        teams.addView(label(date + (time.isEmpty() ? "" : " · " + time) + (round.isEmpty() ? "" : " · тур " + round), 11, MUTED, false));
        teams.addView(teamLine(home), lp(2, 0));
        teams.addView(teamLine(away), lp(0, 0));
        top.addView(teams, new LinearLayout.LayoutParams(0, -2, 1f));
        final Button analyze = smallButton("АНАЛИЗ");
        top.addView(analyze, new LinearLayout.LayoutParams(dp(92), dp(40)));
        box.addView(top);

        final TextView report = label("", 12, 0xffdbe7f1, false);
        report.setLineSpacing(dp(2), 1.0f); report.setPadding(0, dp(8), 0, 0); report.setVisibility(View.GONE);
        box.addView(report);
        final Button save = smallButton("💾 СОХРАНИТЬ АНАЛИЗ В ИСТОРИЮ");
        save.setVisibility(View.GONE); box.addView(save, new LinearLayout.LayoutParams(-1, dp(38)));

        final String[] cachedReport = {""};
        analyze.setOnClickListener(v -> {
            if (!cachedReport[0].isEmpty()) {            // уже рассчитан: свернуть / развернуть
                boolean show = report.getVisibility() != View.VISIBLE;
                report.setVisibility(show ? View.VISIBLE : View.GONE);
                save.setVisibility(show ? View.VISIBLE : View.GONE);
                analyze.setText(tr(show ? "СВЕРНУТЬ" : "РАЗВЕРНУТЬ"));
                return;
            }
            analyze.setEnabled(false);
            report.setVisibility(View.VISIBLE);
            report.setText(tr("Собираю статистику последних ") + selectedMatchCount + tr(" матчей…"));
            worker.execute(() -> {
                String text;
                try { text = makeReport(league, home, away, resultRows); }
                catch (Exception e) { text = tr("⚠️ Не удалось рассчитать анализ: ") + (e.getMessage() == null ? e.toString() : e.getMessage()); }
                final String finalText = text;
                ui.post(() -> {
                    cachedReport[0] = finalText; report.setText(finalText);
                    save.setVisibility(View.VISIBLE); analyze.setEnabled(true); analyze.setText(tr("СВЕРНУТЬ"));
                });
            });
        });
        save.setOnClickListener(v -> {
            String saved = date + " · " + league.title + "\n" + home + " — " + away + (cachedReport[0].isEmpty() ? "\n" + tr("Анализ ещё не рассчитан") : "\n" + cachedReport[0]);
            saveHistory(saved);
            saveLearningForecast(date, league.title, home, away, cachedReport[0]);
            toast("Матч сохранён в историю и базу обучения");
        });
    }

    private TeamStats collectTeam(String team, List<String[]> rows, Map<String,Integer> ix, Map<String,Map<String,Double>> supplemental) {
        ArrayList<String[]> appearances = new ArrayList<>();
        for (int i=1; i<rows.size(); i++) {
            String[] r=rows.get(i);
            if (team.equalsIgnoreCase(val(r,ix,"home")) || team.equalsIgnoreCase(val(r,ix,"away"))) appearances.add(r);
        }
        appearances.sort((a,b) -> val(b,ix,"date").compareTo(val(a,ix,"date")));
        TeamStats st = new TeamStats();
        for (String[] r : appearances) {
            if (st.played >= selectedMatchCount) break;
            boolean atHome = team.equalsIgnoreCase(val(r,ix,"home"));
            Double gf=number(r,ix,atHome?"ft_home":"ft_away");
            Double ga=number(r,ix,atHome?"ft_away":"ft_home");
            if (gf==null || ga==null) continue;
            st.played++; st.goalsFor+=gf; st.goalsAgainst+=ga;
            if (gf>ga) st.wins++; else if (gf.equals(ga)) st.draws++; else st.losses++;
            String side = atHome ? "home" : "away";
            String key = matchKey(val(r,ix,"date"),val(r,ix,"home"),val(r,ix,"away")) + "|" + side;
            Map<String,Double> extra = supplemental == null ? null : supplemental.get(key);
            for (String metric : new String[]{"corners","yellow","target","shots","fouls"}) {
                Double value = number(r,ix,side+"_"+metric);
                if (value == null && extra != null) value = extra.get(metric);
                st.addMetric(metric,value);
                if ("corners".equals(metric)) {
                    Double against = number(r,ix,(atHome?"away":"home")+"_corners");
                    if (against == null && supplemental != null) {
                        String otherKey = matchKey(val(r,ix,"date"),val(r,ix,"home"),val(r,ix,"away")) + "|" + (atHome?"away":"home");
                        Map<String,Double> otherExtra = supplemental.get(otherKey);
                        if (otherExtra != null) against = otherExtra.get("corners");
                    }
                    st.addConceded("corners", against);
                }
            }
        }
        return st;
    }

    // Keep the public-source statistics when API-Football has no coverage for a metric.
    // The previous implementation replaced the whole TeamStats object, which erased
    // corners/cards/shots/fouls even when open-matchday or ESPN had those values.
    private TeamStats mergeTeamStats(TeamStats fallback, TeamStats api) {
        if (api == null || api.played < 3) return fallback;
        TeamStats merged = new TeamStats();
        merged.played = api.played;
        merged.wins = api.wins;
        merged.draws = api.draws;
        merged.losses = api.losses;
        merged.goalsFor = api.goalsFor;
        merged.goalsAgainst = api.goalsAgainst;

        String[] keys = new String[]{"corners","yellow","target","shots","fouls"};
        for (String key : keys) {
            ArrayList<Double> apiValues = api.values(key);
            ArrayList<Double> fallbackValues = fallback == null ? null : fallback.values(key);
            ArrayList<Double> chosen = (apiValues != null && apiValues.size() >= 3)
                    ? apiValues : fallbackValues;
            if (chosen != null) {
                for (Double value : chosen) merged.addMetric(key, value);
            }
            if ("corners".equals(key)) {
                ArrayList<Double> apiAgainst = api.concededValues(key);
                ArrayList<Double> fallbackAgainst = fallback == null ? null : fallback.concededValues(key);
                ArrayList<Double> chosenAgainst = (apiAgainst != null && apiAgainst.size() >= 3) ? apiAgainst : fallbackAgainst;
                if (chosenAgainst != null) for (Double value : chosenAgainst) merged.addConceded(key, value);
            }
        }
        return merged;
    }

    private String oneDecimal(double v) { return String.format(Locale.US,"%.1f",v); }
    private String metricTeamLine(String team, TeamStats st, String key) {
        ArrayList<Double> vals=st.values(key);
        if(vals==null||vals.isEmpty()) return "   " + team + ": нет опубликованных данных";
        return "   " + team + ": всего " + oneDecimal(st.metricSum(key)) + " · в среднем " + oneDecimal(st.metricAvg(key)) + " за матч (данные по " + vals.size() + " матчам)";
    }
    private String metricSection(String emoji, String title, String key, TeamStats h, TeamStats a, String home, String away) {
        return emoji + " " + title + "\n" + metricTeamLine(home,h,key) + "\n" + metricTeamLine(away,a,key) + "\n";
    }

    private double mean(ArrayList<Double> values) {
        double sum = 0; for (double v : values) sum += v; return sum / values.size();
    }


    // API-Football key is stored locally on this device, never embedded in the APK.
    private String apiFootballKey() {
        return apiPrefs == null ? "" : apiPrefs.getString("api_football_key", "");
    }

    private JSONObject apiFootballRequest(String path) throws Exception {
        String k = apiFootballKey();
        if (k.isEmpty()) throw new IOException("Не введён API-Football ключ. Вставь его вверху приложения и нажми «Сохранить ключ».");
        HttpURLConnection c = null;
        try {
            URL url = new URL("https://v3.football.api-sports.io/" + path);
            c = (HttpURLConnection) url.openConnection();
            c.setRequestMethod("GET");
            c.setConnectTimeout(12000);
            c.setReadTimeout(18000);
            c.setRequestProperty("x-apisports-key", k);
            c.setRequestProperty("Accept", "application/json");
            int code = c.getResponseCode();
            InputStream in = (code >= 200 && code < 300) ? c.getInputStream() : c.getErrorStream();
            if (in == null) throw new IOException("API-Football HTTP " + code);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            try (InputStream stream = in) {
                byte[] buf = new byte[8192]; int n;
                while ((n = stream.read(buf)) != -1) out.write(buf, 0, n);
            }
            JSONObject j = new JSONObject(out.toString("UTF-8"));
            if (code < 200 || code >= 300) throw new IOException("API-Football HTTP " + code + ": " + j.opt("errors"));
            Object errors = j.opt("errors");
            if (errors != null && errors != JSONObject.NULL && !errors.toString().equals("{}") && !errors.toString().equals("[]"))
                throw new IOException("API-Football: " + errors.toString());
            return j;
        } finally { if (c != null) c.disconnect(); }
    }

    private void testApiFootballKey() {
        String k = apiKeyField == null ? "" : apiKeyField.getText().toString().trim();
        if (k.isEmpty()) { Toast.makeText(this, tr("Сначала вставь API-Football ключ"), Toast.LENGTH_LONG).show(); return; }
        apiPrefs.edit().putString("api_football_key", k).apply();
        Toast.makeText(this, tr("Проверяю ключ…"), Toast.LENGTH_SHORT).show();
        worker.execute(() -> {
            try {
                JSONObject j = apiFootballRequest("status");
                JSONObject response = j.optJSONObject("response");
                String msg = "API-Football подключён";
                if (response != null) {
                    JSONObject requests = response.optJSONObject("requests");
                    if (requests != null) msg += ". Запросов сегодня: " + requests.optInt("current") + "/" + requests.optInt("limit_day");
                }
                final String result = msg;
                ui.post(() -> Toast.makeText(this, tr(result), Toast.LENGTH_LONG).show());
            } catch (Exception e) {
                final String msg = "Ошибка API-Football: " + e.getMessage();
                ui.post(() -> Toast.makeText(this, tr(msg), Toast.LENGTH_LONG).show());
            }
        });
    }

    private String apiSearchSafe(String name) {
        String value = Normalizer.normalize(name == null ? "" : name, Normalizer.Form.NFD)
                .replaceAll("\\p{M}+", "");
        value = value.replaceAll("[^A-Za-z0-9 ]", " ").replaceAll("\\s+", " ").trim();
        return value;
    }

    private String apiNorm(String name) {
        return apiSearchSafe(name).toLowerCase(Locale.ROOT).replace(" ", "");
    }

    private JSONObject apiFindTeam(String name) throws Exception {
        String safeName = apiSearchSafe(name);
        if (safeName.isEmpty()) throw new IOException("Название команды не подходит для поиска API-Football: " + name);
        JSONObject j = apiFootballRequest("teams?search=" + URLEncoder.encode(safeName, "UTF-8"));
        JSONArray arr = j.optJSONArray("response");
        if (arr == null || arr.length() == 0) throw new IOException("API-Football не нашёл команду: " + name);
        JSONObject selected = null;
        for (int i=0; i<arr.length(); i++) {
            JSONObject team = arr.optJSONObject(i) == null ? null : arr.optJSONObject(i).optJSONObject("team");
            if (team == null) continue;
            if (name.equalsIgnoreCase(team.optString("name")) || apiNorm(name).equals(apiNorm(team.optString("name")))) {
                selected = team; break;
            }
            if (selected == null) selected = team;
        }
        if (selected == null) throw new IOException("Не удалось определить команду: " + name);
        return selected;
    }

    private Double apiStatValue(JSONArray stats, String... names) {
        if (stats == null) return null;
        for (int i=0; i<stats.length(); i++) {
            JSONObject st = stats.optJSONObject(i); if (st == null) continue;
            String type = st.optString("type", "");
            boolean wanted = false;
            for (String n : names) if (n.equalsIgnoreCase(type)) wanted = true;
            if (!wanted) continue;
            Object value = st.opt("value");
            if (value == null || value == JSONObject.NULL) return null;
            try { return Double.parseDouble(value.toString().replace("%", "").replace(",", "")); }
            catch (Exception ignored) { return null; }
        }
        return null;
    }



    // Build the team's last-10 form directly from API-Football, across ALL competitions.
    // Upcoming fixture itself is not used; only completed historical fixtures are requested.
    // Load last 10 completed matches for both teams, then fetch all fixture statistics
    // in ONE bulk request (API-Football supports up to 20 fixture IDs per request).
    // Load the selected number of recent completed fixtures for both teams.
    // API-Football fixture statistics are fetched through the dedicated statistics endpoint.
    private Map<String,TeamStats> loadApiFootballHistories(String homeName, String awayName) throws Exception {
        JSONObject homeTeam = apiFindTeam(homeName);
        JSONObject awayTeam = apiFindTeam(awayName);
        int homeId = homeTeam.optInt("id"), awayId = awayTeam.optInt("id");
        if (homeId <= 0 || awayId <= 0) throw new IOException("Не удалось определить ID обеих команд");

        int limit = selectedMatchCount;
        TeamStats homeStats = new TeamStats(), awayStats = new TeamStats();
        Map<Integer,Set<Integer>> fixturesByTeam = new HashMap<>();
        LinkedHashSet<Integer> allFixtureIds = new LinkedHashSet<>();
        int[] teamIds = new int[]{homeId, awayId};
        TeamStats[] teamStats = new TeamStats[]{homeStats, awayStats};

        for (int ti=0; ti<teamIds.length; ti++) {
            int teamId = teamIds[ti];
            JSONObject fixturesJson = apiFootballRequest("fixtures?team=" + teamId + "&last=" + limit);
            JSONArray fixtures = fixturesJson.optJSONArray("response");
            if (fixtures == null || fixtures.length() == 0)
                throw new IOException("API не вернул историю матчей для " + (ti==0?homeName:awayName));

            for (int fi=0; fi<fixtures.length() && teamStats[ti].played<limit; fi++) {
                JSONObject item = fixtures.optJSONObject(fi); if (item == null) continue;
                JSONObject fx = item.optJSONObject("fixture");
                JSONObject teams = item.optJSONObject("teams");
                JSONObject goals = item.optJSONObject("goals");
                if (fx == null || teams == null || goals == null) continue;
                JSONObject status = fx.optJSONObject("status");
                String state = status == null ? "" : status.optString("short","");
                if (!("FT".equals(state) || "AET".equals(state) || "PEN".equals(state))) continue;
                JSONObject hTeam = teams.optJSONObject("home"), aTeam = teams.optJSONObject("away");
                if (hTeam == null || aTeam == null) continue;
                boolean isHome = hTeam.optInt("id") == teamId;
                int gf = goals.optInt(isHome ? "home" : "away", -1);
                int ga = goals.optInt(isHome ? "away" : "home", -1);
                int fixtureId = fx.optInt("id");
                if (gf < 0 || ga < 0 || fixtureId <= 0) continue;

                TeamStats st = teamStats[ti];
                st.played++; st.goalsFor += gf; st.goalsAgainst += ga;
                if (gf > ga) st.wins++; else if (gf == ga) st.draws++; else st.losses++;
                allFixtureIds.add(fixtureId);
                if (!fixturesByTeam.containsKey(teamId)) fixturesByTeam.put(teamId,new HashSet<Integer>());
                fixturesByTeam.get(teamId).add(fixtureId);
            }
        }
        if (homeStats.played == 0 || awayStats.played == 0)
            throw new IOException("Не удалось получить завершённые матчи обеих команд");

        int statsFixtureCount = 0;
        // Statistics endpoint returns both teams for one fixture. Avoid duplicate calls
        // when the two teams have faced each other within the selected sample.
        for (Integer fixtureId : allFixtureIds) {
            JSONObject statJson = apiFootballRequest("fixtures/statistics?fixture=" + fixtureId);
            JSONArray statRows = statJson.optJSONArray("response");
            if (statRows == null) continue;
            for (int si=0; si<statRows.length(); si++) {
                JSONObject side = statRows.optJSONObject(si); if (side == null) continue;
                JSONObject sideTeam = side.optJSONObject("team"); if (sideTeam == null) continue;
                int sideTeamId = sideTeam.optInt("id");
                Set<Integer> teamFixtures = fixturesByTeam.get(sideTeamId);
                if (teamFixtures == null || !teamFixtures.contains(fixtureId)) continue;
                TeamStats target = sideTeamId == homeId ? homeStats : sideTeamId == awayId ? awayStats : null;
                if (target == null) continue;
                JSONArray values = side.optJSONArray("statistics");
                Double v = apiStatValue(values, "Corner Kicks", "Corners"); if (v != null) target.addMetric("corners",v);
                v = apiStatValue(values, "Yellow Cards"); if (v != null) target.addMetric("yellow",v);
                v = apiStatValue(values, "Shots on Goal", "Shots on Target"); if (v != null) target.addMetric("target",v);
                v = apiStatValue(values, "Total Shots", "Shots"); if (v != null) target.addMetric("shots",v);
                v = apiStatValue(values, "Fouls"); if (v != null) target.addMetric("fouls",v);
                statsFixtureCount++;
            }
        }

        int hc = homeStats.values("corners")==null?0:homeStats.values("corners").size();
        int ac = awayStats.values("corners")==null?0:awayStats.values("corners").size();
        apiFootballDiagnostic = "API-Football: выборка " + limit + " матчей; поиск команд: " + apiSearchSafe(homeName) + " / " + apiSearchSafe(awayName) + ". "
                + homeName + ": сыграно " + homeStats.played + ", статистика угловых в " + hc + " матчах; "
                + awayName + ": сыграно " + awayStats.played + ", статистика угловых в " + ac
                + " матчах. Статистических строк получено: " + statsFixtureCount + ".";
        Map<String,TeamStats> result = new HashMap<>();
        result.put("home",homeStats);
        result.put("away",awayStats);
        return result;
    }


    // ===== Сборные: последние N матчей по ВСЕМ турнирам (ESPN scoreboard по месяцам, от новых к старым) =====
    private static final String[] NATIONAL_SLUGS = {"uefa.nations","fifa.friendly","fifa.worldq.uefa","uefa.euroq","uefa.euro","fifa.world"};
    private final Map<String,JSONObject> boardCache = new ConcurrentHashMap<>();

    private static class NatCand {
        String slug="", date="", h="", a="", hs="", as="";
        JSONObject ev, hSide, aSide;
    }

    // "Ireland" не должна совпадать с "Northern Ireland", а "Niger" с "Nigeria": для сборных только точное совпадение.
    private boolean sameNation(String a, String b) {
        String x = normTeam(a), y = normTeam(b);
        return !x.isEmpty() && x.equals(y);
    }

    private JSONObject cachedBoard(String slug, String month, boolean cacheable) {
        String ck = slug + "|" + month;
        JSONObject c = boardCache.get(ck);
        if (c != null) return c;
        try {
            JSONObject b = fetchJson("https://site.api.espn.com/apis/site/v2/sports/soccer/" + slug + "/scoreboard?dates=" + month + "&limit=500");
            if (cacheable) boardCache.put(ck, b);   // текущий месяц не кэшируем: он ещё меняется
            return b;
        } catch (Exception e) { return null; }
    }

    private String scoreText(JSONObject side) {
        Object sc = side.opt("score");
        if (sc instanceof JSONObject) return ((JSONObject) sc).optString("displayValue", "");
        return sc == null || sc == JSONObject.NULL ? "" : sc.toString();
    }

    private String statCell(Map<String,Double> m, String key) {
        Double v = m.get(key);
        return v == null ? "" : String.valueOf(Math.round(v));
    }

    private void putMissing(Map<String,Double> target, Map<String,Double> source) {
        if (source == null) return;
        for (Map.Entry<String,Double> e : source.entrySet()) if (!target.containsKey(e.getKey())) target.put(e.getKey(), e.getValue());
    }

    private boolean hasAllStats(Map<String,Double> m) {
        for (String k : new String[]{"corners","yellow","target","shots","fouls"}) if (!m.containsKey(k)) return false;
        return true;
    }

    private List<String[]> loadNationalHistory(String home, String away) {
        List<String[]> rows = new ArrayList<>();
        rows.add(new String[]{"gw","date","time","home","away","ft_home","ft_away","ft_result",
                "home_corners","away_corners","home_yellow","away_yellow","home_target","away_target",
                "home_shots","away_shots","home_fouls","away_fouls"});
        final int need = selectedMatchCount;
        int hCount = 0, aCount = 0;
        Set<String> seen = new HashSet<>();
        SimpleDateFormat monthFmt = new SimpleDateFormat("yyyyMM", Locale.US);
        Calendar cur = Calendar.getInstance();
        ExecutorService pool = Executors.newFixedThreadPool(NATIONAL_SLUGS.length);
        try {
            for (int back = 0; back < 24 && (hCount < need || aCount < need); back++, cur.add(Calendar.MONTH, -1)) {
                final String month = monthFmt.format(cur.getTime());
                final boolean cacheable = back > 0;
                List<Future<JSONObject>> futures = new ArrayList<>();
                for (final String slug : NATIONAL_SLUGS) futures.add(pool.submit(() -> cachedBoard(slug, month, cacheable)));

                List<NatCand> cands = new ArrayList<>();
                for (int si = 0; si < futures.size(); si++) {
                    JSONObject board;
                    try { board = futures.get(si).get(); } catch (Exception e) { continue; }
                    JSONArray events = board == null ? null : board.optJSONArray("events");
                    if (events == null) continue;
                    for (int i = 0; i < events.length(); i++) {
                        JSONObject ev = events.optJSONObject(i); if (ev == null) continue;
                        JSONArray comps = ev.optJSONArray("competitions"); if (comps == null || comps.length() == 0) continue;
                        JSONObject comp = comps.optJSONObject(0); if (comp == null) continue;
                        JSONObject statusObj = comp.optJSONObject("status");
                        if (statusObj == null) statusObj = ev.optJSONObject("status");
                        JSONObject type = statusObj == null ? null : statusObj.optJSONObject("type");
                        if (type == null || !type.optBoolean("completed", false)) continue;
                        JSONArray sides = comp.optJSONArray("competitors"); if (sides == null) continue;
                        NatCand c = new NatCand(); c.slug = NATIONAL_SLUGS[si]; c.ev = ev;
                        boolean hasHome = false, hasAway = false;
                        for (int j = 0; j < sides.length(); j++) {
                            JSONObject side = sides.optJSONObject(j); if (side == null) continue;
                            JSONObject team = side.optJSONObject("team");
                            String name = team == null ? "" : team.optString("displayName", team.optString("name", ""));
                            if ("home".equalsIgnoreCase(side.optString("homeAway"))) { c.h = name; c.hs = scoreText(side); c.hSide = side; hasHome = true; }
                            else { c.a = name; c.as = scoreText(side); c.aSide = side; hasAway = true; }
                        }
                        if (!hasHome || !hasAway || c.h.isEmpty() || c.a.isEmpty() || c.hs.isEmpty() || c.as.isEmpty()) continue;
                        String d = ev.optString("date", "");
                        if (d.length() < 10) continue;
                        c.date = d.substring(0, 10);
                        boolean involved = sameNation(home, c.h) || sameNation(home, c.a) || sameNation(away, c.h) || sameNation(away, c.a);
                        if (!involved) continue;
                        if (!seen.add(c.date + "|" + normTeam(c.h) + "|" + normTeam(c.a))) continue;
                        cands.add(c);
                    }
                }
                Collections.sort(cands, (x, y) -> y.date.compareTo(x.date));   // новые первыми

                for (NatCand c : cands) {
                    boolean forHome = sameNation(home, c.h) || sameNation(home, c.a);
                    boolean forAway = sameNation(away, c.h) || sameNation(away, c.a);
                    if (!((forHome && hCount < need) || (forAway && aCount < need))) continue;
                    if (forHome) hCount++;
                    if (forAway) aCount++;

                    Map<String,Double> hm = new HashMap<>(), am = new HashMap<>();
                    mergeEspnStats(hm, parseEspnCompetitorStats(c.hSide));
                    mergeEspnStats(am, parseEspnCompetitorStats(c.aSide));
                    Map<String,Integer> yellow = parseEspnYellowCards(c.ev);
                    String hid = c.hSide.optString("id", ""), aid = c.aSide.optString("id", "");
                    if (yellow.containsKey(hid)) hm.put("yellow", (double) yellow.get(hid));
                    if (yellow.containsKey(aid)) am.put("yellow", (double) yellow.get(aid));
                    if (!hasAllStats(hm) || !hasAllStats(am)) {
                        String eventId = c.ev.optString("id", "");
                        if (!eventId.isEmpty()) {
                            try {
                                JSONObject summary = fetchJson("https://site.api.espn.com/apis/site/v2/sports/soccer/" + c.slug + "/summary?event=" + eventId);
                                JSONObject box = summary.optJSONObject("boxscore");
                                JSONArray teams = box == null ? null : box.optJSONArray("teams");
                                if (teams != null) for (int j = 0; j < teams.length(); j++) {
                                    JSONObject tb = teams.optJSONObject(j); if (tb == null) continue;
                                    JSONObject t = tb.optJSONObject("team");
                                    String tn = t == null ? "" : t.optString("displayName", t.optString("name", ""));
                                    if (sameNation(c.h, tn)) putMissing(hm, parseEspnTeamStats(tb));
                                    else if (sameNation(c.a, tn)) putMissing(am, parseEspnTeamStats(tb));
                                }
                            } catch (Exception ignored) { }
                        }
                    }
                    int hsInt, asInt;
                    String result = "";
                    try { hsInt = Integer.parseInt(c.hs); asInt = Integer.parseInt(c.as); result = hsInt > asInt ? "H" : hsInt < asInt ? "A" : "D"; }
                    catch (Exception ignored) { continue; }
                    rows.add(new String[]{c.slug, c.date, "", c.h, c.a, c.hs, c.as, result,
                            statCell(hm,"corners"), statCell(am,"corners"), statCell(hm,"yellow"), statCell(am,"yellow"),
                            statCell(hm,"target"), statCell(am,"target"), statCell(hm,"shots"), statCell(am,"shots"),
                            statCell(hm,"fouls"), statCell(am,"fouls")});
                }
            }
        } finally { pool.shutdownNow(); }
        return rows;
    }

    private double[] toArr(ArrayList<Double> list) {
        if (list == null) return null;
        double[] r = new double[list.size()];
        for (int i = 0; i < r.length; i++) r[i] = list.get(i);
        return r;
    }

    // Средние голы хозяев/гостей по всей лиге (из сыгранных матчей CSV); при малой выборке - типичные значения.
    private double[] leagueGoalAverages(List<String[]> rows, Map<String,Integer> ix) {
        double sh = 0, sa = 0; int n = 0;
        for (int i = 1; i < rows.size(); i++) {
            Double gh = number(rows.get(i), ix, "ft_home"), ga = number(rows.get(i), ix, "ft_away");
            if (gh == null || ga == null) continue;
            sh += gh; sa += ga; n++;
        }
        return n >= 30 ? new double[]{sh / n, sa / n} : new double[]{1.45, 1.15};
    }

    // Среднее значение показателя на одну команду за матч по всей лиге; если данных мало - типичное значение.
    private double leagueMetricMean(List<String[]> rows, Map<String,Integer> ix, String metric, double fallback, boolean national) {
        if (national) return fallback;
        double sum = 0; int n = 0;
        for (int i = 1; i < rows.size(); i++) {
            Double hv = number(rows.get(i), ix, "home_" + metric), av = number(rows.get(i), ix, "away_" + metric);
            if (hv != null) { sum += hv; n++; }
            if (av != null) { sum += av; n++; }
        }
        return n >= 60 ? sum / n : fallback;
    }

    private String makeReport(League league, String home, String away, List<String[]> rows) {
        final boolean national = "UEFA_NATIONS_LEAGUE".equals(league.folder);
        if (national) rows = loadNationalHistory(home, away);
        if (rows == null || rows.size() < 2) return "⚠️ АНАЛИЗ НЕВОЗМОЖЕН\nНет опубликованных сыгранных матчей этой лиги.";
        Map<String,Integer> ix = headerIndex(rows.get(0));
        Map<String,Map<String,Double>> supplemental = national
                ? new HashMap<String,Map<String,Double>>()
                : loadEspnFallback(league,home,away,rows,ix);
        TeamStats h=collectTeam(home,rows,ix,supplemental), a=collectTeam(away,rows,ix,supplemental);
        if (!apiFootballKey().isEmpty()) {
            try {
                Map<String,TeamStats> apiHistory = loadApiFootballHistories(home, away);
                TeamStats apiHome = apiHistory.get("home");
                TeamStats apiAway = apiHistory.get("away");
                h = mergeTeamStats(h, apiHome);
                a = mergeTeamStats(a, apiAway);
            } catch (Exception apiError) {
                apiFootballDiagnostic = "API-Football: " + apiError.getMessage()
                        + ". Показана доступная статистика основного источника.";
            }
        }
        StringBuilder out = new StringBuilder();
        out.append("━━━━━━━━━━━━━━━━━━\n⚽ АНАЛИЗ МАТЧА\n").append(home).append(" — ").append(away).append("\n━━━━━━━━━━━━━━━━━━\n");
        out.append("🔌 ").append(apiFootballDiagnostic).append("\n");
        if (national) out.append("🌍 Сборные: в выборку входят матчи всех турниров (Лига наций, товарищеские, отбор, ЧЕ, ЧМ) по данным ESPN.\n");
        out.append("━━━━━━━━━━━━━━━━━━\n\n");
        out.append("📈 1. ГОЛЫ И ФОРМА КОМАНД\n");
        out.append("🏠 ").append(home).append("\n");
        out.append("   Сыграно матчей: ").append(h.played).append(" из ").append(selectedMatchCount).append("\n");
        out.append("   Забито: ").append(oneDecimal(h.goalsFor)).append(" всего · ").append(oneDecimal(h.avgGoalsFor())).append(" за матч\n");
        out.append("   Пропущено: ").append(oneDecimal(h.goalsAgainst)).append(" всего · ").append(oneDecimal(h.avgGoalsAgainst())).append(" за матч\n");
        out.append("   Результаты: ").append(h.form()).append("\n\n");
        out.append("✈️ ").append(away).append("\n");
        out.append("   Сыграно матчей: ").append(a.played).append(" из ").append(selectedMatchCount).append("\n");
        out.append("   Забито: ").append(oneDecimal(a.goalsFor)).append(" всего · ").append(oneDecimal(a.avgGoalsFor())).append(" за матч\n");
        out.append("   Пропущено: ").append(oneDecimal(a.goalsAgainst)).append(" всего · ").append(oneDecimal(a.avgGoalsAgainst())).append(" за матч\n");
        out.append("   Результаты: ").append(a.form()).append("\n\n");
        out.append("📊 2. ДЕТАЛЬНАЯ СТАТИСТИКА ПО КОМАНДАМ\n");
        if (noStats(h) && noStats(a)) out.append("ℹ️ Для этого турнира нет угловых, карточек, ударов и фолов: open-matchday публикует их не для всех лиг, а ESPN и API-Football могут не покрывать матч. Ниже есть прогноз по голам.\n");
        out.append(metricSection("🚩","Угловые","corners",h,a,home,away)).append("\n");
        out.append(metricSection("🟨","Жёлтые карточки","yellow",h,a,home,away)).append("\n");
        out.append(metricSection("🎯","Удары в створ","target",h,a,home,away)).append("\n");
        out.append(metricSection("🥅","Все удары по воротам","shots",h,a,home,away)).append("\n");
        out.append(metricSection("🤼","Фолы","fouls",h,a,home,away)).append("\n");
        out.append("🔌 ").append(apiFootballDiagnostic).append("\n\n");
        out.append("↗️ Вбрасывания из аута\n   Источник open-matchday не публикует эту статистику — цифры не подставляются.\n\n");
        out.append("🔮 3. ПРОГНОЗЫ ТОТАЛОВ НА МАТЧ\n");
        if(h.played<3||a.played<3) {
            out.append("⚠️ Для надёжного расчёта пока мало матчей: нужно минимум 3 сыгранных матча каждой команды.\n");
        } else {
            double[] lg = national ? new double[]{1.45, 1.15} : leagueGoalAverages(rows, ix);
            double[] xg = ForecastModel.expectedGoals(h.goalsFor, h.goalsAgainst, h.played, a.goalsFor, a.goalsAgainst, a.played, lg[0], lg[1]);
            double[] rel = ForecastModel.matchupLogRatios(h.goalsFor, h.goalsAgainst, h.played, a.goalsFor, a.goalsAgainst, a.played, lg[0], lg[1]);
            out.append(ForecastModel.goalsBlock(home, away, xg[0], xg[1], Math.min(h.played, a.played)));
            out.append("\n🚩 УГЛОВЫЕ\n").append(ForecastModel.countBlock("Тотал угловых", toArr(h.values("corners")), toArr(a.values("corners")),
                    toArr(h.concededValues("corners")), toArr(a.concededValues("corners")), leagueMetricMean(rows, ix, "corners", 5.0, national), 1.05, rel, 0.25));
            out.append("\n🟨 ЖЁЛТЫЕ КАРТОЧКИ\n").append(ForecastModel.countBlock("Тотал карточек", toArr(h.values("yellow")), toArr(a.values("yellow")),
                    null, null, leagueMetricMean(rows, ix, "yellow", 2.0, national), 1.2, rel, -0.15));
            out.append("\n🤼 ФОЛЫ\n").append(ForecastModel.countBlock("Тотал фолов", toArr(h.values("fouls")), toArr(a.values("fouls")),
                    null, null, leagueMetricMean(rows, ix, "fouls", 12.0, national), 1.05, rel, -0.12));
            out.append("\n🎯 УДАРЫ В СТВОР\n").append(ForecastModel.countBlock("Тотал ударов в створ", toArr(h.values("target")), toArr(a.values("target")),
                    null, null, leagueMetricMean(rows, ix, "target", 4.2, national), 1.15, rel, 0.35));
            out.append("\n🥅 ВСЕ УДАРЫ\n").append(ForecastModel.countBlock("Тотал всех ударов", toArr(h.values("shots")), toArr(a.values("shots")),
                    null, null, leagueMetricMean(rows, ix, "shots", 12.5, national), 1.2, rel, 0.30));
        }
        out.append("\n━━━━━━━━━━━━━━━━━━\nℹ️ КАК ЧИТАТЬ ПРОГНОЗ\n🔼 Больше — вероятность превышения указанной линии. 🔽 Меньше — вероятность остаться ниже неё. Это математическая оценка по средним показателям последних матчей, не гарантия и не букмекерские коэффициенты.\n");
        out.append("Модель: голы — Пуассон с поправкой Диксона–Коулса, силы атаки и обороны относительно среднего по лиге со сглаживанием; угловые, карточки, фолы и удары — сглаженное среднее и отрицательное биномиальное распределение с поправкой на расклад сил (сильная сторона бьёт и подаёт угловые чаще, слабая чаще фолит и получает карточки; коэффициенты стартовые), линии подбираются вокруг ожидаемого значения. «Уверенность» зависит от размера выборки.\n");
        out.append("Сначала используются данные open-matchday; если отдельные показатели отсутствуют, приложение пытается найти их в публичном ESPN API без ключа. Если ESPN не покрывает матч или турнир, статистика остаётся пустой. Угловые, карточки, удары и фолы доступны не для всех матчей. Вбрасывания из аута в этом источнике отсутствуют.\n");
        out.append("Выборка: ").append(h.played).append(" матчей — ").append(home).append("; ").append(a.played).append(" — ").append(away).append(". Результаты open-matchday обновляются примерно раз в сутки; резервная статистика ESPN может обновляться чаще. Источники: open-matchday и ESPN.");
        return translateReport(out.toString());
    }

    private double poisson(int k,double lambda) { return Math.exp(-lambda)*Math.pow(lambda,k)/factorial(k); }
    private double factorial(int n) { double x=1; for(int i=2;i<=n;i++)x*=i; return x; }
    private String pct(double v) { return String.format(Locale.US,"%.0f%%",v*100); }
    private String fmt(double v) { return String.format(Locale.US,"%.2f",v); }

    private void saveHistory(String item) {
        SharedPreferences p = getSharedPreferences("football_history", MODE_PRIVATE);
        try {
            JSONArray old = new JSONArray(p.getString("items", "[]"));
            JSONArray arr = new JSONArray();
            arr.put(item);                                           // новый — первым (раньше put(0, …) затирал предыдущий)
            for (int i = 0; i < old.length() && arr.length() < 100; i++) arr.put(old.optString(i));
            p.edit().putString("items", arr.toString()).apply();
        } catch (Exception e) {
            p.edit().putString("items", new JSONArray().put(item).toString()).apply();
        }
    }

    private void saveLearningForecast(String date, String league, String home, String away, String report) {
        SharedPreferences p = getSharedPreferences("football_learning", MODE_PRIVATE);
        try {
            JSONArray arr = new JSONArray(p.getString("records", "[]"));
            List<JSONObject> list = new ArrayList<>();
            JSONObject existing = null;
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.optJSONObject(i);
                if (o == null) continue;
                list.add(o);
                if (date.equals(o.optString("date")) && home.equals(o.optString("home")) && away.equals(o.optString("away"))) existing = o;
            }
            if (existing != null) {                                   // тот же матч: обновляем прогноз, результат не трогаем
                existing.put("report", report == null ? "" : report);
                existing.put("saved_at", System.currentTimeMillis());
            } else {
                JSONObject item = new JSONObject();
                item.put("date", date); item.put("league", league); item.put("home", home); item.put("away", away);
                item.put("report", report == null ? "" : report);
                item.put("actual_entered", false);
                item.put("saved_at", System.currentTimeMillis());
                list.add(item);
            }
            while (list.size() > 300) list.remove(0);                 // удаляем самые старые (раньше удалялась самая новая)
            p.edit().putString("records", new JSONArray(list).toString()).apply();
        } catch (Exception ignored) { }
    }

    private void showLearning() {
        SharedPreferences p = getSharedPreferences("football_learning", MODE_PRIVATE);
        try {
            final JSONArray arr = new JSONArray(p.getString("records", "[]"));
            final int total = arr.length();
            int completed = 0;
            for (int i = 0; i < total; i++) if (arr.optJSONObject(i) != null && arr.optJSONObject(i).optBoolean("actual_entered")) completed++;
            String summary = "Сохранено прогнозов: " + total + "\nВнесено фактических результатов: " + completed
                    + "\n\nСохраняй анализ до матча, а после финального свистка внеси реальные показатели. Так мы соберём честную обучающую выборку."
                    + "\n\nДля первой калибровки желательно минимум 100 матчей. До накопления данных коэффициенты автоматически не меняются.";
            LinearLayout panel = new LinearLayout(this);
            panel.setOrientation(LinearLayout.VERTICAL);
            panel.setPadding(dp(16), dp(8), dp(16), dp(4));
            panel.addView(label(summary, 12, MUTED, false), lp(0, 8));
            if (total == 0) {
                panel.addView(label("Сначала сделай анализ и нажми «СОХРАНИТЬ АНАЛИЗ В ИСТОРИЮ».", 13, Color.WHITE, true));
                new AlertDialog.Builder(this).setTitle(tr("🧠 Обучение")).setView(panel).setPositiveButton("OK", null).show();
                return;
            }
            panel.addView(label("Выбери матч, чтобы внести фактическую статистику.", 13, Color.WHITE, true), lp(0, 4));
            String[] choices = new String[total];
            for (int i = 0; i < total; i++) {                         // новые сверху
                JSONObject o = arr.optJSONObject(total - 1 - i);
                choices[i] = (o == null ? "?" : o.optString("date") + " · " + o.optString("home") + " — " + o.optString("away"))
                        + (o != null && o.optBoolean("actual_entered") ? "  ✓" : "  ·");
            }
            ListView list = new ListView(this);
            list.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, choices));
            panel.addView(list, new LinearLayout.LayoutParams(-1, dp(300)));
            final AlertDialog dialog = new AlertDialog.Builder(this).setTitle(tr("🧠 Обучение")).setView(panel)
                    .setPositiveButton(tr("Закрыть"), null).create();
            list.setOnItemClickListener((parent, view, position, id) -> { dialog.dismiss(); showLearningResultEntry(total - 1 - position); });
            dialog.show();
        } catch (Exception e) {
            new AlertDialog.Builder(this).setTitle(tr("🧠 Обучение")).setMessage(tr("Не удалось прочитать обучающую базу."))
                    .setPositiveButton("OK", null).show();
        }
    }

    private void showLearningResultEntry(final int index) {
        final SharedPreferences p = getSharedPreferences("football_learning", MODE_PRIVATE);
        try {
            final JSONArray arr = new JSONArray(p.getString("records", "[]"));
            final JSONObject record = arr.optJSONObject(index);
            if (record == null) return;
            LinearLayout panel = new LinearLayout(this);
            panel.setOrientation(LinearLayout.VERTICAL);
            panel.setPadding(dp(18), dp(8), dp(18), dp(4));
            panel.addView(label(record.optString("home") + " — " + record.optString("away"), 16, GREEN, true));
            final EditText[] fields = new EditText[6];
            String[] names = {"Голы в матче", "Угловые всего", "Жёлтые карточки всего", "Удары в створ всего", "Все удары всего", "Фолы всего"};
            final String[] keys = {"goals", "corners", "yellow", "target", "shots", "fouls"};
            JSONObject actual = record.optJSONObject("actual");
            for (int i = 0; i < fields.length; i++) {
                panel.addView(label(names[i], 13, Color.WHITE, true), lp(8, 2));
                fields[i] = new EditText(this);
                fields[i].setSingleLine(true);
                fields[i].setInputType(2);
                fields[i].setTextColor(Color.WHITE);
                fields[i].setHintTextColor(MUTED);
                fields[i].setHint(tr("Введите фактическое число"));
                fields[i].setBackground(shape(PANEL2, 8));
                fields[i].setPadding(dp(12), dp(7), dp(12), dp(7));
                if (actual != null && actual.has(keys[i])) fields[i].setText(String.valueOf(actual.optInt(keys[i])));
                panel.addView(fields[i], lp(0, 2));
            }
            ScrollView sv = new ScrollView(this); sv.addView(panel);
            new AlertDialog.Builder(this).setTitle(tr("Фактический результат"))
                    .setView(sv).setNegativeButton(tr("Отмена"), null)
                    .setPositiveButton(tr("Сохранить результат"), (d, w) -> {
                        try {
                            JSONObject result = new JSONObject();
                            for (int i = 0; i < fields.length; i++) {
                                String value = fields[i].getText().toString().trim();
                                if (!value.isEmpty()) result.put(keys[i], Integer.parseInt(value));
                            }
                            if (result.length() == 0) { toast("Введи хотя бы один показатель"); return; }
                            record.put("actual", result);
                            record.put("actual_entered", true);
                            arr.put(index, record);
                            p.edit().putString("records", arr.toString()).apply();
                            toast("Результат добавлен в обучающую базу");
                        } catch (Exception ex) {
                            toast("Проверь введённые числа");
                        }
                    }).show();
        } catch (Exception ignored) { }
    }

    private void showHistory() {
        final SharedPreferences p = getSharedPreferences("football_history", MODE_PRIVATE);
        try {
            JSONArray arr = new JSONArray(p.getString("items", "[]"));
            if (arr.length() == 0) {
                new AlertDialog.Builder(this).setTitle(tr("История")).setMessage(tr("Пока нет сохранённых матчей.")).setPositiveButton("OK", null).show();
                return;
            }
            String[] items = new String[arr.length()];
            for (int i = 0; i < arr.length(); i++) items[i] = arr.optString(i);
            new AlertDialog.Builder(this).setTitle(tr("Сохранённые матчи")).setItems(items, null)
                    .setPositiveButton(tr("Закрыть"), null)
                    .setNeutralButton(tr("Очистить"), (d, w) -> p.edit().remove("items").apply()).show();
        } catch (Exception e) {
            new AlertDialog.Builder(this).setTitle(tr("История")).setMessage(tr("Не удалось прочитать историю.")).setPositiveButton("OK", null).show();
        }
    }

    @Override protected void onDestroy() { RadioService.listener = null; super.onDestroy(); worker.shutdownNow(); }
}
