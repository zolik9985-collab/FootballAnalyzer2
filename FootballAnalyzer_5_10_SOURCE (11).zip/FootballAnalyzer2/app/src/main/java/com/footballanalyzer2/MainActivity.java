package com.footballanalyzer2;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.AlertDialog;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.text.TextUtils;
import android.widget.*;
import android.content.SharedPreferences;
import android.content.ClipData;
import android.content.Context;
import android.content.ClipboardManager;
import java.net.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.text.Normalizer;
import java.util.*;
import java.util.concurrent.*;
import org.json.*;

public class MainActivity extends Activity {
    private TextView radioBtn, radioInfo;
    private TextView[] chips;
    private volatile int historyAdded = 0;   // сколько матчей прошлых сезонов добавлено к выборке
    private volatile Map<String, Double> lastProbs = new HashMap<>();   // сырые вероятности последнего расчёта (для самообучения)
    private static final String RAW = "https://raw.githubusercontent.com/oladeeayo/open-matchday/master/data/";
    private static final String CDN = "https://cdn.jsdelivr.net/gh/oladeeayo/open-matchday@master/data/";
    private static final int BG = 0xff0b1722, GREEN = 0xff35d879, PANEL = 0xff132434, PANEL2 = 0xff1b3248, MUTED = 0xff8aa0b4;

    // Лиги, где open-matchday публикует угловые, карточки, удары и фолы (проверено по данным репозитория)
    private static final Set<String> STATS_FOLDERS = new HashSet<>(Arrays.asList(
        "ENG_1_premier-league","ESP_1_la-liga","GER_1_bundesliga","ITA_1_serie-a","FRA_1_ligue-1","NED_1_eredivisie",
        "POR_1_primeira-liga","BEL_1_pro-league","TUR_1_super-lig","GRE_1_super-league","SCO_1_premiership",
        "ENG_2_championship","ENG_3_league-one","ENG_4_league-two","SCO_2_championship","SCO_3_league-one","SCO_4_league-two"));

    private static class League {
        final String title, folder;
        League(String title, String folder) { this.title = title; this.folder = folder; }
        public String toString() { return Lang.translate(title) + (STATS_FOLDERS.contains(folder) ? "  📊" : ""); }
    }

    // Only competitions confirmed in the public open-matchday index are listed.
    // Турниры, которых нет в open-matchday: расписание и результаты берутся из ESPN.
    private static final Set<String> ESPN_ONLY = new HashSet<>(Arrays.asList("UEFA_NATIONS_LEAGUE", "UEFA_W_champions-league", "AUS_W_a-league-women", "AUS_CUP_australia-cup"));

    private final League[] leagues = new League[] {
        new League("🌐 Все матчи (все лиги)", "ALL_MATCHES"),
        new League("🏆 Лига чемпионов UEFA", "UEFA_1_champions-league"),
        new League("🏆 Лига Европы UEFA", "UEFA_1_europa-league"),
        new League("🏆 Лига конференций UEFA", "UEFA_1_conference-league"),
        new League("🌍 Лига наций UEFA", "UEFA_NATIONS_LEAGUE"),
        new League("🏆 Лига чемпионов УЕФА (женщины)", "UEFA_W_champions-league"),
        new League("Англия · Premier League", "ENG_1_premier-league"),
        new League("Германия · Bundesliga", "GER_1_bundesliga"),
        new League("Испания · La Liga", "ESP_1_la-liga"),
        new League("Италия · Serie A", "ITA_1_serie-a"),
        new League("Франция · Ligue 1", "FRA_1_ligue-1"),
        new League("Португалия · Primeira Liga", "POR_1_primeira-liga"),
        new League("Нидерланды · Eredivisie", "NED_1_eredivisie"),
        new League("Бельгия · Pro League", "BEL_1_pro-league"),
        new League("Турция · Süper Lig", "TUR_1_super-lig"),
        new League("Англия · FA Cup", "ENG_CUP_fa-cup"),
        new League("Англия · EFL Cup", "ENG_CUP_efl-cup"),
        new League("Испания · Copa del Rey", "ESP_CUP_copa-del-rey"),
        new League("Италия · Coppa Italia", "ITA_CUP_coppa-italia"),
        new League("Германия · DFB-Pokal", "GER_CUP_dfb-pokal"),
        new League("Нидерланды · KNVB Beker", "NED_CUP_knvb-beker"),
        new League("Португалия · Кубок", "POR_CUP_taca-de-portugal"),
        new League("Бразилия · Série A", "BRA_1_serie-a"),
        new League("Аргентина · Liga Profesional", "ARG_1_liga-profesional"),
        new League("Мексика · Liga MX", "MEX_1_liga-mx"),
        new League("США · MLS", "USA_1_mls"),
        new League("Россия · Премьер-лига", "RUS_1_premier-liga"),
        new League("Украина · Премьер-лига", "UKR_1_premier-league"),
        new League("Шотландия · Premiership", "SCO_1_premiership"),
        new League("Греция · Super League", "GRE_1_super-league"),
        new League("Австрия · Bundesliga", "AUT_1_bundesliga"),
        new League("Швейцария · Super League", "SUI_1_super-league"),
        new League("Дания · Superliga", "DEN_1_superliga"),
        new League("Норвегия · Eliteserien", "NOR_1_eliteserien"),
        new League("Швеция · Allsvenskan", "SWE_1_allsvenskan"),
        new League("Польша · Ekstraklasa", "POL_1_ekstraklasa"),
        new League("Хорватия · HNL", "CRO_1_hnl"),
        new League("Чехия · Chance Liga", "CZE_1_chance-liga"),
        new League("Румыния · Liga I", "ROU_1_liga-1"),
        new League("Япония · J1 League", "JPN_1_j1-league"),
        new League("Китай · Super League", "CHN_1_super-league"),
        new League("Австралия · A-League", "AUS_1_a-league"),
        new League("Австралия · A-League (женщины)", "AUS_W_a-league-women"),
        new League("Австралия · Кубок", "AUS_CUP_australia-cup"),
        new League("🌏 Австралия · все турниры (API-Football)", "API_AUS"),
        new League("🌏 Весь мир · любые турниры (API-Football)", "API_WORLD"),
        new League("Англия · Championship", "ENG_2_championship"),
        new League("Испания · Segunda División", "ESP_2_segunda-division"),
        new League("Италия · Serie B", "ITA_2_serie-b"),
        new League("Франция · Ligue 2", "FRA_2_ligue-2"),
        new League("Нидерланды · Eerste Divisie", "NED_2_eerste-divisie"),
        new League("Англия · League One", "ENG_3_league-one"),
        new League("Англия · League Two", "ENG_4_league-two"),
        new League("Шотландия · Championship", "SCO_2_championship"),
        new League("Шотландия · League One", "SCO_3_league-one"),
        new League("Шотландия · League Two", "SCO_4_league-two"),
        new League("Шотландия · Кубок", "SCO_CUP_scottish-cup"),
        new League("Шотландия · Кубок лиги", "SCO_CUP_league-cup"),
        new League("Австрия · Кубок", "AUT_CUP_ofb-cup"),
        new League("Швейцария · Кубок", "SUI_CUP_swiss-cup"),
        new League("Ирландия · First Division", "IRE_2_first-division"),
        new League("Ирландия · National League", "IRE_3_national-league"),
        new League("Польша · I Liga", "POL_2_division-1"),
        new League("Польша · II Liga", "POL_3_division-2"),
        new League("Бельгия · U21 Pro League", "BEL_U21_pro-league"),
        new League("Уэльс · Cymru Premier", "WAL_1_cymru-premier"),
        new League("Уэльс · Cymru North", "WAL_2_cymru-north"),
        new League("Уэльс · Cymru South", "WAL_3_cymru-south"),
        new League("Кипр · First Division", "CYP_1_first-division"),
        new League("Словакия · Nike Liga", "SVK_1_nike-liga"),
        new League("Словения · Prva Liga", "SVN_1_prva-liga"),
        new League("Финляндия · Veikkausliiga", "FIN_1_veikkausliiga"),
        new League("Казахстан · Премьер-лига", "KAZ_1_premier-league"),
        new League("Бразилия · Série B", "BRA_2_serie-b"),
        new League("Аргентина · Primera Nacional", "ARG_2_primera-nacional"),
        new League("Мексика · Liga de Expansión", "MEX_2_liga-expansion")
    };

    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final Handler ui = new Handler(Looper.getMainLooper());
    private LinearLayout root, cards;
    private TextView status, selectedDateText;
    private Spinner leagueSpinner;
    private SharedPreferences apiPrefs;
    private EditText apiKeyField;
    private Spinner matchCountSpinner;
    private int selectedMatchCount = 5;
    private volatile String apiFootballDiagnostic = "API-Football: проверка ещё не выполнялась";
    private int selectedLeague = 0;
    private String mode = "today";
    private String chosenDate;
    private boolean dateWasChosen = false;


    private String currentLanguage() { return apiPrefs.getString("app_language", "ru"); }
    private String tr(String text) { return Lang.translate(text); }
    private String translateReport(String report) { return Lang.translate(report); }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density); }
    private GradientDrawable shape(int color, int radius) { GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d; }
    private TextView label(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(tr(s)); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(null, Typeface.BOLD); return t;
    }
    private LinearLayout.LayoutParams lp(int top, int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.setMargins(0, dp(top), 0, dp(bottom)); return p;
    }
    private Button button(String s) {
        Button b = new Button(this); b.setText(tr(s)); b.setAllCaps(false); b.setTextColor(BG); b.setTextSize(15); b.setTypeface(null, Typeface.BOLD); b.setBackground(shape(GREEN, 10)); return b;
    }
    private Button smallButton(String s) {
        Button b = new Button(this); b.setText(tr(s)); b.setAllCaps(false); b.setTextColor(BG); b.setTextSize(12); b.setTypeface(null, Typeface.BOLD);
        b.setBackground(shape(GREEN, 8)); b.setPadding(dp(8), 0, dp(8), 0); b.setMinHeight(0); b.setMinimumHeight(0); b.setMinWidth(0); b.setMinimumWidth(0);
        return b;
    }
    private TextView iconButton(String glyph, View.OnClickListener l) {
        TextView t = new TextView(this); t.setText(glyph); t.setTextSize(17); t.setGravity(Gravity.CENTER); t.setTextColor(Color.WHITE);
        t.setBackground(shape(PANEL2, 10)); t.setOnClickListener(l); return t;
    }
    private LinearLayout.LayoutParams iconParams() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(38), dp(38)); p.setMargins(dp(6), 0, 0, 0); return p;
    }
    private void toast(String s) { Toast.makeText(this, tr(s), Toast.LENGTH_SHORT).show(); }
    private void setStatus(String s) { if (status != null) status.setText(tr(s)); }
    private String today() { return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date()); }

    private String effectiveDate() {
        if ("today".equals(mode)) return today();
        if ("tomorrow".equals(mode)) { Calendar c = Calendar.getInstance(); c.add(Calendar.DAY_OF_YEAR, 1); return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(c.getTime()); }
        return chosenDate;
    }

    private void styleSpinnerText(TextView t, boolean dropdown, boolean arrow) {
        t.setTextColor(Color.WHITE); t.setTextSize(14);
        if (dropdown) { t.setBackgroundColor(PANEL2); t.setPadding(dp(14), dp(10), dp(14), dp(10)); }
        else { t.setPadding(dp(12), dp(8), dp(12), dp(8)); if (arrow) t.setText(t.getText() + "  ▾"); }
    }

    private <T> ArrayAdapter<T> spinnerAdapter(T[] items, final boolean arrow) {
        return new ArrayAdapter<T>(this, android.R.layout.simple_spinner_item, items) {
            @Override public View getView(int position, View convertView, ViewGroup parent) {
                TextView t = (TextView) super.getView(position, convertView, parent); styleSpinnerText(t, false, arrow); return t;
            }
            @Override public View getDropDownView(int position, View convertView, ViewGroup parent) {
                TextView t = (TextView) super.getDropDownView(position, convertView, parent); styleSpinnerText(t, true, false); return t;
            }
        };
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG);
        chosenDate = today();
        apiPrefs = getSharedPreferences("football_analyzer", MODE_PRIVATE);
        Lang.current = apiPrefs.getString("app_language", "ru");
        loadLineLimits();
        rebuildCalibration();
        buildUi();
        loadFixtures();
        fillResultsAuto(null);
    }

    @Override protected void onResume() {
        super.onResume();
        RadioService.listener = () -> updateRadioUi();
        updateRadioUi();
    }

    @Override protected void onPause() {
        RadioService.listener = null;
        super.onPause();
    }

    // ---------- радио (работает в фоне через RadioService) ----------
    private void toggleRadio() {
        int st = RadioService.state;
        if (st == 1 || st == 2) {
            stopService(new Intent(this, RadioService.class));
            return;
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 77);
        Intent i = new Intent(this, RadioService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
    }

    private void updateRadioUi() {
        if (radioBtn == null || radioInfo == null) return;
        int st = RadioService.state;
        radioBtn.setText(st == 1 || st == 2 ? "⏹" : "📻");
        if (st == 0) { radioInfo.setVisibility(View.GONE); return; }
        radioInfo.setVisibility(View.VISIBLE);
        if (st == 1) radioInfo.setText(tr("📻 Подключаюсь…") + (RadioService.info.isEmpty() ? "" : " " + RadioService.info));
        else if (st == 2) radioInfo.setText(tr("📻 Играет: ") + RadioService.info + tr(" · нажми, чтобы выключить"));
        else radioInfo.setText(tr("📻 Нет соединения ни с одним потоком. Нажми, чтобы повторить."));
    }

    // ---------- меню и настройки ----------
    // ---- Границы линий букмекера: чтобы программа не предлагала линий, которых у 1xBet нет ----
    private static final String[][] LINE_FAMS = {{"yellow", "Карточки"}, {"corners", "Угловые"}, {"fouls", "Фолы"}, {"target", "Удары в створ"}, {"shots", "Все удары"}};

    private void loadLineLimits() {
        try {
            JSONObject o = new JSONObject(apiPrefs.getString("lines", "{}"));
            Iterator<String> it = o.keys();
            while (it.hasNext()) {
                String k = it.next(); JSONArray a = o.optJSONArray(k);
                if (a != null && a.length() == 2) ForecastModel.LINES.put(k, new int[]{a.optInt(0), a.optInt(1) < 0 ? ForecastModel.NO_MAX : a.optInt(1)});
            }
        } catch (Exception ignored) { }
    }

    private void showLineLimits() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(16), dp(8), dp(16), dp(4));
        panel.addView(label("Впиши, какие линии реально есть в 1xBet: самую маленькую (≥) и самую большую (≤), например 3.5 и 5.5. Пустое поле справа — без ограничения. Программа не предложит ставку на линию вне этого диапазона.", 12, MUTED, false), lp(0, 6));
        final List<String> keys = new ArrayList<>(); final List<EditText[]> fields = new ArrayList<>();
        for (String scope : new String[]{"total", "team"}) {
            panel.addView(label(tr(scope.equals("total") ? "Тотал матча" : "Индивидуальный тотал команды"), 14, GREEN, true), lp(10, 2));
            for (String[] f : LINE_FAMS) {
                int[] v = ForecastModel.LINES.get(scope + "_" + f[0]);
                LinearLayout row = new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL);
                row.addView(label(tr(f[1]) + "  ≥", 13, Color.WHITE, false), new LinearLayout.LayoutParams(0, -2, 1.3f));
                EditText mn = lineField(v[0] + ".5"), mx = lineField(v[1] == ForecastModel.NO_MAX ? "" : v[1] + ".5");
                row.addView(mn, new LinearLayout.LayoutParams(0, -2, 1f));
                row.addView(label("  ≤  ", 13, Color.WHITE, false));
                row.addView(mx, new LinearLayout.LayoutParams(0, -2, 1f));
                panel.addView(row, lp(2, 2));
                keys.add(scope + "_" + f[0]); fields.add(new EditText[]{mn, mx});
            }
        }
        ScrollView sv = new ScrollView(this); sv.addView(panel);
        new AlertDialog.Builder(this).setTitle(tr("📏 Линии букмекера")).setView(sv)
            .setPositiveButton(tr("Сохранить"), (d, w) -> {
                JSONObject out = new JSONObject();
                try {
                    for (int i = 0; i < keys.size(); i++) {
                        int mn = lineN(fields.get(i)[0].getText().toString(), 0), mx = lineN(fields.get(i)[1].getText().toString(), -1);
                        if (mx >= 0 && mx < mn) mx = mn;
                        ForecastModel.LINES.put(keys.get(i), new int[]{mn, mx < 0 ? ForecastModel.NO_MAX : mx});
                        out.put(keys.get(i), new JSONArray().put(mn).put(mx));
                    }
                    apiPrefs.edit().putString("lines", out.toString()).apply();
                } catch (Exception ignored) { }
                toast("Линии сохранены");
            })
            .setNegativeButton(tr("Закрыть"), null).show();
    }

    private EditText lineField(String text) {
        EditText e = new EditText(this);
        e.setSingleLine(true); e.setInputType(8194); e.setTextColor(Color.WHITE); e.setText(text); e.setGravity(Gravity.CENTER);
        e.setBackground(shape(PANEL2, 8)); e.setPadding(dp(6), dp(6), dp(6), dp(6));
        return e;
    }

    private static int lineN(String text, int fallback) {
        try { return (int) Math.floor(Double.parseDouble(text.trim().replace(',', '.'))); } catch (Exception e) { return fallback; }
    }

    private void showToolsMenu() {
        String[] items = { tr("📅 История сохранённых прогнозов"), tr("🧠 Обучение и разбор ошибок"), tr("📈 Точность модели"), tr("🎰 Экспресс (3 события)"), tr("🎰 Мои экспрессы (итоги)"), tr("📏 Линии букмекера") };
        new AlertDialog.Builder(this)
            .setTitle(tr("Дополнительные функции"))
            .setItems(items, (dialog, which) -> { if (which == 0) showHistory(); else if (which == 1) showLearning(); else if (which == 2) showAccuracy(); else if (which == 3) showExpress(); else if (which == 4) showExpressHistory(); else showLineLimits(); })
            .setNegativeButton(tr("Закрыть"), null)
            .show();
    }

    private void showSettings() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(18), dp(8), dp(18), dp(4));
        panel.addView(label("Язык приложения / App language", 14, GREEN, true));
        final Spinner language = new Spinner(this);
        final String[] names = {"Русский", "English", "Español", "Deutsch", "Italiano", "Français", "Norsk"};
        final String[] codes = {"ru", "en", "es", "de", "it", "fr", "no"};
        language.setAdapter(spinnerAdapter(names, true));
        language.setBackground(shape(PANEL2, 10));
        String current = currentLanguage(); int selected = 0;
        for (int i = 0; i < codes.length; i++) if (codes[i].equals(current)) selected = i;
        language.setSelection(selected);
        panel.addView(language, lp(4, 0));

        panel.addView(label("API-Football key", 14, GREEN, true), lp(14, 4));
        apiKeyField = new EditText(this);
        apiKeyField.setSingleLine(true); apiKeyField.setTextSize(14);
        apiKeyField.setTextColor(Color.WHITE); apiKeyField.setHintTextColor(MUTED);
        apiKeyField.setHint(tr("Вставь сюда API-Football ключ"));
        apiKeyField.setInputType(129); apiKeyField.setPadding(dp(13), dp(8), dp(13), dp(8));
        apiKeyField.setBackground(shape(PANEL2, 10));
        apiKeyField.setText(apiPrefs.getString("api_football_key", ""));
        panel.addView(apiKeyField, lp(0, 8));

        LinearLayout actions = new LinearLayout(this);
        Button save = smallButton("СОХРАНИТЬ КЛЮЧ"), test = smallButton("ПРОВЕРИТЬ КЛЮЧ");
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(0, dp(40), 1); ap.setMargins(dp(2), 0, dp(2), 0);
        actions.addView(save, ap);
        actions.addView(test, ap);
        panel.addView(actions);
        final AlertDialog dialog = new AlertDialog.Builder(this).setTitle(tr("⚙️ НАСТРОЙКИ")).setView(panel)
            .setNegativeButton(tr("Закрыть"), null)
            .setPositiveButton(tr("Сохранить настройки"), null).create();
        save.setOnClickListener(v -> {
            String key = apiKeyField.getText().toString().trim();
            if (!key.isEmpty()) apiPrefs.edit().putString("api_football_key", key).apply();
            toast("Ключ сохранён");
        });
        test.setOnClickListener(v -> testApiFootballKey());
        dialog.setOnShowListener(v -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(w -> {
            String key = apiKeyField.getText().toString().trim();
            if (!key.isEmpty()) apiPrefs.edit().putString("api_football_key", key).apply();
            String code = codes[language.getSelectedItemPosition()];
            apiPrefs.edit().putString("app_language", code).apply();
            Lang.current = code;
            dialog.dismiss();
            buildUi();
            loadFixtures();
        }));
        dialog.show();
    }

    // ---------- главный экран (компактный, тёмно-синий стиль) ----------
    private void buildUi() {
        final ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        scroll.setOnApplyWindowInsetsListener((v, insets) -> {
            v.setPadding(0, insets.getSystemWindowInsetTop(), 0, insets.getSystemWindowInsetBottom());
            return insets;
        });
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(12), dp(10), dp(12), dp(20)); root.setBackgroundColor(BG);
        scroll.addView(root); setContentView(scroll);

        // верхняя панель
        LinearLayout bar = new LinearLayout(this); bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.addView(label("⚽ FOOTBALL ANALYZER", 17, Color.WHITE, true), new LinearLayout.LayoutParams(0, -2, 1f));
        radioBtn = iconButton("📻", v -> toggleRadio());
        bar.addView(radioBtn, iconParams());
        bar.addView(iconButton("⚙️", v -> showSettings()), iconParams());
        bar.addView(iconButton("☰", v -> showToolsMenu()), iconParams());
        root.addView(bar, lp(0, 2));
        root.addView(label("v5.10 · open-matchday · football-data · ESPN", 10, MUTED, false), lp(0, 8));

        radioInfo = label("", 12, GREEN, true);
        radioInfo.setPadding(dp(10), dp(7), dp(10), dp(7)); radioInfo.setBackground(shape(PANEL2, 8));
        radioInfo.setVisibility(View.GONE); radioInfo.setOnClickListener(v -> toggleRadio());
        root.addView(radioInfo, lp(0, 8));

        // турнир
        leagueSpinner = new Spinner(this);
        leagueSpinner.setAdapter(spinnerAdapter(leagues, true));
        leagueSpinner.setBackground(shape(PANEL2, 10));
        leagueSpinner.setSelection(selectedLeague);
        root.addView(leagueSpinner, lp(0, 2));
        root.addView(label("📊 — в данных есть угловые, карточки, удары и фолы", 10, MUTED, false), lp(0, 8));

        // дата: компактные «чипы»
        LinearLayout chipRow = new LinearLayout(this);
        String[] chipText = {"Сегодня", "Завтра", "Все матчи", "📅"};
        final String[] chipMode = {"today", "tomorrow", "all", "custom"};
        chips = new TextView[4];
        for (int i = 0; i < 4; i++) {
            final String m = chipMode[i];
            TextView chip = new TextView(this);
            chip.setText(tr(chipText[i])); chip.setTextSize(13); chip.setGravity(Gravity.CENTER);
            chip.setTypeface(null, Typeface.BOLD); chip.setPadding(dp(4), dp(9), dp(4), dp(9));
            chip.setOnClickListener(v -> {
                if ("custom".equals(m)) { openDatePicker(); return; }
                mode = m; dateWasChosen = false; refreshChips(); loadFixtures();
            });
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, -2, i == 3 ? 1.1f : 1f); cp.setMargins(dp(2), 0, dp(2), 0);
            chipRow.addView(chip, cp); chips[i] = chip;
        }
        root.addView(chipRow, lp(0, 4));
        selectedDateText = label("", 11, MUTED, false); root.addView(selectedDateText, lp(0, 8));

        // сколько матчей брать в статистику
        LinearLayout cnt = new LinearLayout(this); cnt.setGravity(Gravity.CENTER_VERTICAL);
        cnt.addView(label("📊 Матчей для статистики (на команду)", 12, MUTED, false), new LinearLayout.LayoutParams(0, -2, 1f));
        matchCountSpinner = new Spinner(this);
        final String[] matchCountOptions = {"2", "5", "6", "8", "10", "15", "20", "30"};
        final int[] counts = {2, 5, 6, 8, 10, 15, 20, 30};
        matchCountSpinner.setAdapter(spinnerAdapter(matchCountOptions, true));
        matchCountSpinner.setBackground(shape(PANEL2, 10));
        selectedMatchCount = apiPrefs.getInt("analysis_match_count", 5);
        int initialCountPosition = 1;
        for (int ci = 0; ci < counts.length; ci++) if (counts[ci] == selectedMatchCount) initialCountPosition = ci;
        matchCountSpinner.setSelection(initialCountPosition);
        matchCountSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onNothingSelected(AdapterView<?> parent) {}
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedMatchCount = counts[position];
                apiPrefs.edit().putInt("analysis_match_count", selectedMatchCount).apply();
            }
        });
        cnt.addView(matchCountSpinner, new LinearLayout.LayoutParams(dp(92), dp(38)));
        root.addView(cnt, lp(0, 8));

        // статус + обновить
        LinearLayout statusRow = new LinearLayout(this); statusRow.setGravity(Gravity.CENTER_VERTICAL);
        status = label("Подключаюсь к бесплатному источнику…", 12, MUTED, false);
        statusRow.addView(status, new LinearLayout.LayoutParams(0, -2, 1f));
        statusRow.addView(iconButton("↻", v -> loadFixtures()), iconParams());
        root.addView(statusRow, lp(0, 8));

        cards = new LinearLayout(this); cards.setOrientation(LinearLayout.VERTICAL); root.addView(cards);
        root.addView(label("Источники: open-matchday + ESPN + API-Football (если добавлен ключ). Покрытие статистики зависит от лиги и тарифа API. Прогноз — оценка модели, а не гарантия.", 10, 0xff6f8498, false), lp(14, 0));

        leagueSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onNothingSelected(AdapterView<?> parent) {}
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position == selectedLeague) return;   // начальный вызов: расписание уже грузится
                selectedLeague = position; loadFixtures();
            }
        });
        refreshChips();
        updateRadioUi();
    }

    private void refreshChips() {
        if (chips == null) return;
        String[] modes = {"today", "tomorrow", "all", "custom"};
        for (int i = 0; i < chips.length; i++) {
            boolean on = modes[i].equals(mode);
            chips[i].setBackground(shape(on ? GREEN : PANEL2, 8));
            chips[i].setTextColor(on ? BG : Color.WHITE);
        }
        chips[3].setText("custom".equals(mode) ? "📅 " + chosenDate.substring(5) : "📅");
        selectedDateText.setText("all".equals(mode) ? tr("Все будущие матчи") : tr("Дата: ") + effectiveDate());
    }

    private void openDatePicker() {
        Calendar c = Calendar.getInstance();
        try { c.setTime(new SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(chosenDate)); } catch (Exception ignored) {}
        DatePickerDialog dlg = new DatePickerDialog(this, (picker, y, m, d) -> {
            Calendar picked = Calendar.getInstance(); picked.set(y, m, d);
            chosenDate = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(picked.getTime());
            dateWasChosen = true; mode = "custom"; refreshChips(); loadFixtures();
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH));
        dlg.show();
    }

    // Код сезона по дате: с июля 2026 это 2627. Если файла нет, пробуем следующий и предыдущий сезон.
    private List<String> seasonCandidates() {
        Calendar c = Calendar.getInstance();
        int start = c.get(Calendar.MONTH) >= Calendar.JULY ? c.get(Calendar.YEAR) : c.get(Calendar.YEAR) - 1;
        List<String> out = new ArrayList<>();
        for (int y : new int[]{start, start + 1, start - 1}) out.add(String.format(Locale.US, "%02d%02d", y % 100, (y + 1) % 100));
        return out;
    }

    private String fetchWithFallback(String path) throws Exception {
        Exception last = null;
        for (String base : new String[]{RAW, CDN}) {
            HttpURLConnection conn = null;
            try {
                URL url = new URL(base + path);
                conn = (HttpURLConnection) url.openConnection();
                conn.setConnectTimeout(12000); conn.setReadTimeout(18000);
                conn.setRequestProperty("User-Agent", "FootballAnalyzer3/3.0");
                conn.setRequestProperty("Accept", "text/csv,*/*");
                int code = conn.getResponseCode();
                InputStream in = (code >= 200 && code < 300) ? conn.getInputStream() : conn.getErrorStream();
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                if (in != null) { try (InputStream stream = in) { byte[] buf = new byte[8192]; int n; while ((n = stream.read(buf)) != -1) out.write(buf, 0, n); } }
                String body = out.toString("UTF-8");
                if (code == 404) throw new FileNotFoundException("Для этого турнира файл пока не опубликован: " + path);
                if (code < 200 || code >= 300) throw new IOException("HTTP " + code + " при загрузке CSV");
                if (body.trim().isEmpty()) throw new IOException("Источник вернул пустой CSV: " + path);
                return body;
            } catch (Exception e) { last = e; }
            finally { if (conn != null) conn.disconnect(); }
        }
        throw last == null ? new IOException("Не удалось подключиться к open-matchday") : last;
    }

    private List<String[]> parseCsv(String csv) throws IOException {
        List<String[]> rows = new ArrayList<>();
        BufferedReader reader = new BufferedReader(new StringReader(csv));
        String line;
        while ((line = reader.readLine()) != null) {
            if (line.trim().isEmpty()) continue;
            ArrayList<String> cells = new ArrayList<>(); StringBuilder cell = new StringBuilder(); boolean quoted = false;
            for (int i = 0; i < line.length(); i++) {
                char ch = line.charAt(i);
                if (ch == '"') {
                    if (quoted && i + 1 < line.length() && line.charAt(i + 1) == '"') { cell.append('"'); i++; }
                    else quoted = !quoted;
                } else if (ch == ',' && !quoted) { cells.add(cell.toString()); cell.setLength(0); }
                else cell.append(ch);
            }
            cells.add(cell.toString()); rows.add(cells.toArray(new String[0]));
        }
        return rows;
    }

    private Map<String, Integer> headerIndex(String[] header) {
        Map<String, Integer> map = new HashMap<>();
        for (int i = 0; i < header.length; i++) map.put(header[i].trim().toLowerCase(Locale.US), i);
        return map;
    }
    private String val(String[] row, Map<String, Integer> ix, String key) {
        Integer i = ix.get(key.toLowerCase(Locale.US)); return i == null || i < 0 || i >= row.length ? "" : row[i].trim();
    }
    private Double number(String[] row, Map<String, Integer> ix, String key) {
        try { String s = val(row, ix, key); return s.isEmpty() ? null : Double.parseDouble(s); } catch (Exception e) { return null; }
    }

    private static final String[] RESULT_HEADER = ("gw,date,time,home,away,ft_home,ft_away,ft_result,ht_home,ht_away,ht_result,home_shots,away_shots,home_target,away_target,"
            + "home_fouls,away_fouls,home_corners,away_corners,home_corners_1h,away_corners_1h,home_corners_2h,away_corners_2h,home_yellow,away_yellow,home_red,away_red,goal_minutes,source").split(",");

    /** Файл прошлого сезона football-data.co.uk: сначала кэш на телефоне (прошлые сезоны не меняются), потом сеть. */
    private String fetchFootballData(String seasonCode, String div) throws Exception {
        File cache = new File(getFilesDir(), "fd_" + seasonCode + "_" + div + ".csv");
        if (cache.exists() && cache.length() > 1000) {
            try (InputStream in = new FileInputStream(cache)) {
                ByteArrayOutputStream out = new ByteArrayOutputStream(); byte[] buf = new byte[8192]; int n;
                while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
                return out.toString("ISO-8859-1");
            }
        }
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL("https://www.football-data.co.uk/mmz4281/" + seasonCode + "/" + div + ".csv").openConnection();
            conn.setConnectTimeout(10000); conn.setReadTimeout(20000);
            conn.setRequestProperty("User-Agent", "FootballAnalyzer/5.10");
            if (conn.getResponseCode() != 200) throw new IOException("HTTP " + conn.getResponseCode());
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            try (InputStream in = conn.getInputStream()) { byte[] buf = new byte[8192]; int n; while ((n = in.read(buf)) != -1) out.write(buf, 0, n); }
            String body = out.toString("ISO-8859-1");
            String firstLine = body.length() > 300 ? body.substring(0, 300) : body;
            if (!firstLine.contains("HomeTeam") || !firstLine.contains("FTHG")) throw new IOException("Неожиданный формат файла");   // например, HTML-страница вместо CSV
            try (FileOutputStream fo = new FileOutputStream(cache)) { fo.write(out.toByteArray()); } catch (Exception ignored) { }
            return body;
        } finally { if (conn != null) conn.disconnect(); }
    }

    /** Добавляет к выборке матчи двух прошлых сезонов (угловые, карточки, удары, фолы) для лиг, которые есть в football-data. При любой ошибке — без изменений. */
    private List<String[]> extendWithHistory(League league, List<String[]> results, List<String[]> fixtures, String season) {
        String div = HistoryImport.divisionFor(league.folder);
        if (div == null || season == null) return results;
        String[] header = results.isEmpty() ? RESULT_HEADER : results.get(0);
        Set<String> target = new TreeSet<>();
        for (List<String[]> src : Arrays.asList(fixtures, results)) {
            if (src.isEmpty()) continue;
            Map<String, Integer> ix = headerIndex(src.get(0));
            for (int i = 1; i < src.size(); i++) { String h = val(src.get(i), ix, "home"), a = val(src.get(i), ix, "away"); if (!h.isEmpty()) target.add(h); if (!a.isEmpty()) target.add(a); }
        }
        if (target.isEmpty()) return results;
        List<String[]> added = new ArrayList<>();
        for (int back = 1; back <= 2; back++) {
            String code = HistoryImport.prevSeason(season, back);
            if (code == null) continue;
            try {
                List<String[]> fd = parseCsv(fetchFootballData(code, div));
                Map<String, String> names = HistoryImport.mapNames(target, HistoryImport.teamNames(fd));
                Map<String, Integer> oi = headerIndex(header);
                for (String[] row : HistoryImport.convert(fd, header, names)) {
                    if (target.contains(row[oi.get("home")]) || target.contains(row[oi.get("away")])) added.add(row);   // только матчи команд этой лиги
                }
            } catch (Exception ignored) { }
        }
        if (added.isEmpty()) return results;
        List<String[]> merged = new ArrayList<>();
        merged.add(header);
        for (int i = 1; i < results.size(); i++) merged.add(results.get(i));
        merged.addAll(added);
        historyAdded = added.size();
        return merged;
    }

    private void loadFixtures() {
        if (status == null || cards == null) return;
        final League league = leagues[selectedLeague]; final String selectedMode = mode; final String date = chosenDate;
        setStatus("Загружаю CSV: " + league.title + "…"); cards.removeAllViews();
        worker.execute(() -> {
            try {
                if ("ALL_MATCHES".equals(league.folder)) { loadAllMatches(selectedMode, date); return; }
                if (league.folder.startsWith("API_")) { loadApiFixtures(league, selectedMode, date); return; }
                if (ESPN_ONLY.contains(league.folder)) {
                    final String slug = ESPN.get(league.folder);
                    // ESPN removed support for long YYYYMMDD-YYYYMMDD ranges (returns HTTP 400).
                    // Request each month separately using the supported YYYYMM format.
                    String target = date;
                    if (selectedMode.equals("today")) target = today();
                    else if (selectedMode.equals("tomorrow")) { Calendar cal = Calendar.getInstance(); cal.add(Calendar.DAY_OF_YEAR, 1); target = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.getTime()); }

                    LinkedHashMap<String,String[]> unique = new LinkedHashMap<>();
                    Calendar monthCursor = Calendar.getInstance();
                    monthCursor.setTime(new SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(today()));
                    int monthsBack = selectedMode.equals("all") ? 11 : "UEFA_NATIONS_LEAGUE".equals(league.folder) ? 2 : 5;
                    monthCursor.add(Calendar.MONTH, -monthsBack);
                    SimpleDateFormat monthFmt = new SimpleDateFormat("yyyyMM", Locale.US);
                    for (int mi=0; mi<=monthsBack; mi++) {
                        String month = monthFmt.format(monthCursor.getTime());
                        JSONObject monthly = fetchJson("https://site.api.espn.com/apis/site/v2/sports/soccer/" + slug + "/scoreboard?dates=" + month);
                        List<String[]> monthRows = nationsRows(monthly);
                        for (int ri=1; ri<monthRows.size(); ri++) {
                            String[] r=monthRows.get(ri);
                            String eventKey = r[1] + "|" + r[3] + "|" + r[4];
                            unique.put(eventKey,r);
                        }
                        monthCursor.add(Calendar.MONTH,1);
                    }
                    // Include the chosen month too, if a custom date is outside the rolling window.
                    String targetMonth = target.replace("-","");
                    if (targetMonth.length() >= 6) {
                        String ym=targetMonth.substring(0,6);
                        boolean present=false;
                        for(String k:unique.keySet()) if(k.startsWith(ym.substring(0,4)+"-"+ym.substring(4,6))) { present=true; break; }
                        if(!present) {
                            JSONObject customMonth=fetchJson("https://site.api.espn.com/apis/site/v2/sports/soccer/"+slug+"/scoreboard?dates="+ym);
                            List<String[]> extra=nationsRows(customMonth);
                            for(int ri=1;ri<extra.size();ri++){String[] r=extra.get(ri);unique.put(r[1]+"|"+r[3]+"|"+r[4],r);}
                        }
                    }
                    List<String[]> allRows = new ArrayList<>();
                    allRows.add(new String[]{"gw","date","time","home","away","ft_home","ft_away","ft_result",
                        "home_corners","away_corners","home_yellow","away_yellow","home_target","away_target",
                        "home_shots","away_shots","home_fouls","away_fouls"});
                    allRows.addAll(unique.values());
                    List<String[]> fixtures = new ArrayList<>();
                    List<String[]> results = new ArrayList<>();
                    fixtures.add(allRows.get(0)); results.add(allRows.get(0));
                    for (int ri = 1; ri < allRows.size(); ri++) {
                        String[] r = allRows.get(ri);
                        boolean played = !r[5].isEmpty() && !r[6].isEmpty();
                        if (played) results.add(r);
                        if ((selectedMode.equals("all") && !played) || (!selectedMode.equals("all") && r[1].equals(target))) fixtures.add(r);
                    }
                    Map<String,Integer> fixIx = headerIndex(fixtures.get(0));
                    List<String[]> found = new ArrayList<>();
                    for (int fi = 1; fi < fixtures.size(); fi++) found.add(fixtures.get(fi));
                    found.sort((a,b) -> (val(a,fixIx,"date")+val(a,fixIx,"time")).compareTo(val(b,fixIx,"date")+val(b,fixIx,"time")));
                    List<String[]> finalResults = results;
                    int fixtureCount = fixtures.size()-1, resultCount = Math.max(0, results.size()-1);
                    ui.post(() -> renderMatches(league, found, finalResults, fixIx, date, selectedMode, fixtureCount, resultCount));
                    return;
                }
                String folder = league.folder + "/";
                String season = null, fixturesCsv = null; Exception seasonError = null;
                for (String code : seasonCandidates()) {
                    try { fixturesCsv = fetchWithFallback(folder + "fixtures_" + code + ".csv"); season = code; break; }
                    catch (Exception e) { seasonError = e; }
                }
                if (fixturesCsv == null) throw seasonError == null ? new IOException("Не удалось загрузить расписание") : seasonError;
                List<String[]> fixtures = parseCsv(fixturesCsv);
                List<String[]> results;
                try { results = parseCsv(fetchWithFallback(folder + "results_" + season + ".csv")); }
                catch (Exception unavailable) { results = new ArrayList<>(); }
                if (fixtures.isEmpty()) throw new IOException("CSV расписания не содержит заголовка и матчей.");
                historyAdded = 0;
                try { results = extendWithHistory(league, results, fixtures, season); } catch (Exception ignored) { }
                Map<String, Integer> fixIx = headerIndex(fixtures.get(0));
                if (!fixIx.containsKey("date") || !fixIx.containsKey("home") || !fixIx.containsKey("away")) throw new IOException("Неожиданный формат CSV расписания.");
                String target = date;
                if (selectedMode.equals("today")) target = today();
                else if (selectedMode.equals("tomorrow")) { Calendar cal = Calendar.getInstance(); cal.add(Calendar.DAY_OF_YEAR, 1); target = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.getTime()); }
                final String filterDate = target;
                List<String[]> found = new ArrayList<>();
                for (int i = 1; i < fixtures.size(); i++) {
                    String[] row = fixtures.get(i); String rowDate = val(row, fixIx, "date");
                    if (selectedMode.equals("all") || rowDate.equals(filterDate)) found.add(row);
                }
                found.sort((a,b) -> (val(a,fixIx,"date") + val(a,fixIx,"time")).compareTo(val(b,fixIx,"date") + val(b,fixIx,"time")));
                List<String[]> finalResults = results; int fixtureCount = fixtures.size() - 1; int resultCount = Math.max(0, results.size() - 1);
                ui.post(() -> renderMatches(league, found, finalResults, fixIx, filterDate, selectedMode, fixtureCount, resultCount));
            } catch (Exception e) {
                String message = e.getMessage() == null ? e.toString() : e.getMessage();
                ui.post(() -> { setStatus("Ошибка open-matchday: " + message); cards.removeAllViews(); });
            }
        });
    }

    // ================= API-Football: любые турниры (нужен ключ в настройках; бесплатный тариф может не отдавать текущий сезон) =================
    private static final String[] API_HEADER = {"gw","date","time","home","away","ft_home","ft_away","ft_result",
        "home_corners","away_corners","home_yellow","away_yellow","home_target","away_target","home_shots","away_shots","home_fouls","away_fouls","home_id","away_id"};
    private final Map<String, List<String[]>> apiTeamCache = new HashMap<>();

    private String[] apiRow(JSONObject f) {
        JSONObject fx = f.optJSONObject("fixture"), tm = f.optJSONObject("teams"), gl = f.optJSONObject("goals");
        if (fx == null || tm == null || tm.optJSONObject("home") == null || tm.optJSONObject("away") == null) return null;
        String iso = fx.optString("date", "");
        String date = iso.length() >= 10 ? iso.substring(0, 10) : "", time = iso.length() >= 16 ? iso.substring(11, 16) : "";
        String st = fx.optJSONObject("status") == null ? "" : fx.optJSONObject("status").optString("short", "");
        boolean finished = st.equals("FT") || st.equals("AET") || st.equals("PEN");
        String hs = "", as = "", res = "";
        if (finished && gl != null && !JSONObject.NULL.equals(gl.opt("home")) && !JSONObject.NULL.equals(gl.opt("away")) && gl.has("home") && gl.has("away")) {
            int h = gl.optInt("home"), a = gl.optInt("away"); hs = "" + h; as = "" + a; res = h > a ? "H" : h < a ? "A" : "D";
        }
        String[] r = new String[API_HEADER.length];
        Arrays.fill(r, "");
        r[1] = date; r[2] = time; r[3] = tm.optJSONObject("home").optString("name"); r[4] = tm.optJSONObject("away").optString("name");
        r[5] = hs; r[6] = as; r[7] = res;
        r[18] = "" + tm.optJSONObject("home").optInt("id"); r[19] = "" + tm.optJSONObject("away").optInt("id");
        return r;
    }

    private void loadApiFixtures(final League league, final String selectedMode, final String date) throws Exception {
        String target = date;
        if (selectedMode.equals("today") || selectedMode.equals("all")) target = today();
        else if (selectedMode.equals("tomorrow")) { Calendar cal = Calendar.getInstance(); cal.add(Calendar.DAY_OF_YEAR, 1); target = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.getTime()); }
        JSONObject j = apiFootballRequest("fixtures?date=" + target + "&timezone=Europe/Oslo");
        JSONArray resp = j.optJSONArray("response");
        final boolean aus = "API_AUS".equals(league.folder);
        TreeMap<String, List<String[]>> groups = new TreeMap<>();
        int total = 0;
        if (resp != null) for (int i = 0; i < resp.length() && total < 400; i++) {
            JSONObject f = resp.optJSONObject(i); if (f == null) continue;
            JSONObject lg = f.optJSONObject("league"); if (lg == null) continue;
            String country = lg.optString("country", "");
            if (aus && !"Australia".equalsIgnoreCase(country)) continue;
            String[] row = apiRow(f); if (row == null) continue;
            String key = country + " · " + lg.optString("name", "");
            List<String[]> g = groups.get(key); if (g == null) { g = new ArrayList<>(); groups.put(key, g); }
            g.add(row); total++;
        }
        final Map<String, Integer> ix = headerIndex(API_HEADER);
        final int totalFinal = total; final TreeMap<String, List<String[]>> gf = groups; final String targetDay = target;
        ui.post(() -> {
            cards.removeAllViews();
            setStatus("API-Football · " + targetDay + " · матчей: " + totalFinal + " · турниров: " + gf.size());
            if (gf.isEmpty()) { cards.addView(label(tr("Матчей на эту дату в API-Football нет (или тариф ключа не даёт доступ к текущему сезону)."), 15, Color.WHITE, true), lp(8, 8)); return; }
            for (Map.Entry<String, List<String[]>> e : gf.entrySet()) {
                cards.addView(label(e.getKey(), 14, Color.WHITE, true), lp(10, 4));
                League l = new League(e.getKey(), league.folder);
                List<String[]> rows = e.getValue();
                rows.sort((a, b) -> a[2].compareTo(b[2]));
                for (String[] r : rows) addMatchCard(l, r, ix, null);
            }
        });
    }

    private List<String[]> loadResultsForMatch(League league, String[] row, Map<String, Integer> ix) throws Exception {
        if (!league.folder.startsWith("API_")) return loadResultsFor(league);
        LinkedHashMap<String, String[]> uniq = new LinkedHashMap<>();
        for (String idCol : new String[]{"home_id", "away_id"}) {
            String id = val(row, ix, idCol);
            if (id.isEmpty()) continue;
            List<String[]> hist = apiTeamCache.get(id);
            if (hist == null) {
                hist = new ArrayList<>();
                JSONObject j = apiFootballRequest("fixtures?team=" + id + "&last=" + Math.max(selectedMatchCount, 20) + "&timezone=Europe/Oslo");
                JSONArray resp = j.optJSONArray("response");
                if (resp != null) for (int i = 0; i < resp.length(); i++) {
                    JSONObject f = resp.optJSONObject(i); String[] r = f == null ? null : apiRow(f);
                    if (r != null && !r[5].isEmpty()) hist.add(r);
                }
                apiTeamCache.put(id, hist);
            }
            for (String[] r : hist) uniq.put(r[1] + "|" + r[3] + "|" + r[4], r);
        }
        List<String[]> out = new ArrayList<>();
        out.add(API_HEADER);
        out.addAll(uniq.values());
        return out;
    }

    private final List<Object[]> dayMatches = new ArrayList<>();   // {League, String[] row, Map ix} — матчи на экране «Все матчи»

    private static class DayPick {
        League league; String date, home, away, report, label, key, grade; boolean pos; double p; Map<String, Double> probs;
    }
    private static final int DAY_MAX_MATCHES = 40;
    private static final double DAY_MAX_P = 0.72, DAY_MIN_P = 0.55;   // ≈ коэффициент 1.4–1.8: событие с коэффициентом 1.1 — не ставка

    /** Экспресс дня (3 самых надёжных события из разных матчей) или ставка дня (1 самое надёжное). Считает все матчи на экране. */
    private void runDayPicks(final boolean express) {
        final List<Object[]> ms = new ArrayList<>(dayMatches);
        if (ms.isEmpty()) { toast("Нет матчей для расчёта"); return; }
        setStatus("Считаю надёжные события дня…");
        worker.execute(() -> {
            List<DayPick> picks = new ArrayList<>();
            int total = Math.min(ms.size(), DAY_MAX_MATCHES), done = 0;
            for (Object[] m : ms) {
                if (done >= total) break;
                done++;
                final int d0 = done;
                ui.post(() -> setStatus(tr("Считаю надёжные события дня… ") + d0 + "/" + total));
                League l = (League) m[0]; String[] r = (String[]) m[1];
                @SuppressWarnings("unchecked") Map<String, Integer> ix = (Map<String, Integer>) m[2];
                String home = val(r, ix, "home"), away = val(r, ix, "away"), date = val(r, ix, "date");
                try {
                    List<String[]> rr = loadResultsForMatch(l, r, ix);
                    String rep = makeReport(l, home, away, rr);
                    Map<String, Double> pr = new HashMap<>(lastProbs);
                    if (pr.isEmpty() || !pr.containsKey("n_min")) continue;
                    String g = gradeLetter(pr.get("n_min"), pr.get("n_stats") != null && pr.get("n_stats") > 0);
                    if (g.equals("C")) continue;
                    Object[] best = null;
                    for (Object[] c : betCandidates(home, away, pr)) {
                        String key = (String) c[3]; double p = (Double) c[0];
                        if (key.equals("goals_o1.5") || key.equals("res_draw") || p > DAY_MAX_P || p < DAY_MIN_P) continue;   // тривиальные «1.5 больше» не берём
                        if (best == null || p > (Double) best[0]) best = c;
                    }
                    if (best == null) continue;
                    DayPick k = new DayPick();
                    k.league = l; k.date = date; k.home = home; k.away = away; k.report = rep; k.label = (String) best[1]; k.key = (String) best[3];
                    k.pos = (Boolean) best[4]; k.p = (Double) best[0]; k.grade = g; k.probs = pr;
                    picks.add(k);
                } catch (Exception ignored) { }
            }
            Collections.sort(picks, (x, y) -> Double.compare(y.p, x.p));
            final List<DayPick> top = new ArrayList<>(picks.subList(0, Math.min(express ? 3 : 1, picks.size())));
            final int analyzed = done, usable = picks.size(), shown = ms.size();
            ui.post(() -> {
                setStatus("Все лиги · матчей: " + shown + " · рассчитано: " + analyzed + " · с надёжными данными: " + usable);
                if (top.size() < (express ? 3 : 1)) {
                    new AlertDialog.Builder(this).setTitle(tr(express ? "🎰 Экспресс дня" : "⭐ Ставка дня"))
                        .setMessage(tr("Недостаточно матчей с надёжными данными (A или B). Найдено: ") + usable + tr(". Попробуй другой день или добавь матчи топовых лиг."))
                        .setPositiveButton(tr("Закрыть"), null).show();
                    return;
                }
                if (express) showExpressDialog(legsOf(top), top);
                else showDayBet(top.get(0), picks);
            });
        });
    }

    private List<JSONObject> legsOf(List<DayPick> picks) {
        List<JSONObject> legs = new ArrayList<>();
        for (DayPick k : picks) {
            try {
                JSONObject o = new JSONObject();
                o.put("date", k.date); o.put("home", k.home); o.put("away", k.away);
                o.put("bet_v", 3); o.put("bet_label", k.label); o.put("bet_p", k.p); o.put("bet_key", k.key); o.put("bet_pos", k.pos); o.put("league", k.league.title);
                JSONObject pr = new JSONObject(); pr.put("n_min", k.probs.get("n_min")); pr.put("n_stats", k.probs.get("n_stats") == null ? 0 : k.probs.get("n_stats"));
                o.put("probs", pr);
                legs.add(o);
            } catch (Exception ignored) { }
        }
        return legs;
    }

    private void saveDayPick(DayPick k) {
        saveHistory(k.date + " · " + k.league.title + "\n" + k.home + " — " + k.away + "\n" + k.report);
        saveLearningForecast(k.date, k.league.title, k.league.folder, k.home, k.away, k.report, k.probs);
    }

    private void showDayBet(final DayPick best, List<DayPick> all) {
        StringBuilder sb = new StringBuilder();
        sb.append(best.date).append(" · ").append(best.league.title).append("\n").append(best.home).append(" — ").append(best.away).append("\n\n")
          .append("🎯 ").append(best.label).append("\nВероятность по модели: ").append(Math.round(best.p * 100)).append("%\n")
          .append("🛡 Надёжность данных: ").append(best.grade).append("\n");
        int n = 0;
        for (DayPick k : all) {
            if (k == best) continue;
            if (n == 0) sb.append("\nСледом по надёжности:\n");
            if (n++ >= 3) break;
            sb.append("• ").append(k.home).append(" — ").append(k.away).append(": ").append(k.label).append(" — ").append(Math.round(k.p * 100)).append("%\n");
        }
        sb.append("\nЭто самое вероятное событие из рассчитанных матчей дня (вероятность 55–72%, где коэффициент букмекера обычно 1.4–1.8; события с коэффициентом около 1.1 не берутся). Это расчёт модели, а не гарантия, коэффициентов букмекера программа не знает.");
        new AlertDialog.Builder(this).setTitle(tr("⭐ Ставка дня")).setMessage(translateReport(sb.toString()))
            .setPositiveButton(tr("Закрыть"), null)
            .setNeutralButton(tr("Сохранить в историю"), (d, w) -> { saveDayPick(best); toast("Матч сохранён в историю и базу обучения"); }).show();
    }

    private final Map<String, List<String[]>> resultsCache = new HashMap<>();

    // Результаты лиги для анализа (в режиме «Все матчи» грузятся только при нажатии АНАЛИЗ).
    private List<String[]> loadResultsFor(League league) throws Exception {
        List<String[]> cached = resultsCache.get(league.folder);
        if (cached != null) return cached;
        if (ESPN_ONLY.contains(league.folder)) {
            List<String[]> res = new ArrayList<>();
            res.add(nationsRows(null).get(0));
            if (!"UEFA_NATIONS_LEAGUE".equals(league.folder)) {   // у сборных история берётся отдельно (loadNationalHistory)
                Calendar mc = Calendar.getInstance(); mc.add(Calendar.MONTH, -6);
                SimpleDateFormat mf = new SimpleDateFormat("yyyyMM", Locale.US);
                LinkedHashMap<String, String[]> uniq = new LinkedHashMap<>();
                for (int i = 0; i <= 6; i++) {
                    try {
                        List<String[]> mr = nationsRows(fetchJson("https://site.api.espn.com/apis/site/v2/sports/soccer/" + ESPN.get(league.folder) + "/scoreboard?dates=" + mf.format(mc.getTime())));
                        for (int k = 1; k < mr.size(); k++) { String[] r = mr.get(k); if (!r[5].isEmpty() && !r[6].isEmpty()) uniq.put(r[1] + "|" + r[3] + "|" + r[4], r); }
                    } catch (Exception ignored) { }
                    mc.add(Calendar.MONTH, 1);
                }
                res.addAll(uniq.values());
            }
            resultsCache.put(league.folder, res);
            return res;
        }
        String folder = league.folder + "/";
        String season = null; List<String[]> fixtures = null; Exception err = null;
        for (String code : seasonCandidates()) {
            try { fixtures = parseCsv(fetchWithFallback(folder + "fixtures_" + code + ".csv")); season = code; break; }
            catch (Exception e) { err = e; }
        }
        if (fixtures == null) throw err == null ? new IOException("Не удалось загрузить расписание") : err;
        List<String[]> results;
        try { results = parseCsv(fetchWithFallback(folder + "results_" + season + ".csv")); }
        catch (Exception unavailable) { results = new ArrayList<>(); }
        historyAdded = 0;
        try { results = extendWithHistory(league, results, fixtures, season); } catch (Exception ignored) { }
        resultsCache.put(league.folder, results);
        return results;
    }

    // «Все матчи»: расписание всех лиг на выбранную дату, лиги по порядку списка (топовые сверху).
    private void loadAllMatches(final String selectedMode, final String date) throws Exception {
        final SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        final Set<String> days = new HashSet<>();
        Calendar cal = Calendar.getInstance();
        if (selectedMode.equals("today")) days.add(today());
        else if (selectedMode.equals("tomorrow")) { cal.add(Calendar.DAY_OF_YEAR, 1); days.add(f.format(cal.getTime())); }
        else if (selectedMode.equals("all")) { for (int i = 0; i < 3; i++) { days.add(f.format(cal.getTime())); cal.add(Calendar.DAY_OF_YEAR, 1); } }
        else days.add(date);
        final List<String> seasons = seasonCandidates();
        java.util.concurrent.ExecutorService pool = Executors.newFixedThreadPool(8);
        List<java.util.concurrent.Future<Object[]>> futures = new ArrayList<>();
        for (final League l : leagues) {
            if ("ALL_MATCHES".equals(l.folder)) continue;
            if (ESPN_ONLY.contains(l.folder)) {
                futures.add(pool.submit(() -> {
                    try {
                        List<String[]> hit = new ArrayList<>(); String[] header = null;
                        for (String d : days) {
                            List<String[]> rr = nationsRows(fetchJson("https://site.api.espn.com/apis/site/v2/sports/soccer/" + ESPN.get(l.folder) + "/scoreboard?dates=" + d.replace("-", "")));
                            header = rr.get(0);
                            for (int i = 1; i < rr.size(); i++) if (days.contains(rr.get(i)[1])) hit.add(rr.get(i));
                        }
                        if (header == null) return null;
                        final Map<String, Integer> ix = headerIndex(header);
                        hit.sort((a, b) -> val(a, ix, "time").compareTo(val(b, ix, "time")));
                        return new Object[]{l, ix, hit};
                    } catch (Exception e) { return null; }
                }));
                continue;
            }
            futures.add(pool.submit(() -> {
                for (String code : seasons) {
                    try {
                        List<String[]> fx = parseCsv(fetchWithFallback(l.folder + "/fixtures_" + code + ".csv"));
                        if (fx.isEmpty()) return null;
                        Map<String, Integer> ix = headerIndex(fx.get(0));
                        if (!ix.containsKey("date") || !ix.containsKey("home") || !ix.containsKey("away")) return null;
                        List<String[]> hit = new ArrayList<>();
                        for (int i = 1; i < fx.size(); i++) if (days.contains(val(fx.get(i), ix, "date"))) hit.add(fx.get(i));
                        hit.sort((a, b) -> val(a, ix, "time").compareTo(val(b, ix, "time")));
                        return new Object[]{l, ix, hit};
                    } catch (Exception ignored) { }
                }
                return null;
            }));
        }
        pool.shutdown();
        final List<Object[]> groups = new ArrayList<>();
        int failed = 0;
        for (java.util.concurrent.Future<Object[]> fu : futures) {
            Object[] g = null;
            try { g = fu.get(); } catch (Exception ignored) { }
            if (g == null) failed++; else if (!((List<?>) g[2]).isEmpty()) groups.add(g);
        }
        final int failedCount = failed;
        ui.post(() -> {
            cards.removeAllViews();
            int total = 0;
            for (Object[] g : groups) total += ((List<?>) g[2]).size();
            setStatus("Все лиги · матчей: " + total + " · лиг с матчами: " + groups.size()
                    + (failedCount > 0 ? " · не загрузилось лиг: " + failedCount : ""));
            if (groups.isEmpty()) {
                cards.addView(label(tr("Матчей на выбранную дату нет ни в одной лиге из открытых расписаний."), 15, Color.WHITE, true), lp(8, 8));
                return;
            }
            dayMatches.clear();
            LinearLayout dayBar = new LinearLayout(this);
            Button bx = smallButton(tr("🎰 ЭКСПРЕСС ДНЯ")), bb = smallButton(tr("⭐ СТАВКА ДНЯ"));
            dayBar.addView(bx, new LinearLayout.LayoutParams(0, dp(42), 1f));
            LinearLayout.LayoutParams bbp = new LinearLayout.LayoutParams(0, dp(42), 1f); bbp.setMargins(dp(6), 0, 0, 0);
            dayBar.addView(bb, bbp);
            cards.addView(dayBar, lp(0, 6));
            bx.setOnClickListener(v -> runDayPicks(true));
            bb.setOnClickListener(v -> runDayPicks(false));
            for (Object[] g : groups) {
                @SuppressWarnings("unchecked") List<String[]> rows = (List<String[]>) g[2];
                @SuppressWarnings("unchecked") Map<String, Integer> ix = (Map<String, Integer>) g[1];
                League l = (League) g[0];
                cards.addView(label(tr(l.title), 14, Color.WHITE, true), lp(10, 4));
                for (String[] r : rows) { addMatchCard(l, r, ix, null); dayMatches.add(new Object[]{l, r, ix}); }
            }
        });
    }

    private void renderMatches(League league, List<String[]> found, List<String[]> results, Map<String,Integer> fixIx,
                               String date, String selectedMode, int fixtureCount, int resultCount) {
        setStatus("open-matchday · расписание: " + fixtureCount + " · сыграно: " + Math.max(0, resultCount - historyAdded) + " · найдено: " + found.size()
                + (historyAdded > 0 ? " · история прошлых сезонов: +" + historyAdded : ""));
        if (found.isEmpty()) {
            String msg = selectedMode.equals("all") ? "В опубликованном файле расписания пока нет будущих матчей." : "Матчей на дату " + date + " в опубликованном расписании этого турнира нет. Это не ошибка API.";
            cards.addView(label(msg, 15, Color.WHITE, true), lp(8, 8));
            return;
        }
        for (String[] row : found) addMatchCard(league, row, fixIx, results);
    }

    // Дополнительный источник статистики: публичный ESPN Site API (без ключа).
    // Используется только как резерв, когда поле отсутствует в open-matchday.
    // Коды лиг в публичном ESPN Site API. Если код для лиги не существует, запрос просто вернёт пустой ответ.
    private static final Map<String,String> ESPN = new HashMap<>();
    static {
        String[][] m = {
            {"UEFA_1_champions-league","uefa.champions"},{"UEFA_1_europa-league","uefa.europa"},{"UEFA_1_conference-league","uefa.europa.conf"},
            {"UEFA_NATIONS_LEAGUE","uefa.nations"},{"UEFA_W_champions-league","uefa.wchampions"},{"AUS_W_a-league-women","aus.w.1"},{"AUS_CUP_australia-cup","aus.cup"},
            {"ENG_CUP_fa-cup","eng.fa"},{"ENG_CUP_efl-cup","eng.league_cup"},{"ESP_CUP_copa-del-rey","esp.copa_del_rey"},
            {"ITA_CUP_coppa-italia","ita.coppa_italia"},{"GER_CUP_dfb-pokal","ger.dfb_pokal"},{"NED_CUP_knvb-beker","ned.cup"},
            {"POR_CUP_taca-de-portugal","por.taca.portugal"},{"SCO_CUP_scottish-cup","sco.tennents"},{"SCO_CUP_league-cup","sco.cis"},
            {"ENG_1_premier-league","eng.1"},{"ESP_1_la-liga","esp.1"},{"GER_1_bundesliga","ger.1"},{"ITA_1_serie-a","ita.1"},
            {"FRA_1_ligue-1","fra.1"},{"NED_1_eredivisie","ned.1"},{"POR_1_primeira-liga","por.1"},{"BEL_1_pro-league","bel.1"},
            {"TUR_1_super-lig","tur.1"},{"GRE_1_super-league","gre.1"},{"RUS_1_premier-liga","rus.1"},{"UKR_1_premier-league","ukr.1"},
            {"NOR_1_eliteserien","nor.1"},{"SCO_1_premiership","sco.1"},{"POL_1_ekstraklasa","pol.1"},
            {"ENG_2_championship","eng.2"},{"ENG_3_league-one","eng.3"},{"ENG_4_league-two","eng.4"},
            {"SCO_2_championship","sco.2"},{"SCO_3_league-one","sco.3"},{"SCO_4_league-two","sco.4"},
            {"AUT_1_bundesliga","aut.1"},{"SUI_1_super-league","sui.1"},{"DEN_1_superliga","den.1"},{"SWE_1_allsvenskan","swe.1"},
            {"ROU_1_liga-1","rou.1"},{"CRO_1_hnl","cro.1"},{"CZE_1_chance-liga","cze.1"},{"CYP_1_first-division","cyp.1"},
            {"SVK_1_nike-liga","svk.1"},{"SVN_1_prva-liga","svn.1"},{"FIN_1_veikkausliiga","fin.1"},{"KAZ_1_premier-league","kaz.1"},
            {"ESP_2_segunda-division","esp.2"},{"ITA_2_serie-b","ita.2"},{"FRA_2_ligue-2","fra.2"},{"NED_2_eerste-divisie","ned.2"},
            {"BRA_1_serie-a","bra.1"},{"BRA_2_serie-b","bra.2"},{"ARG_1_liga-profesional","arg.1"},{"ARG_2_primera-nacional","arg.2"},
            {"MEX_1_liga-mx","mex.1"},{"USA_1_mls","usa.1"},{"JPN_1_j1-league","jpn.1"},{"AUS_1_a-league","aus.1"},{"CHN_1_super-league","chn.1"}
        };
        for (String[] e : m) ESPN.put(e[0], e[1]);
    }
    private String espnLeague(League league) { String v = ESPN.get(league.folder); return v == null ? "" : v; }

    // true, если в строке CSV не хватает хотя бы одного показателя (тогда имеет смысл спрашивать ESPN)
    private boolean missingStats(String[] r, Map<String,Integer> ix) {
        for (String m : new String[]{"corners","yellow","target","shots","fouls"})
            if (number(r, ix, "home_" + m) == null || number(r, ix, "away_" + m) == null) return true;
        return false;
    }
    private boolean noStats(TeamStats t) {
        for (String m : new String[]{"corners","yellow","target","shots","fouls"}) { ArrayList<Double> v = t.values(m); if (v != null && !v.isEmpty()) return false; }
        return true;
    }

    // ESPN schedule/results adapter for UEFA Nations League (not present in open-matchday CSV registry).
    private List<String[]> nationsRows(JSONObject board) {
        List<String[]> rows = new ArrayList<>();
        rows.add(new String[]{"gw","date","time","home","away","ft_home","ft_away","ft_result",
                "home_corners","away_corners","home_yellow","away_yellow","home_target","away_target",
                "home_shots","away_shots","home_fouls","away_fouls"});
        JSONArray events = board == null ? null : board.optJSONArray("events");
        if (events == null) return rows;
        for (int i=0; i<events.length(); i++) {
            JSONObject ev = events.optJSONObject(i); if (ev == null) continue;
            JSONArray comps = ev.optJSONArray("competitions"); if (comps == null || comps.length()==0) continue;
            JSONObject comp = comps.optJSONObject(0); if (comp == null) continue;
            JSONArray sides = comp.optJSONArray("competitors"); if (sides == null) continue;
            String home="", away="", hs="", as="";
            for (int j=0; j<sides.length(); j++) {
                JSONObject side=sides.optJSONObject(j); if(side==null)continue;
                JSONObject team=side.optJSONObject("team");
                String name=team==null?"":team.optString("displayName",team.optString("name",""));
                if ("home".equalsIgnoreCase(side.optString("homeAway"))) { home=name; hs=side.optString("score",""); }
                else { away=name; as=side.optString("score",""); }
            }
            if(home.isEmpty()||away.isEmpty()) continue;
            String date=ev.optString("date","");
            if(date.length()>=10) date=date.substring(0,10);
            String time="";
            if(date.length()==10) {
                try { time=new SimpleDateFormat("HH:mm",Locale.US).format(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm",Locale.US).parse(ev.optString("date").substring(0,16))); } catch(Exception ignored) {}
            }
            String round=comp.optString("series",""); 
            String completed=comp.optJSONObject("status")==null?"":comp.optJSONObject("status").optJSONObject("type")==null?"":comp.optJSONObject("status").optJSONObject("type").optString("completed","");
            String result="";
            if(!hs.isEmpty()&&!as.isEmpty()) {
                try { int h=Integer.parseInt(hs), a=Integer.parseInt(as); result=h>a?"H":h<a?"A":"D"; } catch(Exception ignored) { hs=""; as=""; }
            }
            rows.add(new String[]{round,date,time,home,away,hs,as,result,"","","","","","","","","",""});
        }
        List<String[]> body = new ArrayList<>(rows.subList(1, rows.size()));
        Collections.sort(body, (a,b)->(a[1]+a[2]).compareTo(b[1]+b[2]));
        rows.subList(1, rows.size()).clear();
        rows.addAll(body);
        return rows;
    }

    private JSONObject fetchJson(String urlText) throws Exception {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(urlText).openConnection();
            c.setConnectTimeout(5000); c.setReadTimeout(7000);
            c.setRequestProperty("User-Agent", "Mozilla/5.0 FootballAnalyzer/3.8");
            c.setRequestProperty("Accept", "application/json");
            int code = c.getResponseCode();
            InputStream in = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
            if (in == null) throw new IOException("ESPN HTTP " + code);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            try (InputStream stream = in) { byte[] b = new byte[8192]; int n; while ((n=stream.read(b))!=-1) out.write(b,0,n); }
            if (code < 200 || code >= 300) throw new IOException("ESPN HTTP " + code);
            return new JSONObject(out.toString("UTF-8"));
        } finally { if (c != null) c.disconnect(); }
    }

    private String normTeam(String name) {
        String n = java.text.Normalizer.normalize(name == null ? "" : name, java.text.Normalizer.Form.NFD)
                .replaceAll("\\p{M}+", "").toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", "");
        n = n.replace("fc", "").replace("afc", "").replace("cf", "");
        if (n.equals("turkiye") || n.equals("turkiyea")) n = "turkey";
        if (n.equals("czechrepublic")) n = "czechia";
        if (n.equals("korearepublic")) n = "southkorea";
        if (n.equals("iriran")) n = "iran";
        return n;
    }
    private boolean sameTeam(String a, String b) {
        String x=normTeam(a), y=normTeam(b);
        return !x.isEmpty() && !y.isEmpty() && (x.equals(y) || (x.length()>=3 && y.length()>=3 && (x.contains(y)||y.contains(x))));
    }
    private String statName(JSONObject stat) {
        return (stat.optString("name", "") + " " + stat.optString("displayName", "") + " " + stat.optString("abbreviation", "")).toLowerCase(Locale.ROOT).replaceAll("[^a-z]", "");
    }
    private Double espnStat(JSONArray stats, String wanted) {
        if (stats == null) return null;
        for (int i=0;i<stats.length();i++) {
            JSONObject st=stats.optJSONObject(i); if(st==null) continue;
            String n=statName(st); boolean match=false;
            if (wanted.equals("corners")) match=n.contains("woncorners")||n.equals("corners")||n.contains("cornerkicks");
            else if (wanted.equals("yellow")) match=n.contains("yellowcards")||n.equals("yellowcard");
            else if (wanted.equals("target")) match=n.contains("shotsontarget")||n.contains("shotsongoal");
            else if (wanted.equals("shots")) match=n.equals("totalshots")||n.equals("shots")||n.equals("totalshot");
            else if (wanted.equals("fouls")) match=n.contains("foulscommitted")||n.equals("fouls");
            if (match) {
                String v=st.optString("displayValue", "");
                if(v.isEmpty()) v=st.optString("value", "");
                try { return Double.parseDouble(v.replace(",", "")); } catch(Exception ignored) {}
            }
        }
        return null;
    }
    private Map<String,Double> parseEspnTeamStats(JSONObject teamBox) {
        Map<String,Double> m=new HashMap<>();
        JSONArray stats=teamBox.optJSONArray("statistics");
        for(String key:new String[]{"corners","yellow","target","shots","fouls"}) {
            Double v=espnStat(stats,key); if(v!=null)m.put(key,v);
        }
        return m;
    }

    // ESPN scoreboard events often include team statistics directly on competitors.
    // Use this before requesting /summary so UCL/UEL matches do not lose available data.
    private Map<String,Double> parseEspnCompetitorStats(JSONObject competitor) {
        Map<String,Double> m = new HashMap<>();
        JSONArray stats = competitor.optJSONArray("statistics");
        for (String key : new String[]{"corners","target","shots","fouls"}) {
            Double value = espnStat(stats, key);
            if (value != null) m.put(key, value);
        }
        return m;
    }

    private Map<String,Integer> parseEspnYellowCards(JSONObject event) {
        Map<String,Integer> cards = new HashMap<>();
        JSONArray competitions = event.optJSONArray("competitions");
        if (competitions == null || competitions.length() == 0) return cards;
        JSONArray competitors = competitions.optJSONObject(0).optJSONArray("competitors");
        if (competitors == null) return cards;
        String homeId = "", awayId = "";
        for (int i=0; i<competitors.length(); i++) {
            JSONObject c = competitors.optJSONObject(i);
            if (c == null) continue;
            if ("home".equalsIgnoreCase(c.optString("homeAway"))) homeId = c.optString("id","");
            else awayId = c.optString("id","");
        }
        int homeCards = 0, awayCards = 0;
        JSONArray details = event.optJSONArray("details");
        if (details == null && competitions.optJSONObject(0) != null)
            details = competitions.optJSONObject(0).optJSONArray("details");
        if (details != null) for (int i=0; i<details.length(); i++) {
            JSONObject d = details.optJSONObject(i);
            if (d == null) continue;
            boolean yellow = d.optBoolean("yellowCard", false)
                    || "Yellow Card".equalsIgnoreCase(d.optJSONObject("type") == null ? "" : d.optJSONObject("type").optString("text",""));
            if (!yellow) continue;
            JSONObject team = d.optJSONObject("team");
            String id = team == null ? "" : team.optString("id","");
            if (!homeId.isEmpty() && homeId.equals(id)) homeCards++;
            else if (!awayId.isEmpty() && awayId.equals(id)) awayCards++;
        }
        if (details == null || details.length() == 0) return cards; // no event details => unknown, not 0
        if (!homeId.isEmpty()) cards.put(homeId, homeCards);
        if (!awayId.isEmpty()) cards.put(awayId, awayCards);
        return cards;
    }
    private String matchKey(String date,String home,String away) { return date+"|"+normTeam(home)+"|"+normTeam(away); }

    private String shiftIsoDate(String isoDate, int days) {
        try {
            SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
            fmt.setTimeZone(TimeZone.getTimeZone("UTC"));
            Date d = fmt.parse(isoDate);
            Calendar c = Calendar.getInstance(TimeZone.getTimeZone("UTC"), Locale.US);
            c.setTime(d);
            c.add(Calendar.DAY_OF_MONTH, days);
            return fmt.format(c.getTime());
        } catch (Exception e) {
            return isoDate;
        }
    }

    private JSONObject findEspnEvent(JSONObject board, String rowHome, String rowAway) {
        JSONArray events = board == null ? null : board.optJSONArray("events");
        if (events == null) return null;
        for (int i=0; i<events.length(); i++) {
            JSONObject ev = events.optJSONObject(i);
            if (ev == null) continue;
            JSONArray comps = ev.optJSONArray("competitions");
            if (comps == null || comps.length()==0) continue;
            JSONObject comp = comps.optJSONObject(0);
            JSONArray sides = comp == null ? null : comp.optJSONArray("competitors");
            if (sides == null) continue;
            String eh="", ea="";
            for (int j=0; j<sides.length(); j++) {
                JSONObject side=sides.optJSONObject(j);
                JSONObject team=side==null?null:side.optJSONObject("team");
                if (team==null) continue;
                String n=team.optString("displayName",team.optString("name",""));
                if ("home".equalsIgnoreCase(side.optString("homeAway"))) eh=n; else ea=n;
            }
            if (sameTeam(rowHome,eh) && sameTeam(rowAway,ea)) return ev;
        }
        return null;
    }

    private void mergeEspnStats(Map<String,Double> target, Map<String,Double> source) {
        if (source == null) return;
        for (String k : new String[]{"corners","yellow","target","shots","fouls"}) {
            if (source.containsKey(k)) target.put(k, source.get(k));
        }
    }

    private Map<String,Map<String,Double>> loadEspnFallback(League league, String home, String away, List<String[]> rows, Map<String,Integer> ix) {
        Map<String,Map<String,Double>> out=new HashMap<>();
        String slug=espnLeague(league);
        if (slug.isEmpty()) return out;

        LinkedHashMap<String,String[]> candidates=new LinkedHashMap<>();
        for (String team : new String[]{home,away}) {
            ArrayList<String[]> apps=new ArrayList<>();
            for (int i=1;i<rows.size();i++) {
                String[] r=rows.get(i);
                if (sameTeam(team,val(r,ix,"home")) || sameTeam(team,val(r,ix,"away"))) apps.add(r);
            }
            apps.sort((a,b)->val(b,ix,"date").compareTo(val(a,ix,"date")));
            int count=0;
            for (String[] r:apps) {
                if (count>=selectedMatchCount) break;
                String k=matchKey(val(r,ix,"date"),val(r,ix,"home"),val(r,ix,"away"));
                if (missingStats(r,ix) && !"football-data".equals(val(r,ix,"source"))) candidates.put(k,r);
                count++;
            }
        }

        // UEFA competitions can span many months. A single wide ESPN scoreboard
        // range is truncated/incomplete, so query each match date (free ESPN endpoint).
        Map<String,JSONObject> scoreboards = new HashMap<>();
        int misses = 0;
        for (String[] r : candidates.values()) {
            String date=val(r,ix,"date"), rh=val(r,ix,"home"), ra=val(r,ix,"away");
            if (date.length()!=10) continue;
            String key=matchKey(date,rh,ra);
            try {
                JSONObject event=null;
                for (int offset=-1; offset<=1 && event==null; offset++) {
                    String queryDate=shiftIsoDate(date,offset);
                    JSONObject board=scoreboards.get(queryDate);
                    if (board==null) {
                        board=cachedBoard(slug,queryDate.replace("-",""),queryDate.compareTo(today())<0);
                        if (board==null) board=new JSONObject();
                        scoreboards.put(queryDate,board);
                    }
                    event=findEspnEvent(board,rh,ra);
                }
                if (event==null) { misses++; if (misses>=4 && out.isEmpty()) break; continue; }

                Map<String,Map<String,Double>> perSide=new HashMap<>();
                perSide.put("home",new HashMap<String,Double>());
                perSide.put("away",new HashMap<String,Double>());

                // Read any values embedded in scoreboard competitors.
                JSONArray comps=event.optJSONArray("competitions");
                JSONArray sides=(comps==null||comps.length()==0||comps.optJSONObject(0)==null)
                        ? null : comps.optJSONObject(0).optJSONArray("competitors");
                Map<String,Integer> yellowById=parseEspnYellowCards(event);
                if (sides!=null) for (int j=0;j<sides.length();j++) {
                    JSONObject side=sides.optJSONObject(j);
                    if (side==null) continue;
                    JSONObject team=side.optJSONObject("team");
                    String teamName=team==null?"":team.optString("displayName",team.optString("name",""));
                    String sideName=sameTeam(rh,teamName)?"home":sameTeam(ra,teamName)?"away":"";
                    if (sideName.isEmpty()) continue;
                    mergeEspnStats(perSide.get(sideName),parseEspnCompetitorStats(side));
                    String teamId=side.optString("id","");
                    if (yellowById.containsKey(teamId)) perSide.get(sideName).put("yellow",(double)yellowById.get(teamId));
                }

                // Always read summary too and merge field-by-field. Previously, one
                // scoreboard value could prevent summary from filling the other metrics.
                String eventId=event.optString("id","");
                if (!eventId.isEmpty()) {
                    try {
                        JSONObject summary=fetchJson("https://site.api.espn.com/apis/site/v2/sports/soccer/"+slug+"/summary?event="+eventId);
                        JSONObject box=summary.optJSONObject("boxscore");
                        JSONArray teams=box==null?null:box.optJSONArray("teams");
                        if (teams!=null) for (int j=0;j<teams.length();j++) {
                            JSONObject tb=teams.optJSONObject(j);
                            if (tb==null) continue;
                            JSONObject t=tb.optJSONObject("team");
                            String tn=t==null?"":t.optString("displayName",t.optString("name",""));
                            String sideName=sameTeam(rh,tn)?"home":sameTeam(ra,tn)?"away":"";
                            if (!sideName.isEmpty()) mergeEspnStats(perSide.get(sideName),parseEspnTeamStats(tb));
                        }
                    } catch(Exception ignored) { }
                }

                for (String sideName : new String[]{"home","away"}) {
                    if (!perSide.get(sideName).isEmpty()) out.put(key+"|"+sideName,perSide.get(sideName));
                }
            } catch(Exception ignored) { /* ESPN may not publish stats for every match */ }
        }
        return out;
    }

    private static class TeamStats {
        int played, wins, draws, losses;
        double goalsFor, goalsAgainst;
        final Map<String, ArrayList<Double>> metrics = new HashMap<>();
        final Map<String, ArrayList<Double>> conceded = new HashMap<>();
        void addConceded(String key, Double value) { if (value == null) return; if (!conceded.containsKey(key)) conceded.put(key, new ArrayList<>()); conceded.get(key).add(value); }
        ArrayList<Double> concededValues(String key) { return conceded.get(key); }
        void addMetric(String key, Double value) {
            if (value == null) return;
            if (!metrics.containsKey(key)) metrics.put(key, new ArrayList<>());
            metrics.get(key).add(value);
        }
        ArrayList<Double> values(String key) { return metrics.get(key); }
        double metricSum(String key) { ArrayList<Double> v=values(key); if(v==null)return 0; double s=0; for(double x:v)s+=x; return s; }
        double metricAvg(String key) { ArrayList<Double> v=values(key); return v==null||v.isEmpty()?Double.NaN:metricSum(key)/v.size(); }
        double avgGoalsFor() { return played == 0 ? 0 : goalsFor / played; }
        double avgGoalsAgainst() { return played == 0 ? 0 : goalsAgainst / played; }
        String form() { return "В-Н-П: " + wins + "-" + draws + "-" + losses; }
    }

    private TextView teamLine(String name) {
        TextView t = label(name, 15, Color.WHITE, true);
        t.setSingleLine(true); t.setEllipsize(TextUtils.TruncateAt.END);
        return t;
    }

    private void addMatchCard(League league, String[] match, Map<String,Integer> fixIx, List<String[]> resultRows) {
        final LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(12), dp(9), dp(12), dp(9)); box.setBackground(shape(PANEL, 10)); cards.addView(box, lp(0, 6));
        final String date = val(match,fixIx,"date"), time = val(match,fixIx,"time"), home = val(match,fixIx,"home"), away = val(match,fixIx,"away"), round = val(match,fixIx,"gw");

        LinearLayout top = new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout teams = new LinearLayout(this); teams.setOrientation(LinearLayout.VERTICAL);
        teams.addView(label(date + (time.isEmpty() ? "" : " · " + time) + (round.isEmpty() ? "" : " · тур " + round), 11, MUTED, false));
        teams.addView(teamLine(home), lp(2, 0));
        teams.addView(teamLine(away), lp(0, 0));
        top.addView(teams, new LinearLayout.LayoutParams(0, -2, 1f));
        final Button analyze = smallButton("АНАЛИЗ");
        final Button bet = smallButton("🎯 СТАВКА");
        bet.setVisibility(View.GONE);
        LinearLayout rightCol = new LinearLayout(this); rightCol.setOrientation(LinearLayout.VERTICAL);
        rightCol.addView(analyze, new LinearLayout.LayoutParams(-1, dp(40)));
        LinearLayout.LayoutParams betLp = new LinearLayout.LayoutParams(-1, dp(36)); betLp.setMargins(0, dp(4), 0, 0);
        rightCol.addView(bet, betLp);
        top.addView(rightCol, new LinearLayout.LayoutParams(dp(110), -2));
        box.addView(top);

        final TextView report = label("", 12, 0xffdbe7f1, false);
        report.setLineSpacing(dp(2), 1.0f); report.setPadding(0, dp(8), 0, 0); report.setVisibility(View.GONE);
        box.addView(report);
        final Button save = smallButton("💾 СОХРАНИТЬ АНАЛИЗ В ИСТОРИЮ");
        save.setVisibility(View.GONE); box.addView(save, new LinearLayout.LayoutParams(-1, dp(38)));

        final String[] cachedReport = {""};
        final Map<String, Double> cardProbs = new HashMap<>();
        analyze.setOnClickListener(v -> {
            if (!cachedReport[0].isEmpty()) {            // уже рассчитан: свернуть / развернуть
                boolean show = report.getVisibility() != View.VISIBLE;
                report.setVisibility(show ? View.VISIBLE : View.GONE);
                save.setVisibility(show ? View.VISIBLE : View.GONE);
                bet.setVisibility(show ? View.VISIBLE : View.GONE);
                analyze.setText(tr(show ? "СВЕРНУТЬ" : "РАЗВЕРНУТЬ"));
                return;
            }
            analyze.setEnabled(false);
            report.setVisibility(View.VISIBLE);
            report.setText(tr("Собираю статистику последних ") + selectedMatchCount + tr(" матчей…"));
            worker.execute(() -> {
                String text;
                try { text = makeReport(league, home, away, resultRows != null ? resultRows : loadResultsForMatch(league, match, fixIx)); cardProbs.clear(); cardProbs.putAll(lastProbs); }
                catch (Exception e) { text = tr("⚠️ Не удалось рассчитать анализ: ") + (e.getMessage() == null ? e.toString() : e.getMessage()); }
                final String finalText = text;
                ui.post(() -> {
                    cachedReport[0] = finalText; report.setText(finalText);
                    save.setVisibility(View.VISIBLE); bet.setVisibility(View.VISIBLE); analyze.setEnabled(true); analyze.setText(tr("СВЕРНУТЬ"));
                });
            });
        });
        bet.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle(tr("🎯 Рекомендуемая ставка"))
                .setMessage(translateReport(recommendBet(home, away, cardProbs))).setPositiveButton(tr("Закрыть"), null).show());
        save.setOnClickListener(v -> {
            String saved = date + " · " + league.title + "\n" + home + " — " + away + (cachedReport[0].isEmpty() ? "\n" + tr("Анализ ещё не рассчитан") : "\n" + cachedReport[0]);
            saveHistory(saved);
            saveLearningForecast(date, league.title, league.folder, home, away, cachedReport[0], cardProbs);
            toast("Матч сохранён в историю и базу обучения");
        });
    }

    private TeamStats collectTeam(String team, List<String[]> rows, Map<String,Integer> ix, Map<String,Map<String,Double>> supplemental) {
        ArrayList<String[]> appearances = new ArrayList<>();
        for (int i=1; i<rows.size(); i++) {
            String[] r=rows.get(i);
            if (team.equalsIgnoreCase(val(r,ix,"home")) || team.equalsIgnoreCase(val(r,ix,"away"))) appearances.add(r);
        }
        appearances.sort((a,b) -> val(b,ix,"date").compareTo(val(a,ix,"date")));
        TeamStats st = new TeamStats();
        for (String[] r : appearances) {
            if (st.played >= selectedMatchCount) break;
            boolean atHome = team.equalsIgnoreCase(val(r,ix,"home"));
            Double gf=number(r,ix,atHome?"ft_home":"ft_away");
            Double ga=number(r,ix,atHome?"ft_away":"ft_home");
            if (gf==null || ga==null) continue;
            st.played++; st.goalsFor+=gf; st.goalsAgainst+=ga;
            if (gf>ga) st.wins++; else if (gf.equals(ga)) st.draws++; else st.losses++;
            String side = atHome ? "home" : "away";
            String key = matchKey(val(r,ix,"date"),val(r,ix,"home"),val(r,ix,"away")) + "|" + side;
            Map<String,Double> extra = supplemental == null ? null : supplemental.get(key);
            for (String metric : new String[]{"corners","yellow","target","shots","fouls"}) {
                Double value = number(r,ix,side+"_"+metric);
                if (value == null && extra != null) value = extra.get(metric);
                st.addMetric(metric,value);
                if ("corners".equals(metric)) {
                    Double against = number(r,ix,(atHome?"away":"home")+"_corners");
                    if (against == null && supplemental != null) {
                        String otherKey = matchKey(val(r,ix,"date"),val(r,ix,"home"),val(r,ix,"away")) + "|" + (atHome?"away":"home");
                        Map<String,Double> otherExtra = supplemental.get(otherKey);
                        if (otherExtra != null) against = otherExtra.get("corners");
                    }
                    st.addConceded("corners", against);
                }
            }
        }
        return st;
    }

    // Keep the public-source statistics when API-Football has no coverage for a metric.
    // The previous implementation replaced the whole TeamStats object, which erased
    // corners/cards/shots/fouls even when open-matchday or ESPN had those values.
    private TeamStats mergeTeamStats(TeamStats fallback, TeamStats api) {
        if (api == null || api.played < 3) return fallback;
        TeamStats merged = new TeamStats();
        merged.played = api.played;
        merged.wins = api.wins;
        merged.draws = api.draws;
        merged.losses = api.losses;
        merged.goalsFor = api.goalsFor;
        merged.goalsAgainst = api.goalsAgainst;

        String[] keys = new String[]{"corners","yellow","target","shots","fouls"};
        for (String key : keys) {
            ArrayList<Double> apiValues = api.values(key);
            ArrayList<Double> fallbackValues = fallback == null ? null : fallback.values(key);
            ArrayList<Double> chosen = (apiValues != null && apiValues.size() >= 3)
                    ? apiValues : fallbackValues;
            if (chosen != null) {
                for (Double value : chosen) merged.addMetric(key, value);
            }
            if ("corners".equals(key)) {
                ArrayList<Double> apiAgainst = api.concededValues(key);
                ArrayList<Double> fallbackAgainst = fallback == null ? null : fallback.concededValues(key);
                ArrayList<Double> chosenAgainst = (apiAgainst != null && apiAgainst.size() >= 3) ? apiAgainst : fallbackAgainst;
                if (chosenAgainst != null) for (Double value : chosenAgainst) merged.addConceded(key, value);
            }
        }
        return merged;
    }

    private String oneDecimal(double v) { return String.format(Locale.US,"%.1f",v); }
    private String metricTeamLine(String team, TeamStats st, String key) {
        ArrayList<Double> vals=st.values(key);
        if(vals==null||vals.isEmpty()) return "   " + team + ": нет опубликованных данных";
        return "   " + team + ": всего " + oneDecimal(st.metricSum(key)) + " · в среднем " + oneDecimal(st.metricAvg(key)) + " за матч (данные по " + vals.size() + " матчам)";
    }
    private String metricSection(String emoji, String title, String key, TeamStats h, TeamStats a, String home, String away) {
        return emoji + " " + title + "\n" + metricTeamLine(home,h,key) + "\n" + metricTeamLine(away,a,key) + "\n";
    }

    private double mean(ArrayList<Double> values) {
        double sum = 0; for (double v : values) sum += v; return sum / values.size();
    }


    // API-Football key is stored locally on this device, never embedded in the APK.
    private String apiFootballKey() {
        return apiPrefs == null ? "" : apiPrefs.getString("api_football_key", "");
    }

    private JSONObject apiFootballRequest(String path) throws Exception {
        String k = apiFootballKey();
        if (k.isEmpty()) throw new IOException("Не введён API-Football ключ. Вставь его вверху приложения и нажми «Сохранить ключ».");
        HttpURLConnection c = null;
        try {
            URL url = new URL("https://v3.football.api-sports.io/" + path);
            c = (HttpURLConnection) url.openConnection();
            c.setRequestMethod("GET");
            c.setConnectTimeout(12000);
            c.setReadTimeout(18000);
            c.setRequestProperty("x-apisports-key", k);
            c.setRequestProperty("Accept", "application/json");
            int code = c.getResponseCode();
            InputStream in = (code >= 200 && code < 300) ? c.getInputStream() : c.getErrorStream();
            if (in == null) throw new IOException("API-Football HTTP " + code);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            try (InputStream stream = in) {
                byte[] buf = new byte[8192]; int n;
                while ((n = stream.read(buf)) != -1) out.write(buf, 0, n);
            }
            JSONObject j = new JSONObject(out.toString("UTF-8"));
            if (code < 200 || code >= 300) throw new IOException("API-Football HTTP " + code + ": " + j.opt("errors"));
            Object errors = j.opt("errors");
            if (errors != null && errors != JSONObject.NULL && !errors.toString().equals("{}") && !errors.toString().equals("[]"))
                throw new IOException("API-Football: " + errors.toString());
            return j;
        } finally { if (c != null) c.disconnect(); }
    }

    private void testApiFootballKey() {
        String k = apiKeyField == null ? "" : apiKeyField.getText().toString().trim();
        if (k.isEmpty()) { Toast.makeText(this, tr("Сначала вставь API-Football ключ"), Toast.LENGTH_LONG).show(); return; }
        apiPrefs.edit().putString("api_football_key", k).apply();
        Toast.makeText(this, tr("Проверяю ключ…"), Toast.LENGTH_SHORT).show();
        worker.execute(() -> {
            try {
                JSONObject j = apiFootballRequest("status");
                JSONObject response = j.optJSONObject("response");
                String msg = "API-Football подключён";
                if (response != null) {
                    JSONObject requests = response.optJSONObject("requests");
                    if (requests != null) msg += ". Запросов сегодня: " + requests.optInt("current") + "/" + requests.optInt("limit_day");
                }
                final String result = msg;
                ui.post(() -> Toast.makeText(this, tr(result), Toast.LENGTH_LONG).show());
            } catch (Exception e) {
                final String msg = "Ошибка API-Football: " + e.getMessage();
                ui.post(() -> Toast.makeText(this, tr(msg), Toast.LENGTH_LONG).show());
            }
        });
    }

    private String apiSearchSafe(String name) {
        String value = Normalizer.normalize(name == null ? "" : name, Normalizer.Form.NFD)
                .replaceAll("\\p{M}+", "");
        value = value.replaceAll("[^A-Za-z0-9 ]", " ").replaceAll("\\s+", " ").trim();
        return value;
    }

    private String apiNorm(String name) {
        return apiSearchSafe(name).toLowerCase(Locale.ROOT).replace(" ", "");
    }

    private JSONObject apiFindTeam(String name) throws Exception {
        String safeName = apiSearchSafe(name);
        if (safeName.isEmpty()) throw new IOException("Название команды не подходит для поиска API-Football: " + name);
        JSONObject j = apiFootballRequest("teams?search=" + URLEncoder.encode(safeName, "UTF-8"));
        JSONArray arr = j.optJSONArray("response");
        if (arr == null || arr.length() == 0) throw new IOException("API-Football не нашёл команду: " + name);
        JSONObject selected = null;
        for (int i=0; i<arr.length(); i++) {
            JSONObject team = arr.optJSONObject(i) == null ? null : arr.optJSONObject(i).optJSONObject("team");
            if (team == null) continue;
            if (name.equalsIgnoreCase(team.optString("name")) || apiNorm(name).equals(apiNorm(team.optString("name")))) {
                selected = team; break;
            }
            if (selected == null) selected = team;
        }
        if (selected == null) throw new IOException("Не удалось определить команду: " + name);
        return selected;
    }

    private Double apiStatValue(JSONArray stats, String... names) {
        if (stats == null) return null;
        for (int i=0; i<stats.length(); i++) {
            JSONObject st = stats.optJSONObject(i); if (st == null) continue;
            String type = st.optString("type", "");
            boolean wanted = false;
            for (String n : names) if (n.equalsIgnoreCase(type)) wanted = true;
            if (!wanted) continue;
            Object value = st.opt("value");
            if (value == null || value == JSONObject.NULL) return null;
            try { return Double.parseDouble(value.toString().replace("%", "").replace(",", "")); }
            catch (Exception ignored) { return null; }
        }
        return null;
    }



    // Build the team's last-10 form directly from API-Football, across ALL competitions.
    // Upcoming fixture itself is not used; only completed historical fixtures are requested.
    // Load last 10 completed matches for both teams, then fetch all fixture statistics
    // in ONE bulk request (API-Football supports up to 20 fixture IDs per request).
    // Load the selected number of recent completed fixtures for both teams.
    // API-Football fixture statistics are fetched through the dedicated statistics endpoint.
    private Map<String,TeamStats> loadApiFootballHistories(String homeName, String awayName) throws Exception {
        JSONObject homeTeam = apiFindTeam(homeName);
        JSONObject awayTeam = apiFindTeam(awayName);
        int homeId = homeTeam.optInt("id"), awayId = awayTeam.optInt("id");
        if (homeId <= 0 || awayId <= 0) throw new IOException("Не удалось определить ID обеих команд");

        int limit = selectedMatchCount;
        TeamStats homeStats = new TeamStats(), awayStats = new TeamStats();
        Map<Integer,Set<Integer>> fixturesByTeam = new HashMap<>();
        LinkedHashSet<Integer> allFixtureIds = new LinkedHashSet<>();
        int[] teamIds = new int[]{homeId, awayId};
        TeamStats[] teamStats = new TeamStats[]{homeStats, awayStats};

        for (int ti=0; ti<teamIds.length; ti++) {
            int teamId = teamIds[ti];
            JSONObject fixturesJson = apiFootballRequest("fixtures?team=" + teamId + "&last=" + limit);
            JSONArray fixtures = fixturesJson.optJSONArray("response");
            if (fixtures == null || fixtures.length() == 0)
                throw new IOException("API не вернул историю матчей для " + (ti==0?homeName:awayName));

            for (int fi=0; fi<fixtures.length() && teamStats[ti].played<limit; fi++) {
                JSONObject item = fixtures.optJSONObject(fi); if (item == null) continue;
                JSONObject fx = item.optJSONObject("fixture");
                JSONObject teams = item.optJSONObject("teams");
                JSONObject goals = item.optJSONObject("goals");
                if (fx == null || teams == null || goals == null) continue;
                JSONObject status = fx.optJSONObject("status");
                String state = status == null ? "" : status.optString("short","");
                if (!("FT".equals(state) || "AET".equals(state) || "PEN".equals(state))) continue;
                JSONObject hTeam = teams.optJSONObject("home"), aTeam = teams.optJSONObject("away");
                if (hTeam == null || aTeam == null) continue;
                boolean isHome = hTeam.optInt("id") == teamId;
                int gf = goals.optInt(isHome ? "home" : "away", -1);
                int ga = goals.optInt(isHome ? "away" : "home", -1);
                int fixtureId = fx.optInt("id");
                if (gf < 0 || ga < 0 || fixtureId <= 0) continue;

                TeamStats st = teamStats[ti];
                st.played++; st.goalsFor += gf; st.goalsAgainst += ga;
                if (gf > ga) st.wins++; else if (gf == ga) st.draws++; else st.losses++;
                allFixtureIds.add(fixtureId);
                if (!fixturesByTeam.containsKey(teamId)) fixturesByTeam.put(teamId,new HashSet<Integer>());
                fixturesByTeam.get(teamId).add(fixtureId);
            }
        }
        if (homeStats.played == 0 || awayStats.played == 0)
            throw new IOException("Не удалось получить завершённые матчи обеих команд");

        int statsFixtureCount = 0;
        // Statistics endpoint returns both teams for one fixture. Avoid duplicate calls
        // when the two teams have faced each other within the selected sample.
        for (Integer fixtureId : allFixtureIds) {
            JSONObject statJson = apiFootballRequest("fixtures/statistics?fixture=" + fixtureId);
            JSONArray statRows = statJson.optJSONArray("response");
            if (statRows == null) continue;
            for (int si=0; si<statRows.length(); si++) {
                JSONObject side = statRows.optJSONObject(si); if (side == null) continue;
                JSONObject sideTeam = side.optJSONObject("team"); if (sideTeam == null) continue;
                int sideTeamId = sideTeam.optInt("id");
                Set<Integer> teamFixtures = fixturesByTeam.get(sideTeamId);
                if (teamFixtures == null || !teamFixtures.contains(fixtureId)) continue;
                TeamStats target = sideTeamId == homeId ? homeStats : sideTeamId == awayId ? awayStats : null;
                if (target == null) continue;
                JSONArray values = side.optJSONArray("statistics");
                Double v = apiStatValue(values, "Corner Kicks", "Corners"); if (v != null) target.addMetric("corners",v);
                v = apiStatValue(values, "Yellow Cards"); if (v != null) target.addMetric("yellow",v);
                v = apiStatValue(values, "Shots on Goal", "Shots on Target"); if (v != null) target.addMetric("target",v);
                v = apiStatValue(values, "Total Shots", "Shots"); if (v != null) target.addMetric("shots",v);
                v = apiStatValue(values, "Fouls"); if (v != null) target.addMetric("fouls",v);
                statsFixtureCount++;
            }
        }

        int hc = homeStats.values("corners")==null?0:homeStats.values("corners").size();
        int ac = awayStats.values("corners")==null?0:awayStats.values("corners").size();
        apiFootballDiagnostic = "API-Football: выборка " + limit + " матчей; поиск команд: " + apiSearchSafe(homeName) + " / " + apiSearchSafe(awayName) + ". "
                + homeName + ": сыграно " + homeStats.played + ", статистика угловых в " + hc + " матчах; "
                + awayName + ": сыграно " + awayStats.played + ", статистика угловых в " + ac
                + " матчах. Статистических строк получено: " + statsFixtureCount + ".";
        Map<String,TeamStats> result = new HashMap<>();
        result.put("home",homeStats);
        result.put("away",awayStats);
        return result;
    }


    // ===== Сборные: последние N матчей по ВСЕМ турнирам (ESPN scoreboard по месяцам, от новых к старым) =====
    private static final String[] NATIONAL_SLUGS = {"uefa.nations","fifa.friendly","fifa.worldq.uefa","uefa.euroq","uefa.euro","fifa.world"};
    private final Map<String,JSONObject> boardCache = new ConcurrentHashMap<>();

    private static class NatCand {
        String slug="", date="", h="", a="", hs="", as="";
        JSONObject ev, hSide, aSide;
    }

    // "Ireland" не должна совпадать с "Northern Ireland", а "Niger" с "Nigeria": для сборных только точное совпадение.
    private boolean sameNation(String a, String b) {
        String x = normTeam(a), y = normTeam(b);
        return !x.isEmpty() && x.equals(y);
    }

    private JSONObject cachedBoard(String slug, String month, boolean cacheable) {
        String ck = slug + "|" + month;
        JSONObject c = boardCache.get(ck);
        if (c != null) return c;
        try {
            JSONObject b = fetchJson("https://site.api.espn.com/apis/site/v2/sports/soccer/" + slug + "/scoreboard?dates=" + month + "&limit=500");
            if (cacheable) boardCache.put(ck, b);   // текущий месяц не кэшируем: он ещё меняется
            return b;
        } catch (Exception e) { return null; }
    }

    private String scoreText(JSONObject side) {
        Object sc = side.opt("score");
        if (sc instanceof JSONObject) return ((JSONObject) sc).optString("displayValue", "");
        return sc == null || sc == JSONObject.NULL ? "" : sc.toString();
    }

    private String statCell(Map<String,Double> m, String key) {
        Double v = m.get(key);
        return v == null ? "" : String.valueOf(Math.round(v));
    }

    private void putMissing(Map<String,Double> target, Map<String,Double> source) {
        if (source == null) return;
        for (Map.Entry<String,Double> e : source.entrySet()) if (!target.containsKey(e.getKey())) target.put(e.getKey(), e.getValue());
    }

    private boolean hasAllStats(Map<String,Double> m) {
        for (String k : new String[]{"corners","yellow","target","shots","fouls"}) if (!m.containsKey(k)) return false;
        return true;
    }

    private List<String[]> loadNationalHistory(String home, String away) {
        List<String[]> rows = new ArrayList<>();
        rows.add(new String[]{"gw","date","time","home","away","ft_home","ft_away","ft_result",
                "home_corners","away_corners","home_yellow","away_yellow","home_target","away_target",
                "home_shots","away_shots","home_fouls","away_fouls"});
        final int need = selectedMatchCount;
        int hCount = 0, aCount = 0;
        Set<String> seen = new HashSet<>();
        SimpleDateFormat monthFmt = new SimpleDateFormat("yyyyMM", Locale.US);
        Calendar cur = Calendar.getInstance();
        ExecutorService pool = Executors.newFixedThreadPool(NATIONAL_SLUGS.length);
        try {
            for (int back = 0; back < 24 && (hCount < need || aCount < need); back++, cur.add(Calendar.MONTH, -1)) {
                final String month = monthFmt.format(cur.getTime());
                final boolean cacheable = back > 0;
                List<Future<JSONObject>> futures = new ArrayList<>();
                for (final String slug : NATIONAL_SLUGS) futures.add(pool.submit(() -> cachedBoard(slug, month, cacheable)));

                List<NatCand> cands = new ArrayList<>();
                for (int si = 0; si < futures.size(); si++) {
                    JSONObject board;
                    try { board = futures.get(si).get(); } catch (Exception e) { continue; }
                    JSONArray events = board == null ? null : board.optJSONArray("events");
                    if (events == null) continue;
                    for (int i = 0; i < events.length(); i++) {
                        JSONObject ev = events.optJSONObject(i); if (ev == null) continue;
                        JSONArray comps = ev.optJSONArray("competitions"); if (comps == null || comps.length() == 0) continue;
                        JSONObject comp = comps.optJSONObject(0); if (comp == null) continue;
                        JSONObject statusObj = comp.optJSONObject("status");
                        if (statusObj == null) statusObj = ev.optJSONObject("status");
                        JSONObject type = statusObj == null ? null : statusObj.optJSONObject("type");
                        if (type == null || !type.optBoolean("completed", false)) continue;
                        JSONArray sides = comp.optJSONArray("competitors"); if (sides == null) continue;
                        NatCand c = new NatCand(); c.slug = NATIONAL_SLUGS[si]; c.ev = ev;
                        boolean hasHome = false, hasAway = false;
                        for (int j = 0; j < sides.length(); j++) {
                            JSONObject side = sides.optJSONObject(j); if (side == null) continue;
                            JSONObject team = side.optJSONObject("team");
                            String name = team == null ? "" : team.optString("displayName", team.optString("name", ""));
                            if ("home".equalsIgnoreCase(side.optString("homeAway"))) { c.h = name; c.hs = scoreText(side); c.hSide = side; hasHome = true; }
                            else { c.a = name; c.as = scoreText(side); c.aSide = side; hasAway = true; }
                        }
                        if (!hasHome || !hasAway || c.h.isEmpty() || c.a.isEmpty() || c.hs.isEmpty() || c.as.isEmpty()) continue;
                        String d = ev.optString("date", "");
                        if (d.length() < 10) continue;
                        c.date = d.substring(0, 10);
                        boolean involved = sameNation(home, c.h) || sameNation(home, c.a) || sameNation(away, c.h) || sameNation(away, c.a);
                        if (!involved) continue;
                        if (!seen.add(c.date + "|" + normTeam(c.h) + "|" + normTeam(c.a))) continue;
                        cands.add(c);
                    }
                }
                Collections.sort(cands, (x, y) -> y.date.compareTo(x.date));   // новые первыми

                for (NatCand c : cands) {
                    boolean forHome = sameNation(home, c.h) || sameNation(home, c.a);
                    boolean forAway = sameNation(away, c.h) || sameNation(away, c.a);
                    if (!((forHome && hCount < need) || (forAway && aCount < need))) continue;
                    if (forHome) hCount++;
                    if (forAway) aCount++;

                    Map<String,Double> hm = new HashMap<>(), am = new HashMap<>();
                    mergeEspnStats(hm, parseEspnCompetitorStats(c.hSide));
                    mergeEspnStats(am, parseEspnCompetitorStats(c.aSide));
                    Map<String,Integer> yellow = parseEspnYellowCards(c.ev);
                    String hid = c.hSide.optString("id", ""), aid = c.aSide.optString("id", "");
                    if (yellow.containsKey(hid)) hm.put("yellow", (double) yellow.get(hid));
                    if (yellow.containsKey(aid)) am.put("yellow", (double) yellow.get(aid));
                    if (!hasAllStats(hm) || !hasAllStats(am)) {
                        String eventId = c.ev.optString("id", "");
                        if (!eventId.isEmpty()) {
                            try {
                                JSONObject summary = fetchJson("https://site.api.espn.com/apis/site/v2/sports/soccer/" + c.slug + "/summary?event=" + eventId);
                                JSONObject box = summary.optJSONObject("boxscore");
                                JSONArray teams = box == null ? null : box.optJSONArray("teams");
                                if (teams != null) for (int j = 0; j < teams.length(); j++) {
                                    JSONObject tb = teams.optJSONObject(j); if (tb == null) continue;
                                    JSONObject t = tb.optJSONObject("team");
                                    String tn = t == null ? "" : t.optString("displayName", t.optString("name", ""));
                                    if (sameNation(c.h, tn)) putMissing(hm, parseEspnTeamStats(tb));
                                    else if (sameNation(c.a, tn)) putMissing(am, parseEspnTeamStats(tb));
                                }
                            } catch (Exception ignored) { }
                        }
                    }
                    int hsInt, asInt;
                    String result = "";
                    try { hsInt = Integer.parseInt(c.hs); asInt = Integer.parseInt(c.as); result = hsInt > asInt ? "H" : hsInt < asInt ? "A" : "D"; }
                    catch (Exception ignored) { continue; }
                    rows.add(new String[]{c.slug, c.date, "", c.h, c.a, c.hs, c.as, result,
                            statCell(hm,"corners"), statCell(am,"corners"), statCell(hm,"yellow"), statCell(am,"yellow"),
                            statCell(hm,"target"), statCell(am,"target"), statCell(hm,"shots"), statCell(am,"shots"),
                            statCell(hm,"fouls"), statCell(am,"fouls")});
                }
            }
        } finally { pool.shutdownNow(); }
        return rows;
    }

    private double[] toArr(ArrayList<Double> list) {
        if (list == null) return null;
        double[] r = new double[list.size()];
        for (int i = 0; i < r.length; i++) r[i] = list.get(i);
        return r;
    }

    // Средние голы хозяев/гостей по всей лиге (из сыгранных матчей CSV); при малой выборке - типичные значения.
    private double[] leagueGoalAverages(List<String[]> rows, Map<String,Integer> ix) {
        double sh = 0, sa = 0; int n = 0;
        for (int i = 1; i < rows.size(); i++) {
            Double gh = number(rows.get(i), ix, "ft_home"), ga = number(rows.get(i), ix, "ft_away");
            if (gh == null || ga == null) continue;
            sh += gh; sa += ga; n++;
        }
        return n >= 30 ? new double[]{sh / n, sa / n} : new double[]{1.45, 1.15};
    }

    // Среднее значение показателя на одну команду за матч по всей лиге; если данных мало - типичное значение.
    private double leagueMetricMean(List<String[]> rows, Map<String,Integer> ix, String metric, double fallback, boolean national) {
        if (national) return fallback;
        double sum = 0; int n = 0;
        for (int i = 1; i < rows.size(); i++) {
            Double hv = number(rows.get(i), ix, "home_" + metric), av = number(rows.get(i), ix, "away_" + metric);
            if (hv != null) { sum += hv; n++; }
            if (av != null) { sum += av; n++; }
        }
        return n >= 60 ? sum / n : fallback;
    }

    // Домашнее преимущество по показателю: {коэффициент хозяев, коэффициент гостей} по средним лиги; без данных — {1, 1}.
    private double[] leagueVenue(List<String[]> rows, Map<String,Integer> ix, String metric, boolean national) {
        if (national) return new double[]{1.0, 1.0};
        double sh = 0, sa = 0; int n = 0;
        for (int i = 1; i < rows.size(); i++) {
            Double hv = number(rows.get(i), ix, "home_" + metric), av = number(rows.get(i), ix, "away_" + metric);
            if (hv == null || av == null) continue;
            sh += hv; sa += av; n++;
        }
        if (n < 30 || sh + sa <= 0) return new double[]{1.0, 1.0};
        double mean = (sh + sa) / (2.0 * n);
        return new double[]{(sh / n) / mean, (sa / n) / mean};
    }

    private String makeReport(League league, String home, String away, List<String[]> rows) {
        final boolean national = "UEFA_NATIONS_LEAGUE".equals(league.folder);
        final Map<String, Double> probs = new HashMap<>();
        lastProbs = probs;
        if (national) rows = loadNationalHistory(home, away);
        if (rows == null || rows.size() < 2) return "⚠️ АНАЛИЗ НЕВОЗМОЖЕН\nНет опубликованных сыгранных матчей этой лиги.";
        Map<String,Integer> ix = headerIndex(rows.get(0));
        Map<String,Map<String,Double>> supplemental = national
                ? new HashMap<String,Map<String,Double>>()
                : loadEspnFallback(league,home,away,rows,ix);
        TeamStats h=collectTeam(home,rows,ix,supplemental), a=collectTeam(away,rows,ix,supplemental);
        if (!apiFootballKey().isEmpty()) {
            try {
                Map<String,TeamStats> apiHistory = loadApiFootballHistories(home, away);
                TeamStats apiHome = apiHistory.get("home");
                TeamStats apiAway = apiHistory.get("away");
                h = mergeTeamStats(h, apiHome);
                a = mergeTeamStats(a, apiAway);
            } catch (Exception apiError) {
                apiFootballDiagnostic = "API-Football: " + apiError.getMessage()
                        + ". Показана доступная статистика основного источника.";
            }
        }
        StringBuilder out = new StringBuilder();
        out.append("━━━━━━━━━━━━━━━━━━\n⚽ АНАЛИЗ МАТЧА\n").append(home).append(" — ").append(away).append("\n━━━━━━━━━━━━━━━━━━\n");
        out.append("🔌 ").append(apiFootballDiagnostic).append("\n");
        if (national) out.append("🌍 Сборные: в выборку входят матчи всех турниров (Лига наций, товарищеские, отбор, ЧЕ, ЧМ) по данным ESPN.\n");
        out.append("━━━━━━━━━━━━━━━━━━\n\n");
        out.append("📈 1. ГОЛЫ И ФОРМА КОМАНД\n");
        out.append("🏠 ").append(home).append("\n");
        out.append("   Сыграно матчей: ").append(h.played).append(" из ").append(selectedMatchCount).append("\n");
        out.append("   Забито: ").append(oneDecimal(h.goalsFor)).append(" всего · ").append(oneDecimal(h.avgGoalsFor())).append(" за матч\n");
        out.append("   Пропущено: ").append(oneDecimal(h.goalsAgainst)).append(" всего · ").append(oneDecimal(h.avgGoalsAgainst())).append(" за матч\n");
        out.append("   Результаты: ").append(h.form()).append("\n\n");
        out.append("✈️ ").append(away).append("\n");
        out.append("   Сыграно матчей: ").append(a.played).append(" из ").append(selectedMatchCount).append("\n");
        out.append("   Забито: ").append(oneDecimal(a.goalsFor)).append(" всего · ").append(oneDecimal(a.avgGoalsFor())).append(" за матч\n");
        out.append("   Пропущено: ").append(oneDecimal(a.goalsAgainst)).append(" всего · ").append(oneDecimal(a.avgGoalsAgainst())).append(" за матч\n");
        out.append("   Результаты: ").append(a.form()).append("\n\n");
        out.append("📊 2. ДЕТАЛЬНАЯ СТАТИСТИКА ПО КОМАНДАМ\n");
        if (noStats(h) && noStats(a)) out.append("ℹ️ Для этого турнира нет угловых, карточек, ударов и фолов: open-matchday публикует их не для всех лиг, а ESPN и API-Football могут не покрывать матч. Ниже есть прогноз по голам.\n");
        out.append(metricSection("🚩","Угловые","corners",h,a,home,away)).append("\n");
        out.append(metricSection("🟨","Жёлтые карточки","yellow",h,a,home,away)).append("\n");
        out.append(metricSection("🎯","Удары в створ","target",h,a,home,away)).append("\n");
        out.append(metricSection("🥅","Все удары по воротам","shots",h,a,home,away)).append("\n");
        out.append(metricSection("🤼","Фолы","fouls",h,a,home,away)).append("\n");
        out.append("🔌 ").append(apiFootballDiagnostic).append("\n\n");
        out.append("↗️ Вбрасывания из аута\n   Источник open-matchday не публикует эту статистику — цифры не подставляются.\n\n");
        out.append("🔮 3. ПРОГНОЗЫ ТОТАЛОВ НА МАТЧ\n");
        if(h.played<3||a.played<3) {
            out.append("⚠️ Для надёжного расчёта пока мало матчей: нужно минимум 3 сыгранных матча каждой команды.\n");
        } else {
            double[] lg = national ? new double[]{1.45, 1.15} : leagueGoalAverages(rows, ix);
            double[] xg = ForecastModel.expectedGoals(h.goalsFor, h.goalsAgainst, h.played, a.goalsFor, a.goalsAgainst, a.played, lg[0], lg[1]);
            double[] rel = ForecastModel.matchupLogRatios(h.goalsFor, h.goalsAgainst, h.played, a.goalsFor, a.goalsAgainst, a.played, lg[0], lg[1]);
            int nCounts = Math.min(h.values("corners") == null ? 0 : h.values("corners").size(), a.values("corners") == null ? 0 : a.values("corners").size());
            probs.put("n_min", (double) (nCounts > 0 ? nCounts : Math.min(h.played, a.played)));
            probs.put("n_stats", nCounts > 0 ? 1.0 : 0.0);
            out.append("🛡 Надёжность данных: ").append(gradeText(probs.get("n_min"), nCounts > 0)).append("\n");
            out.append(ForecastModel.goalsBlock(home, away, xg[0], xg[1], Math.min(h.played, a.played), probs));
            out.append("\n🚩 УГЛОВЫЕ\n").append(ForecastModel.countBlock("Тотал угловых", toArr(h.values("corners")), toArr(a.values("corners")),
                    toArr(h.concededValues("corners")), toArr(a.concededValues("corners")), leagueMetricMean(rows, ix, "corners", 5.0, national), 1.05, rel, 0.25, "corners", probs, home, away, leagueVenue(rows, ix, "corners", national)));
            out.append("\n🟨 ЖЁЛТЫЕ КАРТОЧКИ\n").append(ForecastModel.countBlock("Тотал карточек", toArr(h.values("yellow")), toArr(a.values("yellow")),
                    null, null, leagueMetricMean(rows, ix, "yellow", 2.0, national), 1.2, rel, -0.15, "yellow", probs, home, away, leagueVenue(rows, ix, "yellow", national)));
            out.append("\n🤼 ФОЛЫ\n").append(ForecastModel.countBlock("Тотал фолов", toArr(h.values("fouls")), toArr(a.values("fouls")),
                    null, null, leagueMetricMean(rows, ix, "fouls", 12.0, national), 1.05, rel, -0.12, "fouls", probs, home, away, leagueVenue(rows, ix, "fouls", national)));
            out.append("\n🎯 УДАРЫ В СТВОР\n").append(ForecastModel.countBlock("Тотал ударов в створ", toArr(h.values("target")), toArr(a.values("target")),
                    null, null, leagueMetricMean(rows, ix, "target", 4.2, national), 1.15, rel, 0.35, "target", probs, home, away, leagueVenue(rows, ix, "target", national)));
            out.append("\n🥅 ВСЕ УДАРЫ\n").append(ForecastModel.countBlock("Тотал всех ударов", toArr(h.values("shots")), toArr(a.values("shots")),
                    null, null, leagueMetricMean(rows, ix, "shots", 12.5, national), 1.2, rel, 0.30, "shots", probs, home, away, leagueVenue(rows, ix, "shots", national)));
        }
        out.append("\n━━━━━━━━━━━━━━━━━━\nℹ️ КАК ЧИТАТЬ ПРОГНОЗ\n🔼 Больше — вероятность превышения указанной линии. 🔽 Меньше — вероятность остаться ниже неё. Это математическая оценка по средним показателям последних матчей, не гарантия и не букмекерские коэффициенты.\n");
        out.append("Модель: голы — Пуассон с поправкой Диксона–Коулса, силы атаки и обороны относительно среднего по лиге со сглаживанием; угловые, карточки, фолы и удары — сглаженное среднее и отрицательное биномиальное распределение с поправкой на расклад сил (сильная сторона бьёт и подаёт угловые чаще, слабая чаще фолит и получает карточки; коэффициенты стартовые), линии подбираются вокруг ожидаемого значения. «Уверенность» зависит от размера выборки.\n");
        out.append("Сначала используются данные open-matchday; если отдельные показатели отсутствуют, приложение пытается найти их в публичном ESPN API без ключа. Если ESPN не покрывает матч или турнир, статистика остаётся пустой. Угловые, карточки, удары и фолы доступны не для всех матчей. Вбрасывания из аута в этом источнике отсутствуют.\n");
        out.append("Выборка: ").append(h.played).append(" матчей — ").append(home).append("; ").append(a.played).append(" — ").append(away).append(". Результаты open-matchday обновляются примерно раз в сутки; резервная статистика ESPN может обновляться чаще. Источники: open-matchday и ESPN.");
        return translateReport(out.toString());
    }

    private double poisson(int k,double lambda) { return Math.exp(-lambda)*Math.pow(lambda,k)/factorial(k); }
    private double factorial(int n) { double x=1; for(int i=2;i<=n;i++)x*=i; return x; }
    private String pct(double v) { return String.format(Locale.US,"%.0f%%",v*100); }
    private String fmt(double v) { return String.format(Locale.US,"%.2f",v); }

    private void saveHistory(String item) {
        SharedPreferences p = getSharedPreferences("football_history", MODE_PRIVATE);
        try {
            JSONArray old = new JSONArray(p.getString("items", "[]"));
            JSONArray arr = new JSONArray();
            arr.put(item);                                           // новый — первым (раньше put(0, …) затирал предыдущий)
            for (int i = 0; i < old.length() && arr.length() < 100; i++) arr.put(old.optString(i));
            p.edit().putString("items", arr.toString()).apply();
        } catch (Exception e) {
            p.edit().putString("items", new JSONArray().put(item).toString()).apply();
        }
    }

    private void saveLearningForecast(String date, String league, String folder, String home, String away, String report, Map<String, Double> probs) {
        SharedPreferences p = getSharedPreferences("football_learning", MODE_PRIVATE);
        try {
            JSONArray arr = new JSONArray(p.getString("records", "[]"));
            List<JSONObject> list = new ArrayList<>();
            JSONObject existing = null;
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.optJSONObject(i);
                if (o == null) continue;
                list.add(o);
                if (date.equals(o.optString("date")) && home.equals(o.optString("home")) && away.equals(o.optString("away"))) existing = o;
            }
            if (existing != null) {                                   // тот же матч: обновляем прогноз, результат не трогаем
                existing.put("report", report == null ? "" : report);
                existing.put("saved_at", System.currentTimeMillis());
                if (!existing.optBoolean("actual_entered")) existing.put("model_v", ForecastModel.MODEL_VERSION);
                if (probs != null && !probs.isEmpty() && !existing.optBoolean("actual_entered")) { existing.put("probs", probsJson(probs)); putBet(existing, home, away, probs); }
                if (!existing.has("folder")) existing.put("folder", folder);
            } else {
                JSONObject item = new JSONObject();
                item.put("date", date); item.put("league", league); item.put("home", home); item.put("away", away);
                item.put("report", report == null ? "" : report);
                item.put("folder", folder == null ? "" : folder);
                item.put("model_v", ForecastModel.MODEL_VERSION);
                if (probs != null && !probs.isEmpty()) { item.put("probs", probsJson(probs)); putBet(item, home, away, probs); }
                item.put("actual_entered", false);
                item.put("saved_at", System.currentTimeMillis());
                list.add(item);
            }
            while (list.size() > 300) list.remove(0);                 // удаляем самые старые (раньше удалялась самая новая)
            p.edit().putString("records", new JSONArray(list).toString()).apply();
        } catch (Exception ignored) { }
    }

    private void showLearning() {
        SharedPreferences p = getSharedPreferences("football_learning", MODE_PRIVATE);
        try {
            final JSONArray arr = new JSONArray(p.getString("records", "[]"));
            final int total = arr.length();
            int completed = 0;
            for (int i = 0; i < total; i++) if (arr.optJSONObject(i) != null && arr.optJSONObject(i).optBoolean("actual_entered")) completed++;
            String summary = "Сохранено прогнозов: " + total + "\nВнесено фактических результатов: " + completed
                    + "\n\nСохраняй анализ до матча, а после финального свистка внеси реальные показатели. Так мы соберём честную обучающую выборку."
                    + "\n\nДля первой калибровки желательно минимум 100 матчей. До накопления данных коэффициенты автоматически не меняются.";
            LinearLayout panel = new LinearLayout(this);
            panel.setOrientation(LinearLayout.VERTICAL);
            panel.setPadding(dp(16), dp(8), dp(16), dp(4));
            panel.addView(label(summary, 12, MUTED, false), lp(0, 8));
            if (total == 0) {
                panel.addView(label("Сначала сделай анализ и нажми «СОХРАНИТЬ АНАЛИЗ В ИСТОРИЮ».", 13, Color.WHITE, true));
                new AlertDialog.Builder(this).setTitle(tr("🧠 Обучение")).setView(panel).setPositiveButton("OK", null).show();
                return;
            }
            panel.addView(label("Выбери матч, чтобы внести фактическую статистику.", 13, Color.WHITE, true), lp(0, 4));
            String[] choices = new String[total];
            for (int i = 0; i < total; i++) {                         // новые сверху
                JSONObject o = arr.optJSONObject(total - 1 - i);
                String mark = o == null ? "·" : betMark(o);
                if (mark.isEmpty()) mark = o != null && o.optBoolean("actual_entered") ? "✓" : "·";
                choices[i] = (o == null ? "?" : o.optString("date") + " · " + o.optString("home") + " — " + o.optString("away"))
                        + "  " + mark + (o != null && o.has("bet_label") ? "\n" + betLine(o) : "");
            }
            ListView list = new ListView(this);
            list.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, choices));
            panel.addView(list, new LinearLayout.LayoutParams(-1, dp(300)));
            final AlertDialog dialog = new AlertDialog.Builder(this).setTitle(tr("🧠 Обучение")).setView(panel)
                    .setPositiveButton(tr("Закрыть"), null).create();
            list.setOnItemClickListener((parent, view, position, id) -> { dialog.dismiss(); showLearningResultEntry(total - 1 - position); });
            dialog.show();
        } catch (Exception e) {
            new AlertDialog.Builder(this).setTitle(tr("🧠 Обучение")).setMessage(tr("Не удалось прочитать обучающую базу."))
                    .setPositiveButton("OK", null).show();
        }
    }

    private static final String[][] ENTRY_STATS = {{"g", "Голы"}, {"corners", "Угловые"}, {"yellow", "Жёлтые карточки"},
        {"target", "Удары в створ"}, {"shots", "Все удары"}, {"fouls", "Фолы"}, {"offsides", "Офсайды"}, {"throwins", "Вбрасывания из аута"}};

    private static String teamKey(String stat, boolean home) { return stat.equals("g") ? (home ? "gh" : "ga") : stat + (home ? "_h" : "_a"); }

    private void showLearningResultEntry(final int index) {
        final SharedPreferences p = getSharedPreferences("football_learning", MODE_PRIVATE);
        try {
            final JSONArray arr = new JSONArray(p.getString("records", "[]"));
            final JSONObject record = arr.optJSONObject(index);
            if (record == null) return;
            LinearLayout panel = new LinearLayout(this);
            panel.setOrientation(LinearLayout.VERTICAL);
            panel.setPadding(dp(18), dp(8), dp(18), dp(4));
            panel.addView(label(record.optString("home") + " — " + record.optString("away"), 16, GREEN, true));
            ensureBet(record);
            if (record.has("bet_label")) {
                panel.addView(label(betLine(record), 12, 0xffdbe7f1, false), lp(2, 0));
                Boolean res = betResult(record);
                if (res != null) panel.addView(label(res ? "✅ Зашла" : "❌ Не зашла", 14, res ? GREEN : 0xffff5a5f, true), lp(2, 2));
            }
            String sum = resultSummary(record);
            if (!sum.isEmpty()) panel.addView(label(sum, 12, 0xffdbe7f1, false), lp(6, 6));
            LinearLayout head = new LinearLayout(this);
            TextView hh = label(record.optString("home"), 12, MUTED, true), ha = label(record.optString("away"), 12, MUTED, true);
            hh.setSingleLine(true); ha.setSingleLine(true); hh.setEllipsize(TextUtils.TruncateAt.END); ha.setEllipsize(TextUtils.TruncateAt.END);
            head.addView(hh, new LinearLayout.LayoutParams(0, -2, 1f)); head.addView(ha, new LinearLayout.LayoutParams(0, -2, 1f));
            panel.addView(head, lp(8, 0));
            final EditText oddsField = new EditText(this);
            if (record.has("bet_label")) {
                panel.addView(label("Коэффициент ставки программы (необязательно, для ROI)", 12, MUTED, false), lp(8, 2));
                oddsField.setSingleLine(true); oddsField.setInputType(8194); oddsField.setTextColor(Color.WHITE); oddsField.setHintTextColor(MUTED); oddsField.setHint("например 1.85");
                oddsField.setBackground(shape(PANEL2, 8)); oddsField.setPadding(dp(12), dp(7), dp(12), dp(7));
                if (record.optDouble("bet_odds", 0) > 1) oddsField.setText(String.valueOf(record.optDouble("bet_odds")));
                panel.addView(oddsField, lp(0, 4));
            }
            final EditText[] hf = new EditText[ENTRY_STATS.length], af = new EditText[ENTRY_STATS.length];
            JSONObject actual = record.optJSONObject("actual");
            for (int i = 0; i < ENTRY_STATS.length; i++) {
                panel.addView(label(ENTRY_STATS[i][1], 13, Color.WHITE, true), lp(8, 2));
                LinearLayout row = new LinearLayout(this);
                for (int side = 0; side < 2; side++) {
                    EditText e = new EditText(this);
                    e.setSingleLine(true); e.setInputType(2); e.setTextColor(Color.WHITE); e.setHintTextColor(MUTED); e.setHint("—");
                    e.setBackground(shape(PANEL2, 8)); e.setPadding(dp(12), dp(7), dp(12), dp(7));
                    String k = teamKey(ENTRY_STATS[i][0], side == 0);
                    if (actual != null && actual.has(k)) e.setText(String.valueOf(actual.optInt(k)));
                    LinearLayout.LayoutParams lpE = new LinearLayout.LayoutParams(0, -2, 1f);
                    lpE.setMargins(side == 0 ? 0 : dp(6), 0, side == 0 ? dp(6) : 0, 0);
                    row.addView(e, lpE);
                    if (side == 0) hf[i] = e; else af[i] = e;
                }
                panel.addView(row, lp(0, 2));
            }
            ScrollView sv = new ScrollView(this); sv.addView(panel);
            new AlertDialog.Builder(this).setTitle(tr("Фактический результат"))
                    .setView(sv).setNegativeButton(tr("Отмена"), null)
                    .setPositiveButton(tr("Сохранить результат"), (d, w) -> {
                        try {
                            JSONObject result = actual == null ? new JSONObject() : new JSONObject(actual.toString());
                            int entered = 0;
                            for (int i = 0; i < ENTRY_STATS.length; i++) {
                                String st = ENTRY_STATS[i][0];
                                String hv = hf[i].getText().toString().trim(), av = af[i].getText().toString().trim();
                                if (!hv.isEmpty()) { result.put(teamKey(st, true), Integer.parseInt(hv)); entered++; }
                                if (!av.isEmpty()) { result.put(teamKey(st, false), Integer.parseInt(av)); entered++; }
                                if (!st.equals("g") && result.has(teamKey(st, true)) && result.has(teamKey(st, false)))
                                    result.put(st, result.optInt(teamKey(st, true)) + result.optInt(teamKey(st, false)));   // тотал считается сам
                            }
                            String oddsText = oddsField.getText().toString().trim().replace(',', '.');
                            if (!oddsText.isEmpty()) { double od = Double.parseDouble(oddsText); if (od > 1.0 && od < 1000) record.put("bet_odds", od); }
                            if (entered == 0 && oddsText.isEmpty()) { toast("Введи хотя бы один показатель"); return; }
                            record.put("actual", result);
                            record.put("actual_entered", true);
                            arr.put(index, record);
                            p.edit().putString("records", arr.toString()).apply();
                            rebuildCalibration();
                            String summary = resultSummary(record);
                            if (summary.isEmpty()) toast("Результат добавлен в обучающую базу");
                            else new AlertDialog.Builder(this).setTitle(tr("📋 Итоги прогнозов"))
                                    .setMessage(translateReport(summary)).setPositiveButton(tr("Закрыть"), null).show();
                        } catch (Exception ex) {
                            toast("Проверь введённые числа");
                        }
                    }).show();
        } catch (Exception ignored) { }
    }

    private void showHistory() {
        final SharedPreferences p = getSharedPreferences("football_history", MODE_PRIVATE);
        try {
            JSONArray arr = new JSONArray(p.getString("items", "[]"));
            if (arr.length() == 0) {
                new AlertDialog.Builder(this).setTitle(tr("История")).setMessage(tr("Пока нет сохранённых матчей.")).setPositiveButton("OK", null).show();
                return;
            }
            String[] items = new String[arr.length()];
            for (int i = 0; i < arr.length(); i++) items[i] = arr.optString(i);
            new AlertDialog.Builder(this).setTitle(tr("Сохранённые матчи")).setItems(items, null)
                    .setPositiveButton(tr("Закрыть"), null)
                    .setNeutralButton(tr("Очистить"), (d, w) -> p.edit().remove("items").apply()).show();
        } catch (Exception e) {
            new AlertDialog.Builder(this).setTitle(tr("История")).setMessage(tr("Не удалось прочитать историю.")).setPositiveButton("OK", null).show();
        }
    }

    // ================= Самообучение: вероятности, результаты, калибровка =================
    private JSONObject probsJson(Map<String, Double> probs) {
        JSONObject o = new JSONObject();
        try { for (Map.Entry<String, Double> e : probs.entrySet()) o.put(e.getKey(), e.getValue()); } catch (Exception ignored) { }
        return o;
    }

    private JSONArray loadRecords() {
        try { return new JSONArray(getSharedPreferences("football_learning", MODE_PRIVATE).getString("records", "[]")); }
        catch (Exception e) { return new JSONArray(); }
    }

    private Map<String, Double> actualMap(JSONObject rec) {
        Map<String, Double> m = new HashMap<>();
        JSONObject a = rec == null ? null : rec.optJSONObject("actual");
        if (a == null) return m;
        Iterator<String> it = a.keys();
        while (it.hasNext()) { String k = it.next(); m.put(k, a.optDouble(k)); }
        return m;
    }

    private Map<String, List<Calibration.Sample>> collectSamples() {
        Map<String, List<Calibration.Sample>> out = new HashMap<>();
        JSONArray arr = loadRecords();
        for (int i = 0; i < arr.length(); i++) {
            JSONObject rec = arr.optJSONObject(i);
            if (rec == null || !rec.optBoolean("actual_entered")) continue;
            JSONObject pr = rec.optJSONObject("probs");
            if (pr == null) continue;
            Map<String, Double> actual = actualMap(rec);
            Iterator<String> it = pr.keys();
            while (it.hasNext()) {
                String key = it.next();
                Boolean y = Calibration.outcome(key, actual);
                if (y == null) continue;
                String fam = Calibration.family(key);
                List<Calibration.Sample> l = out.get(fam);
                if (l == null) { l = new ArrayList<>(); out.put(fam, l); }
                l.add(new Calibration.Sample(pr.optDouble(key), y));
            }
        }
        return out;
    }

    private void rebuildCalibration() {
        try {
            Calibration c = new Calibration();
            c.fit(collectSamples());
            ForecastModel.calibration = c;
        } catch (Exception ignored) { }
    }

    /** Подтягивает фактические результаты прошедших матчей из open-matchday (голы, а где есть — угловые, карточки, удары, фолы). */
    private void fillResultsAuto(final Runnable done) {
        final JSONArray snapshot = loadRecords();
        worker.execute(() -> {
            final List<String[]> keys = new ArrayList<>();          // date, home, away
            final List<JSONObject> actuals = new ArrayList<>();
            try {
                Map<String, List<List<String[]>>> cache = new HashMap<>();
                for (int i = 0; i < snapshot.length(); i++) {
                    JSONObject rec = snapshot.optJSONObject(i);
                    if (rec == null || rec.optBoolean("actual_entered")) continue;
                    String date = rec.optString("date"), folder = rec.optString("folder");
                    if (folder.isEmpty() || ESPN_ONLY.contains(folder) || folder.startsWith("API_") || date.compareTo(today()) >= 0) continue;
                    List<List<String[]>> files = cache.get(folder);
                    if (files == null) {
                        files = new ArrayList<>();
                        for (String code : seasonCandidates()) {
                            try { files.add(parseCsv(fetchWithFallback(folder + "/results_" + code + ".csv"))); } catch (Exception ignored) { }
                        }
                        cache.put(folder, files);
                    }
                    for (List<String[]> rows : files) {
                        if (rows.isEmpty()) continue;
                        Map<String, Integer> ix = headerIndex(rows.get(0));
                        String[] hit = null;
                        for (int r = 1; r < rows.size() && hit == null; r++) {
                            String[] row = rows.get(r);
                            if (date.equals(val(row, ix, "date")) && rec.optString("home").equalsIgnoreCase(val(row, ix, "home"))
                                    && rec.optString("away").equalsIgnoreCase(val(row, ix, "away"))) hit = row;
                        }
                        if (hit == null) continue;
                        Double gh = number(hit, ix, "ft_home"), ga = number(hit, ix, "ft_away");
                        if (gh == null || ga == null) continue;
                        JSONObject act = new JSONObject();
                        act.put("gh", gh.intValue()); act.put("ga", ga.intValue());
                        for (String m : new String[]{"corners", "yellow", "fouls", "target", "shots"}) {
                            Double a = number(hit, ix, "home_" + m), b = number(hit, ix, "away_" + m);
                            if (a != null && b != null) { act.put(m, (int) Math.round(a + b)); act.put(m + "_h", a.intValue()); act.put(m + "_a", b.intValue()); }
                        }
                        keys.add(new String[]{date, rec.optString("home"), rec.optString("away")});
                        actuals.add(act);
                        break;
                    }
                }
            } catch (Exception ignored) { }
            ui.post(() -> {
                try {
                    SharedPreferences p = getSharedPreferences("football_learning", MODE_PRIVATE);
                    JSONArray fresh = loadRecords();
                    int changed = 0;
                    for (int k = 0; k < keys.size(); k++) {
                        for (int i = 0; i < fresh.length(); i++) {
                            JSONObject rec = fresh.optJSONObject(i);
                            if (rec == null || rec.optBoolean("actual_entered")) continue;
                            if (keys.get(k)[0].equals(rec.optString("date")) && keys.get(k)[1].equals(rec.optString("home")) && keys.get(k)[2].equals(rec.optString("away"))) {
                                rec.put("actual", actuals.get(k)); rec.put("actual_entered", true); rec.put("auto", true); changed++;
                            }
                        }
                    }
                    if (changed > 0) { p.edit().putString("records", fresh.toString()).apply(); rebuildCalibration(); }
                } catch (Exception ignored) { }
                if (done != null) done.run();
            });
        });
    }

    private static final String[][] FAMILY_NAMES = {
        {"goals", "Тотал голов"}, {"btts", "Обе забьют"}, {"res", "Исход 1X2"}, {"corners", "Угловые"},
        {"yellow", "Жёлтые карточки"}, {"fouls", "Фолы"}, {"target", "Удары в створ"}, {"shots", "Все удары"}};

    private void showAccuracy() {
        rebuildCalibration();
        JSONArray arr = loadRecords();
        int withProbs = 0, finished = 0, auto = 0;
        for (int i = 0; i < arr.length(); i++) {
            JSONObject r = arr.optJSONObject(i);
            if (r == null || r.optJSONObject("probs") == null) continue;
            withProbs++;
            if (r.optBoolean("actual_entered")) { finished++; if (r.optBoolean("auto")) auto++; }
        }
        int betWon = 0, betTotal = 0;
        for (int i = 0; i < arr.length(); i++) { Boolean br = betResult(arr.optJSONObject(i)); if (br != null) { betTotal++; if (br) betWon++; } }
        Map<String, List<Calibration.Sample>> by = collectSamples();
        StringBuilder sb = new StringBuilder();
        sb.append("Прогнозов с вероятностями: ").append(withProbs).append("\nС внесённым результатом: ").append(finished)
          .append(" (из них подтянуто автоматически: ").append(auto).append(")\n");
        if (betTotal > 0) sb.append("\n🎯 Рекомендованные ставки: зашло ").append(betWon).append(" из ").append(betTotal).append(" (").append(Math.round(100.0 * betWon / betTotal)).append("%)\n");
        double profit = 0; int oddsBets = 0, gradeA = 0, gradeAWon = 0, gradeB = 0, gradeBWon = 0, gradeC = 0, gradeCWon = 0;
        double[] maeSum = new double[6]; int[] maeN = new int[6];
        String[] maeFam = {"goals", "corners", "yellow", "fouls", "target", "shots"};
        for (int i = 0; i < arr.length(); i++) {
            JSONObject r = arr.optJSONObject(i);
            Boolean br = betResult(r);
            if (br != null) {
                if (r.optDouble("bet_odds", 0) > 1) { oddsBets++; profit += br ? r.optDouble("bet_odds") - 1 : -1; }
                String g = gradeOf(r);
                if (g.equals("A")) { gradeA++; if (br) gradeAWon++; } else if (g.equals("B")) { gradeB++; if (br) gradeBWon++; } else if (g.equals("C")) { gradeC++; if (br) gradeCWon++; }
            }
            JSONObject pr = r == null ? null : r.optJSONObject("probs");
            if (pr == null || !r.optBoolean("actual_entered")) continue;
            Map<String, Double> act = actualMap(r);
            for (int k = 0; k < maeFam.length; k++) {
                if (!pr.has("exp_" + maeFam[k])) continue;
                Double real = k == 0 ? (act.containsKey("gh") && act.containsKey("ga") ? act.get("gh") + act.get("ga") : null) : act.get(maeFam[k]);
                if (real == null) continue;
                maeSum[k] += Math.abs(pr.optDouble("exp_" + maeFam[k]) - real); maeN[k]++;
            }
        }
        if (oddsBets > 0) sb.append("💰 ROI по ставкам с введённым коэффициентом: ").append(String.format(Locale.US, "%+.1f", 100.0 * profit / oddsBets)).append("% (").append(oddsBets).append(" ставок)\n");
        if (gradeA + gradeB + gradeC > 0) {
            sb.append("Ставки по надёжности данных:");
            if (gradeA > 0) sb.append(" A ").append(gradeAWon).append("/").append(gradeA);
            if (gradeB > 0) sb.append(" · B ").append(gradeBWon).append("/").append(gradeB);
            if (gradeC > 0) sb.append(" · C ").append(gradeCWon).append("/").append(gradeC);
            sb.append("\n");
        }
        StringBuilder mae = new StringBuilder();
        for (int k = 0; k < maeFam.length; k++) if (maeN[k] >= 3) mae.append(mae.length() > 0 ? " · " : "").append(FAMILY_NAMES[k == 0 ? 0 : k + 2][1]).append(" ").append(String.format(Locale.US, "%.2f", maeSum[k] / maeN[k]));
        if (mae.length() > 0) sb.append("Среднее отклонение ожидания от факта (MAE): ").append(mae).append("\n");
        if (finished == 0) sb.append("\nПока нечего проверять. Сохраняй анализ до матча — после игры результат подтянется сам (для лиг со статистикой — полностью), остальное внеси в «Обучение».\n");
        for (String[] f : FAMILY_NAMES) {
            List<Calibration.Sample> l = by.get(f[0]);
            if (l == null || l.isEmpty()) continue;
            double[] st = Calibration.stats(l);
            Calibration c = ForecastModel.calibration;
            sb.append("\n").append(f[1]).append(": исходов ").append((int) st[0])
              .append(" · в среднем прогноз ").append(Math.round(st[1] * 100)).append("%, сбылось ").append(Math.round(st[2] * 100))
              .append("% · ошибка ").append(String.format(Locale.US, "%.3f", st[3])).append(" · log loss ").append(String.format(Locale.US, "%.3f", st[4])).append("\n");
            if (c != null && c.isActive(f[0])) sb.append("   Калибровка включена: проценты поправлены по твоим матчам\n");
            else if (!f[0].equals("res")) sb.append("   Калибровка включится после ").append(Calibration.MIN_SAMPLES).append(" исходов (ещё ").append(Math.max(0, Calibration.MIN_SAMPLES - (int) st[0])).append(")\n");
            if (st[0] >= 20) for (String line : Calibration.bins(l)) sb.append("   ").append(line).append("\n");
        }
        sb.append("\nОшибка 0.250 — как у подбрасывания монетки, чем меньше, тем лучше. Если «прогноз» заметно выше, чем «сбылось», модель завышает проценты — калибровка это исправляет сама.");
        TextView tv = label(sb.toString(), 12, 0xffdbe7f1, false);
        tv.setLineSpacing(dp(2), 1.0f);
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(16), dp(8), dp(16), dp(4));
        panel.addView(tv);
        ScrollView sv = new ScrollView(this); sv.addView(panel);
        new AlertDialog.Builder(this).setTitle(tr("📈 Точность модели")).setView(sv)
            .setPositiveButton(tr("Закрыть"), null)
            .setNeutralButton(tr("Обновить результаты"), (d, w) -> { toast("Ищу результаты сыгранных матчей…"); fillResultsAuto(() -> showAccuracy()); })
            .setNegativeButton(tr("Копировать / вставить данные"), (d, w) -> showDataTransfer())
            .show();
    }

    private void showDataTransfer() {
        String[] items = { tr("Скопировать мои данные в буфер обмена"), tr("Вставить данные из буфера обмена") };
        new AlertDialog.Builder(this).setTitle(tr("Перенос данных"))
            .setItems(items, (d, which) -> {
                try {
                    ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    if (which == 0) {
                        cm.setPrimaryClip(ClipData.newPlainText("FootballAnalyzer", loadRecords().toString()));
                        toast("Данные скопированы. Вставь их в заметки и сохрани.");
                    } else {
                        ClipData clip = cm.getPrimaryClip();
                        CharSequence text = clip == null || clip.getItemCount() == 0 ? null : clip.getItemAt(0).getText();
                        JSONArray incoming = new JSONArray(text == null ? "[]" : text.toString());
                        JSONArray mine = loadRecords();
                        int added = 0;
                        for (int i = 0; i < incoming.length(); i++) {
                            JSONObject in = incoming.optJSONObject(i);
                            if (in == null) continue;
                            boolean exists = false;
                            for (int j = 0; j < mine.length() && !exists; j++) {
                                JSONObject m = mine.optJSONObject(j);
                                exists = m != null && in.optString("date").equals(m.optString("date")) && in.optString("home").equals(m.optString("home")) && in.optString("away").equals(m.optString("away"));
                            }
                            if (!exists) { mine.put(in); added++; }
                        }
                        getSharedPreferences("football_learning", MODE_PRIVATE).edit().putString("records", mine.toString()).apply();
                        rebuildCalibration();
                        toast("Добавлено матчей: " + added);
                    }
                } catch (Exception e) { toast("Не удалось прочитать данные из буфера обмена"); }
            })
            .setNegativeButton(tr("Закрыть"), null).show();
    }

    /** Уровень надёжности по качеству и объёму данных (не по величине вероятности): A — 15+ матчей со статистикой, B — 8–14, C — меньше или только голы. */
    private static String gradeLetter(double n, boolean hasStats) { return !hasStats ? (n >= 8 ? "B" : "C") : n >= 15 ? "A" : n >= 8 ? "B" : "C"; }

    private static String gradeText(double n, boolean hasStats) {
        String g = gradeLetter(n, hasStats);
        return g + " — " + (int) n + " матчей на команду" + (hasStats ? "" : ", только голы (нет угловых/карточек)") + (g.equals("C") ? ": прогноз ненадёжный" : "");
    }

    private String gradeOf(JSONObject rec) {
        JSONObject pr = rec == null ? null : rec.optJSONObject("probs");
        if (pr == null || !pr.has("n_min")) return "";
        return gradeLetter(pr.optDouble("n_min"), pr.optDouble("n_stats") > 0);
    }

    private void putBet(JSONObject rec, String home, String away, Map<String, Double> probs) {
        try {
            List<Object[]> cand = rankBets(betCandidates(home, away, probs));
            if (cand.isEmpty()) return;
            Object[] best = cand.get(0);
            rec.put("bet_v", 3);
            rec.put("bet_label", (String) best[1]); rec.put("bet_key", (String) best[3]);
            rec.put("bet_pos", ((Boolean) best[4]).booleanValue()); rec.put("bet_p", ((Double) best[0]).doubleValue());
        } catch (Exception ignored) { }
    }

    /** true — ставка программы зашла, false — не зашла, null — ставки нет или не хватает фактических данных. */
    /** У записей, сохранённых до появления поля ставки, но с вероятностями — вычисляем ставку из сохранённых вероятностей. */
    private void ensureBet(JSONObject rec) {
        if (rec == null || rec.optInt("bet_v", 0) >= 3) return;
        JSONObject pr = rec.optJSONObject("probs");
        if (pr == null) return;
        Map<String, Double> m = new HashMap<>();
        Iterator<String> it = pr.keys();
        while (it.hasNext()) { String k = it.next(); m.put(k, pr.optDouble(k)); }
        putBet(rec, rec.optString("home"), rec.optString("away"), m);
    }

    private Boolean betResult(JSONObject rec) {
        ensureBet(rec);
        if (rec == null || !rec.has("bet_key") || !rec.optBoolean("actual_entered")) return null;
        Boolean y = Calibration.outcome(rec.optString("bet_key"), actualMap(rec));
        if (y == null) return null;
        return rec.optBoolean("bet_pos", true) ? y : !y;
    }

    private String betMark(JSONObject rec) {
        Boolean r = betResult(rec);
        return r == null ? "" : r ? "✅" : "❌";
    }

    private String betLine(JSONObject rec) {
        ensureBet(rec);
        if (rec == null || !rec.has("bet_label")) return "";
        return "🎯 " + tr("Ставка программы: ") + tr(rec.optString("bet_label")) + " · " + Math.round(rec.optDouble("bet_p") * 100) + "%";
    }

    /** Самый вероятный исход среди всех рассчитанных рынков (по вероятностям модели с учётом калибровки). */
    private List<Object[]> betCandidates(String home, String away, Map<String, Double> probs) {
        final List<Object[]> cand = new ArrayList<>();          // {вероятность, текст, семейство}
        for (Map.Entry<String, Double> e : probs.entrySet()) {
            String key = e.getKey(); double p = e.getValue(); String fam = Calibration.family(key);
            if (key.equals("res_home")) cand.add(new Object[]{p, "Победа: " + home, fam, key, true});
            else if (key.equals("res_away")) cand.add(new Object[]{p, "Победа: " + away, fam, key, true});
            else if (key.equals("res_draw")) cand.add(new Object[]{p, "Ничья", fam, key, true});
            else if (key.equals("btts")) {
                double q = ForecastModel.adj("btts", p);
                cand.add(new Object[]{q, "Обе забьют: Да", fam, key, true}); cand.add(new Object[]{1 - q, "Обе забьют: Нет", fam, key, false});
            } else {
                int i = key.indexOf("_o");
                if (i <= 0) continue;
                String line = key.substring(i + 2), title;
                String base = fam;
                String teamName = null;
                if (fam.endsWith("_h")) { base = fam.substring(0, fam.length() - 2); teamName = home; }
                else if (fam.endsWith("_a")) { base = fam.substring(0, fam.length() - 2); teamName = away; }
                if (teamName != null) {
                    try { int ln = (int) Math.floor(Double.parseDouble(line)); if (ln < ForecastModel.minTeamLineN(base) || ln > ForecastModel.maxTeamLineN(base)) continue; } catch (NumberFormatException ex) { continue; }
                    String noun;
                    switch (base) {
                        case "corners": noun = "угловых"; break;
                        case "yellow": noun = "карточек"; break;
                        case "fouls": noun = "фолов"; break;
                        case "target": noun = "ударов в створ"; break;
                        default: noun = "всех ударов";
                    }
                    double qt = p;
                    cand.add(new Object[]{qt, "Инд. тотал " + noun + " (" + teamName + ") " + line + ": 🔼 Больше", fam, key, true});
                    cand.add(new Object[]{1 - qt, "Инд. тотал " + noun + " (" + teamName + ") " + line + ": 🔽 Меньше", fam, key, false});
                    continue;
                }
                try { int tl = (int) Math.floor(Double.parseDouble(line)); if (tl < ForecastModel.minLineN(fam) || tl > ForecastModel.maxLineN(fam)) continue; } catch (NumberFormatException ex) { continue; }
                switch (fam) {
                    case "goals": title = "Тотал голов"; break;
                    case "corners": title = "Тотал угловых"; break;
                    case "yellow": title = "Тотал карточек"; break;
                    case "fouls": title = "Тотал фолов"; break;
                    case "target": title = "Тотал ударов в створ"; break;
                    default: title = "Тотал всех ударов";
                }
                double q = ForecastModel.adj(fam, p);
                cand.add(new Object[]{q, title + " " + line + ": 🔼 Больше", fam, key, true});
                cand.add(new Object[]{1 - q, title + " " + line + ": 🔽 Меньше", fam, key, false});
            }
        }
        Collections.sort(cand, (x, y) -> Double.compare((Double) y[0], (Double) x[0]));
        return cand;
    }

    private static int famOrd(String fam) {
        boolean team = fam.endsWith("_h") || fam.endsWith("_a");
        String base = team ? fam.substring(0, fam.length() - 2) : fam;
        int i = Arrays.asList(FAM_ORDER).indexOf(base);
        return (i < 0 ? 99 : i) * 3 + (team ? (fam.endsWith("_h") ? 1 : 2) : 0);
    }

    private static final String[] FAM_ORDER = {"res", "goals", "btts", "corners", "yellow", "target", "shots", "fouls"};

    /** Итоги по каждому рынку: ✅ / ❌ напротив самой вероятной стороны каждой линии. */
    private String resultSummary(JSONObject rec) {
        JSONObject pr = rec == null ? null : rec.optJSONObject("probs");
        if (pr == null || !rec.optBoolean("actual_entered")) return "";
        Map<String, Double> m = new HashMap<>();
        Iterator<String> it = pr.keys();
        while (it.hasNext()) { String k = it.next(); m.put(k, pr.optDouble(k)); }
        Map<String, Double> act = actualMap(rec);
        Map<String, Object[]> pick = new HashMap<>();
        for (Object[] c : betCandidates(rec.optString("home"), rec.optString("away"), m)) {
            String key = (String) c[3];
            Object[] cur = pick.get(key);
            if (cur == null || (Double) c[0] > (Double) cur[0]) pick.put(key, c);
        }
        Object[] bestRes = null;
        List<Object[]> rows = new ArrayList<>();
        for (Object[] c : pick.values()) {
            if ("res".equals(c[2])) { if (bestRes == null || (Double) c[0] > (Double) bestRes[0]) bestRes = c; }
            else rows.add(c);
        }
        if (bestRes != null) rows.add(bestRes);
        Collections.sort(rows, (x, y) -> {
            int a = famOrd((String) x[2]), b = famOrd((String) y[2]);
            return a != b ? Integer.compare(a, b) : ((String) x[3]).compareTo((String) y[3]);
        });
        StringBuilder sb = new StringBuilder();
        int won = 0, total = 0;
        for (Object[] c : rows) {
            Boolean y = Calibration.outcome((String) c[3], act);
            String mark = "▫️";
            if (y != null) { boolean win = ((Boolean) c[4]) ? y : !y; mark = win ? "✅" : "❌"; total++; if (win) won++; }
            sb.append(mark).append(" ").append(c[1]).append(" — ").append(Math.round((Double) c[0] * 100)).append("%\n");
        }
        if (rows.isEmpty()) return "";
        return "Итоги прогнозов: " + won + " из " + total + " (▫️ — не хватает цифр для проверки)\n\n" + sb;
    }

    // ================= Экспресс из 3 событий =================
    private String legTitle(JSONObject r) { return r.optString("date") + " · " + r.optString("home") + " — " + r.optString("away"); }

    /** Подбирает 3 события из разных сохранённых матчей (ещё не сыгранных): надёжность A или B, вероятность в рабочем диапазоне. */
    private void showExpress() {
        JSONArray arr = loadRecords();
        final List<JSONObject> cands = new ArrayList<>();
        for (int i = 0; i < arr.length(); i++) {
            JSONObject rec = arr.optJSONObject(i);
            if (rec == null || rec.optBoolean("actual_entered") || rec.optString("date").compareTo(today()) < 0) continue;
            ensureBet(rec);
            if (!rec.has("bet_label")) continue;
            String g = gradeOf(rec);
            double p = rec.optDouble("bet_p");
            if (g.isEmpty() || g.equals("C") || p < BET_MIN || p > BET_MAX) continue;
            cands.add(rec);
        }
        Collections.sort(cands, (x, y) -> Double.compare(y.optDouble("bet_p"), x.optDouble("bet_p")));
        final List<JSONObject> legs = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        for (JSONObject c : cands) {
            if (legs.size() >= 3) break;
            if (seen.add(c.optString("date") + "|" + c.optString("home") + "|" + c.optString("away"))) legs.add(c);
        }
        if (legs.size() < 3) {
            new AlertDialog.Builder(this).setTitle(tr("🎰 Экспресс (3 события)"))
                .setMessage(tr("Подходящего экспресса нет. Нужны 3 события из разных ещё не сыгранных матчей, сохранённых в историю, с надёжностью данных A или B и вероятностью 55–72%. Сейчас подходит: ") + legs.size() + tr(". Сохрани больше анализов до матчей."))
                .setPositiveButton(tr("Закрыть"), null).show();
            return;
        }
        showExpressDialog(legs, null);
    }

    private void showExpressDialog(final List<JSONObject> legs, final List<DayPick> picks) {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(16), dp(8), dp(16), dp(4));
        panel.addView(label("Подобраны 3 события с наибольшей вероятностью. Введи коэффициенты букмекера (необязательно), чтобы увидеть ожидание.", 12, MUTED, false), lp(0, 6));
        final EditText[] odds = new EditText[3];
        for (int i = 0; i < 3; i++) {
            JSONObject r = legs.get(i);
            panel.addView(label((i + 1) + ". " + legTitle(r), 13, Color.WHITE, true), lp(6, 0));
            panel.addView(label(betLine(r) + " · " + tr("надёжность") + " " + gradeOf(r), 12, 0xffdbe7f1, false), lp(0, 2));
            odds[i] = new EditText(this);
            odds[i].setSingleLine(true); odds[i].setInputType(8194); odds[i].setTextColor(Color.WHITE); odds[i].setHintTextColor(MUTED); odds[i].setHint(tr("Коэффициент, например 1.85"));
            odds[i].setBackground(shape(PANEL2, 8)); odds[i].setPadding(dp(12), dp(7), dp(12), dp(7));
            panel.addView(odds[i], lp(0, 4));
        }
        ScrollView sv = new ScrollView(this); sv.addView(panel);
        new AlertDialog.Builder(this).setTitle(tr("🎰 Экспресс (3 события)")).setView(sv)
            .setPositiveButton(tr("Рассчитать"), (dlg, w) -> {
                double[] o = new double[3];
                for (int i = 0; i < 3; i++) {
                    try { o[i] = Double.parseDouble(odds[i].getText().toString().trim().replace(',', '.')); } catch (Exception e) { o[i] = 0; }
                }
                final String summary = expressSummary(legs, o);
                new AlertDialog.Builder(this).setTitle(tr("🎰 Экспресс (3 события)")).setMessage(translateReport(summary))
                    .setPositiveButton(tr("Закрыть"), null)
                    .setNeutralButton(tr("Сохранить в историю"), (d2, w2) -> {
                        saveHistory(summary);
                        saveExpress(legs, o, picks);
                    }).show();
            })
            .setNeutralButton(tr("💾 Сохранить экспресс"), (dlg, w) -> {
                double[] o = new double[3];
                for (int i = 0; i < 3; i++) {
                    try { o[i] = Double.parseDouble(odds[i].getText().toString().trim().replace(',', '.')); } catch (Exception e) { o[i] = 0; }
                }
                saveHistory(expressSummary(legs, o));
                saveExpress(legs, o, picks);
            })
            .setNegativeButton(tr("Закрыть"), null).show();
    }

    // ---- Журнал экспрессов: событие считается по сохранённым результатам матчей (база обучения) ----
    private SharedPreferences expressPrefs() { return getSharedPreferences("football_express", MODE_PRIVATE); }

    private void saveExpress(List<JSONObject> legs, double[] odds, List<DayPick> picks) {
        try {
            if (picks != null) for (DayPick k : picks) saveLearningForecast(k.date, k.league.title, k.league.folder, k.home, k.away, k.report, k.probs);
            JSONObject e = new JSONObject();
            e.put("created", new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(new Date()));
            JSONArray la = new JSONArray(); double prob = 1, total = 1; boolean allOdds = true;
            for (int i = 0; i < legs.size(); i++) {
                JSONObject r = legs.get(i), o = new JSONObject();
                o.put("date", r.optString("date")); o.put("home", r.optString("home")); o.put("away", r.optString("away"));
                o.put("label", r.optString("bet_label")); o.put("key", r.optString("bet_key")); o.put("pos", r.optBoolean("bet_pos", true));
                o.put("p", r.optDouble("bet_p")); o.put("odds", i < odds.length ? odds[i] : 0);
                prob *= r.optDouble("bet_p"); if (i < odds.length && odds[i] > 1) total *= odds[i]; else allOdds = false;
                la.put(o);
            }
            e.put("legs", la); e.put("prob", prob); e.put("total_odds", allOdds ? total : 0);
            JSONArray old = new JSONArray(expressPrefs().getString("items", "[]"));
            JSONArray arr = new JSONArray(); arr.put(e);
            for (int i = 0; i < old.length() && arr.length() < 200; i++) arr.put(old.opt(i));
            expressPrefs().edit().putString("items", arr.toString()).apply();
            toast("Экспресс сохранён. После матчей результаты подтянутся сами или введи их вручную в «Обучение»: здесь появятся ✅ и ❌.");
        } catch (Exception ex) { toast("Не удалось сохранить экспресс"); }
    }

    /** true — событие зашло, false — не зашло, null — результата ещё нет. */
    private Boolean expressLegResult(JSONObject leg) {
        JSONArray arr = loadRecords();
        for (int i = 0; i < arr.length(); i++) {
            JSONObject r = arr.optJSONObject(i);
            if (r == null || !r.optBoolean("actual_entered")) continue;
            if (!r.optString("date").equals(leg.optString("date")) || !r.optString("home").equals(leg.optString("home")) || !r.optString("away").equals(leg.optString("away"))) continue;
            Boolean y = Calibration.outcome(leg.optString("key"), actualMap(r));
            if (y == null) return null;
            return leg.optBoolean("pos", true) ? y : !y;
        }
        return null;
    }

    private void showExpressHistory() {
        JSONArray arr;
        try { arr = new JSONArray(expressPrefs().getString("items", "[]")); } catch (Exception e) { arr = new JSONArray(); }
        if (arr.length() == 0) {
            new AlertDialog.Builder(this).setTitle(tr("🎰 Мои экспрессы (итоги)")).setMessage(tr("Экспрессов пока нет. Собери экспресс дня и нажми «Сохранить экспресс»."))
                .setPositiveButton(tr("Закрыть"), null).show();
            return;
        }
        StringBuilder body = new StringBuilder(); int done = 0, won = 0, wait = 0; double stake = 0, ret = 0;
        for (int i = 0; i < arr.length(); i++) {
            JSONObject e = arr.optJSONObject(i); if (e == null) continue;
            JSONArray legs = e.optJSONArray("legs"); if (legs == null) continue;
            int ok = 0, bad = 0, open = 0; StringBuilder lb = new StringBuilder();
            for (int k = 0; k < legs.length(); k++) {
                JSONObject l = legs.optJSONObject(k); Boolean r = expressLegResult(l);
                if (r == null) open++; else if (r) ok++; else bad++;
                lb.append("  ").append(r == null ? "⏳" : r ? "✅" : "❌").append(" ").append(l.optString("date")).append(" · ").append(l.optString("home")).append(" — ").append(l.optString("away"))
                  .append("\n      ").append(l.optString("label")).append(" — ").append(Math.round(l.optDouble("p") * 100)).append("%")
                  .append(l.optDouble("odds") > 1 ? " · " + String.format(Locale.US, "%.2f", l.optDouble("odds")) : "").append("\n");
            }
            String st, man = e.optString("manual", "");
            if (man.equals("won")) { st = "✅ " + tr("Экспресс зашёл") + " ✏️"; done++; won++; if (e.optDouble("total_odds") > 1) { stake += 1; ret += e.optDouble("total_odds"); } }
            else if (man.equals("lost")) { st = "❌ " + tr("Экспресс не зашёл") + " ✏️"; done++; if (e.optDouble("total_odds") > 1) stake += 1; }
            else if (bad > 0) { st = "❌ " + tr("Экспресс не зашёл"); done++; if (e.optDouble("total_odds") > 1) stake += 1; }
            else if (open == 0) { st = "✅ " + tr("Экспресс зашёл"); done++; won++; if (e.optDouble("total_odds") > 1) { stake += 1; ret += e.optDouble("total_odds"); } }
            else { st = "⏳ " + tr("Ждём результаты"); wait++; }
            body.append(e.optString("created")).append(" · ").append(st).append("\n").append(lb)
                .append("  ").append(tr("Общая вероятность: ")).append(String.format(Locale.US, "%.1f", e.optDouble("prob") * 100)).append("%")
                .append(e.optDouble("total_odds") > 1 ? " · " + tr("Общий коэффициент букмекера: ") + String.format(Locale.US, "%.2f", e.optDouble("total_odds")) : "").append("\n\n");
        }
        String head = tr("Экспрессов завершено: ") + done + tr("; зашло: ") + won + (wait > 0 ? "\n" + tr("Ожидают результатов: ") + wait : "")
            + (stake > 0 ? "\nROI: " + String.format(Locale.US, "%+.0f%%", (ret - stake) / stake * 100) : "") + "\n\n";
        ScrollView sv = new ScrollView(this);
        TextView tv = label(head + body, 13, 0xffdbe7f1, false); tv.setPadding(dp(16), dp(8), dp(16), dp(8)); sv.addView(tv);
        new AlertDialog.Builder(this).setTitle(tr("🎰 Мои экспрессы (итоги)")).setView(sv).setPositiveButton(tr("Закрыть"), null)
            .setNeutralButton(tr("✏️ Отметить вручную"), (d, w) -> pickExpressToMark()).show();
    }

    /** Ручная отметка: если результаты матчей не подтянулись, можно самой поставить «зашёл» / «не зашёл». */
    private void pickExpressToMark() {
        final JSONArray arr;
        try { arr = new JSONArray(expressPrefs().getString("items", "[]")); } catch (Exception e) { return; }
        final int n = Math.min(arr.length(), 30);
        String[] items = new String[n];
        for (int i = 0; i < n; i++) {
            JSONObject e = arr.optJSONObject(i); JSONArray legs = e == null ? null : e.optJSONArray("legs");
            String m = e == null ? "" : e.optString("manual", "");
            items[i] = (m.equals("won") ? "✅ " : m.equals("lost") ? "❌ " : "") + (e == null ? "" : e.optString("created")) + " · "
                + (legs != null && legs.length() > 0 ? legs.optJSONObject(0).optString("home") + " — " + legs.optJSONObject(0).optString("away") + " …" : "");
        }
        new AlertDialog.Builder(this).setTitle(tr("Какой экспресс отметить?")).setItems(items, (d, which) -> {
            final int idx = which;
            new AlertDialog.Builder(this).setTitle(tr("Результат экспресса"))
                .setItems(new String[]{"✅ " + tr("Экспресс зашёл"), "❌ " + tr("Экспресс не зашёл"), tr("Сбросить (считать по матчам)")}, (d2, c) -> {
                    try {
                        JSONObject e = arr.getJSONObject(idx);
                        if (c == 0) e.put("manual", "won"); else if (c == 1) e.put("manual", "lost"); else e.put("manual", "");
                        expressPrefs().edit().putString("items", arr.toString()).apply();
                    } catch (Exception ignored) { }
                    showExpressHistory();
                }).show();
        }).setNegativeButton(tr("Закрыть"), null).show();
    }

    private String expressSummary(List<JSONObject> legs, double[] odds) {
        double prob = 1;
        StringBuilder sb = new StringBuilder("🎰 Экспресс из 3 событий (разные матчи, события считаются независимыми)\n\n");
        for (int i = 0; i < legs.size(); i++) {
            JSONObject r = legs.get(i);
            prob *= r.optDouble("bet_p");
            sb.append(i + 1).append(". ").append(legTitle(r)).append("\n   ").append(r.optString("bet_label")).append(" — ").append(Math.round(r.optDouble("bet_p") * 100)).append("%")
              .append(odds[i] > 1 ? " · коэф. " + String.format(Locale.US, "%.2f", odds[i]) : "").append("\n");
        }
        sb.append("\nОбщая вероятность: ").append(String.format(Locale.US, "%.1f", prob * 100)).append("%\nЧестный коэффициент без маржи: ").append(String.format(Locale.US, "%.2f", 1.0 / prob)).append("\n");
        boolean all = odds[0] > 1 && odds[1] > 1 && odds[2] > 1;
        if (all) {
            double total = odds[0] * odds[1] * odds[2], ev = prob * total - 1;
            sb.append("Общий коэффициент букмекера: ").append(String.format(Locale.US, "%.2f", total)).append("\nВыплата со ставки 100: ").append(Math.round(100 * total))
              .append("\nБукмекер оценивает вероятность в ").append(String.format(Locale.US, "%.1f", 100.0 / total)).append("%\nМатематическое ожидание на 1 единицу ставки: ")
              .append(String.format(Locale.US, "%+.2f", ev)).append("\n").append(ev > 0 ? "По модели перевес есть, но модель может ошибаться." : "По модели перевеса нет: коэффициент ниже честного.").append("\n");
        } else sb.append("Введи коэффициенты всех трёх событий, чтобы увидеть математическое ожидание.\n");
        sb.append("\nВероятность экспресса всегда ниже вероятности каждого события: так работает перемножение. Это расчёт модели, а не гарантия. Играй только на те деньги, которые не жалко потерять.");
        return sb.toString();
    }

    private static final double BET_MIN = 0.55, BET_MAX = 0.72;

    /** Рекомендация: самая вероятная ставка в «рабочем» диапазоне 55–72% (у букмекера коэффициент примерно 1.4–1.8). Очевидные 80%+ (коэффициент ~1.1) не берём. */
    private List<Object[]> rankBets(List<Object[]> cand) {
        List<Object[]> inBand = new ArrayList<>(), below = new ArrayList<>();
        for (Object[] c : cand) {
            double p = (Double) c[0];
            if (p >= BET_MIN && p <= BET_MAX) inBand.add(c); else if (p < BET_MAX) below.add(c);
        }
        return !inBand.isEmpty() ? inBand : !below.isEmpty() ? below : cand;
    }

    private String recommendBet(String home, String away, Map<String, Double> probs) {
        if (probs == null || probs.isEmpty()) return "Для этого матча недостаточно данных: нужно минимум 3 сыгранных матча у каждой команды.";
        final List<Object[]> cand = rankBets(betCandidates(home, away, probs));
        StringBuilder sb = new StringBuilder();
        Object[] best = cand.get(0);
        if (probs.containsKey("n_min")) sb.append("🛡 Надёжность данных: ").append(gradeText(probs.get("n_min"), probs.get("n_stats") != null && probs.get("n_stats") > 0)).append("\n\n");
        sb.append("Самый вероятный исход в рабочем диапазоне 55–72%:\n\n").append(best[1]).append("\nВероятность по модели: ").append(Math.round((Double) best[0] * 100)).append("%\n");
        Set<String> used = new HashSet<>(); used.add((String) best[2]);
        int shown = 0;
        for (Object[] c : cand) {
            if (shown >= 2) break;
            if (used.contains((String) c[2])) continue;
            if (shown == 0) sb.append("\nТакже вероятно:\n");
            used.add((String) c[2]); shown++;
            sb.append("• ").append(c[1]).append(" — ").append(Math.round((Double) c[0] * 100)).append("%\n");
        }
        sb.append("\nИсходы выше 72% не берутся: на них у букмекера коэффициент около 1.1–1.3, это не ставка. Не берутся и линии, которых у букмекеров обычно нет (карточки меньше 2.5, угловые меньше 6.5 и т. п.). Это расчёт модели, а не гарантия; коэффициентов букмекера программа не знает.");
        return sb.toString();
    }

    @Override protected void onDestroy() { RadioService.listener = null; super.onDestroy(); worker.shutdownNow(); }
}
