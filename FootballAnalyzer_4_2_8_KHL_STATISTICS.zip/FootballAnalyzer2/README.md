# Football Analyzer 3.5

Android-приложение на Java. Источник: open-matchday CSV (обновление примерно раз в сутки, без API-ключа).

## Что изменено в 3.5
- Вместо одного среднего голевого показателя показываются забитые и пропущенные голы и форма В-Н-П.
- Для каждой команды берутся до 8 последних сыгранных матчей по дате.
- Статистические показатели считаются только по реально заполненным значениям; пустые поля не превращаются в нули.
- Добавлен прогноз: ожидаемые голы, вероятности 1X2, тотал больше 2.5 и обе забьют (модель Пуассона).
- Если у команды меньше 3 матчей, приложение честно сообщает, что прогноза недостаточно для расчёта.
- В историю сохраняется и сам рассчитанный прогноз.

Источник обновляется раз в сутки и не предоставляет xG, составы, травмы или коэффициенты. Прогноз не является гарантией результата.


## Версия 3.6 — подробный отчёт и тоталы

Отчёт показывает последние 10 сыгранных матчей каждой команды: забитые/пропущенные голы суммарно и в среднем, угловые, жёлтые карточки, удары в створ, все удары и фолы (сумма и среднее по числу матчей с опубликованной статистикой). Добавлены ориентировочные вероятности больше/меньше по тоталам. Вбрасывания из аута не входят в схему open-matchday и поэтому помечаются как недоступные. Вероятности — простая модель Пуассона по средним, не гарантии и не букмекерские коэффициенты.


## Резервная статистика 3.8

Для матчей с пустыми статистическими полями приложение сначала использует open-matchday CSV, затем пытается найти тот же матч в публичном ESPN Site API без ключа. Совпадение выполняется по дате и названиям обеих команд. Подтягиваются угловые, жёлтые карточки, удары в створ, все удары и фолы. Значения из ESPN используются только для пустых полей; уже опубликованные значения open-matchday не перезаписываются.

ESPN — дополнительный необязательный источник: он не покрывает все турниры и матчи, а его публичный интерфейс не является гарантированным коммерческим API. Если матч не найден или статистика отсутствует, приложение продолжает показывать «нет опубликованных данных», не подставляя нули.


## Update 3.9 (work in progress)
- Added an in-app Settings button.
- Added language selection: Russian, English, Norwegian and Ukrainian for the main navigation and settings controls.
- Added a password-masked SportsAPI Pro token field in Settings; the token is stored in private app preferences and is not hard-coded into source.
- The SportsAPI Pro token is currently saved but is NOT yet wired into match/statistics requests. The API integration requires mapping the provider's tournament, fixture, event and match-statistics response models to the existing analyzer.
- The previously shared token should be revoked and replaced because it was exposed in chat. Enter the replacement token in Settings.
- Android APK build was not run in this environment (Gradle/Android SDK build tools are unavailable).


## Версия 4.0 — проверка SportsAPI Pro
- В настройках добавлена кнопка «Проверить подключение» (на четырёх языках).
- Кнопка выполняет GET-запрос к `https://api.sportsapipro.com/v2/football/api/live` с заголовком `x-api-key`, используя токен из поля настроек (до сохранения).
- Показывает HTTP 200 и количество live-матчей, либо понятные ответы для 401/403 (неверный/неразрешённый ключ), 429 (лимит) и других HTTP-ошибок.
- Токен не зашит в APK или исходный код.
- Важно: это проверка авторизации и live endpoint. Полная интеграция статистики матча (угловые, фолы, карточки, удары) в расчёт последних 10 матчей ещё не реализована и требует проверки фактической схемы ответа `match/{matchId}/statistics`.
- Сборка APK в этой среде не запускалась: Android SDK/Gradle отсутствуют. Для APK используйте GitHub Actions workflow `Build Football Analyzer 3`.


## Версия 4.1.5 — отдельный раздел хоккея
- Добавлен отдельный экран Hockey Analyzer, вход с футбольного экрана и кнопка возврата.
- Добавлен список основных хоккейных соревнований: NHL, AHL, ECHL, КХЛ, ВХЛ, МХЛ, SHL, HockeyAllsvenskan, Liiga, чешская и словацкая Extraliga, Swiss National League, DEL, ICEHL, Норвегия, Польша, Франция, OHL, WHL, QMJHL, NCAA, PWHL, IIHF и Champions Hockey League.
- Хоккейный экран использует сохранённый в настройках SportsAPI Pro токен и отдельные запросы live / scheduled; футбольный экран и его загрузчик не изменялись.
- Важно: endpoint hockey и структура ответа требуют проверки реальным токеном в установленной версии API. При ошибке приложение показывает HTTP/формат ответа, а не выдумывает матчи. Лиги в списке являются фильтрами по названию турнира, фактическая доступность зависит от ответа провайдера.
- Этот этап добавляет загрузку матчей и счёта. Анализ бросков по периодам, штрафов, вратарских сейвов и историю хоккейных команд нужно подключить следующим этапом после проверки реальных полей статистики провайдера.
- APK в локальной среде не собирался; используйте GitHub Actions workflow.


## Hockey data provider fallback (4.2.2)

- Primary: configured SportsAPI Pro token.
- If the token is missing or the provider returns HTTP 429 / daily-limit errors, the app tries the public NHL Web API (no key).
- If the NHL public endpoint has no usable games or is unavailable, it tries ESPN's public NHL scoreboard API (no key).
- Public NHL game cards open a separate public-source details screen using NHL boxscore/play-by-play or ESPN summary.
- These no-key fallbacks currently cover NHL only. They do not claim KHL/VHL/European coverage. European public feeds (SHL, Liiga, DEL, ICEHL, KHL, VHL, etc.) have been identified in SportsDataverse/fastRhockey documentation, but each requires a league-specific adapter and response parser before it can be safely enabled.
- The app must not treat an empty or unavailable statistics field as zero.

\n## Hockey public fallback (4.2.3)\n\n- NHL: public NHL Web API, with ESPN scoreboard as a fallback. No API key.\n- KHL: keyless KHL Webcaster JSON feed (`khl.api.webcaster.pro`) with dynamic stage discovery and a documented 2026/27 fallback stage ID. Normalizes schedule/live cards, score, and per-period score fields.\n- When the selected filter is `Все хоккейные лиги`, the app merges available KHL and NHL free-source cards. For KHL-only selection, it tries KHL Webcaster after any SportsAPI Pro failure or when the token is absent.\n- KHL match detail currently displays score and period scores. Shot totals, penalties, power-play and goalie saves are NOT yet connected to this keyless KHL adapter.\n- VHL, MHL and the remaining European league adapters are not yet enabled.\n- The KHL Webcaster feed is documented as keyless; respect its usage terms and avoid rapid repeated requests.\n

## 4.2.4 ESPN live status fix

ESPN scoreboard `competitions[].status.type.state` is parsed as a text state (`pre`, `in`, `post`), not as a boolean. Live NHL events are now retained when state is `in`/`live` or type name indicates in-progress/live. This fixes the prior boolean-only filter that could discard every ESPN live event. ESPN remains a no-key fallback after NHL API returns no events or fails.

\n## 4.2.5 KHL Webcaster response fix\n\nThe KHL `events_v2.json` endpoint can return a top-level JSON array containing wrapper objects with an `event` property. The previous code attempted to parse every response as a JSON object, producing `Value [...]` and no matches. Added a JSON object/array response reader, unwraps `event`, reads nested `team_a` / `team_b`, and maps period scores from nested `scores`. Stage discovery no longer accepts a stage with no matching season; falls back to the documented current-season stage ID.\n

## 4.2.6 compile fix

Removed a duplicate declaration of `hockeyPublicGetAny(String)` introduced by the 4.2.5 patch. The first implementation is retained; KHL JSON-array handling is unchanged.

\n## 4.2.7 KHL Webcaster request fix\n\nCorrected KHL events_v2 query parameter names to `q[start_at_gt_time_from_unixtime]` and `q[start_at_lt_time_from_unixtime]` (URL-encoded brackets). The previous plain `start_after` / `start_before` names are not accepted by the mobile endpoint and were silently ignored, causing old unrelated games to be returned and then removed by the local date filter. Stage discovery now checks `current_stage_id` and `stages_v2[].id`, matching the documented API payload.\n