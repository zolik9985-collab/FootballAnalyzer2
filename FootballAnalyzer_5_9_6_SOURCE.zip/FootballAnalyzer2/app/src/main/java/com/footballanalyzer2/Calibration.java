package com.footballanalyzer2;

import java.util.*;

/**
 * Проверка прогнозов по фактическим результатам и калибровка вероятностей (чистая Java, без Android).
 * Ключи прогнозов: goals_o2.5, btts, res_home/res_draw/res_away, corners_o9.5, yellow_o4.5, fouls_o24.5, target_o8.5, shots_o24.5.
 * Фактические данные: gh, ga (голы), corners, yellow, fouls, target, shots (суммы за матч).
 * Калибровка: логистическая поправка p' = sigmoid(a*logit(p)+b), параметры подбираются по накопленным матчам
 * с сильным притяжением к a=1, b=0; включается только когда по семейству рынков есть минимум MIN_SAMPLES исходов.
 */
final class Calibration {
    static final int MIN_SAMPLES = 40;
    private static final double RIDGE = 3.0;

    static final class Sample {
        final double p; final boolean y;
        Sample(double p, boolean y) { this.p = p; this.y = y; }
    }

    private final Map<String, double[]> params = new HashMap<>();

    static String family(String key) {
        if (key.startsWith("res_")) return "res";
        int i = key.indexOf("_o");
        return i > 0 ? key.substring(0, i) : key;
    }

    /** Исход события или null, если фактических данных для него нет. */
    static Boolean outcome(String key, Map<String, Double> actual) {
        Double gh = actual.get("gh"), ga = actual.get("ga");
        if (key.equals("btts")) return gh == null || ga == null ? null : (gh > 0 && ga > 0);
        if (key.equals("res_home")) return gh == null || ga == null ? null : gh > ga;
        if (key.equals("res_draw")) return gh == null || ga == null ? null : gh.doubleValue() == ga.doubleValue();
        if (key.equals("res_away")) return gh == null || ga == null ? null : ga > gh;
        int i = key.indexOf("_o");
        if (i <= 0) return null;
        double line;
        try { line = Double.parseDouble(key.substring(i + 2)); } catch (NumberFormatException e) { return null; }
        String fam = key.substring(0, i);
        Double value = fam.equals("goals") ? (gh == null || ga == null ? null : gh + ga) : actual.get(fam);
        return value == null ? null : value > line;
    }

    private static double clamp(double v) { return Math.max(0.02, Math.min(0.98, v)); }
    private static double logit(double p) { p = clamp(p); return Math.log(p / (1 - p)); }
    private static double sigmoid(double x) { return 1.0 / (1.0 + Math.exp(-x)); }

    double apply(String family, double p) {
        double[] ab = params.get(family);
        if (ab == null) return p;
        return Math.max(0.03, Math.min(0.97, sigmoid(ab[0] * logit(p) + ab[1])));
    }

    boolean isActive(String family) { return params.containsKey(family); }
    double[] paramsFor(String family) { return params.get(family); }

    static double[] fitPlatt(List<Sample> list) {
        double bestA = 1, bestB = 0, best = Double.MAX_VALUE;
        for (int ia = 0; ia <= 24; ia++) {
            double a = 0.4 + ia * 0.05;
            for (int ib = -20; ib <= 20; ib++) {
                double b = ib * 0.05, loss = RIDGE * ((a - 1) * (a - 1) * 4 + b * b * 4);
                for (Sample s : list) {
                    double q = Math.max(1e-6, Math.min(1 - 1e-6, sigmoid(a * logit(s.p) + b)));
                    loss -= s.y ? Math.log(q) : Math.log(1 - q);
                }
                if (loss < best) { best = loss; bestA = a; bestB = b; }
            }
        }
        return new double[]{bestA, bestB};
    }

    void fit(Map<String, List<Sample>> byFamily) {
        params.clear();
        for (Map.Entry<String, List<Sample>> e : byFamily.entrySet()) {
            if (e.getKey().equals("res") || e.getValue().size() < MIN_SAMPLES) continue;
            params.put(e.getKey(), fitPlatt(e.getValue()));
        }
    }

    /** {n, средний прогноз, доля сбывшихся, Brier} */
    static double[] stats(List<Sample> list) {
        double sp = 0, sy = 0, br = 0;
        for (Sample s : list) { sp += s.p; sy += s.y ? 1 : 0; double d = s.p - (s.y ? 1 : 0); br += d * d; }
        int n = list.size();
        return n == 0 ? new double[]{0, 0, 0, 0} : new double[]{n, sp / n, sy / n, br / n};
    }

    /** Надёжность по корзинам вероятности: строки "50–60%: прогноз ср. 55%, сбылось 52% (n=34)". */
    static List<String> bins(List<Sample> list) {
        double[] edges = {0, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 1.01};
        List<String> out = new ArrayList<>();
        for (int b = 0; b + 1 < edges.length; b++) {
            int n = 0; double sp = 0, sy = 0;
            for (Sample s : list) if (s.p >= edges[b] && s.p < edges[b + 1]) { n++; sp += s.p; sy += s.y ? 1 : 0; }
            if (n == 0) continue;
            out.add(String.format(Locale.US, "%d–%d%%: прогноз %.0f%%, сбылось %.0f%% (n=%d)",
                    Math.round(edges[b] * 100), Math.round(Math.min(edges[b + 1], 1.0) * 100), sp / n * 100, sy / n * 100, n));
        }
        return out;
    }
}
