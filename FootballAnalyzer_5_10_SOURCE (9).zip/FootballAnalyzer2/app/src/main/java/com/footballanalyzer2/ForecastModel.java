package com.footballanalyzer2;

import java.util.Locale;

/**
 * Чистая математика прогнозов (без Android-зависимостей, поэтому проверяется обычным JVM-тестом).
 *
 * Голы: силы атаки/обороны относительно среднего по лиге со сглаживанием к среднему (малая выборка
 * не даёт экстремальных значений), домашнее преимущество берётся из средних лиги (хозяева/гости),
 * счёт считается по Пуассону с поправкой Диксона-Коулса для низких счетов.
 * Счётные рынки (угловые, карточки, фолы, удары): сглаженное среднее + отрицательное биномиальное
 * распределение (Пуассон, если разброс не больше среднего), линии подбираются вокруг ожидания.
 */
final class ForecastModel {
    private ForecastModel() {}

    static double DC_RHO = -0.10;          // настраиваемые параметры (подбираются бэктестом)
    /** Калибровка по накопленным результатам (null — выключена). Меняет только показываемые вероятности "Больше/Меньше" и "Обе забьют". */
    static volatile Calibration calibration;
    static final String MODEL_VERSION = "5.10";
    /** Наименьшая целая часть линии N.5, которую реально дают букмекеры (карточки: от 2.5, угловые: от 6.5 и т. д.). */
    static int minLineN(String family) {
        if (family == null) return 0;
        switch (family) {
            case "yellow": return 2;
            case "corners": return 6;
            case "fouls": return 16;
            case "target": return 4;
            case "shots": return 10;
            default: return 0;
        }
    }

    /** Наименьшая линия индивидуального тотала команды у букмекеров. */
    /** Верхняя линия, которую у букмекеров ещё предлагают (индивидуальные карточки: максимум 2.5). */
    static int maxTeamLineN(String family) {
        return "yellow".equals(family) ? 2 : Integer.MAX_VALUE;
    }

    static int minTeamLineN(String family) {
        switch (family) {
            case "yellow": return 1;   // индивидуальные карточки у букмекеров с 1.5
            case "corners": return 2;
            case "fouls": return 8;
            case "target": return 1;
            case "shots": return 4;
            default: return 0;
        }
    }

    private static String teamLines(String icon, String name, double rate, double phi, String key, String suffix, java.util.Map<String, Double> sink) {
        if (!(rate > 0)) return "";
        double var = rate * Math.max(1.0, phi);
        int start = Math.min(Math.max(Math.max((int) Math.floor(rate) - 1, 0), minTeamLineN(key)), maxTeamLineN(key));
        StringBuilder b = new StringBuilder("      ").append(icon).append(name).append(" · ожидание ").append(f1(rate)).append(": ");
        for (int n = start; n <= start + 2 && n <= maxTeamLineN(key); n++) {
            double over = overProbability(n, rate, var);
            if (sink != null) sink.put(key + suffix + "_o" + n + ".5", over);
            b.append(n > start ? " · " : "").append(n).append(".5 🔼 ").append(pct(over));
        }
        return b.append("\n").toString();
    }

    static double adj(String family, double p) { Calibration c = calibration; return c == null ? p : c.apply(family, p); }
    private static final int MAX_GOALS = 10;
    static double GOALS_PRIOR_MATCHES = 20.0;   // подобрано бэктестом: малая выборка команды сильно сжимается к среднему лиги   // вес "среднего по лиге" в матчах
    static double COUNT_PRIOR_MATCHES = 16.0;
    static double DISPERSION_PRIOR_WEIGHT = 20.0;
    static double VENUE_WEIGHT = 1.0;      // сила поправки на домашнее преимущество в счётных рынках
    static double CONC_WEIGHT = 0.5;       // вес пропущенных соперниками значений при расчёте ожидания

    // ---------- базовые функции ----------
    static double mean(double[] v) { double s = 0; for (double x : v) s += x; return s / v.length; }

    static double sampleVariance(double[] v) {
        if (v.length < 2) return Double.NaN;
        double m = mean(v), s = 0;
        for (double x : v) { double d = x - m; s += d * d; }
        return s / (v.length - 1);
    }

    static double shrunkMean(double[] v, double prior, double k) {
        double s = 0; for (double x : v) s += x;
        return (s + k * prior) / (v.length + k);
    }

    private static double logFactorial(int n) { double r = 0; for (int i = 2; i <= n; i++) r += Math.log(i); return r; }

    static double poisson(int k, double lambda) {
        return Math.exp(-lambda + k * Math.log(lambda) - logFactorial(k));
    }

    private static double clamp(double v, double lo, double hi) { return Math.max(lo, Math.min(hi, v)); }
    private static String pct(double v) { return String.format(Locale.US, "%.0f%%", clamp(v, 0, 1) * 100); }
    private static String f1(double v) { return String.format(Locale.US, "%.1f", v); }
    private static String f2(double v) { return String.format(Locale.US, "%.2f", v); }

    static String confidence(int n) { return n >= 8 ? "высокая" : n >= 5 ? "средняя" : "низкая"; }

    // ---------- голы ----------
    /** Возвращает {ожидаемые голы хозяев, ожидаемые голы гостей}. gf/ga — суммы за n матчей. */
    static double[] expectedGoals(double gfH, double gaH, int nH, double gfA, double gaA, int nA,
                                  double leagueHome, double leagueAway) {
        double avgTeam = (leagueHome + leagueAway) / 2.0, k = GOALS_PRIOR_MATCHES;
        double attH = ((gfH + k * avgTeam) / (nH + k)) / avgTeam;
        double defH = ((gaH + k * avgTeam) / (nH + k)) / avgTeam;
        double attA = ((gfA + k * avgTeam) / (nA + k)) / avgTeam;
        double defA = ((gaA + k * avgTeam) / (nA + k)) / avgTeam;
        double lh = leagueHome * attH * defA;
        double la = leagueAway * attA * defH;
        return new double[]{clamp(lh, 0.15, 4.5), clamp(la, 0.15, 4.5)};
    }

    /**
     * Расклад сил относительно "обычного" матча каждой команды.
     * Среднее по последним матчам команды уже отражает её силу против обычных соперников, поэтому поправка зависит только от того,
     * насколько ЭТОТ соперник отличается от среднего: ln(слабость обороны соперника / сила его атаки).
     * > 0 : соперник слабее обычного (команда будет доминировать), < 0 : сильнее обычного.
     * Возвращает {для хозяев, для гостей}.
     */
    static double[] matchupLogRatios(double gfH, double gaH, int nH, double gfA, double gaA, int nA,
                                     double leagueHome, double leagueAway) {
        double avgTeam = (leagueHome + leagueAway) / 2.0, k = GOALS_PRIOR_MATCHES;
        double attH = ((gfH + k * avgTeam) / (nH + k)) / avgTeam;
        double defH = ((gaH + k * avgTeam) / (nH + k)) / avgTeam;
        double attA = ((gfA + k * avgTeam) / (nA + k)) / avgTeam;
        double defA = ((gaA + k * avgTeam) / (nA + k)) / avgTeam;
        return new double[]{clamp(Math.log(defA / attA), -1.0, 1.0), clamp(Math.log(defH / attH), -1.0, 1.0)};
    }

    private static double tau(int i, int j, double lh, double la) {
        if (i == 0 && j == 0) return 1.0 - lh * la * DC_RHO;
        if (i == 0 && j == 1) return 1.0 + lh * DC_RHO;
        if (i == 1 && j == 0) return 1.0 + la * DC_RHO;
        if (i == 1 && j == 1) return 1.0 - DC_RHO;
        return 1.0;
    }

    static double[][] scoreGrid(double lh, double la) {
        double[][] g = new double[MAX_GOALS + 1][MAX_GOALS + 1];
        double sum = 0;
        for (int i = 0; i <= MAX_GOALS; i++) for (int j = 0; j <= MAX_GOALS; j++) {
            double p = poisson(i, lh) * poisson(j, la) * tau(i, j, lh, la);
            g[i][j] = p; sum += p;
        }
        for (int i = 0; i <= MAX_GOALS; i++) for (int j = 0; j <= MAX_GOALS; j++) g[i][j] /= sum;
        return g;
    }

    static String goalsBlock(String home, String away, double lh, double la, int minSample) {
        return goalsBlock(home, away, lh, la, minSample, null);
    }

    /** sink (может быть null) получает СЫРЫЕ вероятности модели для последующей проверки по фактическим результатам. */
    static String goalsBlock(String home, String away, double lh, double la, int minSample, java.util.Map<String, Double> sink) {
        double[][] g = scoreGrid(lh, la);
        double pH = 0, pD = 0, pA = 0, btts = 0;
        double[] totalOver = new double[3];   // P(сумма >= 2), >=3, >=4  -> линии 1.5 / 2.5 / 3.5
        for (int i = 0; i <= MAX_GOALS; i++) for (int j = 0; j <= MAX_GOALS; j++) {
            double p = g[i][j];
            if (i > j) pH += p; else if (i == j) pD += p; else pA += p;
            if (i >= 1 && j >= 1) btts += p;
            for (int t = 0; t < 3; t++) if (i + j >= t + 2) totalOver[t] += p;
        }
        // три самых вероятных счёта
        int[][] best = new int[3][2]; double[] bestP = new double[3];
        for (int i = 0; i <= MAX_GOALS; i++) for (int j = 0; j <= MAX_GOALS; j++) {
            double p = g[i][j];
            for (int r = 0; r < 3; r++) if (p > bestP[r]) {
                for (int s = 2; s > r; s--) { bestP[s] = bestP[s - 1]; best[s][0] = best[s - 1][0]; best[s][1] = best[s - 1][1]; }
                bestP[r] = p; best[r][0] = i; best[r][1] = j; break;
            }
        }
        if (sink != null) {
            sink.put("exp_goals", lh + la);
            sink.put("res_home", pH); sink.put("res_draw", pD); sink.put("res_away", pA); sink.put("btts", btts);
            double[] ln = {1.5, 2.5, 3.5};
            for (int t = 0; t < 3; t++) sink.put("goals_o" + f1(ln[t]), totalOver[t]);
        }
        StringBuilder b = new StringBuilder();
        b.append("⚽ ГОЛЫ · ожидаемый счёт: ").append(home).append(" ").append(f2(lh)).append(" : ").append(f2(la)).append(" ").append(away)
         .append(" · уверенность: ").append(confidence(minSample)).append("\n");
        b.append("   1X2: ").append(home).append(" ").append(pct(pH)).append(" · ничья ").append(pct(pD)).append(" · ").append(away).append(" ").append(pct(pA)).append("\n");
        double[] lines = {1.5, 2.5, 3.5};
        for (int t = 0; t < 3; t++)
            b.append("   Тотал голов ").append(f1(lines[t])).append(": 🔼 Больше ").append(pct(adj("goals", totalOver[t]))).append(" · 🔽 Меньше ").append(pct(1 - adj("goals", totalOver[t]))).append("\n");
        b.append("   Обе забьют: Да ").append(pct(adj("btts", btts))).append(" · Нет ").append(pct(1 - adj("btts", btts))).append("\n");
        b.append("   Вероятные счета: ");
        for (int r = 0; r < 3; r++) b.append(r > 0 ? ", " : "").append(best[r][0]).append(":").append(best[r][1]).append(" (").append(pct(bestP[r])).append(")");
        b.append("\n");
        return b.toString();
    }

    // ---------- счётные рынки ----------
    /** P(X >= line+1) для целого N=line (линия N.5). Отрицательное биномиальное при разбросе > среднего, иначе Пуассон. */
    static double overProbability(int line, double mean, double variance) {
        double cdf;
        if (variance > mean + 0.05) {
            double r = mean * mean / (variance - mean), p = r / (r + mean);
            double term = Math.pow(p, r);
            cdf = term;
            for (int k = 1; k <= line; k++) { term *= ((k - 1 + r) / k) * (1.0 - p); cdf += term; }
        } else {
            double term = Math.exp(-mean);
            cdf = term;
            for (int k = 1; k <= line; k++) { term *= mean / k; cdf += term; }
        }
        return clamp(1.0 - cdf, 0.0, 1.0);
    }

    /**
     * @param hOwn  значения команды-хозяев по матчам (за матч), aOwn - гостей
     * @param hConc что пропускают хозяева (может быть null), aConc - гости (может быть null)
     * @param prior среднее по лиге на одну команду за матч; phiPrior - типичное отношение дисперсии к среднему
     */
    static String countBlock(String title, double[] hOwn, double[] aOwn, double[] hConc, double[] aConc,
                             double prior, double phiPrior, double[] matchup, double elasticity) {
        return countBlock(title, hOwn, aOwn, hConc, aConc, prior, phiPrior, matchup, elasticity, null, null);
    }

    static String countBlock(String title, double[] hOwn, double[] aOwn, double[] hConc, double[] aConc,
                             double prior, double phiPrior, double[] matchup, double elasticity,
                             String key, java.util.Map<String, Double> sink) {
        return countBlock(title, hOwn, aOwn, hConc, aConc, prior, phiPrior, matchup, elasticity, key, sink, null, null);
    }

    /** С названиями команд дополнительно выводит индивидуальные тоталы каждой команды (с поправкой на расклад сил). */
    static String countBlock(String title, double[] hOwn, double[] aOwn, double[] hConc, double[] aConc,
                             double prior, double phiPrior, double[] matchup, double elasticity,
                             String key, java.util.Map<String, Double> sink, String homeName, String awayName) {
        return countBlock(title, hOwn, aOwn, hConc, aConc, prior, phiPrior, matchup, elasticity, key, sink, homeName, awayName, null);
    }

    /** venue = {коэффициент хозяев, коэффициент гостей} — домашнее преимущество по средним лиги (null — без поправки). */
    static String countBlock(String title, double[] hOwn, double[] aOwn, double[] hConc, double[] aConc,
                             double prior, double phiPrior, double[] matchup, double elasticity,
                             String key, java.util.Map<String, Double> sink, String homeName, String awayName, double[] venue) {
        int nh = hOwn == null ? 0 : hOwn.length, na = aOwn == null ? 0 : aOwn.length;
        if (nh < 3 || na < 3)
            return "   " + title + ": недостаточно данных (" + nh + "/" + na + "; нужно минимум 3 матча со статистикой у каждой команды)\n";
        double k = COUNT_PRIOR_MATCHES;
        double ownH = shrunkMean(hOwn, prior, k), ownA = shrunkMean(aOwn, prior, k);
        double rateH = ownH, rateA = ownA;
        if (aConc != null && aConc.length >= 3) rateH = (1.0 - CONC_WEIGHT) * ownH + CONC_WEIGHT * shrunkMean(aConc, prior, k);
        if (hConc != null && hConc.length >= 3) rateA = (1.0 - CONC_WEIGHT) * ownA + CONC_WEIGHT * shrunkMean(hConc, prior, k);
        if (venue != null && venue.length == 2 && VENUE_WEIGHT != 0) {
            rateH *= Math.pow(venue[0], VENUE_WEIGHT); rateA *= Math.pow(venue[1], VENUE_WEIGHT);
        }
        // Поправка на расклад сил: elasticity > 0 для "атакующих" показателей (удары, угловые), < 0 для фолов и карточек
        double multH = 1.0, multA = 1.0;
        if (matchup != null && matchup.length == 2) {
            multH = clamp(Math.exp(elasticity * matchup[0]), 0.7, 1.4);
            multA = clamp(Math.exp(elasticity * matchup[1]), 0.7, 1.4);
            rateH *= multH; rateA *= multA;
        }
        double expected = rateH + rateA;
        if (!(expected > 0) || Double.isInfinite(expected)) return "   " + title + ": некорректные данные, прогноз отключён\n";

        double vh = sampleVariance(hOwn), va = sampleVariance(aOwn);
        double phiSample = (Double.isNaN(vh) || Double.isNaN(va)) ? phiPrior : (vh + va) / (mean(hOwn) + mean(aOwn));
        if (Double.isNaN(phiSample) || Double.isInfinite(phiSample)) phiSample = phiPrior;
        double nTot = nh + na;
        double phi = clamp((nTot * phiSample + DISPERSION_PRIOR_WEIGHT * phiPrior) / (nTot + DISPERSION_PRIOR_WEIGHT), 1.0, 2.2);
        double variance = expected * phi;
        if (sink != null && key != null) { sink.put("exp_" + key, expected); sink.put("exp_" + key + "_h", rateH); sink.put("exp_" + key + "_a", rateA); }

        int nearest = (int) Math.floor(expected);   // ближайшая к ожиданию линия = nearest + 0.5
        StringBuilder b = new StringBuilder();
        b.append("   ").append(title).append(" · ожидание ").append(f1(expected)).append(" (").append(f1(rateH)).append(" + ").append(f1(rateA))
         .append(") · уверенность: ").append(confidence(Math.min(nh, na))).append(" (").append(nh).append("+").append(na).append(" матчей)\n");
        if (Math.abs(multH - 1.0) >= 0.02 || Math.abs(multA - 1.0) >= 0.02)
            b.append("      Поправка на расклад сил: хозяева ×").append(f2(multH)).append(" · гости ×").append(f2(multA)).append("\n");
        int start = Math.max(Math.max(nearest - 1, 0), minLineN(key));   // линии ниже обычных у букмекеров не показываем
        for (int n = start; n <= start + 2; n++) {
            double over = overProbability(n, expected, variance);
            if (sink != null && key != null) sink.put(key + "_o" + n + ".5", over);
            double shown = key == null ? over : adj(key, over);
            b.append("      ").append(n).append(".5: 🔼 Больше ").append(pct(shown)).append(" · 🔽 Меньше ").append(pct(1 - shown)).append("\n");
        }
        if (homeName != null && awayName != null && key != null) {
            b.append(teamLines("🏠 ", homeName, rateH, variance / expected, key, "_h", sink));
            b.append(teamLines("✈️ ", awayName, rateA, variance / expected, key, "_a", sink));
        }
        return b.toString();
    }
}
